from pathlib import Path
import subprocess, hashlib, json, shutil, difflib, tarfile, csv, statistics

root=Path('/Users/liu/workspace/ccv')
p=Path('/private/tmp/ccv-fused-cast-integration')
out=root/'doc/benchmarks/m5-ultra-na-2026-10-02'
prefix='inference-fused-cast-integration'
validation=json.loads((p/'validation.json').read_text())
assert len(validation)==4 and all(x['exit']==0 for x in validation)
summary=json.loads((p/'summary.json').read_text())
manifest=json.loads((p/'manifest.json').read_text())
records=[]
for kind in ('operator','graph'):
    rows=list(csv.DictReader((p/(kind+'.csv')).open()))
    assert all(int(x['exit'])==0 for x in rows)
    records+=rows
assert len(records)==summary['records']==272
pairs=0
for kind,cases,kinds in [('operator',manifest['cases'],['int8']),('graph',manifest['graph_cases'],['int8','fp16'])]:
    for case in cases:
        for order in range(2):
            for precision in kinds:
                rows=[x for x in records if x['kind']==kind and x['case']==case['id'] and int(x['order'])==order and x['variant'].startswith(precision)]
                assert len(rows)==2
                assert len({(x['output_sha256'],x['arena_bytes']) for x in rows})==1
                pairs+=1
assert pairs==100
for test,count in [('mpsblas-full',301),('mpsdnn-full',126),('cnnp-core-full',61)]:
    log=(p/(test+'.log')).read_text(errors='replace')
    assert 'all test case(s) passed, congratulations!' in log
    assert f'[{count}/{count}] [PASS]' in log

paths=[x.relative_to(p/'before') for x in (p/'before').rglob('*') if x.is_file()]
changed=[];patch=[]
for rel in sorted(paths):
    before=(p/'before'/rel).read_text();after=(root/rel).read_text()
    target=p/'current'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(after)
    changed.append(dict(path=str(rel),before_sha256=hashlib.sha256(before.encode()).hexdigest(),current_sha256=hashlib.sha256(after.encode()).hexdigest()))
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+str(rel),tofile='current/'+str(rel)))
(p/'integration.patch').write_text(''.join(patch))
revisions={name:subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip() for name,path in [('ccv',root),('mlx',Path('/Users/liu/workspace/mlx')),('draw-things',Path('/Users/liu/workspace/draw-things'))]}
binaries={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [p/'frontend',p/'operator',Path('/private/tmp/ccv-projection-cast/mlx'),root/'lib/libccv.a',root/'test/int/nnc/mpsblas.tests',root/'test/int/nnc/mpsdnn.tests',root/'test/unit/nnc/cnnp.core.tests']}
provenance=dict(revisions=revisions,changed=changed,binaries=binaries,
    machine='Apple M5 Ultra, 80 GPU cores, 256 GB, macOS 27.0.1',
    mlx_note='Actual local MLX binary from the preceding projection-cast checkpoint; documented D256 SDPA JIT signature correction only. MLX matmul unchanged.',
    records=len(records),full_output_pairs=pairs,validation=validation)
(p/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=root,check=True)

lines=['Inference INT8 GEMM / Float32-store fusion integration, 2026-10-03','',
'Retained: the previous fused-store prototype now runs through the production',
'MPS GEMM frontend and compiled CNNP inference graphs. The original half rounding',
'is preserved, and graph arena allocation does not grow. This is an inference',
'improvement beyond tile tuning; the broader approximately-2x target remains open.',
'',
'Implementation and reasoning',
'- Explicit castOutputToFloat is included in both the kernel-source and pipeline',
'  cache descriptors. INT8 output still rounds into a half fragment before its',
'  Float32 store. Dimensions and dispatch geometry remain runtime-derived.',
'- The new try-encode entry point uses the existing register INT8 selector. It',
'  returns without encoding when unsupported. No new chip-name, per-model, or',
'  shape tuning gate is added. Normal GEMM selection is unchanged.',
'- The compiled no-gradient graph recognizes a sole-use GEMM -> Float32 cast.',
'  It keeps the original symbolic graph, half allocation, edges and cast node.',
'  A guarded composite executes the widened store when supported; otherwise it',
'  executes the original half GEMM followed by the cast. The cast node is a NOOP.',
'- Compiled dependency checks require GEMM to have only the cast successor and',
'  the cast to have only GEMM as predecessor. Exposed half outputs, half aliases,',
'  extra consumers, IO flags, control flow, parallel copies and multiviews are',
'  excluded. Absent tensor symbols are skipped. Graph reinitialization restores',
'  the original pair before rebinding and then reapplies the guarded composite.',
'- Heap ranges and offsets are checked against weights and bias. Activation',
'  overlap is allowed only for a private sole-read intermediate, including a',
'  contiguous reshape. This INT8 path quantizes the entire activation into',
'  separate scratch before writing the result. FP16, chunked quantization and',
'  Hadamard paths use the original pair. Caller-owned/exposed activations do not',
'  receive the early-overwrite allowance. The original half allocation remains.',
'- Switching to a gradient graph retains the original commands. Returning to',
'  no-gradient evaluation can reuse that training graph and stays unfused, as',
'  required by the existing model lifecycle. No backward optimization is added.',
'',
'A fallback regression also exposed an existing decoded-weight offset bug:',
'MPSGraph described a decoded scratch operand using its packed source offset.',
'The fallback now uses matching decoded buffer, offset and dtype metadata for',
'the cache key, placeholder and runtime tensor. A nonzero-offset randomized',
'packed-weight case matches the independent CPU GEMM reference.',
'',
'Source applicability',
'Draw Things MiniMaxH3.swift:230-238 reshapes attention output to [1,S,7168],',
'applies a no-bias output Dense, and immediately converts to Float32.',
'MiniMaxH3.swift:284-294 does the same conversion after the no-bias FFN-down',
'projection. These exact dimensions, no-bias setting and private activation',
'reshape are represented here. The surrounding scalar operations are synthetic',
'producers/consumers, not complete attention or FFN blocks. No attention transpose',
'is implemented. The 480p/10s and 720p/10s UI scenarios use S31018 and S70186.',
'FLUX.2 has the cast adjacency with scaleFactor configured (Flux2.swift:151-164).',
'Other image graph cases are shape controls, not claims of adjacency or complete',
'model timing. 768px/2048px image grids use M2304/M16384; Krea/Ideogram include',
'a stated 256-text-token scenario, giving M2560/M16640. Local Code-specific',
'non-image workloads retain prior coverage and are not remeasured here.',
'',
'Operator comparison against actual MLX',
'Median of two reversed-order GPU medians, milliseconds. Each side includes the',
'GEMM and following Float32 conversion (or half-rounded fused store). MLX uses',
'FP16 matmul then astype(float32). INT8 includes activation quantization; weights',
'are prepared offline. No bias. This compares different arithmetic precisions.',
'Case                                 M      N      K | CCV FP16 INT8 before after | MLX FP16 | MLX/INT8',]
for c in summary['cases']:
    if c['kind']!='operator':continue
    v=c['medians']
    lines.append(f"{c['id']:<34} {c['shape'][0]:6} {c['shape'][1]:6} {c['shape'][2]:6} | {v['fp16']:8.4f} {v['int8-separate']:8.4f} {v['int8-fused']:8.4f} | {v['mlx']:8.4f} | {v['mlx']/v['int8-fused']:.3f}x")
lines+=['',
'The newly covered 768px FP16 FFN-down rows expose remaining gaps: FLUX.2 is',
'about 43% slower than actual MLX, Ideogram about 18%, and Qwen about 6.5%.',
'Both orders show the FLUX/Ideogram gaps. These paths are unchanged by this',
'integration. H3 FP16 remains within about 1.1% of MLX in this sweep. Earlier',
'FP16 parity statements applied to the earlier listed shapes, not all 768px',
'projections. The FP16 register selector still starts at M4096, excluding these',
'medium-row cases. The next experiment should compare existing register split',
'and unsplit paths below that bound with neighboring shapes before changing it.',
'',
'Compiled CNNP graph confirmation',
'Actual model evaluation includes scalar producer, optional contiguous reshape,',
'GEMM, Float32 conversion, and scalar consumer. GPU time sums every submitted',
'command buffer; the default queue policy is unchanged. The selected INT8 path',
'uses three buffers instead of four. FP16 and small-row fallback retain four.',
'Both precisions preserve complete output hashes. Arena sizes are identical',
'before/after; arena accounting excludes bound external tensors and MFA scratch.',
'Do not compare these graph timings directly with the MLX operator table.',
'Case                               FP16 pair composite | INT8 pair fused | INT8 saved | Arena MiB']
for c in summary['cases']:
    if c['kind']!='graph':continue
    v=c['medians']
    lines.append(f"{c['id']:<34} {v['fp16-separate']:8.4f} {v['fp16-composite']:8.4f} | {v['int8-separate']:8.4f} {v['int8-fused']:8.4f} | {100*(1-v['int8-fused']/v['int8-separate']):7.2f}% | {c['arena_bytes']/2**20:9.3f}")
lines+=['','Validation and limits',
'- 18 operator shapes x 4 variants x 2 orders = 144 records, including actual MLX.',
'- 16 compiled graph shapes x 4 variants x 2 orders = 128 records.',
'- All 272 processes succeed. All 100 same-precision full-output pairs are',
'  bit-identical; graph arena allocations match in every pair. Output scans',
'  are finite. Operator probes include sampled CPU-reference checks and exact',
'  half representability; graph probes use separately randomized input data.',
'- Three warm iterations, at least .5 GPU seconds warmup, seven samples, two',
'  reversed orders. All CPU compilation precedes serial GPU jobs. Raw orders',
'  and timing variation are retained. Wall times and GPU spans are in graph.csv.',
'- Three new regression cases cover full output equality, biased/unbiased',
'  execution, nonzero offsets, same/partial buffer overlap, packed Q5_K decode,',
'  rowwise-X, Hadamard fallback, disabled MFA, cache separation, model shrinking',
'  and growth, output rebinding, private reshapes, exposed half tensors, multiple',
'  consumers and inference/training transitions. They pass in the full suite.',
'- Final rebuilt MPSBLAS 301/301, MPSDNN 126/126 and CNNP core 61/61 pass.',
'- The earlier interrupted',
'  MPSBLAS run was stopped for the absent-symbol guard; it is not counted.',]
for v in validation:lines.append(f"  {v['name']}: exit {v['exit']}, {v['seconds']:.2f} seconds")
lines+=['- git diff --check passes. Nothing is staged or committed. Before/current',
'  source snapshots, exact commands, binary hashes and test logs are archived.',
'',
'This checkpoint validates the production integration, not full model generation',
'latency or rendered quality. FP16 uses its existing kernel and separate cast;',
'the FP16 composite is a fallback control. Small projections and several image',
'attention cases still miss approximately 2x. Latest attention measurements are',
'in inference-probability-bounds.txt; actual MLX VJP comparisons remain in the',
'earlier priority-report.txt. Inference remains the current priority.', '']
(out/(prefix+'.txt')).write_text('\n'.join(lines))
for name in ['operator.csv','graph.csv','summary.json','manifest.json','provenance.json','validation.json','frontend.m','operator.cpp','mlx.cpp','sweep.py','build-probes.py','validate.py','publish.py','integration.patch']:
    shutil.copy2(p/name,out/(prefix+'-'+name))
files=[x for x in p.rglob('*') if x.is_file() and x.name not in ['frontend','operator','archive-index.json'] and '__pycache__' not in x.parts]
index={str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in files}
(p/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=out/(prefix+'-raw-logs.tar.gz')
with tarfile.open(archive,'w:gz') as t:
    for x in sorted(files)+[p/'archive-index.json']:t.add(x,arcname=str(x.relative_to(p)))
with tarfile.open(archive,'r:gz') as t:
    for name,digest in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==digest,name
print(json.dumps(dict(records=len(records),pairs=pairs,archive_entries=len(index)+1,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2))
