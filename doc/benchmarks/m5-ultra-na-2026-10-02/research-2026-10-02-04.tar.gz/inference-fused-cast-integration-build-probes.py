from pathlib import Path
import subprocess,json
root=Path('/Users/liu/workspace/ccv');p=Path('/private/tmp/ccv-fused-cast-integration');commands=[]
s=(p/'frontend.m').read_text().replace('if(M<4096||N<1536||K<4096)return 2;','if(M<=0||N<=0||K<=0)return 2;')
(p/'frontend.m').write_text(s)
s=Path('/private/tmp/ccv-gemm-fused-cast/probe.cpp').read_text()
s=s.replace('    if (attention) ccv_nnc_mfa_encode_attention','    bool cast_encoded = false;\n    if (attention) ccv_nnc_mfa_encode_attention',1)
s=s.replace('      if (fused_cast) tensors[2]=float_output.get();\n','')
s=s.replace('      } else if (quantized) ccv_nnc_mfa_encode_scaled_gemm(context,ip,batch,tensors,offsets);','''      } else if (quantized) {
        if (fused_cast) {
          tensors[2]=float_output.get();
          cast_encoded=ccv_nnc_mfa_encode_scaled_gemm_cast(context,ip,batch,tensors,offsets);
          tensors[2]=buffers[2].get();
        }
        if (!cast_encoded) ccv_nnc_mfa_encode_scaled_gemm(context,ip,batch,tensors,offsets);
      }''',1)
s=s.replace('if (output_cast && !fused_cast)', 'if (output_cast && !cast_encoded)',1)
s=s.replace('    if (output_cast && !cast_encoded)', '    if (i==0) printf("cast_fused=%d\\n",int(cast_encoded));\n    if (output_cast && !cast_encoded)', 1)
(p/'operator.cpp').write_text(s)
for name,compiler,suffix in [('frontend','clang','.m'),('operator','clang++','.cpp')]:
 args=[compiler]+(['-std=c++17'] if suffix=='.cpp' else [])+['-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0',str(p/(name+suffix)),'lib/libccv.a']
 for fw in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',fw]
 args+=['-lsqlite3','-lz','-lc++','-o',str(p/name)];commands.append({'args':args,'cwd':str(root)});subprocess.run(args,cwd=root,check=True)
(p/'build-probes.json').write_text(json.dumps(commands,indent=2)+'\n')
