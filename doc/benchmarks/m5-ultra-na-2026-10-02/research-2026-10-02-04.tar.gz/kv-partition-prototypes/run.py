from pathlib import Path
import subprocess,os,csv,re
out=Path('/private/tmp/ccv-int8-kv-partitions')
with (out/'pilot.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['R','D','H','variant','parts','median_ms','cpu_l2','exit_code'])
 for R,D,H in [(4352,256,18),(14878,128,56),(31018,128,56),(70186,128,56)]:
  for name,parts,exe in [('current',1,'/private/tmp/ccv-fp16-expanded-final-probe')]+[('partition',p,str(out/'probe')) for p in [1,2,4,8]]+[('mlx',1,'/private/tmp/ccv-mlx-dsplit-fix/probe')]:
   cmd=[exe,'attention',str(R),str(R),str(D),'1',str(H),str(H),'3','7','0']
   if name!='mlx':cmd+=['1','0','0']
   r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_PARTITIONS':str(parts),'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
   (out/f'{R}-{D}-{name}-{parts}.log').write_text(r.stdout+r.stderr)
   med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
   row=[R,D,H,name,parts,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
   if r.returncode:raise SystemExit(r.returncode)
