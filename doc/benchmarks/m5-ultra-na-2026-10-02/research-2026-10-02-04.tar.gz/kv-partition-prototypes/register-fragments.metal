constant ushort query_range [[function_constant(40)]];
uint compact_bits(uint x) {
 x &= 0x55555555; x=(x|(x>>1))&0x33333333; x=(x|(x>>2))&0x0f0f0f0f;
 x=(x|(x>>4))&0x00ff00ff; return (x|(x>>8))&0x0000ffff;
}
uint log2ceil(uint x) { return x<=1 ? 0 : 32-clz(x-1); }
uint2 decode_tile(uint code,uint xb,uint yb) {
 uint paired=min(xb,yb), bits=paired*2, mask=(1u<<bits)-1;
 uint2 t=uint2(compact_bits(code&mask),compact_bits((code&mask)>>1));
 if(xb>yb)t.x|=(code>>bits)<<paired; else t.y|=(code>>bits)<<paired;
 return t;
}
kernel void int8_attention(
 const device int8_t* Q [[buffer(0)]], const device int8_t* K [[buffer(1)]],
 const device int8_t* V [[buffer(2)]], device half* O [[buffer(3)]],
 device half* L [[buffer(4)]], const device float* qs [[buffer(10)]],
 const device float* ks [[buffer(11)]], const device float* vs [[buffer(12)]],
 const device float* vm [[buffer(14)]], constant uint4& dims [[buffer(22)]],
 constant float& alpha [[buffer(23)]], uint group [[threadgroup_position_in_grid]],
 ushort sg [[simdgroup_index_in_threadgroup]]) {
 const uint R=dims.x,C=dims.y,Hq=dims.z,Hk=dims.w;
 const uint groups=query_range==2 ? 1 : query_range==1 ? R/64 : (R+63)/64;
 uint2 xy=decode_tile(group,log2ceil(groups),log2ceil(Hq));
 if(xy.x>=groups||xy.y>=Hq)return;
 const uint row=(xy.x+(query_range==2 ? R/64 : 0))*64+sg*16, h=xy.y;
 if(row>=R)return;
 const uint kh=h/(Hq/Hk), qt=(R+15)/16,kt=(C+63)/64;
 Q+=size_t(row)*Hq*128+h*128;
 K+=kh*128;V+=kh*128;O+=size_t(row)*Hq*128+h*128;vm+=kh*128;
 const float qscale=qs[h*qt+row/16]*alpha*1.442695041f;
 NAXTile<float,1,8> output;output.clear();
 float2 maxima(-INFINITY), sums(0);
 for(uint c=0;c<C;c+=64) {
  NAXTile<int,1,4> scores;scores.clear();
  #pragma clang loop unroll(full)
  for(short ik=0;ik<4;ik+=2) {
   #pragma clang loop unroll_count(4)
   for(short id=0;id<8;++id) {
    NAXTile<int8_t,1,1> q;NAXTile<int8_t,2,1> k;
    q.load_rows(Q+id*16,int(Hq*128),min(16u,R-row));
    k.load_rows(K+size_t(c+ik*16)*Hk*128+id*16,int(Hk*128),min(32,int(C)-int(c)-ik*16));
    BaseNAXFrag::mma(scores.frag_at(0,ik),scores.frag_at(0,ik+1),q.frag_at(0,0),metal::false_type{},k.frag_at(0,0),k.frag_at(1,0),metal::true_type{});
   }
  }
  thread NAXTile<float,1,4>& probability=reinterpret_cast<thread NAXTile<float,1,4>&>(scores);
  const float scale=qscale*ks[kh*kt+c/64];
  #pragma clang loop unroll(full)
  for(short ik=0;ik<4;++ik) for(short i=0;i<8;++i) {
   const short2 coord=BaseNAXFrag::get_coord(i);
   const int value=scores.frag_at(0,ik)[i];
   probability.frag_at(0,ik)[i]=(c+ik*16+coord.x<C) ? float(value)*scale : -INFINITY;
  }
  float2 next=maxima;
  probability.row_reduce<MaxOp>(next);
  probability.row_bin_op<SubOp>(next);
  #pragma clang loop unroll(full)
  for(short i=0;i<32;++i) probability.elems()[i]=fast::exp2(probability.elems()[i]);
  float2 factor;
  #pragma clang loop unroll(full)
  for(short i=0;i<2;++i) {factor[i]=fast::exp2(maxima[i]-next[i]);maxima[i]=next[i];sums[i]*=factor[i];}
  probability.row_reduce<SumOp>(sums);
  output.row_bin_op<MulOp>(factor);
  NAXTile<int8_t,1,4> p;
  #pragma clang loop unroll(full)
  for(short i=0;i<32;++i)p.elems()[i]=int8_t(clamp(rint(probability.elems()[i]*127.0f),0.0f,127.0f));
  const float vscale=vs[kh*kt+c/64]*(1.0f/127.0f);
  #pragma clang loop unroll(full)
  for(short id=0;id<8;id+=2) {
   NAXTile<int,1,2> partial;partial.clear();
   #pragma clang loop unroll(full)
   for(short ik=0;ik<4;++ik) {
    NAXTile<int8_t,1,2> v;
    v.load_rows(V+size_t(c+ik*16)*Hk*128+id*16,int(Hk*128),min(16,int(C)-int(c)-ik*16));
    BaseNAXFrag::mma(partial.frag_at(0,0),partial.frag_at(0,1),p.frag_at(0,ik),metal::false_type{},v.frag_at(0,0),v.frag_at(0,1),metal::false_type{});
   }
   #pragma clang loop unroll(full)
   for(short j=0;j<2;++j)for(short i=0;i<8;++i)output.frag_at(0,id+j)[i]+=float(partial.frag_at(0,j)[i])*vscale;
  }
  if((c/64)%2==1)threadgroup_barrier(mem_flags::mem_none);
 }
 float2 reciprocal=1.0f/sums;output.row_bin_op<MulOp>(reciprocal);
 #pragma clang loop unroll(full)
 for(short id=0;id<8;++id)for(short i=0;i<8;++i) {
  const short2 coord=BaseNAXFrag::get_coord(i);
  if(row+coord.y<R)O[size_t(coord.y)*Hq*128+id*16+coord.x]=half(output.frag_at(0,id)[i]+vm[id*16+coord.x]);
 }
 const short2 coord=BaseNAXFrag::get_coord();
 if(coord.x==0)for(short i=0;i<2;++i)if(row+coord.y+i*8<R)L[h*R+row+coord.y+i*8]=half(maxima[i]+fast::log2(sums[i]));
}
