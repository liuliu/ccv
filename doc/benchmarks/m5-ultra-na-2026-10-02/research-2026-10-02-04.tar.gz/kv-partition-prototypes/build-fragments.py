from pathlib import Path
import subprocess,shlex
root=Path(__file__).resolve().parents[4];out=Path('/private/tmp/ccv-int8-fragments');out.mkdir(exist_ok=True)
s=(root/'lib/nnc/mfa/kernels/NAInt8AttentionDescriptor.cpp').read_text()
a=s.index('    auto function = NS::TransferPtr(kernel->library->newFunction')
s=s[:a]+'''    auto* library=kernel->library.get();
    static NS::SharedPtr<MTL::Library> registerLibrary;
    if (std::string(functionNameString) == "int8_attention") {
      if (!registerLibrary) {
        std::string source =
#include "../3rdparty/mlx/attention.metal.inc"
        ;
        source += R"FRAGMENT('''+Path(__file__).with_name('register-fragments.metal').read_text()+''')FRAGMENT";
        registerLibrary=NS::TransferPtr(device->newLibrary(NS::String::string(source.c_str(), NS::UTF8StringEncoding),nullptr,&error));
        CCV_NNC_MFA_CHECK_ERROR(error);
      }
      library=registerLibrary.get();
    }
'''+s[a:]
s=s.replace('kernel->library->newFunction(functionName, constants, &error)','library->newFunction(functionName, constants, &error)')
(out/'NAInt8AttentionDescriptor.cpp').write_text(s)
s=(root/'lib/nnc/mfa/ccv_nnc_mfa_attention.cpp').read_text()
a=s.index('      const bool splitQueryRanges = attentionDesc.splitQueryRanges();');b=s.index('      return;',a)
f=s[a:b];f=f.replace('        encoder->setComputePipelineState(range == 2 ? pipelineValue->sixth.get() : pipeline.get());','''        CCV_NNC_MFA_PRECONDITION(hash.D==128 && hash.Hq % hash.Hk == 0 && batchDimension==1 && !hash.is_causal && !hash.masked && !hash.is_varlen && !hash.attention_sinks && !hash.upcast);
        encoder->setComputePipelineState(range == 2 ? pipelineValue->sixth.get() : pipeline.get());
        const uint32_t arguments[4]={hash.R,hash.C,hash.Hq,hash.Hk};
        encoder->setBytes(arguments,sizeof(arguments),22);
        encoder->setBytes(&hash.alpha,sizeof(hash.alpha),23);''')
s=s[:a]+f+s[b:];(out/'ccv_nnc_mfa_attention.cpp').write_text(s)
log=Path(__file__).with_name('build-link-commands.txt').read_text().splitlines()
lines=subprocess.check_output(['make','-n','-B','DEBUG=1','CC=clang++','lib'],cwd=root/'lib/nnc/mfa',text=True).splitlines()
for source,old,inc in [('NAInt8AttentionDescriptor.cpp','kernels/NAInt8AttentionDescriptor.cpp','lib/nnc/mfa/kernels'),('ccv_nnc_mfa_attention.cpp','ccv_nnc_mfa_attention.cpp','lib/nnc/mfa')]:
 line=next(l for l in lines if l.startswith('clang++ '+old+' ') and ' -c ' in l);args=shlex.split(line);args[1]=str(out/source);args[args.index('-o')+1]=str(out/source.replace('.cpp','.o'));args+=['-I'+str(root/inc)];subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
for wd,target,replacements,dst in [('lib/nnc/mfa','libnnc-compat-mfa.o',{'kernels/NAInt8AttentionDescriptor.o':out/'NAInt8AttentionDescriptor.o','ccv_nnc_mfa_attention.o':out/'ccv_nnc_mfa_attention.o'},out/'mfa.o'),('lib/nnc','libnnc.o',{'mfa/libnnc-compat-mfa.o':out/'mfa.o'},out/'nnc.o')]:
 line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o '+target));args=shlex.split(line);args=[str(replacements.get(x,x)) for x in args];args[-1]=str(dst);subprocess.run(args,cwd=root/wd,check=True)
line=next(l for l in log if l.startswith('ar rcs libccv.a '));args=shlex.split(line);args[2]=str(out/'libccv.a');args=[str(out/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];subprocess.run(args,cwd=root/'lib',check=True)
args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0','bin/mfa/na_application_bench.cpp',str(out/'libccv.a')]
for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
args+=['-lsqlite3','-lz','-o',str(out/'probe')];subprocess.run(args,cwd=root,check=True)
