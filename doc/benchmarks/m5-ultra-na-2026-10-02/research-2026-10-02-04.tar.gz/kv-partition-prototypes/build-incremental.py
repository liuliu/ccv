from pathlib import Path
import subprocess,shlex
root=Path(__file__).resolve().parents[4];out=Path('/private/tmp/ccv-int8-kv-incremental');out.mkdir(exist_ok=True)
s=(root/'lib/nnc/mfa/kernels/NAInt8AttentionKernel.cpp').read_text()
# This isolated prototype only implements unmasked/noncausal B1 inference.
a=s.index('  case AttentionKernelType::forward:\n    source.SetValue("MAIN_KERNEL_NAME"');b=s.index('  case AttentionKernelType::backwardQuery:',a);f=s[a:b]
f=f.replace('    uint3 tgid [[threadgroup_position_in_grid]]', '    uint3 tgid [[threadgroup_position_in_grid]],\n    constant uint2& kv_range [[buffer(22)]]')
s=s[:a]+f+s[b:]
s=s.replace('device {{L_MEMORY_NAME}} *L_buf [[buffer(4)]],','device float *L_buf [[buffer(4)]],',1)
a=s.index('void NAInt8AttentionKernel::loopForward');f=s[a:]
f=f.replace('for (uint c = 0; c < {{C_LENGTH}} && {{C_LENGTH}} >= {{BLOCK_DIMENSIONS_TRAVERSAL}};', 'for (uint c = kv_range.x; c < min({{C_LENGTH}}, kv_range.y) && {{C_LENGTH}} >= {{BLOCK_DIMENSIONS_TRAVERSAL}};')
f=f.replace('for (uint c = 0; c < {{C_EDGE}};', 'for (uint c = kv_range.x; c < min({{C_EDGE}}, kv_range.y);')
f=f.replace('if (c == 0)', 'if (c == kv_range.x)')
s=s[:a]+f
(out/'NAInt8AttentionKernel.cpp').write_text(s)
s=(root/'lib/nnc/mfa/ccv_nnc_mfa_attention.cpp').read_text()
a=s.index('      const bool needsScratchL = !tensors[5];');b=s.index('      return;',a)
f=s[a:b]
f=f.replace('      const bool needsScratchL = !tensors[5];', '''      CCV_NNC_MFA_PRECONDITION(batchDimension == 1 && !hash.is_causal && !hash.masked && !hash.is_varlen && !hash.attention_sinks && !hash.upcast && hash.C >= 2048 && hash.D % 32 == 0 && !tensors[5]);
      const uint32_t partitions = getenv("CCV_NA_PARTITIONS") ? atoi(getenv("CCV_NA_PARTITIONS")) : 4;
      CCV_NNC_MFA_PRECONDITION(partitions >= 1 && partitions <= 16);
      const uint32_t partition_size = ((hash.C + partitions - 1) / partitions + kernel->blockDimensions[1] - 1) / kernel->blockDimensions[1] * kernel->blockDimensions[1];
      const size_t outputBytes = size_t(hash.R) * hash.Hq * hash.D * sizeof(uint16_t);
      const size_t partialLBytes = size_t(hash.R) * hash.Hq * sizeof(float);
      const size_t partialOOffset = reserve(&scratchSize, outputBytes * partitions);
      const size_t partialLOffset = reserve(&scratchSize, partialLBytes * partitions);
      const bool needsScratchL = !tensors[5];''')
f=f.replace('      const bool splitQueryRanges = attentionDesc.splitQueryRanges();', '''      const bool splitQueryRanges = attentionDesc.splitQueryRanges();
      for (uint32_t partition = 0; partition < partitions; ++partition) {
      const uint32_t kv_range[2] = {partition * partition_size, std::min(hash.C, (partition + 1) * partition_size)};''')
f=f.replace('encoder->setBuffer(tensors[3], tensor_offsets[3], 3);','encoder->setBuffer(scratch, partialOOffset + partition * outputBytes, 3);\n        encoder->setBytes(kv_range, sizeof(kv_range), 22);')
f=f.replace('encoder->setBuffer(lBuffer, lBufferOffset, 4);','encoder->setBuffer(scratch, partialLOffset + partition * partialLBytes, 4);')
f+='''      }
      static NS::SharedPtr<MTL::ComputePipelineState> mergePipeline;
      if (!mergePipeline) {
        const char* source = R"(
#include <metal_stdlib>
using namespace metal;
kernel void merge_partitions(const device half* partial [[buffer(0)]], const device float* stats [[buffer(1)]], device half* output [[buffer(2)]], constant uint4& p [[buffer(3)]], uint gid [[thread_position_in_grid]]) {
  const size_t count = size_t(p.x) * p.y * p.z;
  const size_t index = size_t(gid) * 4;
  if (index >= count) return;
  const uint r = index / (p.y * p.z), h = (index / p.z) % p.y;
  const uint lindex = h * p.x + r, lstride = p.x * p.y;
  float maximum = -INFINITY;
  for (uint s = 0; s < p.w; ++s) maximum = max(maximum, stats[size_t(s) * lstride + lindex]);
  float total = 0; float4 value = 0;
  for (uint s = 0; s < p.w; ++s) {
    const float weight = exp2(stats[size_t(s) * lstride + lindex] - maximum);
    value += weight * float4(*reinterpret_cast<const device half4*>(partial + size_t(s) * count + index));
    total += weight;
  }
  *reinterpret_cast<device half4*>(output + index) = half4(value / total);
}
)";
        NS::Error* error = nullptr;
        auto library = NS::TransferPtr(context->device->newLibrary(NS::String::string(source, NS::UTF8StringEncoding), nullptr, &error));
        CCV_NNC_MFA_CHECK_ERROR(error);
        auto function = NS::TransferPtr(library->newFunction(NS::String::string("merge_partitions", NS::UTF8StringEncoding)));
        mergePipeline = NS::TransferPtr(context->device->newComputePipelineState(function.get(), &error));
        CCV_NNC_MFA_CHECK_ERROR(error);
      }
      auto encoder = command_batch->startCommand();
      encoder->setComputePipelineState(mergePipeline.get());
      encoder->setBuffer(scratch, partialOOffset, 0);
      encoder->setBuffer(scratch, partialLOffset, 1);
      encoder->setBuffer(tensors[3], tensor_offsets[3], 2);
      const uint32_t mergeArgs[4] = {hash.R, hash.Hq, hash.D, partitions};
      encoder->setBytes(mergeArgs, sizeof(mergeArgs), 3);
      encoder->useResource(scratch, MTL::ResourceUsageRead);
      encoder->useResource(tensors[3], MTL::ResourceUsageWrite);
      encoder->dispatchThreads(MTL::Size(size_t(hash.R) * hash.Hq * hash.D / 4, 1, 1), MTL::Size(256, 1, 1));
      command_batch->finishCommand(encoder);
'''
s=s[:a]+f+s[b:];s='#include <cstdlib>\n'+s
(out/'ccv_nnc_mfa_attention.cpp').write_text(s)
# Incrementally merge each partial into the half output with FP32 LSE.
s=(out/'ccv_nnc_mfa_attention.cpp').read_text()
s=s.replace('partitions <= 16', 'partitions <= 64')
s=s.replace('const uint32_t partitions = getenv', 'const uint32_t requested_partitions = getenv')
s=s.replace('partitions >= 1 && partitions <= 64','requested_partitions >= 1 && requested_partitions <= 64')
s=s.replace('((hash.C + partitions - 1) / partitions + kernel->blockDimensions[1]', '((hash.C + requested_partitions - 1) / requested_partitions + kernel->blockDimensions[1]')
pos=s.index('      const size_t outputBytes')
s=s[:pos]+'      const uint32_t partitions = (hash.C + partition_size - 1) / partition_size;\n'+s[pos:]

s=s.replace('outputBytes * partitions','outputBytes').replace('partialLBytes * partitions','partialLBytes * 2')
s=s.replace('partialOOffset + partition * outputBytes','partialOOffset').replace('partialLOffset + partition * partialLBytes','partialLOffset')
a=s.index('      static NS::SharedPtr<MTL::ComputePipelineState> mergePipeline;');b=s.index('      auto encoder = command_batch->startCommand();',a)
setup=s[a:b]
a0=setup.index('kernel void merge_partitions(');b0=setup.index('\n)";',a0)
setup=setup[:a0]+r'''kernel void merge_partitions(const device half* partial [[buffer(0)]], device float* stats [[buffer(1)]], device half* output [[buffer(2)]], constant uint4& p [[buffer(3)]], uint gid [[thread_position_in_grid]]) {
  const size_t count = size_t(p.x) * p.y * p.z;
  const size_t index = size_t(gid) * 4;
  float combined = 0;
  uint lindex = 0;
  const size_t lstride = size_t(p.x) * p.y;
  if (index < count) {
    const uint r = index / (p.y * p.z), h = (index / p.z) % p.y;
    lindex = h * p.x + r;
    const float current = stats[lindex];
    half4 value = *reinterpret_cast<const device half4*>(partial + index);
    if (p.w == 0) combined = current;
    else {
      const float previous = stats[lstride + lindex];
      const float maximum = max(current, previous);
      const float wc = exp2(current - maximum), wp = exp2(previous - maximum);
      const float inverse = 1.0f / (wc + wp);
      const float4 old = float4(*reinterpret_cast<const device half4*>(output + index));
      value = half4((float4(value) * wc + old * wp) * inverse);
      combined = maximum + log2(wc + wp);
    }
    *reinterpret_cast<device half4*>(output + index) = value;
  }
  // Every row is wholly within one threadgroup (D=128 or 256).
  // Finish reading the previous LSE before its lane overwrites it.
  threadgroup_barrier(mem_flags::mem_device);
  if (index < count && index % p.z == 0) stats[lstride + lindex] = combined;
}
'''+setup[b0:]
end=s.index('      return;',b)
merge=s[b:end].replace('hash.D, partitions','hash.D, partition').replace('MTL::ResourceUsageRead);','MTL::ResourceUsageRead | MTL::ResourceUsageWrite);').replace('MTL::ResourceUsageWrite);','MTL::ResourceUsageRead | MTL::ResourceUsageWrite);')
s=s[:a]+s[end:]
# Put pipeline setup before the partition loop, and merge inside its end.
a=s.index('      for (uint32_t partition = 0;')
s=s[:a]+setup+s[a:]
a=s.index('      for (uint32_t partition = 0;');b=s.index('      return;',a)
piece=s[a:b]
assert piece.endswith('      }\n      }\n')
piece=piece[:-8]+merge+'      }\n'
s=s[:a]+piece+s[b:]
(out/'ccv_nnc_mfa_attention.cpp').write_text(s)

# Compile two replacements, preserving the current production objects elsewhere.
log=Path(__file__).with_name('build-link-commands.txt').read_text().splitlines()
compile_lines=subprocess.check_output(['make','-n','-B','DEBUG=1','CC=clang++','lib'],cwd=root/'lib/nnc/mfa',text=True).splitlines()
for source,old,inc in [('NAInt8AttentionKernel.cpp','kernels/NAInt8AttentionKernel.cpp','lib/nnc/mfa/kernels'),('ccv_nnc_mfa_attention.cpp','ccv_nnc_mfa_attention.cpp','lib/nnc/mfa')]:
 line=next(l for l in compile_lines if l.startswith('clang++ '+old+' ') and ' -c ' in l)
 args=shlex.split(line);args[1]=str(out/source);args[args.index('-o')+1]=str(out/source.replace('.cpp','.o'));args+=['-I'+str(root/inc)]
 subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o libnnc-compat-mfa.o'));args=shlex.split(line)
args=[str(out/'NAInt8AttentionKernel.o') if x=='kernels/NAInt8AttentionKernel.o' else str(out/'ccv_nnc_mfa_attention.o') if x=='ccv_nnc_mfa_attention.o' else x for x in args];args[-1]=str(out/'mfa.o');subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o libnnc.o'));args=shlex.split(line);args=[str(out/'mfa.o') if x=='mfa/libnnc-compat-mfa.o' else x for x in args];args[-1]=str(out/'nnc.o');subprocess.run(args,cwd=root/'lib/nnc',check=True)
line=next(l for l in log if l.startswith('ar rcs libccv.a '));args=shlex.split(line);args[2]=str(out/'libccv.a');args=[str(out/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];subprocess.run(args,cwd=root/'lib',check=True)
args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0','bin/mfa/na_application_bench.cpp',str(out/'libccv.a')]
for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
args+=['-lsqlite3','-lz','-o',str(out/'probe')];subprocess.run(args,cwd=root,check=True)
