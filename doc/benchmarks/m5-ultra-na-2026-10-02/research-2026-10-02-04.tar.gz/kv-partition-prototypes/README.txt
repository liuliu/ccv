These are isolated experimental source overrides, not production selection code.
Run from the CCV repository root with the production debug objects already built.
The build scripts locate this checkout relative to their own path and write their
objects, archive, and executable beneath /private/tmp. Run GPU jobs serially.

Build individual variants:
  python3 doc/benchmarks/m5-ultra-na-2026-10-02/kv-partition-prototypes/build-materialized.py
  python3 doc/benchmarks/m5-ultra-na-2026-10-02/kv-partition-prototypes/build-fused.py
  python3 doc/benchmarks/m5-ultra-na-2026-10-02/kv-partition-prototypes/build-incremental.py
  python3 doc/benchmarks/m5-ultra-na-2026-10-02/kv-partition-prototypes/build-bounded.py
  python3 doc/benchmarks/m5-ultra-na-2026-10-02/kv-partition-prototypes/build-fragments.py

The exact link command object lists are in build-link-commands.txt. These builders
assume the surrounding measured worktree; source hashes are recorded in
../inference-int8-kv-provenance.json. They are intentionally not generic upstream
MLX patches. The MLX attention source is already vendored in the CCV worktree.

Example bounded experiment:
  CCV_NA_PARTITIONS=8 CCV_NA_QUERY_CHUNK=4096 CCV_NA_WARMUP_SECONDS=.5 \
    /private/tmp/ccv-int8-kv-chunked/probe attention 70186 70186 128 1 56 56 3 7 0 1 0 0

The broad.py sweep uses frozen baseline/MLX executable paths from this session.
To reproduce in a fresh environment, build na_application_bench.cpp against the
production archive at its current baseline path, and build mlx_na_bench.cpp using
the parent report's MLX instructions and D256 JIT correction. Update executable
paths in the driver when appropriate. The paired historical results retain their
original binary hashes; rebuilt binaries should be reported as a new run.

The accuracy probe is deliberately independent of the periodic timing pattern.
Build it with build-accuracy*.py after the associated prototype archives exist.
CCV_ACCURACY_MODE selects the four distributions documented in the report.
Its zero exit code means successful execution and finite outputs, not an accuracy
threshold pass; inspect cpu_l2 and max_abs in the CSV. The initial fused prototype
contains a known empty-partition boundary bug and is retained as rejected evidence.
The materialized prototype has the same partition-count issue; use only covered
nonempty partitions when reproducing its timings. Corrected incremental/bounded
builders derive the actual count after rounding the KV partition size.
