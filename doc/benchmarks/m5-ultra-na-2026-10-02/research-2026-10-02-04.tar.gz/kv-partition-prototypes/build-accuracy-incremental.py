from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[4];out=Path('/private/tmp/ccv-int8-kv-partitions')
for name,lib in [('incremental',Path('/private/tmp/ccv-int8-kv-incremental/libccv.a'))]:
 args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0',str(Path(__file__).with_name('accuracy.cpp')),str(lib)]
 for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
 args+=['-lsqlite3','-lz','-o',str(out/('accuracy-'+name))];subprocess.run(args,cwd=root,check=True)
