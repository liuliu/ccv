from pathlib import Path
import subprocess,os,csv,re,json
out=Path('/private/tmp/ccv-int8-kv-partitions')
manifest=json.loads(Path('doc/benchmarks/m5-ultra-na-2026-10-02/priority-workloads.json').read_text())
cases=[(x['id'],x['shape']) for x in manifest['workloads'] if x['operation']=='attention' and any(s in x['id'] for s in ['1024','1536','2048']) and x['shape'][3]==1]
cases += [(f'h3-{r}',[r,r,128,1,56,56]) for r in [14878,29146,31018,67306,70186]]
cases += [(f'control-{r}-{c}-{d}-{h}',[r,c,d,1,h,h]) for r,c,d,h in [(4096,32768,128,8),(8192,16384,128,16),(16384,8192,128,16),(24576,24576,128,16),(12288,12288,256,18),(16384,16384,128,56)]]
(out/'broad-cases.json').write_text(json.dumps(cases,indent=2))
variants=[('current',1,131072,'/private/tmp/ccv-fp16-expanded-final-probe'),('partial4',4,131072,'/private/tmp/ccv-int8-kv-partitions/probe'),('bounded8',8,4096,'/private/tmp/ccv-int8-kv-chunked/probe'),('mlx',1,131072,'/private/tmp/ccv-mlx-dsplit-fix/probe')]
with (out/'broad.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','R','C','D','B','Hq','Hk','pass','variant','parts','qchunk','median_ms','cpu_l2','exit_code'])
 for order in range(2):
  for case,shape in (cases if order==0 else list(reversed(cases))):
   for name,parts,qchunk,exe in (variants if order==0 else list(reversed(variants))):
    cmd=[exe,'attention',*map(str,shape),'3','7','0']
    if name!='mlx':cmd+=['1','0','0']
    r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_PARTITIONS':str(parts),'CCV_NA_QUERY_CHUNK':str(qchunk),'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
    (out/f'broad-{order}-{case}-{name}.log').write_text(r.stdout+r.stderr)
    med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
    row=[case,*shape,order,name,parts,qchunk,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
