from pathlib import Path
import subprocess,os,csv,re
out=Path('/private/tmp/ccv-int8-kv-partitions')
with (out/'chunked.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['R','D','H','variant','parts','qchunk','median_ms','cpu_l2','exit_code'])
 for R,D,H in [(16640,256,18),(31018,128,56),(70186,128,56)]:
  variants=[('current',1,8192,'/private/tmp/ccv-fp16-expanded-final-probe')]+[('chunked',p,q,'/private/tmp/ccv-int8-kv-chunked/probe') for p,q in [(4,8192),(8,4096),(8,8192),(16,4096)]]+[('mlx',1,8192,'/private/tmp/ccv-mlx-dsplit-fix/probe')]
  for name,parts,qchunk,exe in variants:
   cmd=[exe,'attention',str(R),str(R),str(D),'1',str(H),str(H),'3','7','0']
   if name!='mlx':cmd+=['1','0','0']
   r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_PARTITIONS':str(parts),'CCV_NA_QUERY_CHUNK':str(qchunk),'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
   (out/f'chunked-{R}-{D}-{name}-{parts}-{qchunk}.log').write_text(r.stdout+r.stderr)
   med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
   row=[R,D,H,name,parts,qchunk,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
   if r.returncode:raise SystemExit(r.returncode)
