from pathlib import Path
import shutil,json,hashlib,tarfile,csv,statistics
root=Path('/Users/liu/workspace/ccv');src=Path('/private/tmp/ccv-int8-partition-production');dest=root/'doc/benchmarks/m5-ultra-na-2026-10-02';prefix='inference-partitioned-integration'
for p in src.iterdir():
 if p.suffix in ['.m','.cpp','.csv','.json'] and not p.name.startswith('s4nnc-'):shutil.copyfile(p,dest/(prefix+'-'+p.name))
for name in ['sweep.py','fp16-graph-sweep.py','validate.py','build-probes.py','archive.py']:
 shutil.copyfile(src/name,dest/(prefix+'-'+name))
files=[]
for p in [src/'probe',src/'frontend',src/'accuracy',root/'lib/libccv.a',root/'test/int/nnc/mpsblas.tests',root/'test/int/nnc/mpsdnn.tests',Path('/private/tmp/ccv-fp32-accumulator-current-probe'),Path('/private/tmp/ccv-mlx-dsplit-fix/probe')]:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 files.append({'path':str(p),'sha256':h.hexdigest(),'bytes':p.stat().st_size})
with tarfile.open(dest/(prefix+'-raw-logs.tar.gz'),'w:gz') as tar:
 for p in sorted(src.glob('*.log')):tar.add(p,arcname=p.name)
for input_name,key in [('sweep.csv','case'),('graph-paired.csv','case'),('fp16-graph.csv','case')]:
 if not (src/input_name).exists():continue
 rows=list(csv.DictReader((src/input_name).open()));groups={}
 for r in rows:
  if r['median_ms']:groups.setdefault(r[key],{}).setdefault(r['variant'],[]).append(float(r['median_ms']))
 result=[]
 for k,v in groups.items():result.append({'case':k,**{variant:statistics.median(values) for variant,values in v.items()}})
 (dest/(prefix+'-'+input_name.replace('.csv','-summary.json'))).write_text(json.dumps(result,indent=2)+'\n')
(dest/(prefix+'-provenance.json')).write_text(json.dumps({'files':files,'CCV_HEAD':'6a611be1aab6470ae279115ae4eaf7e01bc87135','MLX_HEAD':'25532871329fe4cafdada9fa0941a1cdbfb3a9f2','DrawThings_HEAD':'afed99ce5981875e3b3aa7d19059a516c73c5f2f','Swift_NNC_pinned':'1db38650465deeff7b51d04e413c9c74ea842464','note':'Integrated inference implementation. Superseded is_test-gated artifacts are retained as historical results, not final application-path validation. Benchmark and check outcomes are recorded in CSV/JSON and report.'},indent=2)+'\n')
