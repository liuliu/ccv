from pathlib import Path
import json,subprocess,shlex,shutil,hashlib
root=Path('/Users/liu/workspace/ccv');p=Path('/private/tmp/ccv-fp32-gemm-aspect');old=Path('/private/tmp/ccv-fp16-medium');commands=[]
def run(args,cwd):
    commands.append(dict(args=args,cwd=str(cwd)));subprocess.run(args,cwd=cwd,check=True)
source=root/'lib/nnc/mfa/ccv_nnc_mfa_gemm.cpp';original=source.read_text()
(p/'baseline.cpp').write_text(original);shutil.copy2(root/'lib/libccv.a',p/'baseline.a');shutil.copy2(old/'probe-production',p/'probe-baseline')
a='''const bool register_unsplit = params.K >= 2048 && (params.K <= 8192 ||
      (params.K <= 16384 && params.K < uint64_t(3) * params.N &&
       (params.M < params.N || params.M >= uint64_t(2) * params.N) &&
       uint64_t(params.N) * params.K * sizeof(uint16_t) <= (192ull << 20)));'''
b='''const bool register_unsplit = params.K >= 2048 && (params.K <= 8192 ||
      (params.K <= 16384 &&
       uint64_t(params.N) * params.K * sizeof(uint16_t) <= (192ull << 20) &&
       (params.register_float || (params.K < uint64_t(3) * params.N &&
        (params.M < params.N || params.M >= uint64_t(2) * params.N)))));'''
assert original.count(a)==1
(p/'ccv_nnc_mfa_gemm.cpp').write_text(original.replace(a,b))
compile_command=next(x for x in json.loads(Path('/private/tmp/ccv-gemm-fused-cast/build-commands.json').read_text()) if x['args'][0]=='clang++' and x['args'][1].endswith('/ccv_nnc_mfa_gemm.cpp'))
args=compile_command['args'].copy();args[1]=str(p/'ccv_nnc_mfa_gemm.cpp');args[args.index('-o')+1]=str(p/'ccv_nnc_mfa_gemm.o');run(args,Path(compile_command['cwd']))
log=Path('/private/tmp/ccv-int8-register-mid-production/build-lib.log').read_text().splitlines()
for suffix,cwd,replace,output in [(' -o libnnc-compat-mfa.o','lib/nnc/mfa',{'ccv_nnc_mfa_gemm.o':str(p/'ccv_nnc_mfa_gemm.o')},'mfa.o'),(' -o libnnc.o','lib/nnc',{'mfa/libnnc-compat-mfa.o':str(p/'mfa.o')},'nnc.o')]:
    args=shlex.split(next(x for x in log if x.startswith('ld -r ') and x.endswith(suffix)));args=[replace.get(x,x) for x in args];args[-1]=str(p/output);run(args,root/cwd)
args=shlex.split(next(x for x in log if x.startswith('ar rcs libccv.a ')));args[2]=str(p/'libccv.a');args=[str(p/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];run(args,root/'lib')
c=json.loads((old/'production/build-probe-command.json').read_text());args=[str(p/'libccv.a') if x==str(root/'lib/libccv.a') else str(p/'probe-fp32') if x==str(old/'probe-production') else x for x in c['args']];run(args,root)
(p/'build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
files=[p/'probe-baseline',p/'probe-fp32',p/'baseline.a',p/'libccv.a',source,root/'lib/libccv.a']
(p/'provenance.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},indent=2)+'\n')
assert source.read_text()==original
print('Built isolated FP32 aspect/reduction candidate; production unchanged.')
