from pathlib import Path
import os,subprocess,json,csv,re,statistics,time,hashlib
p=Path('/private/tmp/ccv-fp32-gemm-aspect');out=p/'sweep';out.mkdir(exist_ok=True)
cases={}
def add(label,m,n,k,flags=0,upcast=1,cast=0):
    key=(m,n,k,flags,upcast,cast)
    if key not in cases:cases[key]=dict(id=f'm{m}-n{n}-k{k}-f{flags}-u{upcast}-cast{cast}',labels=[],shape=[m,n,k],flags=flags,upcast=upcast,cast=cast)
    if label not in cases[key]['labels']:cases[key]['labels'].append(label)
def route(c,variant):
    m,n,k=c['shape'];u=c['upcast']
    native_moderate=k<=8192 and k>=2*n and n%128==0 and k%512==0
    grid=m>=4096 or (m>=512 and u) or (m>=2048 and m*n>=4096*1536 and not native_moderate)
    if not grid or n<1536:return 'native'
    split=m<n and k>=2*n and k<=32768 and m*n*4<=256*2**20
    unsplit=k>=2048 and (k<=8192 or (k<=16384 and n*k*2<=192*2**20 and
        ((variant=='fp32' and u) or (k<3*n and (m<n or m>=2*n)))))
    return 'split' if split else 'register' if unsplit else 'native'

for m in [512,1024,1536,2048,2560,3072,4096,6144,8192,16384]:
    for n in [1536,2048,2560,4096,6144,8192]:
        for k in [9216,12288,16384]:
            c=dict(shape=[m,n,k],upcast=1)
            if route(c,'baseline')!=route(c,'fp32'):add('fp32-aspect-depth-grid',m,n,k,upcast=1)
for m in [4095,4096,4097]:add('row-aspect-boundary',m,4096,12288,upcast=1)
for n in [4095,4096,4097]:add('column-aspect-boundary',4096,n,12288,upcast=1)
for k in [8191,8192,8193,16383,16384,16385]:add('reduction-boundary',3072,2560,k,upcast=1)
for n in [8191,8192,8193]:add('weight-footprint-boundary',8192,n,12288,upcast=1)
for m,n,k in [(3072,2560,9216),(2048,2048,16384),(3072,3072,12288),(6144,6144,16384),(8192,4096,16384),(16384,1536,9216)]:add('low-precision-unchanged-control',m,n,k,upcast=0)
add('local-code-dynamic',3072,2560,9216,flags=1,upcast=1)

cases=list(cases.values())
for c in cases:
    c['variants']=['baseline','fp32','mlx']
    c['routes']={v:route(c,v) for v in c['variants'] if v!='mlx'}
manifest=dict(cases=cases,records_expected=sum(len(c['variants'])*2 for c in cases),
    protocol='Serial GPU execution. Three warm iterations and >=.5 GPU seconds; seven timed samples; two reversed orders. FP16 inputs/output with explicit FP32 accumulation except unchanged low-precision controls. Dense weights already expanded; decode excluded. Actual MLX linked from the local checkout, unchanged matmul. All CCV outputs finite, sampled independent CPU error from every process. Preserve failures without invented times. Different arithmetic order may change output hashes; no bitwise equivalence claim. Candidate removes the deep-aspect and K/N limits only for explicit FP32 accumulation; K<=16384 and weight-footprint limits remain. Production remains unchanged.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('CASES',len(cases),'RECORDS',manifest['records_expected'],flush=True)
fields=['order','case','M','N','K','flags','cast','upcast','variant','route','gpu_median_ms','normalized_l2','output_sha256','exit','seconds']
rows=[]
with (out/'sweep.csv').open('w') as f:
    w=csv.DictWriter(f,fields);w.writeheader();f.flush()
    for order in range(2):
        for c in (cases if order==0 else cases[::-1]):
            for variant in (c['variants'] if order==0 else c['variants'][::-1]):
                exe='/private/tmp/ccv-projection-cast/mlx' if variant=='mlx' else str(p/('probe-'+variant))
                args=[exe,'matmul',*map(str,c['shape']),'1','1','1','3','7','0']
                if variant!='mlx':args+=['0',str(c['upcast']),str(c['flags'])]
                env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5','CCV_NA_OUTPUT_CAST':str(c['cast']),'CCV_GEMM_FUSED_CAST':'0'}
                start=time.time();r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=600)
                stem=f'{order}-{c["id"]}-{variant}'
                (out/(stem+'.log')).write_text(r.stdout+r.stderr)
                (out/(stem+'.command.json')).write_text(json.dumps(dict(args=args,env={k:v for k,v in env.items() if k.startswith('CCV_')},start=start,seconds=time.time()-start,exit=r.returncode),indent=2)+'\n')
                def metric(key):
                    m=re.search(r'(?<![A-Za-z_])'+key+r'=([^\s]+)',r.stdout)
                    return m.group(1) if m else ''
                row=dict(order=order,case=c['id'],M=c['shape'][0],N=c['shape'][1],K=c['shape'][2],flags=c['flags'],cast=c['cast'],upcast=c['upcast'],variant=variant,route=c['routes'].get(variant,'actual-mlx'),
                         **{key:metric(key) for key in ['gpu_median_ms','normalized_l2','output_sha256']},exit=r.returncode,seconds=time.time()-start)
                rows.append(row);w.writerow(row);f.flush()
                print(len(rows),order,c['id'],variant,row['gpu_median_ms'],row['normalized_l2'],'exit',r.returncode,flush=True)
summary=[]
for c in cases:
    values={v:[float(r['gpu_median_ms']) for r in rows if r['case']==c['id'] and r['variant']==v and r['exit']==0] for v in c['variants']}
    summary.append(dict(**c,samples=values,medians={v:statistics.median(a) if len(a)==2 else None for v,a in values.items()}))
(out/'summary.json').write_text(json.dumps(dict(records=len(rows),failures=[r for r in rows if r['exit']],cases=summary),indent=2)+'\n')
print('COMPLETE',len(rows),'FAILURES',sum(bool(r['exit']) for r in rows),flush=True)
