from pathlib import Path
import csv,hashlib,json,shutil,statistics,tarfile
root=Path('/Users/liu/workspace/ccv');dest=root/'doc/benchmarks/m5-ultra-na-2026-10-02'
folders={'attention-k16':Path('/private/tmp/ccv-int8-explicit-fragments'),'attention-k32':Path('/private/tmp/ccv-int8-explicit-fragments-k32'),'gemm-k32':Path('/private/tmp/ccv-int8-gemm-fragments-k32')}
prefix='inference-fragment-reduction'
files=[];summary=[]
with tarfile.open(dest/f'{prefix}-sources-and-logs.tar.gz','w:gz') as tar:
 for tag,p in folders.items():
  for f in sorted(p.iterdir()):
   if f.is_file() and f.suffix in ['.cpp','.inc','.metal','.py','.log','.csv']:
    tar.add(f,arcname=f'{tag}/{f.name}')
  shutil.copyfile(p/'pilot.csv',dest/f'{prefix}-{tag}.csv')
  a=list(csv.DictReader((p/'pilot.csv').open()))
  for case in dict.fromkeys(r['case'] for r in a):
   row={'experiment':tag,'case':case}
   for variant in dict.fromkeys(r['variant'] for r in a):
    row[variant]=statistics.median(float(r['median_ms']) for r in a if r['case']==case and r['variant']==variant)
   summary.append(row)
  for f in [p/'probe',*p.glob('*.cpp'),*p.glob('*.metal'),*p.glob('*.inc')]:
   h=hashlib.sha256()
   with f.open('rb') as g:
    for b in iter(lambda:g.read(1<<20),b''):h.update(b)
   files.append({'path':str(f),'sha256':h.hexdigest(),'bytes':f.stat().st_size})
(dest/f'{prefix}-provenance.json').write_text(json.dumps({'files':files,'note':'Rejected scratch prototypes; validated production source unchanged.'},indent=2)+'\n')
(dest/f'{prefix}-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copyfile(Path('/private/tmp/ccv-int8-explicit-fragments/archive.py'),dest/f'{prefix}-archive.py')
