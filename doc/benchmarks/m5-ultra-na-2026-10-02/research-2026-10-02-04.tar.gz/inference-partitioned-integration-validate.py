from pathlib import Path
import subprocess,json,time,csv,os,re
p=Path('/private/tmp/ccv-int8-partition-production');env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.1'}
with (p/'accuracy.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['R','C','Hq','Hk','mode','variant','cpu_l2','cpu_max_abs','exit'])
 for R,C,Hq,Hk in [(4097,24577,48,12),(4097,32768,32,8),(4097,70186,56,7)]:
  for mode in [0,1,2,3,4,5,6]:
   for variant in ['training','inference']:
    e={**env,'CCV_ACCURACY_MODE':str(mode)}
    if variant=='training':e['CCV_ACCURACY_TRAINING']='1'
    r=subprocess.run([str(p/'accuracy'),'attention',str(R),str(C),'128','1',str(Hq),str(Hk),'1','1','0','1','0','3'],capture_output=True,text=True,env=e,timeout=600)
    (p/f'accuracy-{R}-{C}-{mode}-{variant}.log').write_text(r.stdout+r.stderr)
    l2=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout);ma=re.search(r'cpu_sample_max_abs=([0-9.e+-]+)',r.stdout)
    row=[R,C,Hq,Hk,mode,variant,l2.group(1) if l2 else '',ma.group(1) if ma else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
records=[]
for name in ['mpsblas.tests','mpsdnn.tests']:
 start=time.monotonic()
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(['./'+name],stdout=f,stderr=subprocess.STDOUT,cwd='/Users/liu/workspace/ccv/test/int/nnc')
 records.append({'binary':name,'exit':r.returncode,'seconds':time.monotonic()-start});(p/'validation.json').write_text(json.dumps(records,indent=2));print(records[-1],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
