from pathlib import Path
import subprocess,json,time,hashlib
p=Path('/private/tmp/ccv-fp16-medium');d=p/'production';root=Path('/Users/liu/workspace/ccv')
results=[]
jobs=[('mpsblas',['./mpsblas.tests'],root/'test/int/nnc'),('mpsdnn',['./mpsdnn.tests'],root/'test/int/nnc'),('benchmark',['python3',str(p/'production.py')],root)]
for name,args,cwd in jobs:
    print('START',name,time.time(),flush=True);start=time.time()
    with (d/(name+'.log')).open('w') as f:
        result=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
    row=dict(name=name,args=args,cwd=str(cwd),start=start,seconds=time.time()-start,exit=result.returncode)
    if name=='benchmark' and result.returncode==0:
        summary=json.loads((d/'summary.json').read_text());row['records']=summary['records'];row['failures']=len(summary['failures'])
    results.append(row);(d/'validation.json').write_text(json.dumps(results,indent=2)+'\n')
    print('END',json.dumps(row),flush=True)
    if result.returncode or row.get('failures',0):raise SystemExit(1)
print('COMPLETE',flush=True)
