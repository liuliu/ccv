#include "ccv.h"
#include "nnc/ccv_nnc.h"
#include "nnc/ccv_nnc_easy.h"
#include "nnc/mps/ccv_nnc_mps.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
static int compare_double(const void* a, const void* b) { const double x=*(const double*)a,y=*(const double*)b; return (x>y)-(x<y); }
int main(int argc, char** argv) {
  if (argc != 8) return 2;
  const int R=atoi(argv[1]),C=atoi(argv[2]),B=atoi(argv[3]),Hq=atoi(argv[4]),Hk=atoi(argv[5]),quantized=atoi(argv[6]),saved=atoi(argv[7]),D=256;
  if (R<=0||C<=0||B<=0||Hq<=0||Hk<=0||Hq%Hk) return 2;
  @autoreleasepool {
    ccv_nnc_init();
    ccv_nnc_tensor_t* host[3]; ccv_nnc_tensor_t* input[3];
    for (int j=0;j<3;++j) {
      const int S=j==0?R:C,H=j==0?Hq:Hk;
      host[j]=ccv_nnc_tensor_new(0,CPU_TENSOR_NHWC(16F,B,S,H,D),0);
      input[j]=ccv_nnc_tensor_new(0,GPU_TENSOR_NHWC(000,16F,B,S,H,D),0);
      _Float16* values=(_Float16*)host[j]->data.f16;
      for (size_t i=0;i<(size_t)B*S*H*D;++i) values[i]=(float)((int)((i*17+(j+1)*13)%29)-14)*(8-j)/256;
      ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(),ccv_nnc_no_hint,0,TENSOR_LIST(host[j]),TENSOR_LIST(input[j]),0);
    }
    ccv_nnc_tensor_t* output=ccv_nnc_tensor_new(0,GPU_TENSOR_NHWC(000,16F,B,R,Hq,D),0);
    ccv_nnc_tensor_t* lse=saved?ccv_nnc_tensor_new(0,GPU_TENSOR_NHWC(000,32F,B,Hq,R),0):0;
    ccv_nnc_tensor_t* actual=ccv_nnc_tensor_new(0,CPU_TENSOR_NHWC(16F,B,R,Hq,D),0);
    ccv_nnc_cmd_t command=CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0f/sqrtf(D),0);
    command.info.scaled_dot_product_attention.flags=CCV_NNC_GEMM_16F|(quantized?CCV_NNC_GEMM_8I:0);
    ccv_nnc_stream_context_t* stream=ccv_nnc_stream_context_new(CCV_STREAM_CONTEXT_GPU);
    double samples[7],warm=0;
    int count=0;
    for (int iteration=0;count<7;++iteration) {
      @autoreleasepool {
        MPSCommandBuffer* mps=ccv_nnc_stream_context_start_mps_command_buffer(stream);
        id<MTLCommandBuffer> cb=[mps.commandBuffer retain];
        int status=ccv_nnc_cmd_exec(command,ccv_nnc_no_hint,0,TENSOR_LIST(input[0],input[1],input[2]),TENSOR_LIST(output,lse),stream);
        ccv_nnc_stream_context_wait(stream);
        if (status!=CCV_NNC_EXEC_SUCCESS || cb.status!=MTLCommandBufferStatusCompleted) return 3;
        double seconds=cb.GPUEndTime-cb.GPUStartTime;
        [cb release];
        warm+=seconds;
        if (iteration>=3 && warm>=0.5) samples[count++]=seconds*1000;
      }
    }
    ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(),ccv_nnc_no_hint,0,TENSOR_LIST(output),TENSOR_LIST(actual),0);
    const _Float16* o=(const _Float16*)actual->data.f16;
    for (size_t i=0;i<(size_t)B*R*Hq*D;++i) if (!isfinite((float)o[i])) return 4;
    const _Float16* q=(const _Float16*)host[0]->data.f16;
    const _Float16* k=(const _Float16*)host[1]->data.f16;
    const _Float16* v=(const _Float16*)host[2]->data.f16;
    double error2=0,reference2=0,max_error=0;
    double* scores=malloc(sizeof(double)*C);
    for (int b=0;b<B;++b) for (int sample=0;sample<8;++sample) {
      const int r=sample*(R-1)/7,h=sample%Hq,kh=h/(Hq/Hk);
      double maximum=-INFINITY,total=0;
      for (int c=0;c<C;++c) {
        double dot=0;
        for (int d=0;d<D;++d) dot+=(double)q[((size_t)b*R+r)*Hq*D+h*D+d]*(double)k[((size_t)b*C+c)*Hk*D+kh*D+d];
        scores[c]=dot/sqrt(D);maximum=fmax(maximum,scores[c]);
      }
      for (int c=0;c<C;++c) total+=(scores[c]=exp(scores[c]-maximum));
      for (int d=0;d<D;++d) {
        double ref=0;
        for (int c=0;c<C;++c) ref+=scores[c]*(double)v[((size_t)b*C+c)*Hk*D+kh*D+d];
        ref/=total;
        const double diff=(double)o[((size_t)b*R+r)*Hq*D+h*D+d]-ref;
        error2+=diff*diff;reference2+=ref*ref;max_error=fmax(max_error,fabs(diff));
      }
    }
    free(scores);
    qsort(samples,7,sizeof(double),compare_double);
    const double l2=sqrt(error2/fmax(reference2,1e-30));
    printf("R=%d C=%d B=%d Hq=%d Hk=%d int8_preference=%d saved_lse=%d gpu_median_ms=%.9g normalized_l2=%.9g max_abs=%.9g all_finite=1\n",R,C,B,Hq,Hk,quantized,saved,samples[3],l2,max_error);
    ccv_nnc_stream_context_free(stream);
    for (int j=0;j<3;++j) { ccv_nnc_tensor_free(host[j]);ccv_nnc_tensor_free(input[j]); }
    ccv_nnc_tensor_free(output);ccv_nnc_tensor_free(actual);if(lse)ccv_nnc_tensor_free(lse);
    return l2<(saved&&quantized?0.05:0.003)?0:4;
  }
}
