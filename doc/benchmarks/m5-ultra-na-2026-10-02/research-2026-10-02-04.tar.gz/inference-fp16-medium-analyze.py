from pathlib import Path
import csv,json,statistics,collections
p=Path('/private/tmp/ccv-fp16-medium')
records=[];cases=[]
for stage in ['wide','precision','guard']:
    d=p/stage
    if not (d/'sweep.csv').exists():continue
    rows=list(csv.DictReader((d/'sweep.csv').open()));records+=rows
    meta={c['id']:c for c in json.loads((d/'manifest.json').read_text())['cases']}
    grouped=collections.defaultdict(lambda:collections.defaultdict(list))
    for r in rows:
        if r['exit']=='0' and r['gpu_median_ms']:grouped[r['case']][r['variant']].append(float(r['gpu_median_ms']))
    for key,vs in grouped.items():
        if not all(len(vs[v])==2 for v in ['baseline','medium','mlx']):continue
        c=meta[key];m,n,k=c['shape'];u=c.get('upcast',0)
        med={v:statistics.median(a) for v,a in vs.items()}
        changed=c['routes']['baseline']!=c['routes']['medium']
        area=m*n>=4096*1536
        shallow= k<=8192 and k>=2*n and n%128==0 and k%512==0
        c={**c,'stage':stage,'upcast':u,'medians':med,'ratio':med['medium']/med['baseline'],
           'medium_over_mlx':med['medium']/med['mlx'],'changed':changed,
           'eligible':{'area':area,'area_shallow_guard':area and (u or not shallow),
                       'fp32_or_area_shallow_guard':bool(u) or (area and not shallow),
                       'min1024_fp32_or_area_shallow_guard':m>=1024 and (bool(u) or (area and not shallow)),
                       'fp32_or_medium_area_shallow_guard':bool(u) or (m>=2048 and area and not shallow)}}
        cases.append(c)
summary={}
for rule in ['area','area_shallow_guard','fp32_or_area_shallow_guard','min1024_fp32_or_area_shallow_guard','fp32_or_medium_area_shallow_guard']:
    cs=[c for c in cases if c['changed'] and c['eligible'][rule]]
    summary[rule]=dict(selected=len(cs),median_ratio=statistics.median([c['ratio'] for c in cs]) if cs else None,
        regressions5=[dict(id=c['id'],stage=c['stage'],ratio=c['ratio'],medians=c['medians']) for c in sorted(cs,key=lambda c:c['ratio'],reverse=True) if c['ratio']>1.05],
        worst=[dict(id=c['id'],stage=c['stage'],ratio=c['ratio'],medians=c['medians']) for c in sorted(cs,key=lambda c:c['ratio'],reverse=True)[:10]])
result=dict(records=len(records),failures=[r for r in records if r['exit']!='0'],complete_cases=len(cases),summary=summary,cases=cases)
(p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['records','complete_cases']},indent=2))
for name,s in summary.items():print(name,'selected',s['selected'],'median ratio',s['median_ratio'],'regressions5',len(s['regressions5']))
for c in summary['fp32_or_area_shallow_guard']['regressions5']:print(c)
