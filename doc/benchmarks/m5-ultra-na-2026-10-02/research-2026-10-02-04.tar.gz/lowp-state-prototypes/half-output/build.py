from pathlib import Path
import subprocess,shlex
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-int8-half-output')
s=(root/'lib/nnc/mfa/kernels/NAInt8AttentionKernel.cpp').read_text()
a=s.index('void NAInt8AttentionKernel::loopForward');prefix=s[:a];s=s[a:]
needle='''    source += "  auto cO_{{LOOP_INDEX}} = matmul_pv_op.get_destination_cooperative_tensor<pv_float_left_tensor_t, decltype(mV), float>();\\n";'''
replacement='''    if (i == 0)
      source += "  auto output_index = matmul_pv_op.get_destination_cooperative_tensor<pv_float_left_tensor_t, decltype(mV), float>();\\n";
    source.SetValue("OUTPUT_CAPACITY", std::to_string(blockDimensions[0] * blockDimensions[2] / 32));
    source += "  half cO_{{LOOP_INDEX}}[{{OUTPUT_CAPACITY}}];\\n";'''
assert s.count(needle)==1;s=s.replace(needle,replacement);s=s.replace('cO_0.get_', 'output_index.get_').replace('cO_0.is_valid_element','output_index.is_valid_element')
(out/'NAInt8AttentionKernel.cpp').write_text(prefix+s)
log=Path('/private/tmp/ccv-int8-register-production-build.log').read_text().splitlines()
lines=subprocess.check_output(['make','-n','-B','DEBUG=1','CC=clang++','lib'],cwd=root/'lib/nnc/mfa',text=True).splitlines()
line=next(l for l in lines if l.startswith('clang++ kernels/NAInt8AttentionKernel.cpp ') and ' -c ' in l);args=shlex.split(line);args[1]=str(out/'NAInt8AttentionKernel.cpp');args[args.index('-o')+1]=str(out/'NAInt8AttentionKernel.o');args+=['-I'+str(root/'lib/nnc/mfa/kernels')];subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
for wd,target,old,new,dst in [('lib/nnc/mfa','libnnc-compat-mfa.o','kernels/NAInt8AttentionKernel.o',out/'NAInt8AttentionKernel.o',out/'mfa.o'),('lib/nnc','libnnc.o','mfa/libnnc-compat-mfa.o',out/'mfa.o',out/'nnc.o')]:
 line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o '+target));args=shlex.split(line);args=[str(new) if x==old else x for x in args];args[-1]=str(dst);subprocess.run(args,cwd=root/wd,check=True)
line=next(l for l in log if l.startswith('ar rcs libccv.a '));args=shlex.split(line);args[2]=str(out/'libccv.a');args=[str(out/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];subprocess.run(args,cwd=root/'lib',check=True)
for source,name in [('bin/mfa/na_application_bench.cpp','probe'),('/private/tmp/ccv-int8-kv-partitions/accuracy.cpp','accuracy')]:
 args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0',source,str(out/'libccv.a')]
 for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
 args+=['-lsqlite3','-lz','-o',str(out/name)];subprocess.run(args,cwd=root,check=True)
