from pathlib import Path
import subprocess,os,csv,re
out=Path('/private/tmp/ccv-int8-half-output')
with (out/'pilot.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['R','D','H','variant','median_ms','cpu_l2','exit'])
 for R,D,H in [(4352,256,18),(16640,256,18),(14878,128,56),(70186,128,56)]:
  for name,exe,int8 in [('current','/private/tmp/ccv-fp32-accumulator-current-probe',1),('half',str(out/'probe'),1),('fp16','/private/tmp/ccv-fp32-accumulator-current-probe',0),('mlx','/private/tmp/ccv-mlx-dsplit-fix/probe',0)]:
   cmd=[exe,'attention',str(R),str(R),str(D),'1',str(H),str(H),'3','7','0']
   if name!='mlx':cmd+=[str(int8),'0','0']
   r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
   (out/f'{R}-{D}-{name}.log').write_text(r.stdout+r.stderr)
   med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
   row=[R,D,H,name,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
   if r.returncode not in [0,4] or not med:raise SystemExit(r.returncode or 9)
