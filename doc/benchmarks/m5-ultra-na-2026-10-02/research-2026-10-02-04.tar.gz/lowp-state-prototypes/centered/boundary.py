from pathlib import Path
import subprocess,os,csv,re,json
out=Path('/private/tmp/ccv-int8-centered-chunked')
cases = [(f'footprint-{c}-{h}',[c,c,128,1,h,h]) for c in [24576,32768] for h in [16,24,32,40,48,56,64]]
cases += [(f'longkv-{h}',[16384,65536,128,1,h,h]) for h in [8,16,24]]
cases += [(f'query-{r}-{h}',[r,32768,128,1,h,h]) for r in [4096,8192,16384] for h in [32,56]]
cases += [(f'gqa-{hk}',[31018,31018,128,1,56,hk]) for hk in [7,14,28,56]]
(out/'boundary-cases.json').write_text(json.dumps(cases,indent=2))
variants=[('current',1,4096,'/private/tmp/ccv-fp32-accumulator-current-probe'),('centered8',8,4096,str(out/'probe')),('mlx',1,4096,'/private/tmp/ccv-mlx-dsplit-fix/probe')]
with (out/'boundary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','R','C','D','B','Hq','Hk','pass','variant','parts','qchunk','median_ms','cpu_l2','exit_code'])
 for order in range(2):
  for case,shape in (cases if order==0 else list(reversed(cases))):
   for name,parts,qchunk,exe in (variants if order==0 else list(reversed(variants))):
    cmd=[exe,'attention',*map(str,shape),'3','7','0']
    if name!='mlx':cmd+=['1','0','0']
    r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_PARTITIONS':str(parts),'CCV_NA_QUERY_CHUNK':str(qchunk),'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
    (out/f'boundary-{order}-{case}-{name}.log').write_text(r.stdout+r.stderr)
    med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
    row=[case,*shape,order,name,parts,qchunk,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
