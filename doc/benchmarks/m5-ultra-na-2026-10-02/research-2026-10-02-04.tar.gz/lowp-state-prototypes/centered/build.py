from pathlib import Path
import subprocess,shlex,re
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-int8-centered-chunked')
s=Path('/private/tmp/ccv-int8-normalized-chunked/NAInt8AttentionKernel.cpp').read_text()
# Center V separately in each KV partition, retain those FP32 means separately
# until the FP32 final merge. This prevents cancellation from rounding large
# opposing partition means through the half accumulator / partial-output buffer.
a=s.index('void NAInt8AttentionKernel::createVMean');z=s.index('std::string NAInt8AttentionKernel::createSource',a);v=s[a:z]
v=v.replace('    device {{V_MEAN_MEMORY_NAME}} *mean [[buffer(1)]],','    device {{V_MEAN_MEMORY_NAME}} *mean [[buffer(1)]],\n    constant uint& partition_size [[buffer(22)]],')
v=v.replace('{{QUANTIZE_RUNTIME_CONSTANTS}}{{V_MEAN_ALIASES}}','''{{QUANTIZE_RUNTIME_CONSTANTS}}
  const uint partition_start = tgid.z * partition_size;
  const uint partition_end = min(QUANTIZE_KV_SEQUENCE, partition_start + partition_size);
  const uint partition_length = partition_end - partition_start;
  mean += tgid.z * QUANTIZE_KV_HEADS * {{HEAD_DIMENSION}};
  {{V_MEAN_ALIASES}}''')
v=v.replace('const uint head = morton.y, batch = tgid.z;', 'const uint head = morton.y, batch = 0;')
v=v.replace('for (uint column = row; column < {{V_SEQUENCE_LENGTH}};', 'for (uint column = partition_start + row; column < partition_end;')
v=v.replace('source.GetValue("V_SEQUENCE_DIVISOR")','std::string("partition_length")')
s=s[:a]+v+s[z:]
a=s.index('  if (vectorizeQuantize) {',s.index('  createVMean(source);'));z=s.index('  createConstants(source);',a);v=s[a:z]
v=v.replace('    device const {{V_MEAN_MEMORY_NAME}} *mean [[buffer(3)]],', '    device const {{V_MEAN_MEMORY_NAME}} *mean [[buffer(3)]],\n    constant uint& partition_size [[buffer(22)]],')
v=v.replace('  {{V_QUANTIZE_EXTENT}}','  {{V_QUANTIZE_EXTENT}}\n  mean += (start / partition_size) * QUANTIZE_KV_HEADS * {{HEAD_DIMENSION}};')
s=s[:a]+v+s[z:]
a=s.index('void NAInt8AttentionKernel::loopForward');f=s[a:]
f=re.sub(r'\(float\)V_mean_buf\[idx\[0\] \+ \{\{LOOP_INDEX_BLOCK_DIMENSIONS_HEAD\}\}\]', '0.0f',f)
s=s[:a]+f;(out/'NAInt8AttentionKernel.cpp').write_text(s)
s=Path('/private/tmp/ccv-int8-normalized-chunked/ccv_nnc_mfa_attention.cpp').read_text()
s=s.replace('      const size_t vMeanOffset = reserve(&scratchSize, vMeanBytes);\n','',1)
needle='      const uint32_t partitions = (hash.C + partition_size - 1) / partition_size;'
s=s.replace(needle,needle+'\n      const size_t vMeanOffset = reserve(&scratchSize, vMeanBytes * partitions);\n      CCV_NNC_MFA_PRECONDITION(partition_size % kernel->kvScaleTileSize == 0);',1)
s=s.replace('encoder->setComputePipelineState(computeVMeanPipeline.get());','encoder->setComputePipelineState(computeVMeanPipeline.get());\n        encoder->setBytes(&partition_size, sizeof(partition_size), 22);',1)
s=s.replace('kernel->vMeanThreadgroupsPerGrid(batchDimension),','kernel->vMeanThreadgroupsPerGrid(partitions),',1)
s=s.replace('encoder->setComputePipelineState(quantizeVPipeline.get());','encoder->setComputePipelineState(quantizeVPipeline.get());\n        encoder->setBytes(&partition_size, sizeof(partition_size), 22);',1)
s=s.replace('constant uint4& p [[buffer(3)]], uint gid [[thread_position_in_grid]]) {','constant uint4& p [[buffer(3)]], const device float* means [[buffer(4)]], constant uint& hk [[buffer(5)]], uint gid [[thread_position_in_grid]]) {',1)
s=s.replace('value += weight * float4(*reinterpret_cast<const device half4*>(partial + size_t(s) * count + index));','''const float4 centered = float4(*reinterpret_cast<const device half4*>(partial + size_t(s) * count + index));
    const float4 mean = *reinterpret_cast<const device float4*>(means + (size_t(s) * hk + h / (p.y / hk)) * p.z + index % p.z);
    value += weight * (centered + mean);''',1)
s=s.replace('encoder->setBytes(mergeArgs, sizeof(mergeArgs), 3);','encoder->setBytes(mergeArgs, sizeof(mergeArgs), 3);\n      encoder->setBuffer(scratch, vMeanOffset, 4);\n      encoder->setBytes(&hash.Hk, sizeof(hash.Hk), 5);',1)
(out/'ccv_nnc_mfa_attention.cpp').write_text(s)
# Compile two replacements, preserving the current production objects elsewhere.
log=Path('/private/tmp/ccv-int8-register-production-build.log').read_text().splitlines()
compile_lines=subprocess.check_output(['make','-n','-B','DEBUG=1','CC=clang++','lib'],cwd=root/'lib/nnc/mfa',text=True).splitlines()
for source,old,inc in [('NAInt8AttentionKernel.cpp','kernels/NAInt8AttentionKernel.cpp','lib/nnc/mfa/kernels'),('ccv_nnc_mfa_attention.cpp','ccv_nnc_mfa_attention.cpp','lib/nnc/mfa')]:
 line=next(l for l in compile_lines if l.startswith('clang++ '+old+' ') and ' -c ' in l)
 args=shlex.split(line);args[1]=str(out/source);args[args.index('-o')+1]=str(out/source.replace('.cpp','.o'));args+=['-I'+str(root/inc)]
 subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o libnnc-compat-mfa.o'));args=shlex.split(line)
args=[str(out/'NAInt8AttentionKernel.o') if x=='kernels/NAInt8AttentionKernel.o' else str(out/'ccv_nnc_mfa_attention.o') if x=='ccv_nnc_mfa_attention.o' else x for x in args];args[-1]=str(out/'mfa.o');subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o libnnc.o'));args=shlex.split(line);args=[str(out/'mfa.o') if x=='mfa/libnnc-compat-mfa.o' else x for x in args];args[-1]=str(out/'nnc.o');subprocess.run(args,cwd=root/'lib/nnc',check=True)
line=next(l for l in log if l.startswith('ar rcs libccv.a '));args=shlex.split(line);args[2]=str(out/'libccv.a');args=[str(out/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];subprocess.run(args,cwd=root/'lib',check=True)
args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0','bin/mfa/na_application_bench.cpp',str(out/'libccv.a')]
for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
args+=['-lsqlite3','-lz','-o',str(out/'probe')];subprocess.run(args,cwd=root,check=True)
