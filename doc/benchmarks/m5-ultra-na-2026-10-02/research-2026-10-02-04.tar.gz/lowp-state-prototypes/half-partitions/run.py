from pathlib import Path
import subprocess,os,csv,re
out=Path('/private/tmp/ccv-int8-half-chunked')
variants=[('current','/private/tmp/ccv-fp32-accumulator-current-probe',1,8192),('float4','/private/tmp/ccv-int8-kv-chunked/probe',4,8192),('half4',str(out/'probe'),4,8192),('float8','/private/tmp/ccv-int8-kv-chunked/probe',8,4096),('half8',str(out/'probe'),8,4096),('mlx','/private/tmp/ccv-mlx-dsplit-fix/probe',1,8192)]
with (out/'pilot.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['R','C','D','H','variant','parts','chunk','median_ms','cpu_l2','exit'])
 for R,C,D,H in [(14878,14878,128,56),(31018,31018,128,56),(70186,70186,128,56),(24576,24576,128,16),(4096,32768,128,8),(16640,16640,256,18)]:
  for name,exe,parts,chunk in variants:
   cmd=[exe,'attention',str(R),str(C),str(D),'1',str(H),str(H),'3','7','0']
   if name!='mlx':cmd+=['1','0','0']
   r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5','CCV_NA_PARTITIONS':str(parts),'CCV_NA_QUERY_CHUNK':str(chunk)},timeout=600)
   (out/f'{R}-{C}-{D}-{name}.log').write_text(r.stdout+r.stderr)
   med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
   row=[R,C,D,H,name,parts,chunk,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
   if r.returncode not in [0,4] or not med:raise SystemExit(r.returncode or 9)
