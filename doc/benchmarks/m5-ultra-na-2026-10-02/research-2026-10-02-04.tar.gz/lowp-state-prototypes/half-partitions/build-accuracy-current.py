from pathlib import Path
import subprocess
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-int8-half-chunked')
for source,name in [('/private/tmp/ccv-int8-half-chunked/accuracy.cpp','accuracy-current')]:
 args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0',source,str(root/'lib/libccv.a')]
 for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
 args+=['-lsqlite3','-lz','-o',str(out/name)];subprocess.run(args,cwd=root,check=True)
