from pathlib import Path
import subprocess,csv,re
out=Path('/private/tmp/ccv-lowp-format')
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['format','K','H','M','exit','ms','error'])
 for K,H in [(128,56),(256,18),(4096,1)]:
  for fmt in ['half','int8','fp8']:
   r=subprocess.run([str(out/'probe'),fmt,str(K),str(H),'2048'],capture_output=True,text=True,timeout=120)
   (out/f'{K}-{H}-{fmt}.log').write_text(r.stdout+r.stderr)
   ms=re.search('median_ms=([0-9.]+)',r.stdout);err=re.search('max_error=([0-9.e+-]+)',r.stdout)
   row=[fmt,K,H,2048,r.returncode,ms.group(1) if ms else '',err.group(1) if err else ''];w.writerow(row);f.flush();print(row,flush=True)
