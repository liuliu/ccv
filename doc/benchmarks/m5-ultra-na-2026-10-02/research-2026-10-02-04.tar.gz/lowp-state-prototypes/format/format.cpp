#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "nnc/mfa/ccv_nnc_mfa.hpp"
int main(int argc,char**argv){
 if(argc!=5)return 2;
 std::string mode=argv[1];const int K=atoi(argv[2]),H=atoi(argv[3]),M=atoi(argv[4]),N=M;
 const int stride=K*H;
 auto pool=NS::TransferPtr(NS::AutoreleasePool::alloc()->init());auto dev=NS::TransferPtr(MTL::CreateSystemDefaultDevice());auto queue=NS::TransferPtr(dev->newCommandQueue());
 std::string s="#include <metal_stdlib>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal; using namespace mpp::tensor_ops;\n";
 s += "#define INPUT "+std::string(mode=="half"?"half":mode=="int8"?"int8_t":"metal_fp8_e4m3_format")+"\n";
 s += "#define STORAGE "+std::string(mode=="half"?"half":mode=="int8"?"int8_t":"uchar")+"\n";
 s += "#define ACC "+std::string(mode=="int8"?"int32_t":"float")+"\n";
 s += R"(
 kernel void multiply(device STORAGE* a [[buffer(0)]], device STORAGE* b [[buffer(1)]], device float* o [[buffer(2)]], constant uint4& args [[buffer(3)]], uint2 group [[threadgroup_position_in_grid]]) {
 const uint M=args.x,N=args.y,K=args.z,ld=args.w;
 auto A=tensor<device INPUT,dextents<int,2>,tensor_inline>(a,dextents<int,2>(ld,M));
 auto B=tensor<device INPUT,dextents<int,2>,tensor_inline>(b,dextents<int,2>(ld,N));
 constexpr auto desc=matmul2d_descriptor(64,64,128,false,true,true,matmul2d_descriptor::mode::multiply_accumulate);
 matmul2d<desc,execution_simdgroups<4>> op;
 auto mA=A.slice<128,64>(0,group.y*64);auto mB=B.slice<128,64>(0,group.x*64);
 auto c=op.get_destination_cooperative_tensor<decltype(mA),decltype(mB),ACC>();
 #pragma clang loop unroll(full)
 for(ushort i=0;i<c.get_capacity();++i)if(c.is_valid_element(i))c[i]=0;
 for(uint k=0;k<K;k+=128){auto x=A.slice<128,64>(k,group.y*64);auto y=B.slice<128,64>(k,group.x*64);op.run(x,y,c);}
 #pragma clang loop unroll(full)
 for(ushort i=0;i<c.get_capacity();++i)if(c.is_valid_element(i)){auto xy=c.get_multidimensional_index(i);o[size_t(group.y*64+xy[1])*N+group.x*64+xy[0]]=float(c[i]);}
 }
 )";
 NS::Error* error=nullptr;auto lib=NS::TransferPtr(dev->newLibrary(NS::String::string(s.c_str(),NS::UTF8StringEncoding),nullptr,&error));
 if(!lib){fprintf(stderr,"compile: %s\n",error->localizedDescription()->utf8String());return 3;}
 auto fun=NS::TransferPtr(lib->newFunction(NS::String::string("multiply",NS::UTF8StringEncoding)));auto pipe=NS::TransferPtr(dev->newComputePipelineState(fun.get(),&error));
 if(!pipe){fprintf(stderr,"pipeline: %s\n",error->localizedDescription()->utf8String());return 3;}
 const size_t count=size_t(M)*stride, bytes=count*(mode=="half"?2:1);
 auto a=NS::TransferPtr(dev->newBuffer(bytes,MTL::ResourceStorageModeShared));auto b=NS::TransferPtr(dev->newBuffer(bytes,MTL::ResourceStorageModeShared));auto o=NS::TransferPtr(dev->newBuffer(size_t(M)*N*4,MTL::ResourceStorageModeShared));
 if(mode=="half")for(size_t i=0;i<count;++i){((_Float16*)a->contents())[i]=1;((_Float16*)b->contents())[i]=1;}
 else{memset(a->contents(),mode=="int8"?1:0x38,bytes);memset(b->contents(),mode=="int8"?1:0x38,bytes);}
 const uint32_t args[4]={(uint32_t)M,(uint32_t)N,(uint32_t)K,(uint32_t)stride};std::vector<double> times;double warm=0;
 for(int i=0;times.size()<9;++i){auto cb=NS::RetainPtr(queue->commandBuffer());auto enc=cb->computeCommandEncoder();enc->setComputePipelineState(pipe.get());enc->setBuffer(a.get(),0,0);enc->setBuffer(b.get(),0,1);enc->setBuffer(o.get(),0,2);enc->setBytes(args,sizeof(args),3);enc->dispatchThreadgroups(MTL::Size(N/64,M/64,1),MTL::Size(128,1,1));enc->endEncoding();cb->commit();cb->waitUntilCompleted();if(cb->status()!=MTL::CommandBufferStatusCompleted)return 4;double t=cb->GPUEndTime()-cb->GPUStartTime();warm+=t;if(i>=3&&warm>=.1)times.push_back(t*1000);}
 const auto values=static_cast<const float*>(o->contents());float maxError=0;for(size_t i=0;i<size_t(M)*N;++i){if(!std::isfinite(values[i]))return 5;maxError=std::max(maxError,std::abs(values[i]-K));}
 std::sort(times.begin(),times.end());printf("%s M=%d N=%d K=%d stride=%d median_ms=%.6f max_error=%g\n",mode.c_str(),M,N,K,stride,times[4],maxError);
 return maxError==0?0:5;
}
