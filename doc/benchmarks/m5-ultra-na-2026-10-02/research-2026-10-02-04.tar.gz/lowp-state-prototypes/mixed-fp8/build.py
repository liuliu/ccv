from pathlib import Path
import subprocess,shlex
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-int8-fp8-pv')
s=(root/'lib/nnc/mfa/kernels/NAInt8AttentionKernel.cpp').read_text()
s=s.replace('''    if (!hasCRemainder) {
      return 0;
    }
''','',1)
# Research-only mixed INT8 QK / FP8 PV. Global V scale keeps the persistent
# FP32 accumulator in one scale domain across every KV tile.
a=s.index('  if (vectorizeQuantize) {',s.index('  createVMean(source);'));z=s.index('  createConstants(source);',a);v=s[a:z]
v=v.replace('  const uint tile = tgid.x;','  if (tgid.x != 0) return;\n  const uint tile = 0;')
v=v.replace('  {{V_QUANTIZE_EXTENT}}','  const uint extent = QUANTIZE_KV_SEQUENCE;')
v=v.replace('''  if (tid == 0)
    scales[batch * QUANTIZE_KV_SCALE_BATCH_STRIDE + head * QUANTIZE_KV_SCALE_TILES + tile] = scale;''','''  for (uint scale_tile = tid; scale_tile < QUANTIZE_KV_SCALE_TILES; scale_tile += QUANTIZE_KV_THREADS)
    scales[batch * QUANTIZE_KV_SCALE_BATCH_STRIDE + head * QUANTIZE_KV_SCALE_TILES + scale_tile] = scale;''')
v=v.replace('127.0f','448.0f').replace('device int8_t *dst','device uchar *dst').replace('device char4 *dst4 = reinterpret_cast<device char4 *>(dst);','device uchar4 *dst4 = reinterpret_cast<device uchar4 *>(dst);')
v=v.replace('''    const int4 rounded = int4(rint(value * inv_scale));
    dst4[index / 4] = char4(clamp(rounded, int4(-127), int4(127)));''','''    dst4[index / 4] = uchar4(pack<metal_fp8_e4m3_format>(value * inv_scale).as_storage_type());''')
v=v.replace('''    const int rounded = (int)rint(value * inv_scale);
    dst[index] = (int8_t)clamp(rounded, -127, 127);''','''    dst[index] = pack<metal_fp8_e4m3_format>(float4(value * inv_scale)).as_storage_type()[0];''')
s=s[:a]+v+s[z:]
a=s.index('void NAInt8AttentionKernel::loopForward');prefix=s[:a];f=s[a:]
f=f.replace('auto V = tensor<device {{PV_RIGHT_MEMORY_NAME}}, dextents<int32_t, 2>, tensor_inline>(V_buf,','auto V = tensor<device metal_fp8_e4m3_format, dextents<int32_t, 2>, tensor_inline>((device uchar*)V_buf,')
a=f.index('  using pv_float_left_tensor_t =');b=f.index('\n)";',a)
f=f[:a]+'''  threadgroup uchar *Pq_buf = threadgroup_block + {{BLOCK_DIMENSIONS_PARALLELIZATION}} * {{BLOCK_DIMENSIONS_TRAVERSAL}} * sgid;
  auto Pq = tensor<threadgroup metal_fp8_e4m3_format, dextents<int32_t, 2>, tensor_inline>(Pq_buf, extents<int32_t, {{BLOCK_DIMENSIONS_TRAVERSAL}}, {{BLOCK_DIMENSIONS_PARALLELIZATION}}>());
  constexpr auto pv_remainder_desc = matmul2d_descriptor({{BLOCK_DIMENSIONS_PARALLELIZATION}}, {{BLOCK_DIMENSIONS_HEAD}}, dynamic_length_v<int>, false, false, true, matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<pv_remainder_desc, execution_simdgroups<1>> matmul_pv_remainder_op;'''+f[b:]
f=f.replace('get_destination_cooperative_tensor<pv_float_left_tensor_t, decltype(mV), float>()','get_destination_cooperative_tensor<decltype(Pq), decltype(mV), float>()')
f=f.replace('    const float v_scale_recip_127 = {{V_SCALE_FACTOR_0}} / 127.0f;','').replace('    const float v_scale_recip_127 = {{V_SCALE_FACTOR_REM}} / 127.0f;','')
f=f.replace('    thread pv_int8_left_tensor_t& cP_q_0 = reinterpret_cast<thread pv_int8_left_tensor_t&>(cS_0);','')
f=f.replace('''        const int quantized = (int)rint(cP_0[k] * 127.0f);
        cP_q_0[k] = (int8_t)clamp(quantized, 0, 127);''','''        const auto idx = cP_0.get_multidimensional_index(k);
        Pq_buf[idx[0] + idx[1] * {{BLOCK_DIMENSIONS_TRAVERSAL}}] = pack<metal_fp8_e4m3_format>(float4(cP_0[k] * 448.0f)).as_storage_type()[0];''')
f=f.replace('''    matmul_pv_int8_op.run(cP_q_0, mV_0_{{LOOP_INDEX}}, cOq);
    #pragma clang loop unroll(full)
    for (unsigned short k = 0; k < cOq.get_capacity(); ++k) {
      if (cOq.is_valid_element(k)) {
        cO_{{LOOP_INDEX}}[k] += (float)cOq[k] * v_scale_recip_127;
      }
    }''','''    matmul_pv_op.run(Pq, mV_0_{{LOOP_INDEX}}, cO_{{LOOP_INDEX}});''')
# P writes have to become visible before the first matrix product of each tile.
needle='''        Pq_buf[idx[0] + idx[1] * {{BLOCK_DIMENSIONS_TRAVERSAL}}] = pack<metal_fp8_e4m3_format>(float4(cP_0[k] * 448.0f)).as_storage_type()[0];
      }
    }
'''
assert f.count(needle)==1;f=f.replace(needle,needle+'    simdgroup_barrier(mem_flags::mem_threadgroup);\n')
f=f.replace('const int quantized = (int)rint(cP_0[k] * 127.0f);','const uchar quantized = pack<metal_fp8_e4m3_format>(float4(cP_0[k] * 448.0f)).as_storage_type()[0];')
f=f.replace('(int8_t)clamp(quantized, 0, 127)','quantized')
f=f.replace('''    matmul_pv_int8_op_remainder.run(mP_q, mV_0_{{LOOP_INDEX}}, cOq_remainder);
    #pragma clang loop unroll(full)
    for (unsigned short k = 0; k < cOq_remainder.get_capacity(); ++k) {
      if (cOq_remainder.is_valid_element(k)) {
        cO_{{LOOP_INDEX}}[k] += (float)cOq_remainder[k] * v_scale_recip_127;
      }
    }''','''    matmul_pv_remainder_op.run(mP_q, mV_0_{{LOOP_INDEX}}, cO_{{LOOP_INDEX}});''')
f=f.replace('fast::divide(1, *dst_it)', 'fast::divide(V_scale_buf[0] / 448.0f, *dst_it)')
assert 'cOq' not in f and 'pv_int8' not in f
prefix=prefix.replace('return blockDimensions[0] * blockDimensions[1] * executionSIMDGroups * sizeof(int8_t);', 'return blockDimensions[0] * ((blockDimensions[1] + 127) / 128 * 128) * executionSIMDGroups * sizeof(int8_t);',1)
f=f.replace('  const unsigned short kBlocks =', '  source.SetValue("P_STRIDE", std::to_string((blockDimensions[1] + 127) / 128 * 128));\n  const unsigned short kBlocks =',1)
f=f.replace('threadgroup_block + {{BLOCK_DIMENSIONS_PARALLELIZATION}} * {{BLOCK_DIMENSIONS_TRAVERSAL}} * sgid', 'threadgroup_block + {{BLOCK_DIMENSIONS_PARALLELIZATION}} * {{P_STRIDE}} * sgid')
f=f.replace('auto Pq = tensor<threadgroup metal_fp8_e4m3_format, dextents<int32_t, 2>, tensor_inline>(Pq_buf, extents<int32_t, {{BLOCK_DIMENSIONS_TRAVERSAL}}, {{BLOCK_DIMENSIONS_PARALLELIZATION}}>());', 'auto Pq_storage = tensor<threadgroup metal_fp8_e4m3_format, dextents<int32_t, 2>, tensor_inline>(Pq_buf, extents<int32_t, {{P_STRIDE}}, {{BLOCK_DIMENSIONS_PARALLELIZATION}}>());\n  auto Pq = Pq_storage.slice<{{BLOCK_DIMENSIONS_TRAVERSAL}}, {{BLOCK_DIMENSIONS_PARALLELIZATION}}>(0, 0);')
f=f.replace('idx[1] * {{BLOCK_DIMENSIONS_TRAVERSAL}}]', 'idx[1] * {{P_STRIDE}}]')
(out/'NAInt8AttentionKernel.cpp').write_text(prefix+f)
# Use exactly the current production archive except for this generator.
log=Path('/private/tmp/ccv-int8-register-production-build.log').read_text().splitlines()
lines=subprocess.check_output(['make','-n','-B','DEBUG=1','CC=clang++','lib'],cwd=root/'lib/nnc/mfa',text=True).splitlines()
line=next(l for l in lines if l.startswith('clang++ kernels/NAInt8AttentionKernel.cpp ') and ' -c ' in l);args=shlex.split(line);args[1]=str(out/'NAInt8AttentionKernel.cpp');args[args.index('-o')+1]=str(out/'NAInt8AttentionKernel.o');args+=['-I'+str(root/'lib/nnc/mfa/kernels')];subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
for wd,target,old,new,dst in [('lib/nnc/mfa','libnnc-compat-mfa.o','kernels/NAInt8AttentionKernel.o',out/'NAInt8AttentionKernel.o',out/'mfa.o'),('lib/nnc','libnnc.o','mfa/libnnc-compat-mfa.o',out/'mfa.o',out/'nnc.o')]:
 line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o '+target));args=shlex.split(line);args=[str(new) if x==old else x for x in args];args[-1]=str(dst);subprocess.run(args,cwd=root/wd,check=True)
line=next(l for l in log if l.startswith('ar rcs libccv.a '));args=shlex.split(line);args[2]=str(out/'libccv.a');args=[str(out/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];subprocess.run(args,cwd=root/'lib',check=True)
for source,name in [('bin/mfa/na_application_bench.cpp','probe'),('/private/tmp/ccv-int8-kv-partitions/accuracy.cpp','accuracy')]:
 args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0',source,str(out/'libccv.a')]
 for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
 args+=['-lsqlite3','-lz','-o',str(out/name)];subprocess.run(args,cwd=root,check=True)
