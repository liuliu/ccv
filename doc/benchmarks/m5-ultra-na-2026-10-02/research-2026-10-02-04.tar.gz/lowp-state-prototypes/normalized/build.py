from pathlib import Path
import subprocess,shlex
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-int8-normalized-chunked')
s=Path('/private/tmp/ccv-int8-half-chunked/NAInt8AttentionKernel.cpp').read_text()
a=s.index('void NAInt8AttentionKernel::loopForward');prefix=s[:a];s=s[a:]
# On this B1 unmasked/noncausal prototype C>=2048 always uses the main loop.
# Keep O as one quarter of the normalized weighted mean, bounding its magnitude
# instead of storing the unnormalized sum over thousands of columns in half.
a=s.index('  if (isCausal) {\n    source += R"(\n    #pragma clang loop unroll(full)')
z=s.index('  if (isCausal) {\n    source += R"(\n    if (causal_mask)',a)
rescale=s[a:z];s=s[:a]+s[z:]
needle='''        cL[k] += cL_new[k];
      }
    }
    thread pv_int8_left_tensor_t& cP_q_0'''
replacement='''        const float previous_L = cL[k];
        cL[k] += cL_new[k];
        correction[k] = fast::divide(previous_L, cL[k]);
        cL_new[k] = fast::divide(0.25f * v_scale_recip_127, cL[k]);
      }
    }
)";
'''+rescale+'''  source += R"(
    thread pv_int8_left_tensor_t& cP_q_0'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''        cO_{{LOOP_INDEX}}[k] += (float)cOq[k] * v_scale_recip_127;'''
replacement='''        auto it = output_index.get_iterator(k);
        auto l_it = cL_new.map_iterator(it);
        cO_{{LOOP_INDEX}}[k] += (float)cOq[k] * *l_it;'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('fast::divide(1, *dst_it)', '4.0f')
(out/'NAInt8AttentionKernel.cpp').write_text(prefix+s)
(out/'ccv_nnc_mfa_attention.cpp').write_text(Path('/private/tmp/ccv-int8-half-chunked/ccv_nnc_mfa_attention.cpp').read_text())
# Compile two replacements, preserving the current production objects elsewhere.
log=Path('/private/tmp/ccv-int8-register-production-build.log').read_text().splitlines()
compile_lines=subprocess.check_output(['make','-n','-B','DEBUG=1','CC=clang++','lib'],cwd=root/'lib/nnc/mfa',text=True).splitlines()
for source,old,inc in [('NAInt8AttentionKernel.cpp','kernels/NAInt8AttentionKernel.cpp','lib/nnc/mfa/kernels'),('ccv_nnc_mfa_attention.cpp','ccv_nnc_mfa_attention.cpp','lib/nnc/mfa')]:
 line=next(l for l in compile_lines if l.startswith('clang++ '+old+' ') and ' -c ' in l)
 args=shlex.split(line);args[1]=str(out/source);args[args.index('-o')+1]=str(out/source.replace('.cpp','.o'));args+=['-I'+str(root/inc)]
 subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o libnnc-compat-mfa.o'));args=shlex.split(line)
args=[str(out/'NAInt8AttentionKernel.o') if x=='kernels/NAInt8AttentionKernel.o' else str(out/'ccv_nnc_mfa_attention.o') if x=='ccv_nnc_mfa_attention.o' else x for x in args];args[-1]=str(out/'mfa.o');subprocess.run(args,cwd=root/'lib/nnc/mfa',check=True)
line=next(l for l in log if l.startswith('ld -r ') and l.endswith(' -o libnnc.o'));args=shlex.split(line);args=[str(out/'mfa.o') if x=='mfa/libnnc-compat-mfa.o' else x for x in args];args[-1]=str(out/'nnc.o');subprocess.run(args,cwd=root/'lib/nnc',check=True)
line=next(l for l in log if l.startswith('ar rcs libccv.a '));args=shlex.split(line);args[2]=str(out/'libccv.a');args=[str(out/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];subprocess.run(args,cwd=root/'lib',check=True)
args=['clang++','-std=c++17','-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0','bin/mfa/na_application_bench.cpp',str(out/'libccv.a')]
for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
args+=['-lsqlite3','-lz','-o',str(out/'probe')];subprocess.run(args,cwd=root,check=True)
