from pathlib import Path
import subprocess,os,csv,re
out=Path('/private/tmp/ccv-int8-normalized-chunked')
variants=[('current','/private/tmp/ccv-int8-half-chunked/accuracy-current',1),('half','/private/tmp/ccv-int8-half-chunked/accuracy',8),('normalized',str(out/'accuracy'),8)]
with (out/'accuracy.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['R','C','D','H','mode','variant','parts','cpu_l2','max_abs','exit_code'])
 for R,C,D,H in [(65,70186,128,4),(129,31018,128,4),(65,2049,128,4),(4097,4097,128,4),(513,8191,256,4)]:
  for mode in [0,1,2,3,4,5]:
   for name,exe,parts in variants:
    cmd=[exe,'attention',str(R),str(C),str(D),'1',str(H),str(H),'0','1','0','1','0','0']
    r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_PARTITIONS':str(parts),'CCV_NA_QUERY_CHUNK':'512','CCV_ACCURACY_MODE':str(mode),'CCV_NA_WARMUP_SECONDS':'0'},timeout=600)
    (out/f'accuracy-{R}-{C}-{D}-{mode}-{name}.log').write_text(r.stdout+r.stderr)
    err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout);mx=re.search(r'cpu_sample_max_abs=([0-9.e+-]+)',r.stdout)
    row=[R,C,D,H,mode,name,parts,err.group(1) if err else '',mx.group(1) if mx else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode not in [0,4]:raise SystemExit(r.returncode)
