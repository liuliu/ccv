from pathlib import Path
import json,csv,statistics,hashlib,shutil,tarfile
p=Path('/private/tmp/ccv-fp32-gemm-aspect');out=Path('/Users/liu/workspace/ccv/doc/benchmarks/m5-ultra-na-2026-10-02');prefix='inference-fp32-aspect-rejected'
s=json.loads((p/'sweep/summary.json').read_text());assert s['records']==594 and not s['failures']
changed=[c for c in s['cases'] if c['routes']['baseline']!=c['routes']['fp32']]
ratios=[c['medians']['fp32']/c['medians']['baseline'] for c in changed]
lines=['FP32 GEMM aspect-policy experiment, 2026-10-04 UTC','',
'Rejected: production remains inference-fp16-medium.txt. The isolated candidate',
'removes the K<3*N and M<N-or-M>=2*N conditions only for explicit FP32 requests.',
'The existing K<=16384, weight-footprint, layout, hardware and split-K limits',
'remain. No shader, tile or attention layout changes are involved.','',
'99 cases / 594 process records, all passing independent sampled CPU and finite',
'checks. There are 87 newly selected cases. Median candidate/production ratio',
f'is {statistics.median(ratios):.4f}; {sum(r>1.05 for r in ratios)} regress by more than 5%, worst {max(ratios):.3f}x.',
'The Local Code 4B FFN-down gap improves, but broad deep reductions lose.','',
'Paired medians, GPU milliseconds:','M N K flags | Current candidate actual_MLX | candidate/current']
for c in s['cases']:
    m,n,k=c['shape'];v=c['medians']
    if (m,n,k)==(3072,2560,9216) or (c in changed and v['fp32']/v['baseline']>1.1):
        lines.append(f"{m} {n} {k} {c['flags']} | {v['baseline']:.4f} {v['fp32']:.4f} {v['mlx']:.4f} | {v['fp32']/v['baseline']:.4f}")
lines+=['',
'These results reject a blanket accumulator-mode exemption; they do not justify',
'a special case for one Local Code matrix. The native MPP path is faster on',
'several larger shapes even with explicit FP32 accumulation, sometimes faster',
'than actual MLX. The follow-up tests native tensor base-pointer reuse instead',
'of adding a narrowly selected register exception. That is a separate experiment.',
'',
'Three warm iterations, >=.5 GPU seconds warmup, seven samples, two reversed',
'orders. GPU work is serial and follows all CPU compilation. Weights are already',
'expanded; bias/decode/casts are excluded. Explicit low-precision controls keep',
'their original route. The current production library and source remain unchanged.',
'Complete sources, commands, per-order results, logs and binary hashes are saved.',
'Backward remains deferred; no attention transpose is introduced.','']
(out/(prefix+'.txt')).write_text('\n'.join(lines))
for name in ['summary.json','manifest.json','sweep.csv']:shutil.copy2(p/'sweep'/name,out/(prefix+'-'+name))
for name in ['build.py','sweep.py','publish.py','provenance.json']:shutil.copy2(p/name,out/(prefix+'-'+name))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
files=sorted(f for f in p.rglob('*') if f.is_file() and f.suffix in ['.cpp','.json','.csv','.py','.log'] and f.name!='archive-index.json')
index={str(f.relative_to(p)):sha(f) for f in files};(p/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=out/(prefix+'-raw-logs.tar.gz')
with tarfile.open(archive,'w:gz') as t:
    for f in files+[p/'archive-index.json']:t.add(f,arcname=str(f.relative_to(p)))
with tarfile.open(archive,'r:gz') as t:
    for name,h in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
print(json.dumps(dict(records=594,entries=len(index)+1,archive_sha256=sha(archive)),indent=2))
