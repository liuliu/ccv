from pathlib import Path
import subprocess, os, re, json, csv, statistics

p=Path('/private/tmp/ccv-fp16-medium')
cases=[('flux2-768',[2304,6144,18432]),('krea2-768',[2560,6144,16384]),
       ('ideogram4-768',[2560,4608,12288]),('qwen21-768',[2304,4096,12288]),
       ('flux2-512',[1024,6144,18432]),('narrow',[2048,1536,6144]),
       ('medium-shallow',[2048,6144,6144]),('small-square',[2048,2048,8192]),
       ('flux2-k-neighbor',[2304,6144,16384]),('ideogram-k-neighbor',[2560,4608,8192]),
       ('partial',[2305,6145,18433]),('h3-480-output',[31018,5376,7168])]
variants=['baseline','medium','medium-unsplit','mlx']
(p/'manifest.json').write_text(json.dumps(dict(cases=cases,variants=variants,
    protocol='Isolated selector experiments, not production. FP16 GEMM then Float32 cast. Three warm iterations, .5 GPU seconds minimum, seven samples, two reversed orders. Numeric differences allowed across different accumulation paths; record sampled independent CPU relative L2 and all-output finite checks from probe. Serial actual MLX comparisons. Dynamic M enabled only for H3.'),indent=2)+'\n')
rows=[]
with (p/'pilot.csv').open('w') as f:
    fields=['order','case','M','N','K','flags','variant','gpu_median_ms','normalized_l2','output_sha256','exit']
    w=csv.DictWriter(f,fields);w.writeheader()
    for order in range(2):
        for name,shape in (cases if order==0 else cases[::-1]):
            for variant in (variants if order==0 else variants[::-1]):
                exe='/private/tmp/ccv-projection-cast/mlx' if variant=='mlx' else str(p/('probe-'+variant))
                flags=int(name.startswith('h3'))
                args=[exe,'matmul',*map(str,shape),'1','1','1','3','7','0']
                if variant!='mlx':args+=['0','0',str(flags)]
                env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5','CCV_NA_OUTPUT_CAST':'1','CCV_GEMM_FUSED_CAST':'0'}
                r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=600)
                stem=f'{order}-{name}-{variant}'
                (p/(stem+'.log')).write_text(r.stdout+r.stderr)
                (p/(stem+'.command.json')).write_text(json.dumps(dict(args=args,env={k:v for k,v in env.items() if k.startswith('CCV_')}),indent=2)+'\n')
                def metric(key):
                    m=re.search(r'(?<![A-Za-z_])'+key+r'=([^\s]+)',r.stdout)
                    return m.group(1) if m else ''
                row=dict(order=order,case=name,M=shape[0],N=shape[1],K=shape[2],flags=flags,variant=variant,
                         **{key:metric(key) for key in ['gpu_median_ms','normalized_l2','output_sha256']},exit=r.returncode)
                rows.append(row);w.writerow(row);f.flush();print(row,flush=True)
summary=[]
for name,shape in cases:
    values={v:[float(r['gpu_median_ms']) for r in rows if r['case']==name and r['variant']==v and r['exit']==0] for v in variants}
    summary.append(dict(case=name,shape=shape,samples=values,medians={v:statistics.median(a) if a else None for v,a in values.items()}))
(p/'summary.json').write_text(json.dumps(dict(records=len(rows),failures=[r for r in rows if r['exit']],cases=summary),indent=2)+'\n')
if any(r['exit'] for r in rows):raise SystemExit(1)
