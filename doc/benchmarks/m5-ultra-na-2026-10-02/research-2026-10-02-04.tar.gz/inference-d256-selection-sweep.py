from pathlib import Path
import subprocess,os,csv,re,json
out=Path('/private/tmp/ccv-d256-inference-selection')
cases=[
('r65',65,4096,1,18,18),('r128',128,4096,1,18,18),('r256',256,4096,1,18,18),('r512',512,4096,1,18,18),
('short64',4096,64,1,18,18),('short127',4096,127,1,18,18),('short128',4096,128,1,18,18),('short512',4096,512,1,18,18),
('square256',256,256,1,18,18),('square512',512,512,1,18,18),('square1024',1024,1024,1,18,18),('square2048',2048,2048,1,18,18),
('ideo1024',4352,4352,1,18,18),('ideo1536',9472,9472,1,18,18),('ideo2048',16640,16640,1,18,18),
('onehead',4096,4096,1,1,1),('twoheads',4096,4096,1,2,2),('wideheads',4096,4096,1,32,32),
('gqa',4352,4352,1,16,4),('b2',4352,4352,2,18,18),('b2gqa',4352,4352,2,16,4),
('rect_shortq',512,16384,1,18,18),('rect_shortkv',16384,512,1,18,18),('odd',4097,8191,1,18,18),('boundary',257,1025,1,2,2)]
(out/'cases.json').write_text(json.dumps(cases,indent=2))
variants=[('int8','/private/tmp/ccv-fp32-accumulator-current-probe',1),('fp16','/private/tmp/ccv-fp32-accumulator-current-probe',0),('mlx','/private/tmp/ccv-mlx-dsplit-fix/probe',0)]
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['pass','case','R','C','D','B','Hq','Hkv','variant','median_ms','cpu_l2','exit'])
 for order in range(2):
  for name,R,C,B,Hq,Hkv in (cases if order==0 else list(reversed(cases))):
   for variant,exe,int8 in (variants if order==0 else list(reversed(variants))):
    cmd=[exe,'attention',str(R),str(C),'256',str(B),str(Hq),str(Hkv),'3','7','0']
    if variant!='mlx':cmd += [str(int8),'0','0']
    r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
    (out/f'{order}-{name}-{variant}.log').write_text(r.stdout+r.stderr)
    med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
    row=[order,name,R,C,256,B,Hq,Hkv,variant,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode not in [0,4] or not med:raise SystemExit(r.returncode or 9)
