from pathlib import Path
import os, csv, json, re, subprocess, statistics, time

p = Path('/private/tmp/ccv-fused-cast-integration')
cases = []
for m, label in [(14878, '5s'), (31018, '480-ui-10s'), (70186, '720-ui-10s')]:
    for k, op in [(7168, 'attention-output'), (14336, 'ffn-down')]:
        cases.append(dict(id=f'h3-{label}-{op}', shape=[m, 5376, k], flags=1,
                          reshape=int(k == 7168), no_bias=1))
for size, flux_m, other_m in [(768, 2304, 2560), (2048, 16384, 16640)]:
    for model, m, n, k in [('flux2', flux_m, 6144, 18432),
                            ('krea2', other_m, 6144, 16384),
                            ('ideogram4', other_m, 4608, 12288),
                            ('qwen-image21', flux_m, 4096, 12288)]:
        cases.append(dict(id=f'{model}-{size}-ffn-down', shape=[m, n, k],
                          flags=0, reshape=0, no_bias=0))
for label, shape in [('flux2-1024-ffn-down', [4096, 6144, 18432]),
                     ('qwen-image21-512-fallback', [1024, 4096, 12288]),
                     ('partial-mnk', [8193, 1537, 4097]),
                     ('same-buffer', [4096, 2048, 4096])]:
    cases.append(dict(id=label, shape=shape, flags=0, reshape=int(label=='same-buffer'), no_bias=0))

operator_variants = ['fp16', 'int8-separate', 'int8-fused', 'mlx']
graph_variants = ['fp16-separate', 'fp16-composite', 'int8-separate', 'int8-fused']
graph_cases = [c for c in cases if '-5s-' not in c['id']]
manifest = dict(cases=cases, graph_cases=graph_cases,
    operator_variants=operator_variants, graph_variants=graph_variants,
    protocol='Serial GPU jobs; three warm iterations and at least .5 GPU seconds, seven samples, two reversed orders. Operator: actual production MFA GEMM plus Float32 cast, or fused half-rounded Float32 store, versus actual MLX FP16 matmul then astype(float32); no bias. Graph: actual CNNP scalar producer, optional contiguous reshape, GEMM, Float32 cast, scalar consumer; H3 has no bias, image/control graphs have bias. Graph fusion disabled via existing disableOpt flag in baseline. GPU time sums all command buffers; wall and GPU span also recorded. Full output SHA256 equality for same-precision before/after pairs; identical arena allocation required. FP16 composite intentionally falls back to the original pair. No transpose. Image graph cases are projection-plus-cast shape controls, not full model graphs.')
(p/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')

def metric(stdout, name):
    m = re.search(r'(?<![A-Za-z_])'+re.escape(name)+r'=([^\s]+)', stdout)
    return m.group(1) if m else ''

def run(kind, order, case, variant):
    env = {**os.environ, 'CCV_NA_WARMUP_SECONDS': '.5'}
    if kind == 'operator':
        env.update(CCV_NA_OUTPUT_CAST='1', CCV_GEMM_FUSED_CAST=str(int(variant=='int8-fused')))
        exe = '/private/tmp/ccv-projection-cast/mlx' if variant=='mlx' else str(p/'operator')
        args = [exe, 'matmul', *map(str, case['shape']), '1', '1', '1', '3', '7', '0']
        if variant != 'mlx':
            args += [str(int(variant.startswith('int8'))), '0', str(case['flags'])]
    else:
        env.update(CCV_GEMM_ATTENTION_RESHAPE=str(case['reshape']), CCV_GEMM_NO_BIAS=str(case['no_bias']))
        args = [str(p/'frontend'), *map(str, case['shape']), str(int(variant.startswith('int8'))),
                str(int(variant.endswith(('fused','composite')))), str(case['flags'])]
    start = time.time()
    result = subprocess.run(args, env=env, capture_output=True, text=True, timeout=600)
    stem = f'{kind}-{order}-{case["id"]}-{variant}'
    (p/(stem+'.log')).write_text(result.stdout+result.stderr)
    (p/(stem+'.command.json')).write_text(json.dumps(dict(args=args, env={k:v for k,v in env.items() if k.startswith('CCV_')}, start=start, elapsed=time.time()-start, exit=result.returncode), indent=2)+'\n')
    row = dict(kind=kind, order=order, case=case['id'], M=case['shape'][0], N=case['shape'][1], K=case['shape'][2], flags=case['flags'], variant=variant,
               **{name:metric(result.stdout,name) for name in ['gpu_median_ms', 'wall_median_ms', 'gpu_span_median_ms', 'command_buffers', 'arena_bytes', 'input_float_overlap', 'input_float_same_buffer', 'composites', 'cast_fused', 'normalized_l2', 'output_sha256']}, exit=result.returncode)
    if result.returncode:
        raise RuntimeError((stem, result.returncode, result.stdout[-1000:], result.stderr[-1000:]))
    assert float(row['gpu_median_ms'])>0, row
    if variant!='mlx':
        assert len(row['output_sha256'])==64, row
    if kind=='operator' and variant=='int8-fused':
        assert row['cast_fused']==str(int(case['shape'][0]>=2048)), row
    if kind=='graph':
        expected_fusion = variant=='int8-fused' and case['shape'][0]>=2048
        assert int(row['command_buffers'])==(3 if expected_fusion else 4), row
    return row

fields=['kind','order','case','M','N','K','flags','variant','gpu_median_ms','wall_median_ms','gpu_span_median_ms','command_buffers','arena_bytes','input_float_overlap','input_float_same_buffer','composites','cast_fused','normalized_l2','output_sha256','exit']
all_rows=[]
for kind, group, variants in [('operator',cases,operator_variants), ('graph',graph_cases,graph_variants)]:
    with (p/(kind+'.csv')).open('w') as f:
        writer=csv.DictWriter(f,fields);writer.writeheader();f.flush()
        for order in range(2):
            for c in (group if order==0 else group[::-1]):
                expected={}
                for variant in (variants if order==0 else variants[::-1]):
                    row=run(kind,order,c,variant)
                    writer.writerow(row);f.flush();all_rows.append(row)
                    print(kind,order,c['id'],variant,row['gpu_median_ms'],row['command_buffers'],flush=True)
                    precision=variant.split('-')[0]
                    if precision in ('fp16','int8'):
                        check=(row['output_sha256'],row['arena_bytes'])
                        if precision in expected:
                            assert expected[precision]==check,(kind,c['id'],precision,'full output or allocation differs')
                        expected[precision]=check

summary=[]
for kind, group, variants in [('operator',cases,operator_variants), ('graph',graph_cases,graph_variants)]:
    for c in group:
        rows=[r for r in all_rows if r['kind']==kind and r['case']==c['id']]
        v={variant:[float(r['gpu_median_ms']) for r in rows if r['variant']==variant] for variant in variants}
        entry=dict(kind=kind, **c, medians={k:statistics.median(a) for k,a in v.items()}, samples=v)
        if kind=='graph':
            entry['wall_medians']={variant:statistics.median(float(r['wall_median_ms']) for r in rows if r['variant']==variant) for variant in variants}
            entry['arena_bytes']=int(rows[0]['arena_bytes'])
        summary.append(entry)
(p/'summary.json').write_text(json.dumps(dict(records=len(all_rows),cases=summary),indent=2)+'\n')
