from pathlib import Path
import subprocess,csv,re,os,json
p=Path('/private/tmp/ccv-int8-partition-production')
manifest=json.loads(Path('/Users/liu/workspace/ccv/doc/benchmarks/m5-ultra-na-2026-10-02/priority-workloads.json').read_text())['workloads']
ids=['priority-flux2-2048','krea2-2048','qwen21-2048','ideogram4-1024','ideogram4-2048']
cases=[('h3-480-ui',[31018,31018,128,1,56,56]),('h3-720-ui',[70186,70186,128,1,56,56])]
for ident in ids:
 case=next(x for x in manifest if x['id']==ident)
 cases.append((ident,case['shape']))
(p/'fp16-graph-workloads.json').write_text(json.dumps(cases,indent=2))
with (p/'fp16-graph.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['pass','case','R','C','D','B','Hq','Hk','variant','median_ms','cpu_l2','exit'])
 for order in range(2):
  for case,shape in (cases if order==0 else list(reversed(cases))):
   R,C,D,B,Hq,Hk=shape
   for variant in (['fp16_inplace','int8_preference_inplace','mlx'] if order==0 else ['mlx','int8_preference_inplace','fp16_inplace']):
    if variant=='mlx':cmd=['/private/tmp/ccv-mlx-dsplit-fix/probe','attention',*map(str,[R,C,D,B,Hq,Hk,3,7,0])]
    else:cmd=[str(p/'frontend'),*map(str,[R,C,B,Hq,Hk,int(variant=="int8_preference_inplace"),1,1,2,1,D])]
    r=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
    (p/f'fp16-graph-{order}-{case}-{variant}.log').write_text(r.stdout+r.stderr)
    med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
    row=[order,case,*shape,variant,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
