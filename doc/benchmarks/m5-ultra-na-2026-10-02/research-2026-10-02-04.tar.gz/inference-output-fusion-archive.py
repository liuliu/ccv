from pathlib import Path
import csv, hashlib, json, shutil, statistics, tarfile, xml.etree.ElementTree as ET
root=Path('/Users/liu/workspace/ccv'); dest=root/'doc/benchmarks/m5-ultra-na-2026-10-02'
base=Path('/private/tmp/ccv-int8-output-fusion'); prod=Path('/private/tmp/ccv-int8-output-fusion-production')
prefix='inference-output-fusion'
folders={'pilot':base,'production':prod,'fma-reversed':Path('/private/tmp/ccv-int8-output-fusion-v2'),'probability-storage':Path('/private/tmp/ccv-int8-probability-storage'),'qk-init':Path('/private/tmp/ccv-int8-qk-init')}
for tag,folder in folders.items():
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ['.csv','.json'] and p.name!='recording-options.json':
   shutil.copyfile(p,dest/f'{prefix}-{tag}-{p.name}')
with tarfile.open(dest/f'{prefix}-sources.tar.gz','w:gz') as tar:
 for tag,folder in folders.items():
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.suffix in ['.py','.cpp','.m','.patch','.sha256']:
    tar.add(p,arcname=f'{tag}/{p.name}')
with tarfile.open(dest/f'{prefix}-raw-logs.tar.gz','w:gz') as tar:
 for tag,folder in folders.items():
  for p in sorted(folder.glob('*.log')):tar.add(p,arcname=f'{tag}/{p.name}')
# Export only events for the launched probe, resolving xctrace references.
events=[]
for mode,name in [(0,'trace-mode0-graphics-compiler-spill-events.xml'),(1,'trace-spills.xml'),(3,'trace-mode3-graphics-compiler-spill-events.xml')]:
 tree=ET.parse(base/name);ids={e.get('id'):e for e in tree.iter() if e.get('id')}
 for row in tree.findall('.//row'):
  values={e.tag:ids[e.get('ref')] if e.get('ref') else e for e in row}
  process=values['process']
  if not process.get('fmt','').startswith('probe ('):continue
  events.append({'mode':mode,'timestamp_ns':int(values['start-time'].text),'command_buffer':values['metal-command-buffer-id'].text,'encoder':values['uint64'].text,'spilled_bytes':int(values['size-in-bytes'].text),'process':process.get('fmt')})
(dest/f'{prefix}-spill-events.json').write_text(json.dumps(events,indent=2)+'\n')
for tag,folder,name in [('pilot',base,'broad.csv'),('pilot',base,'tiny-confirmation.csv'),('production',prod,'application.csv')]:
 if not (folder/name).exists():continue
 rows=list(csv.DictReader((folder/name).open()));groups={}
 for r in rows:
  if r['median_ms']:groups.setdefault(r['case'],{}).setdefault(r['variant'],[]).append(float(r['median_ms']))
 summary=[]
 for case,values in groups.items():
  row={'case':case,**{v:statistics.median(a) for v,a in values.items()}}
  current=row.get('current',row.get('fused'))
  if current:
   row['previous_over_current']=row['previous']/current
   if row.get('mlx'):row['mlx_over_current']=row['mlx']/current
  summary.append(row)
 (dest/f'{prefix}-{tag}-{name[:-4]}-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=[base/'probe',base/'batch-probe',base/'accuracy-pair',prod/'probe',prod/'frontend',prod/'accuracy-pair',root/'lib/libccv.a',root/'test/int/nnc/mpsblas.tests',root/'test/int/nnc/mpsdnn.tests',Path('/private/tmp/ccv-int8-partition-production/frontend'),Path('/private/tmp/ccv-mlx-dsplit-fix/probe'),root/'lib/nnc/mfa/kernels/NAInt8AttentionKernel.cpp',root/'test/int/nnc/mpsblas.tests.c']
paths.extend(f/'probe' for tag,f in folders.items() if tag not in ['pilot','production'])
files=[]
for p in paths:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 files.append({'path':str(p),'sha256':h.hexdigest(),'bytes':p.stat().st_size})
(dest/f'{prefix}-provenance.json').write_text(json.dumps({'CCV_HEAD':'6a611be1aab6470ae279115ae4eaf7e01bc87135','MLX_HEAD':'25532871329fe4cafdada9fa0941a1cdbfb3a9f2','DrawThings_HEAD':'afed99ce5981875e3b3aa7d19059a516c73c5f2f','files':files},indent=2)+'\n')
shutil.copyfile(prod/'archive.py',dest/f'{prefix}-archive.py')
