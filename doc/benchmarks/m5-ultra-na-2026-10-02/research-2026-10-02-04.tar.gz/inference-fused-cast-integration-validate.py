from pathlib import Path
import subprocess, time, json

p=Path('/private/tmp/ccv-fused-cast-integration')
root=Path('/Users/liu/workspace/ccv')
jobs=[('sweep', ['python3', str(p/'sweep.py')], root),
      ('mpsblas-full', ['./mpsblas.tests'], root/'test/int/nnc'),
      ('mpsdnn-full', ['./mpsdnn.tests'], root/'test/int/nnc')]
results=[]
for name,args,cwd in jobs:
    start=time.time()
    print('START',name,time.strftime('%Y-%m-%d %H:%M:%S %Z'),flush=True)
    with (p/(name+'.log')).open('w') as f:
        r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
    result=dict(name=name,args=args,cwd=str(cwd),start=start,seconds=time.time()-start,exit=r.returncode)
    results.append(result)
    (p/'validation.json').write_text(json.dumps(results,indent=2)+'\n')
    print('DONE',result,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
