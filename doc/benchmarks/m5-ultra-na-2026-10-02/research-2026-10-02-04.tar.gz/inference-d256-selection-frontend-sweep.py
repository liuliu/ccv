from pathlib import Path
import subprocess,csv,re,os
out=Path('/private/tmp/ccv-d256-inference-selection')
cases=[('ideo1024',4352,4352,1,18,18),('ideo1536',9472,9472,1,18,18),('ideo2048',16640,16640,1,18,18),('r65',65,4096,1,18,18),('b2',4352,4352,2,18,18),('gqa',4352,4352,1,16,4)]
variants=[('selected',1,0),('fp16',0,0),('saved_int8',1,1),('mlx',0,0)]
with (out/'frontend.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['pass','case','R','C','B','Hq','Hk','variant','gpu_median_ms','cpu_l2','exit'])
 for order in range(2):
  for name,R,C,B,Hq,Hk in (cases if order==0 else list(reversed(cases))):
   for variant,int8,saved in (variants if order==0 else list(reversed(variants))):
    if variant=='mlx':cmd=['/private/tmp/ccv-mlx-dsplit-fix/probe','attention',str(R),str(C),'256',str(B),str(Hq),str(Hk),'3','7','0']
    else:cmd=[str(out/'frontend'),*map(str,[R,C,B,Hq,Hk,int8,saved])]
    r=subprocess.run(cmd,text=True,capture_output=True,timeout=300,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'})
    (out/f'frontend-{order}-{name}-{variant}.log').write_text(r.stdout+r.stderr)
    med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
    row=[order,name,R,C,B,Hq,Hk,variant,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode or not med:raise SystemExit(r.returncode or 9)
