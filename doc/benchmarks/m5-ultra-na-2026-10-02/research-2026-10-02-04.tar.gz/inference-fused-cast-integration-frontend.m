#include "ccv.h"
#include "nnc/ccv_nnc.h"
#include "nnc/ccv_nnc_easy.h"
#include "nnc/ccv_nnc_internal.h"
#include "nnc/mps/ccv_nnc_mps.h"
#include "nnc/_ccv_cnnp_model.h"
#include "nnc/_ccv_nnc_graph.h"
#include "nnc/_ccv_nnc_symbolic_graph.h"
#include <CommonCrypto/CommonDigest.h>
#include <objc/runtime.h>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int cmp(const void* a,const void* b){double x=*(const double*)a,y=*(const double*)b;return (x>y)-(x<y);}
// Observe every submitted command buffer: the default queue policy commits
// after each operator, so timing only the first buffer omits the GEMM.
static NSMutableArray* captured;
static void (*original_commit)(id, SEL);
static void observed_commit(id buffer, SEL selector) {
  @synchronized(captured) { [captured addObject:buffer]; }
  original_commit(buffer, selector);
}
static double monotonic_seconds(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void describe(const char* name,ccv_nnc_tensor_t* t){
  if(!t){printf("%s=unallocated\n",name);return;}
  id<MTLBuffer> b=mpgetbuffer(t);
  printf("%s buffer=%p heap=%p heap_offset=%lu data_offset=%zu length=%lu\n",name,b,b.heap,(unsigned long)b.heapOffset,(size_t)t->dataof,(unsigned long)b.length);
}
static int overlaps(ccv_nnc_tensor_t* a,ccv_nnc_tensor_t* b){
  if(!a||!b)return 0;
  id<MTLBuffer> x=mpgetbuffer(a),y=mpgetbuffer(b);
  if(x!=y && (!x.heap || x.heap!=y.heap))return 0;
  size_t xb=(x.heap?x.heapOffset:0)+a->dataof,yb=(y.heap?y.heapOffset:0)+b->dataof;
  return xb<yb+ccv_nnc_tensor_data_size_without_padding(b->info)&&yb<xb+ccv_nnc_tensor_data_size_without_padding(a->info);
}
int main(int argc,char** argv){
  if(argc!=7)return 2;
  const int M=atoi(argv[1]),N=atoi(argv[2]),K=atoi(argv[3]),quantized=atoi(argv[4]),fused=atoi(argv[5]),dynamic=atoi(argv[6]);
  if(M<=0||N<=0||K<=0)return 2;
  const int reshape=getenv("CCV_GEMM_ATTENTION_RESHAPE")?atoi(getenv("CCV_GEMM_ATTENTION_RESHAPE")):0;
  const int no_bias=getenv("CCV_GEMM_NO_BIAS")?atoi(getenv("CCV_GEMM_NO_BIAS")):0;
  const int input_size=no_bias?2:3;
  @autoreleasepool{
    ccv_nnc_init();ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
    if(dynamic)ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
    ccv_nnc_tensor_t* hx=ccv_nnc_tensor_new(0,CPU_TENSOR_NHWC(16F,M,K),0);
    ccv_nnc_tensor_t* hw=ccv_nnc_tensor_new(0,CPU_TENSOR_NHWC(16F,N,K),0);
    ccv_nnc_tensor_t* hb=ccv_nnc_tensor_new(0,CPU_TENSOR_NHWC(16F,N),0);
    uint32_t state=17;
    for(int j=0;j<3;++j){ccv_nnc_tensor_t* t=j==0?hx:j==1?hw:hb;_Float16* data=(_Float16*)t->data.f16;
      for(size_t i=0;i<ccv_nnc_tensor_count(t->info);++i){state=state*1664525u+1013904223u;data[i]=(float)((int)(state>>16)-32768)*(j==1?1.f/sqrtf(K):0.5f)/32768;}}
    ccv_nnc_tensor_t* hwq=quantized?ccv_nnc_tensor_new(0,ccv_nnc_tensor_8i_rowwise(hw->info),0):hw;
    if(quantized){size_t size=ccv_nnc_tensor_data_size_without_padding(hwq->info);assert(ccv_nnc_quantize_8i_rowwise(hw->data.f16,CCV_16F,CCV_TENSOR_CPU_MEMORY,(size_t)N*K,K,0,0,hwq->data.u8,size)==size);}
    ccv_nnc_tensor_t* x=ccv_nnc_tensor_new(0,GPU_TENSOR_NHWC(000,16F,M,K),0);
    ccv_nnc_tensor_param_t wp=GPU_TENSOR_NHWC(000,16F,N,K);if(quantized)wp=ccv_nnc_tensor_8i_rowwise(wp);
    ccv_nnc_tensor_t* w=ccv_nnc_tensor_new(0,wp,0);
    ccv_nnc_tensor_t* bias=ccv_nnc_tensor_new(0,GPU_TENSOR_NHWC(000,16F,N),0);
    ccv_nnc_tensor_t* y=ccv_nnc_tensor_new(0,reshape?GPU_TENSOR_NHWC(000,32F,1,M,N):GPU_TENSOR_NHWC(000,32F,M,N),0);
    ccv_nnc_tensor_t* hy=ccv_nnc_tensor_new(0,reshape?CPU_TENSOR_NHWC(32F,1,M,N):CPU_TENSOR_NHWC(32F,M,N),0);
    ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(),ccv_nnc_no_hint,0,TENSOR_LIST(hx,hwq,hb),TENSOR_LIST(x,w,bias),0);
    ccv_cnnp_model_io_t sx=ccv_cnnp_input(),sw=ccv_cnnp_input(),sb=no_bias?0:ccv_cnnp_input();
    ccv_cnnp_model_io_t model_inputs[3]={sx,sw,sb};
    ccv_nnc_tensor_t* tensor_inputs[3]={x,w,bias};
    ccv_nnc_tensor_param_t input_params[3]={x->info,w->info,bias->info};
    const ccv_cnnp_cmd_exec_io_t input_map[3]={{.type=CCV_CNNP_IO},{.type=CCV_CNNP_IO},{.type=CCV_CNNP_IO}};
    ccv_cnnp_model_io_t sa=ccv_cnnp_model_apply(ccv_cnnp_scalar_mul(1.001,"producer"),MODEL_IO_LIST(sx));
    if(reshape)sa=ccv_cnnp_model_apply(ccv_cnnp_reshape(0,DIM_ALLOC(1,M,K),DIM_ALLOC(),DIM_ALLOC(),"attention_output_reshape"),MODEL_IO_LIST(sa));
    ccv_cnnp_model_t* gemm=ccv_cnnp_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE,TRANSPOSE(0,1)),ccv_nnc_no_hint,0,
      input_map,input_size,MODEL_CMD_EXEC_IO_LIST(CCV_CNNP_IO),1,"gemm");
    if(!fused)ccv_cnnp_model_set_flags(gemm,CCV_NNC_GRAPH_EXEC_DISABLE_OPT);
    ccv_cnnp_model_io_t gemm_inputs[3]={sa,sw,sb};
    ccv_cnnp_model_io_t sh=ccv_cnnp_model_apply(gemm,gemm_inputs,input_size);
    ccv_cnnp_model_io_t sf=ccv_cnnp_model_apply(ccv_cnnp_datatype_conversion(CCV_32F,0,"cast"),MODEL_IO_LIST(sh));
    ccv_cnnp_model_io_t sy=ccv_cnnp_model_apply(ccv_cnnp_scalar_mul(1.001,"consumer"),MODEL_IO_LIST(sf));
    ccv_cnnp_model_t* model=ccv_cnnp_model_new(model_inputs,input_size,MODEL_IO_LIST(sy),1,"projection_cast");
    ccv_cnnp_model_compile(model,input_params,input_size,CMD_NOOP(),CMD_NOOP());
    ccv_cnnp_model_evaluate(model,(ccv_cnnp_evaluate_param_t){.requires_grad=0,.is_test=1},tensor_inputs,input_size,TENSOR_LIST(y),0,0);
    ccv_nnc_graph_t* graph=model->compiled_data->graph;
    ccv_nnc_tensor_t* ia=0,*ih=0,*of=0;int composites=0;
    for(int i=0;i<graph->exec_info->rnum;++i){
      ccv_nnc_graph_exec_info_t* node=ccv_array_get(graph->exec_info,i);
      if(node->cmd.cmd==CCV_NNC_GEMM_FORWARD||ccv_nnc_mps_is_gemm_cast_cmd(node->cmd)){
        ia=node->inputs[0];ih=node->outputs[0];if(node->output_size==2)of=node->outputs[1];
      }
      if(ccv_nnc_mps_is_gemm_cast_cmd(node->cmd))++composites;
      if(node->cmd.cmd==CCV_NNC_DATATYPE_CONVERSION_FORWARD)of=node->outputs[0];
    }
    if(composites!=!!fused){
      fprintf(stderr,"graphmode=%d parallel=%d symbolic_subgraphs=%p compiled_subgraphs=%p\n",model->compiled_data->graph_mode,model->parallel_count,model->graph->sub_graphs,graph->sub_graphs);
      for(int i=0;i<graph->exec_info->rnum;++i){ccv_nnc_graph_exec_info_t* n=ccv_array_get(graph->exec_info,i);fprintf(stderr,"compiled %d cmd=%s backend=%u input=%d output=%d flags=%d io_flags=%p wraps=%d outgoings=%d\n",i,ccv_nnc_cmd_name(n->cmd.cmd),n->cmd.backend,n->input_size,n->output_size,n->flags,n->input_flags,n->tensor_wraps_ref,n->outgoings?n->outgoings->rnum:0);}
      for(int i=0;i<model->graph->exec_symbol_info->rnum;++i){ccv_nnc_graph_exec_symbol_info_t* n=ccv_array_get(model->graph->exec_symbol_info,i);fprintf(stderr,"symbol %d cmd=%s input=%d output=%d flags=%d outgoings=%d\n",i,ccv_nnc_cmd_name(n->cmd.cmd),n->input_size,n->output_size,n->flags,n->outgoings?n->outgoings->rnum:0);}
      for(int i=0;i<model->graph->tensor_symbol_info->rnum;++i){ccv_nnc_tensor_symbol_info_t* t=ccv_array_get(model->graph->tensor_symbol_info,i);fprintf(stderr,"tensor %d dtype=%d type=%d flags=%d alias=%d assign=%d pair=%d p=%d s=%p\n",i,t->info.datatype,t->info.type,t->flags,t->alias_ref,t->assign_ref,t->pair_ref,t->p_ref,t->s_ref);}
    }
    assert(ia&&ih&&of);assert(composites==!!fused);
    describe("internal_a",ia);describe("half_output",ih);describe("float_output",of);
    printf("composites=%d arena_bytes=%llu input_float_overlap=%d input_float_same_buffer=%d\n",composites,(unsigned long long)ccv_nnc_tensor_arena_size(model->compiled_data->tensor_arena),overlaps(ia,of),mpgetbuffer(ia)==mpgetbuffer(of));
    ccv_nnc_stream_context_t* stream=ccv_nnc_stream_context_new(CCV_STREAM_CONTEXT_GPU);
    id<MTLDevice> device=MTLCreateSystemDefaultDevice();
    id<MTLCommandQueue> queue=[device newCommandQueue];
    id<MTLCommandBuffer> example=[queue commandBuffer];
    Method method=class_getInstanceMethod(object_getClass(example),@selector(commit));
    captured=[[NSMutableArray alloc] init];
    original_commit=(void(*)(id,SEL))method_setImplementation(method,(IMP)observed_commit);
    double samples[7],wall_samples[7],span_samples[7],warm=0;int count=0;NSUInteger buffer_count=0;
    for(int iteration=0;count<7;++iteration){@autoreleasepool{
      [captured removeAllObjects];const double start=monotonic_seconds();
      ccv_cnnp_model_evaluate(model,(ccv_cnnp_evaluate_param_t){.requires_grad=0,.is_test=1},tensor_inputs,input_size,TENSOR_LIST(y),0,stream);ccv_nnc_stream_context_wait(stream);
      int status=CCV_NNC_EXEC_SUCCESS;
      const double elapsed=monotonic_seconds()-start;
      assert(status==CCV_NNC_EXEC_SUCCESS);
      double seconds=0,first=INFINITY,last=0;
      for(id<MTLCommandBuffer> cb in captured){assert(cb.status==MTLCommandBufferStatusCompleted);seconds+=cb.GPUEndTime-cb.GPUStartTime;first=fmin(first,cb.GPUStartTime);last=fmax(last,cb.GPUEndTime);}
      buffer_count=captured.count;assert(buffer_count>=3);warm+=seconds;
      if(iteration>=3&&warm>=0.5){samples[count]=seconds*1000;wall_samples[count]=elapsed*1000;span_samples[count]=(last-first)*1000;++count;}
    }}
    method_setImplementation(method,(IMP)original_commit);[captured release];[queue release];[device release];
    ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(),ccv_nnc_no_hint,0,TENSOR_LIST(y),TENSOR_LIST(hy),0);
    size_t size=ccv_nnc_tensor_data_size_without_padding(hy->info);assert(size<=UINT32_MAX);
    for(size_t i=0;i<(size_t)M*N;++i)if(!isfinite(hy->data.f32[i]))return 4;
    unsigned char hash[CC_SHA256_DIGEST_LENGTH];CC_SHA256(hy->data.u8,(CC_LONG)size,hash);
    qsort(samples,7,sizeof(double),cmp);qsort(wall_samples,7,sizeof(double),cmp);qsort(span_samples,7,sizeof(double),cmp);
    printf("command_buffers=%lu wall_median_ms=%.9g gpu_span_median_ms=%.9g\n",(unsigned long)buffer_count,wall_samples[3],span_samples[3]);
    printf("reshape=%d no_bias=%d\n",reshape,no_bias);
    printf("M=%d N=%d K=%d int8=%d fused=%d flags=%d gpu_median_ms=%.9g all_finite=1 composites=%d output_sha256=",M,N,K,quantized,fused,dynamic,samples[3],composites);
    for(int i=0;i<CC_SHA256_DIGEST_LENGTH;++i)printf("%02x",hash[i]);printf("\n");
    ccv_nnc_stream_context_free(stream);ccv_cnnp_model_free(model);
    ccv_nnc_tensor_free(hx);ccv_nnc_tensor_free(hw);if(quantized)ccv_nnc_tensor_free(hwq);ccv_nnc_tensor_free(hb);ccv_nnc_tensor_free(hy);ccv_nnc_tensor_free(x);ccv_nnc_tensor_free(w);ccv_nnc_tensor_free(bias);ccv_nnc_tensor_free(y);
  }return 0;
}
