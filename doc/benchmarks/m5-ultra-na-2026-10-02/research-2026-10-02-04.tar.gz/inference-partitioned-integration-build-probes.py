from pathlib import Path
import subprocess
p=Path('/private/tmp/ccv-int8-partition-production');root=Path('/Users/liu/workspace/ccv')
for name,source,compiler in [('probe',root/'bin/mfa/na_application_bench.cpp','clang++'),('accuracy',p/'accuracy.cpp','clang++'),('frontend',p/'frontend.m','clang')]:
 args=[compiler,'-O2','-g','-Wno-deprecated-declarations','-Ilib','-DCCV_NNC_MFA','-mmacosx-version-min=27.0']
 if compiler=='clang++':args+=['-std=c++17']
 args += [str(source),'lib/libccv.a']
 for f in ['Foundation','Metal','MetalPerformanceShaders','MetalPerformanceShadersGraph','QuartzCore','Accelerate','CoreML','IOSurface']:args+=['-framework',f]
 args+=['-lsqlite3','-lz']
 if compiler=='clang':args+=['-lc++']
 args+=['-o',str(p/name)];subprocess.run(args,cwd=root,check=True)
