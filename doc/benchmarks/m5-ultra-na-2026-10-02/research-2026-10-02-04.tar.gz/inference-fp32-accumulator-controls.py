from pathlib import Path
import subprocess,os,csv,re
out=Path('/private/tmp/ccv-fp32-accumulator-controls');out.mkdir(exist_ok=True)
cases=[(255,65,24576,0),(256,65,24576,1),(257,65,24577,1),(513,1536,8191,1),(4096,1536,2048,1),(6144,10923,24576,1),(31018,14336,5376,0)]
variants=[('previous','/private/tmp/ccv-fp32-accumulator-previous-probe'),('current','/private/tmp/ccv-fp32-accumulator-current-probe'),('mlx','/private/tmp/ccv-mlx-dsplit-fix/probe')]
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['M','N','K','dynamic_m','upcast','pass','variant','median_ms','cpu_l2','exit_code'])
 for order in range(2):
  for M,N,K,flags in (cases if order==0 else list(reversed(cases))):
   for upcast in [0,1]:
    for name,exe in (variants if order==0 else list(reversed(variants))):
     cmd=[exe,'matmul',str(M),str(N),str(K),'1','1','1','3','7','0']
     if name!='mlx':cmd+=['0',str(upcast),str(flags)]
     r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
     (out/f'{order}-{M}-{N}-{K}-{upcast}-{name}.log').write_text(r.stdout+r.stderr)
     med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
     row=[M,N,K,flags,upcast,order,name,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
     if r.returncode not in [0,4] or not med:raise SystemExit(r.returncode or 9)
