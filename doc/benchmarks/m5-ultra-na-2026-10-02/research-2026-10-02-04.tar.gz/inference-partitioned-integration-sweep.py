from pathlib import Path
import subprocess,csv,json,re,os
p=Path('/private/tmp/ccv-int8-partition-production')
# Inference uses DynamicGraph.no_grad with testing=false; the control uses a gradient-required CNNP graph.
cases=[('h3-480-patch',29146,29146,128,1,56,56),('h3-480-ui',31018,31018,128,1,56,56),('h3-720-patch',67306,67306,128,1,56,56),('h3-720-ui',70186,70186,128,1,56,56),('ideo-1024',4352,4352,256,1,18,18),('ideo-1536',9472,9472,256,1,18,18),('ideo-2048',16640,16640,256,1,18,18)]
with (p/'graph-paired.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['pass','case','R','C','D','B','Hq','Hk','variant','median_ms','cpu_l2','exit'])
 for order in range(2):
  for case,R,C,D,B,Hq,Hk in (cases if order==0 else list(reversed(cases))):
   variants=['previous_selection','inference','mlx'];variants=variants if order==0 else list(reversed(variants))
   for variant in variants:
    if variant=='mlx':cmd=['/private/tmp/ccv-mlx-dsplit-fix/probe','attention',*map(str,[R,C,D,B,Hq,Hk,3,7,0])]
    else:cmd=[str(p/'frontend'),*map(str,[R,C,B,Hq,Hk,1,1,int(variant=='inference'),2 if variant=='inference' else 1,0,D])]
    r=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
    (p/f'graph-{order}-{case}-{variant}.log').write_text(r.stdout+r.stderr)
    med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
    row=[order,case,R,C,D,B,Hq,Hk,variant,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
    if r.returncode:raise SystemExit(r.returncode)

# Integrated dynamic-shape selector confirmation after the paired application comparison.
cases=json.loads(Path('/private/tmp/ccv-int8-fused-centered/boundary-cases.json').read_text())
cases += [('small-image',[4352,4352,128,1,40,40]),('h3-short',[14878,14878,128,1,56,56]),('work-below',[8193,32767,128,1,32,8]),('work-at',[8193,32768,128,1,32,8]),('query-below',[4095,24577,128,1,48,12]),('query-at',[4096,24577,128,1,48,12]),('query-tail',[4097,24577,128,1,48,12]),('kv-below',[4097,24575,128,1,48,12]),('kv-at',[4097,24576,128,1,48,12]),('batch-fallback',[4097,24577,128,2,48,12])]
(p/'workloads.json').write_text(json.dumps(cases,indent=2))
with (p/'sweep.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['case','R','C','D','B','Hq','Hk','variant','median_ms','cpu_l2','exit'])
 for case,shape in cases:
  for name,exe in [('previous','/private/tmp/ccv-fp32-accumulator-current-probe'),('integrated',str(p/'probe'))]:
   r=subprocess.run([exe,'attention',*map(str,shape),'3','7','0','1','0','3'],capture_output=True,text=True,env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5'},timeout=600)
   (p/f'sweep-{case}-{name}.log').write_text(r.stdout+r.stderr)
   med=re.search(r'(?:gpu_)?median_ms=([0-9.]+)',r.stdout);err=re.search(r'normalized_l2=([0-9.e+-]+)',r.stdout)
   row=[case,*shape,name,med.group(1) if med else '',err.group(1) if err else '',r.returncode];w.writerow(row);f.flush();print(row,flush=True)
   if r.returncode:raise SystemExit(r.returncode)
