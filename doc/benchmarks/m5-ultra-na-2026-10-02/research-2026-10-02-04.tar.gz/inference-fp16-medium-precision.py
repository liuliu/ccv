from pathlib import Path
import os,subprocess,json,csv,re,statistics,time,hashlib
p=Path('/private/tmp/ccv-fp16-medium');out=p/'precision';out.mkdir(exist_ok=True)
cases={}
def add(label,m,n,k,flags=0,upcast=1,cast=0):
    key=(m,n,k,flags,upcast,cast)
    if key not in cases:cases[key]=dict(id=f'm{m}-n{n}-k{k}-f{flags}-u{upcast}-cast{cast}',labels=[],shape=[m,n,k],flags=flags,upcast=upcast,cast=cast)
    if label not in cases[key]['labels']:cases[key]['labels'].append(label)
for label,n,k,ms in [('flux2',6144,18432,[1024,2304,4096]),('krea2',6144,16384,[1280,2560,4352]),('ideogram4',4608,12288,[1280,2560,4352]),('qwen21',4096,12288,[1024,2304,4096])]:
    for m in ms:
        add(label+'-projection',m,n,n)
        add(label+'-up',m,k,n)
        add(label+'-down',m,n,k)
    add(label+'-down-cast',ms[1],n,k,cast=1)
for label,n,k in [('qwen35-4b',2560,9216),('qwen35-9b',4096,12288),('qwen35-27b',5120,17408)]:
    for m in [512,1024,2048,3072]:
        add(label+'-up',m,k,n,flags=1)
        add(label+'-down',m,n,k,flags=1)
    add(label+'-4k-control',4096,k,n)
for m,n,k in [(512,2048,8192),(512,2048,16384),(512,8192,8192),(1024,2048,8192),(3072,2048,8192),(3072,4096,8192)]:add('upcast-regression-control',m,n,k)
for n in [12287,12288,12289,16384]:
    for k in [2048,8192,24576]:add('low-row-area-boundary',512,n,k,upcast=0)
for n in [6143,6144,6145]:
    for k in [2048,8192,12288]:add('area-boundary',1024,n,k,upcast=0)
for n in [12288,16384]:
    for k in [2048,8192,24576]:add('upcast-low-row-area',512,n,k)
def route(c,variant):
    m,n,k=c['shape']
    minimum=4096 if variant=='baseline' else 512
    if m<minimum or n<1536:return 'native'
    split=m<n and k>=2*n and k<=32768 and m*n*4<=256*2**20
    unsplit=k>=2048 and (k<=8192 or (k<=16384 and k<3*n and (m<n or m>=2*n) and n*k*2<=192*2**20))
    if variant=='medium-unsplit' and m<4096:
        split=False;unsplit=k>=2048 and k<=32768
    return 'split' if split else 'register' if unsplit else 'native'

cases=list(cases.values())
for c in cases:
    # Skip a redundant fourth binary only when its actual dispatch is identical.
    c['variants']=['baseline','medium']+(['medium-unsplit'] if route(c,'medium')!=route(c,'medium-unsplit') else [])+['mlx']
    c['routes']={v:route(c,v) for v in c['variants'] if v!='mlx'}
manifest=dict(cases=cases,records_expected=sum(len(c['variants'])*2 for c in cases),
    protocol='Serial GPU execution. Three warm iterations and >=.5 GPU seconds; seven timed samples; two reversed orders. FP16 inputs/output with explicit FP32 accumulator request except the labeled low-precision area-boundary controls. Dense weights already expanded; decode excluded. Actual MLX linked from the local checkout, unchanged matmul. All CCV outputs finite, sampled independent CPU error from every process. Preserve failures without invented times. Different arithmetic order may change output hashes; no bitwise equivalence claim. Fourth variant omitted only for identical route/source. New selection is experimental and production remains unchanged.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('CASES',len(cases),'RECORDS',manifest['records_expected'],flush=True)
fields=['order','case','M','N','K','flags','cast','upcast','variant','route','gpu_median_ms','normalized_l2','output_sha256','exit','seconds']
rows=[]
with (out/'sweep.csv').open('w') as f:
    w=csv.DictWriter(f,fields);w.writeheader();f.flush()
    for order in range(2):
        for c in (cases if order==0 else cases[::-1]):
            for variant in (c['variants'] if order==0 else c['variants'][::-1]):
                exe='/private/tmp/ccv-projection-cast/mlx' if variant=='mlx' else str(p/('probe-'+variant))
                args=[exe,'matmul',*map(str,c['shape']),'1','1','1','3','7','0']
                if variant!='mlx':args+=['0',str(c['upcast']),str(c['flags'])]
                env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5','CCV_NA_OUTPUT_CAST':str(c['cast']),'CCV_GEMM_FUSED_CAST':'0'}
                start=time.time();r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=600)
                stem=f'{order}-{c["id"]}-{variant}'
                (out/(stem+'.log')).write_text(r.stdout+r.stderr)
                (out/(stem+'.command.json')).write_text(json.dumps(dict(args=args,env={k:v for k,v in env.items() if k.startswith('CCV_')},start=start,seconds=time.time()-start,exit=r.returncode),indent=2)+'\n')
                def metric(key):
                    m=re.search(r'(?<![A-Za-z_])'+key+r'=([^\s]+)',r.stdout)
                    return m.group(1) if m else ''
                row=dict(order=order,case=c['id'],M=c['shape'][0],N=c['shape'][1],K=c['shape'][2],flags=c['flags'],cast=c['cast'],upcast=c['upcast'],variant=variant,route=c['routes'].get(variant,'actual-mlx'),
                         **{key:metric(key) for key in ['gpu_median_ms','normalized_l2','output_sha256']},exit=r.returncode,seconds=time.time()-start)
                rows.append(row);w.writerow(row);f.flush()
                print(len(rows),order,c['id'],variant,row['gpu_median_ms'],row['normalized_l2'],'exit',r.returncode,flush=True)
summary=[]
for c in cases:
    values={v:[float(r['gpu_median_ms']) for r in rows if r['case']==c['id'] and r['variant']==v and r['exit']==0] for v in c['variants']}
    summary.append(dict(**c,samples=values,medians={v:statistics.median(a) if len(a)==2 else None for v,a in values.items()}))
(out/'summary.json').write_text(json.dumps(dict(records=len(rows),failures=[r for r in rows if r['exit']],cases=summary),indent=2)+'\n')
print('COMPLETE',len(rows),'FAILURES',sum(bool(r['exit']) for r in rows),flush=True)
