from pathlib import Path
import csv,json,hashlib,tarfile,shutil,statistics,re
p=Path('/private/tmp/ccv-fp16-medium');root=Path('/Users/liu/workspace/ccv');out=root/'doc/benchmarks/m5-ultra-na-2026-10-02';prefix='inference-fp16-medium'
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
validation=json.loads((p/'production/validation.json').read_text())
assert len(validation)==3 and all(r['exit']==0 and not r.get('failures') for r in validation)
stages={name:json.loads((p/name/'summary.json').read_text()) for name in ['wide','precision','guard','production']}
assert [(s['records'],len(s['failures'])) for s in stages.values()]==[(1600,0),(666,6),(214,0),(378,0)]
start=json.loads((p/'wide/provenance-start.json').read_text())
for path,h in start['binaries'].items():assert sha(Path(path))==h,path
build=json.loads((p/'production/build-provenance.json').read_text())
for path,h in build.items():assert sha(Path(path))==h,path
for name in ['mpsblas','mpsdnn']:
    text=(p/'production'/(name+'.log')).read_text(errors='replace')
    assert 'all test case(s) passed, congratulations!' in text,name
explore=[c for name in ['wide','precision','guard'] for c in stages[name]['cases']]
rows={name:list(csv.DictReader((p/name/'sweep.csv').open())) for name in stages}
provenance=dict(machine='Apple M5 Ultra, 80 GPU cores, 256GB, macOS 27.0.1',
    ccv_head='6a611be1aab6470ae279115ae4eaf7e01bc87135',mlx='25532871329fe4cafdada9fa0941a1cdbfb3a9f2',draw_things='afed99ce5981875e3b3aa7d19059a516c73c5f2f',
    frozen_baseline=start,production_build=build,validation=validation,
    exploratory_cases=len(explore),exploratory_shapes=len({tuple(c['shape']) for c in explore}),
    exploratory_requests=len({tuple(c['shape'])+(c['flags'],c.get('upcast',0),c['cast']) for c in explore}),
    max_sampled_relative_l2={name:max(float(r['normalized_l2']) for r in rs) for name,rs in rows.items()},
    note='FP16 GEMM dispatcher and its randomized regression are the only implementation files changed in this checkpoint. Earlier INT8 cast fusion remains retained. Source and baseline hashes were verified after validation. No staging or commits.')
(p/'production/final-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
cs=stages['production']['cases']
def table(cases):
    lines=['Workload                         M      N      K  acc cast | Previous  Retained  Actual MLX | less GPU time']
    for c in cases:
        m,n,k=c['shape'];v=c['medians'];name=c['labels'][0]
        lines.append(f"{name:<30} {m:6} {n:6} {k:6}  {'f32' if c['upcast'] else 'low':3} {c['cast']:4} | {v['baseline']:8.4f} {v['production']:8.4f} {v['mlx']:11.4f} | {(1-v['production']/v['baseline'])*100:7.2f}%")
    return lines
text=['Medium-row FP16 inference dispatch, 2026-10-03','',
'The register-GEMM minimum row count left measurable gaps at 768px image sizes',
'and Local Code prefill lengths. This checkpoint retains an accumulator-aware',
'extension of the existing dispatcher. Kernel source, tiling, the hardware helper,',
'attention layouts and INT8 selection are unchanged by this checkpoint.',
'',
'GPU milliseconds below are medians of two reversed-order process medians.',
'All matrices use FP16 input, weights and GEMM output. acc=f32 explicitly requests',
'FP32 accumulation; acc=low permits the existing lower-precision path. The selected',
'register implementation accumulates in FP32 in both modes. cast=1 includes the',
'following Float32 conversion for every implementation. Timings exclude weight',
'decode and bias; decoded weights and bias are exercised by the regression.',
'Actual MLX runs from the local checkout; these are not estimates or peak-rate',
'comparisons. They are operator times, not whole-model generation speedups.','',
'768px image projection / FFN surface']
text+=table([c for c in cs if '-768-' in c['labels'][0] and not c['cast']])
text+=['','Projection plus Float32 conversion']+table([c for c in cs if '-768-down-cast' in c['labels'][0]])
text+=['','Local Code prefill']+table([c for c in cs if c['labels'][0].startswith('qwen35')])
text+=['','Exact long H3 UI controls']+table([c for c in cs if 'h3-long-cast-control' in c['labels']])
text+=['','Retained rule and reasoning',
'Keep all previously selected M>=4096 cases. Within the existing contiguous NT,',
'one-batch FP16 IO support (N>=1536), additionally allow:',
'  - Explicit FP32 accumulator requests with M>=512.',
'  - Low-precision requests with M>=2048 and M*N>=4096*1536, except when the',
'    native wide MPP kernel has full N/K tiles (N divisible by 128, K by 512)',
'    and 2*N<=K<=8192. These compact moderate reductions retain the native path.',
'All preexisting unsplit K/aspect/weight-footprint limits and split-K rules remain.',
'Split-K still takes priority for M<N, K>=2*N, K<=32768 and <=256MiB per FP32',
'partial output. This also preserves the existing eight-partition / 2GiB bound.',
'The shared support helper is used for both encoding and decoded-weight scratch',
'reservation. Runtime dimensions and dispatch geometry remain encode-time values.',
'',
'FP32 requests benefit from register fragments even on smaller grids. A blanket',
'extension of low-precision requests loses 8-10% on M512/N12288/K8192 and',
'M1024/N6144/K8192; an output-area bound alone does not protect those rows.',
'M3072/N2048,K8192 and M3072/N3072,K8192 also favor the native profile. The',
'retained mode/row/grid rule preserves those wins. Full-tile qualification matters:',
'neighboring irregular N/K shapes cannot use that native profile and benefit from',
'register fragments. These are measured bounds, not inferred physical cache sizes.',
'No model-name conditions or additional chip-name gate are introduced.',
'',
'Simply enabling the unsplit register kernel is insufficient for wide deep FFNs.',
'For example the exploration measures FLUX.2 M2304/N6144/K18432 at approximately',
'4.47ms with split-K versus 6.02ms unsplit. Partition-major traversal and FP32',
'partial outputs contribute to the result beyond tile selection.',
'The imported register/split kernels and Ultra orientation derive from MLX PR',
'#4447, commit 2d27ab05fb7dcda69bb3c57abd74c0b3bc9a5a99. The local MIT',
'attribution is in lib/nnc/mfa/3rdparty/mlx/README. No new imported shader is added.',
'',
'Coverage and validation',
'Exploration: 353 stage cases, 346 distinct requests, 286 distinct matrix shapes,',
'2,480 process records. Wide sweep: 221 cases / 1600 records; precision and',
'Local Code: 99 / 666; neighboring guard and repeat checks: 33 / 214.',
'Final retained-production comparison: 63 cases / 378 records, all passing.',
'Three warm iterations and at least .5 GPU seconds precede seven timed samples.',
'Processes run serially in opposite orders; no CPU compilation overlaps GPU work.',
'Every process checks all outputs for finiteness and 64 sampled values against',
'an independent CPU reference. Float32 casts are checked exactly against FP16',
'outputs. Different accumulation paths may change rounding; no bitwise identity',
'between old and new FP16 paths is claimed.',
'Full final MPSBLAS: 301/301. Full final MPSDNN: 126/126. Both exit 0 with the',
'expected success message. The GEMM regression now contains 50 cases, comparing',
'16 dispersed rows against CPU GEMM over all N columns at 3e-3 absolute tolerance.',
'It covers signed randomized tensors, prior positive stress cases, both accumulator',
'modes, row/area/K/N boundaries, partial tiles, bias, dynamic M, repeated cache',
'entries, and palettized weights after the enlarged FP32 split scratch region.',
'Existing source cases keep their previous flags and positive-input coverage.',
'',
'Preserved failures and timing uncertainty',
'The precision exploration has six failed records, not six distinct shapes.',
'Both orders of the frozen baseline fail the 1% sampled relative-L2 limit at',
'M512/N12287/K24576 (1.1554%) and M512/N12289/K24576 (1.0620%). The broad',
'medium candidate also retains the latter native fallback and fails identically',
'in both orders. All outputs are finite. These explicitly low-precision stress',
'limitations remain outside the final extension, and are not valid speedup rows.',
'No tolerance was relaxed and no workaround is claimed for the odd-width cases.',
'All register-selected exploratory processes pass. The separate full randomized',
'regression provides stronger bias/tail/decode coverage than the timing probe.',
'',
'One M1024/N2560/K9216 FP32 candidate record measured 0.82225ms instead of the',
'other order\'s 0.46537ms, giving an apparent 21.8% two-pass regression. Both',
'original records are preserved. A specifically labeled repeat measured 0.46671',
'and 0.46546ms; MLX was 0.46863 and 0.46413ms. The production table provides',
'another independent paired measurement. This report does not delete the slow',
'record or present every exploratory paired aggregate as non-regressing.',
'',
'Remaining scope',
'The old deep-reduction aspect policy still leaves the Local Code Qwen 3.5 4B',
'M3072/N2560/K9216 case on its native FP32 path; its residual gap is shown above.',
'The broader unsplit prototype improves that case but regresses other measured',
'near-square low-precision cases, so that broader change is not retained here.',
'Small low-precision image shapes below the new row/area bounds remain on their',
'previous paths. This checkpoint does not assert parity for every possible shape.',
'',
'The prior inference INT8 cast fusion remains integrated and validated; see',
'inference-fused-cast-integration.txt. Latest long H3 INT8 attention remains',
'1.94x / 2.09x actual MLX for exact UI 480p/10s and 720p/10s; the source and',
'protocol are in inference-probability-bounds.txt. Some image INT8 cases remain',
'below the approximately-2x goal. No new backward tuning or SHD-to-HSD attention',
'transpose is included. Earlier actual MLX VJP comparisons remain in',
'priority-report.txt. The wider goal stays open. Nothing is staged or committed.',
'',
'Artifacts',
'Per-stage CSVs retain failures and each order; workloads and summary JSON retain',
'explicit accumulator/cast flags and selector predictions. Raw logs, commands,',
'before/after source snapshots, build logs, benchmark scripts, validation logs and',
'checksums are in the accompanying raw archive. The archive index is verified',
'against every entry after writing. Binary hashes identify the exact local builds.',
'See inference-fp16-medium-reproduce.txt for the build/run procedure.','']
(out/(prefix+'.txt')).write_text('\n'.join(text))
for name in stages:shutil.copy2(p/name/'sweep.csv',out/(prefix+'-'+name+'.csv'))
(out/(prefix+'-summary.json')).write_text(json.dumps(stages,indent=2)+'\n')
(out/(prefix+'-workloads.json')).write_text(json.dumps({name:json.loads((p/name/'manifest.json').read_text()) for name in stages},indent=2)+'\n')
shutil.copy2(p/'production/final-provenance.json',out/(prefix+'-provenance.json'))
shutil.copy2(p/'production/validation.json',out/(prefix+'-validation.json'))
for name in ['wide.py','precision.py','guard.py','production.py','analyze.py','validate.py','publish-medium.py']:
    shutil.copy2(p/name,out/(prefix+'-'+name))
reproduce='''Reproduce the medium-row FP16 inference checkpoint

Use the source snapshots and exact commands in the raw archive. Root checkout
includes earlier retained inference changes described by the adjacent reports.
The frozen baseline is the inference-fused-cast-integration checkpoint; only
ccv_nnc_mfa_gemm.cpp differs in its library from this checkpoint. The final
randomized MPS test also differs and is archived before/after.

The saved build-commands.json lists compiler/linker invocations for the isolated
baseline, medium and medium-unsplit libraries and probes. Before rebuilding,
adapt /private/tmp/ccv-fp16-medium paths to your extraction directory. Build the
baseline library with production-ccv_nnc_mfa_gemm.cpp, then the final library
with production/ccv_nnc_mfa_gemm.cpp. Complete all builds before GPU execution.
production/build-probe-command.json links the final probe to the root library.
The operator probe source is probe.cpp. No MLX GEMM modifications are used.
Use the existing actual-MLX probe and documented D256 JIT-signature-only fix
from inference-fused-cast-integration; it does not alter GEMM arithmetic.

Library / integration build commands used from the recorded root:
  make -C lib lib DEBUG=1 -j4
From test/int/nnc:
  make DEBUG=1 -o libccv.a mpsblas.tests.o
  make DEBUG=1 -o libccv.a -W mpsblas.tests.o -W mpsdnn.tests.o mpsblas.tests mpsdnn.tests

Run wide.py, precision.py and guard.py serially to reproduce the exploratory
requests. production.py compares frozen baseline, retained production and actual
MLX. Every .command.json records its exact args, environment, exit and duration.
validate.py runs the full MPSBLAS and MPSDNN suites then production.py serially.
Metal tests require unrestricted execution in this Codex sandbox.

Only cast=1 rows include the Float32 conversion. All rows use expanded weights;
weight decode is excluded from GPU timing. The randomized MPS test validates
palettized decode plus split scratch. The JSON route fields are selector
predictions from the saved dispatcher, not a separate GPU profiling counter.
Failures stay in the CSVs; do not turn them into successful speedup rows.
'''
(out/(prefix+'-reproduce.txt')).write_text(reproduce)
files=[]
for name in stages:
    files.extend(x for x in (p/name).rglob('*') if x.is_file() and x.suffix in ['.cpp','.c','.json','.csv','.py','.txt','.log'])
for name in ['probe.cpp','production-ccv_nnc_mfa_gemm.cpp','build.py','build-commands.json','wide.py','precision.py','guard.py','analyze.py','analysis.json','production.py','validate.py','publish-medium.py','medium/ccv_nnc_mfa_gemm.cpp','medium-unsplit/ccv_nnc_mfa_gemm.cpp']:
    files.append(p/name)
files=sorted(set(files));index={str(f.relative_to(p)):sha(f) for f in files}
(p/'medium-archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=out/(prefix+'-raw-logs.tar.gz')
with tarfile.open(archive,'w:gz') as t:
    for f in files+[p/'medium-archive-index.json']:t.add(f,arcname=str(f.relative_to(p)))
with tarfile.open(archive,'r:gz') as t:
    for name,h in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h,name
result=dict(records=sum(s['records'] for s in stages.values()),failed_records=sum(len(s['failures']) for s in stages.values()),archive_entries=len(index)+1,archive_sha256=sha(archive))
(out/(prefix+'-archive.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
