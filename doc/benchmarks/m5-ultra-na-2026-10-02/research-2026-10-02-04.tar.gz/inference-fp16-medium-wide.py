from pathlib import Path
import os,subprocess,json,csv,re,statistics,time,hashlib

p=Path('/private/tmp/ccv-fp16-medium');out=p/'wide';out.mkdir(exist_ok=True)
cases={}
def add(label,m,n,k,flags=0,cast=0):
    key=(m,n,k,flags,cast)
    if key not in cases:cases[key]=dict(id=f'm{m}-n{n}-k{k}-f{flags}-cast{cast}',labels=[],shape=[m,n,k],flags=flags,cast=cast)
    if label not in cases[key]['labels']:cases[key]['labels'].append(label)

# Continuous row coverage for the application FFN-down dimensions.
models=[('flux2',6144,18432),('krea2',6144,16384),('ideogram4',4608,12288),('qwen21',4096,12288)]
for label,n,k in models:
    for m in [511,512,513,1024,1280,1536,1984,2048,2304,2560,3072,4095,4096]:add(label+'-rows',m,n,k)

# Separate output width, reduction depth and output-grid size effects.
for m in [512,1024,2048,3072]:
    for n in [1536,2048,4096,8192]:
        for k in [2048,8192,16384,32768]:add('grid-depth',m,n,k)
for m in [1536,2048,2304,3072]:
    for k in [9216,12288,18432,20480,24576,28672]:add('continuous-depth',m,6144,k)

# Full/partial tiles and the existing support / split / scratch boundaries.
for m,n,k in [(511,1536,4096),(512,1535,4096),(512,1536,2047),(512,1536,2048),
              (513,1537,2049),(1025,4097,8193),(2047,6144,18432),(2049,6144,18432),
              (2303,6144,18432),(2305,6145,18433),(2559,4607,12287),(2561,4609,12289),
              (3073,8193,16385),(4095,16384,32768),(4096,16384,32768),(4097,16384,32768),
              (2048,16385,32768),(2048,16384,32769),(2304,8192,12287),
              (2304,8192,12288),(2304,8192,12289),(3072,3072,8192),
              (3072,3073,8192),(3072,3072,12288),(3072,1536,12288)]:add('boundaries',m,n,k)
for m,n in [(1024,4096),(2048,6144),(3072,8192)]:
    for k in [2*n-1,2*n,2*n+1,3*n-1,3*n,3*n+1]:add('ratio-boundaries',m,n,k)

# Project / up matrices also pass through the same selector.
for label,n,k in models:
    m=2304 if label in ['flux2','qwen21'] else 2560
    for mm in [1024,m,3072]:
        add(label+'-projection',mm,n,n)
        add(label+'-ffn-up',mm,k,n)
    add(label+'-down-dynamic',m,n,k,1)
    add(label+'-down-cast',m,n,k,0,1)
for m,n,k in [(513,1537,2049),(2049,6144,18432),(2305,6145,18433),
              (2304,8192,12289),(3072,1536,12288),(4095,16384,32768)]:add('dynamic-boundaries',m,n,k,1)
for m in [31018,70186]:
    for n,k in [(5376,7168),(5376,14336),(7168,5376),(14336,5376)]:add('h3-long-control',m,n,k,1)
for label,m,n,k in [('flux2',16384,6144,18432),('krea2',16640,6144,16384),
                    ('ideogram4',16640,4608,12288),('qwen21',16384,4096,12288)]:add(label+'-2048-control',m,n,k)

def route(c,variant):
    m,n,k=c['shape']
    minimum=4096 if variant=='baseline' else 512
    if m<minimum or n<1536:return 'native'
    split=m<n and k>=2*n and k<=32768 and m*n*4<=256*2**20
    unsplit=k>=2048 and (k<=8192 or (k<=16384 and k<3*n and (m<n or m>=2*n) and n*k*2<=192*2**20))
    if variant=='medium-unsplit' and m<4096:
        split=False;unsplit=k>=2048 and k<=32768
    return 'split' if split else 'register' if unsplit else 'native'

cases=list(cases.values())
for c in cases:
    # Skip a redundant fourth binary only when its actual dispatch is identical.
    c['variants']=['baseline','medium']+(['medium-unsplit'] if route(c,'medium')!=route(c,'medium-unsplit') else [])+['mlx']
    c['routes']={v:route(c,v) for v in c['variants'] if v!='mlx'}
manifest=dict(cases=cases,records_expected=sum(len(c['variants'])*2 for c in cases),
    protocol='Serial GPU execution. Three warm iterations and >=.5 GPU seconds; seven timed samples; two reversed orders. Pure FP16 GEMM except explicit cast controls. Actual MLX linked from the local checkout, unchanged matmul. All CCV outputs finite, sampled independent CPU error from every process. Preserve failures without invented times. Different arithmetic order may change output hashes; no bitwise equivalence claim. Fourth variant omitted only for identical route/source. New selection is experimental and production remains unchanged.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('CASES',len(cases),'RECORDS',manifest['records_expected'],flush=True)
fields=['order','case','M','N','K','flags','cast','variant','route','gpu_median_ms','normalized_l2','output_sha256','exit','seconds']
rows=[]
with (out/'sweep.csv').open('w') as f:
    w=csv.DictWriter(f,fields);w.writeheader();f.flush()
    for order in range(2):
        for c in (cases if order==0 else cases[::-1]):
            for variant in (c['variants'] if order==0 else c['variants'][::-1]):
                exe='/private/tmp/ccv-projection-cast/mlx' if variant=='mlx' else str(p/('probe-'+variant))
                args=[exe,'matmul',*map(str,c['shape']),'1','1','1','3','7','0']
                if variant!='mlx':args+=['0','0',str(c['flags'])]
                env={**os.environ,'CCV_NA_WARMUP_SECONDS':'.5','CCV_NA_OUTPUT_CAST':str(c['cast']),'CCV_GEMM_FUSED_CAST':'0'}
                start=time.time();r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=600)
                stem=f'{order}-{c["id"]}-{variant}'
                (out/(stem+'.log')).write_text(r.stdout+r.stderr)
                (out/(stem+'.command.json')).write_text(json.dumps(dict(args=args,env={k:v for k,v in env.items() if k.startswith('CCV_')},start=start,seconds=time.time()-start,exit=r.returncode),indent=2)+'\n')
                def metric(key):
                    m=re.search(r'(?<![A-Za-z_])'+key+r'=([^\s]+)',r.stdout)
                    return m.group(1) if m else ''
                row=dict(order=order,case=c['id'],M=c['shape'][0],N=c['shape'][1],K=c['shape'][2],flags=c['flags'],cast=c['cast'],variant=variant,route=c['routes'].get(variant,'actual-mlx'),
                         **{key:metric(key) for key in ['gpu_median_ms','normalized_l2','output_sha256']},exit=r.returncode,seconds=time.time()-start)
                rows.append(row);w.writerow(row);f.flush()
                print(len(rows),order,c['id'],variant,row['gpu_median_ms'],row['normalized_l2'],'exit',r.returncode,flush=True)
summary=[]
for c in cases:
    values={v:[float(r['gpu_median_ms']) for r in rows if r['case']==c['id'] and r['variant']==v and r['exit']==0] for v in c['variants']}
    summary.append(dict(**c,samples=values,medians={v:statistics.median(a) if len(a)==2 else None for v,a in values.items()}))
(out/'summary.json').write_text(json.dumps(dict(records=len(rows),failures=[r for r in rows if r['exit']],cases=summary),indent=2)+'\n')
print('COMPLETE',len(rows),'FAILURES',sum(bool(r['exit']) for r in rows),flush=True)
