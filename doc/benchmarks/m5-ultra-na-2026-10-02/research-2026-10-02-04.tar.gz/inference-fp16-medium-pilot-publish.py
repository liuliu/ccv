from pathlib import Path
import json,csv,hashlib,tarfile,shutil

p=Path('/private/tmp/ccv-fp16-medium');root=Path('/Users/liu/workspace/ccv')
out=root/'doc/benchmarks/m5-ultra-na-2026-10-02';prefix='inference-fp16-medium-pilot'
s=json.loads((p/'summary.json').read_text());rows=list(csv.DictReader((p/'pilot.csv').open()))
assert s['records']==len(rows)==96 and not s['failures']
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(p/'baseline.a')==sha(root/'lib/libccv.a')
assert sha(p/'production-ccv_nnc_mfa_gemm.cpp')==sha(root/'lib/nnc/mfa/ccv_nnc_mfa_gemm.cpp')
provenance=dict(binaries={str(x):sha(x) for x in [p/'probe-baseline',p/'probe-medium',p/'probe-medium-unsplit',p/'baseline.a',Path('/private/tmp/ccv-projection-cast/mlx')]},
    production_dispatch_sha256=sha(root/'lib/nnc/mfa/ccv_nnc_mfa_gemm.cpp'),
    baseline='Retained production at inference-fused-cast-integration.txt; no production edits in this pilot.',
    max_sampled_relative_l2=max(float(x['normalized_l2']) for x in rows))
(p/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
text=['Medium-row FP16 inference dispatch pilot, 2026-10-03','',
'The broader fused-cast sweep exposed FP16 gaps on the 768px image projections.',
'This isolated follow-up establishes a concrete candidate without changing the',
'validated production dispatcher. It does not yet justify a final selector.',
'',
'The current register-GEMM support check starts at M4096. The medium candidate',
'lowers that threshold to M512 while preserving every other existing layout,',
'dtype, hardware, orientation, aspect, reduction and scratch bound. It retains',
'the existing split-K choice for M<N and K>=2N. A second candidate disables',
'split-K below M4096 and enables unsplit register GEMM there for K<=32768.',
'Both are scratch libraries linked from the same current objects, replacing',
'only ccv_nnc_mfa_gemm.cpp. No production selector or shader is edited.',
'',
'This reuses existing register-fragment kernels and the single measured-device',
'helper. No attention transpose or backward tuning is involved. Actual MLX is',
'the same local revision/binary used by the production integration report.',
'MLX matmul.cpp:994 selects NAX split-K at K>=3*max(M,N); its regular path is',
'used below that threshold. CCV already selects split-K more broadly for wide',
'outputs based on the earlier large-row measurements. The pilot tests whether',
'that choice also helps these medium-row shapes.',
'',
'GPU milliseconds; median of two reversed-order process medians. All variants',
'include FP16 GEMM and its following Float32 conversion, without bias. The',
'current/medium ratio measures the candidate improvement; MLX is actual execution.',
'Case                       M     N     K | Current  Medium  Unsplit | MLX | Current/medium']
for c in s['cases']:
    v=c['medians'];text.append(f"{c['case']:<24} {c['shape'][0]:5} {c['shape'][1]:5} {c['shape'][2]:5} | {v['baseline']:7.4f} {v['medium']:7.4f} {v['medium-unsplit']:7.4f} | {v['mlx']:7.4f} | {v['baseline']/v['medium']:.3f}x")
text+=['','Findings',
'- FLUX.2 768px drops from 6.590 ms to 4.550 ms, matching MLX. The unsplit',
'  candidate takes 6.030 ms, so changing tile/source choice alone misses most',
'  of this gain; partitioned reduction and traversal matter.',
'- Ideogram drops from 3.210 ms to 2.551 ms versus MLX 2.733 ms. Qwen drops',
'  from 2.252 ms to 2.030 ms versus MLX 2.034 ms. Krea improves modestly.',
'- Blanket extension has tradeoffs: M2048/N2048/K8192 is about 4.2% slower,',
'  and M2048/N6144/K6144 is about 2% slower. The M1024 FLUX control is unchanged.',
'  No final bound is inferred from only these twelve shapes.',
'- The partial M/N/K neighbor also benefits. The unchanged long H3 output',
'  projection control is stable. Dynamic M is enabled for H3 only in this pilot.',
'',
'Validation and next step',
'All 96 processes pass the existing independent sampled CPU-reference checks;',
'every CCV output is finite and every cast output is exactly half-representable.',
f"Largest sampled relative L2 over all variants: {provenance['max_sampled_relative_l2']:.9g}.",
'Different accumulation paths can change rounded outputs; this pilot does not',
'claim bitwise equivalence or randomized full-surface accuracy for the candidates.',
'Three warm iterations, at least .5 GPU seconds, seven samples, two orders;',
'all compilation finished before serial GPU timing. Candidate libraries were',
'built after the final production MPS suites; no compilation overlapped them.',
'',
'Before retaining a selector extension, sweep neighboring row counts, output',
'areas, N/M and K/N ratios, K-depth and scratch boundaries, fixed/dynamic M,',
'then add randomized bias/tail/cache/decode checks for the retained region.',
'Preserve the existing single hardware profile and prefer geometric rules.',
'The retained implementation and its 301/301 MPSBLAS, 126/126 MPSDNN and 61/61',
'CNNP validation remain those in inference-fused-cast-integration.txt. Nothing',
'is staged or committed. The wider parity/approximately-2x goal remains open.','']
(out/(prefix+'.txt')).write_text('\n'.join(text))
for name in ['pilot.csv','summary.json','manifest.json','provenance.json','build.py','pilot.py','publish.py','investigation.txt']:
    shutil.copy2(p/name,out/(prefix+'-'+name))
files=[x for x in p.rglob('*') if x.is_file() and x.suffix in ['.cpp','.json','.csv','.py','.txt','.log'] and x.name!='archive-index.json']
index={str(x.relative_to(p)):sha(x) for x in files};(p/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=out/(prefix+'-raw-logs.tar.gz')
with tarfile.open(archive,'w:gz') as t:
    for x in sorted(files)+[p/'archive-index.json']:t.add(x,arcname=str(x.relative_to(p)))
with tarfile.open(archive,'r:gz') as t:
    for name,digest in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==digest,name
print(json.dumps(dict(records=len(rows),archive_entries=len(index)+1,archive_sha256=sha(archive)),indent=2))
