from pathlib import Path
import subprocess, shlex, json, shutil, hashlib

root=Path('/Users/liu/workspace/ccv');p=Path('/private/tmp/ccv-fp16-medium')
commands=[]
def run(args,cwd):
    commands.append(dict(args=args,cwd=str(cwd)))
    subprocess.run(args,cwd=cwd,check=True)

# Run only after the preceding serial GPU validation finishes.
source=root/'lib/nnc/mfa/ccv_nnc_mfa_gemm.cpp'
original=source.read_text();(p/'production-ccv_nnc_mfa_gemm.cpp').write_text(original)
shutil.copy2(root/'lib/libccv.a',p/'baseline.a')
build=json.loads(Path('/private/tmp/ccv-gemm-fused-cast/build-commands.json').read_text())
compile_command=next(x for x in build if x['args'][0]=='clang++' and x['args'][1].endswith('/ccv_nnc_mfa_gemm.cpp'))
log=Path('/private/tmp/ccv-int8-register-mid-production/build-lib.log').read_text().splitlines()
for variant in ['medium','medium-unsplit']:
    d=p/variant;d.mkdir(exist_ok=True)
    s=original.replace('params.M >= 4096 && params.N >= 1536 &&','params.M >= 512 && params.N >= 1536 &&',1)
    assert s!=original
    if variant=='medium-unsplit':
        s=s.replace('return _ccv_nnc_mfa_register_matmul_supported(params) && params.M < params.N &&',
                    'return params.M >= 4096 && _ccv_nnc_mfa_register_matmul_supported(params) && params.M < params.N &&',1)
        s=s.replace('const bool register_unsplit = params.K >= 2048 && (params.K <= 8192 ||',
                    'const bool register_unsplit = params.K >= 2048 && ((params.M < 4096 && params.K <= 32768) || params.K <= 8192 ||',1)
    (d/'ccv_nnc_mfa_gemm.cpp').write_text(s)
    args=compile_command['args'].copy();args[1]=str(d/'ccv_nnc_mfa_gemm.cpp');args[args.index('-o')+1]=str(d/'ccv_nnc_mfa_gemm.o')
    run(args,Path(compile_command['cwd']))
    replacements={'ccv_nnc_mfa_gemm.o':str(d/'ccv_nnc_mfa_gemm.o')}
    for suffix,cwd,replace,output in [(' -o libnnc-compat-mfa.o','lib/nnc/mfa',replacements,'mfa.o'),(' -o libnnc.o','lib/nnc',{'mfa/libnnc-compat-mfa.o':str(d/'mfa.o')},'nnc.o')]:
        args=shlex.split(next(x for x in log if x.startswith('ld -r ') and x.endswith(suffix)))
        args=[replace.get(x,x) for x in args];args[-1]=str(d/output);run(args,root/cwd)
    args=shlex.split(next(x for x in log if x.startswith('ar rcs libccv.a ')))
    args[2]=str(d/'libccv.a');args=[str(d/'nnc.o') if x=='nnc/libnnc.o' else x for x in args];run(args,root/'lib')

shutil.copy2('/private/tmp/ccv-fused-cast-integration/operator.cpp',p/'probe.cpp')
probe_command=json.loads(Path('/private/tmp/ccv-fused-cast-integration/build-probes.json').read_text())[1]
for variant in ['baseline','medium','medium-unsplit']:
    args=probe_command['args'].copy()
    args=[str(p/'probe.cpp') if x.endswith('/ccv-fused-cast-integration/operator.cpp') else str(p/'baseline.a' if variant=='baseline' else p/variant/'libccv.a') if x=='lib/libccv.a' else x for x in args]
    args[args.index('-o')+1]=str(p/('probe-'+variant));run(args,root)
(p/'build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
assert hashlib.sha256(source.read_bytes()).digest()==hashlib.sha256(original.encode()).digest()
print('Built isolated medium-row FP16 variants; production unchanged.')
