from pathlib import Path
import hashlib,io,json,shutil,tarfile

root=Path('/Users/liu/workspace/ccv/doc/benchmarks/m5-ultra-na-2026-10-02')
work=Path('/private/tmp/ccv-m5-handoff')
backup=work/'research-loose-backup'
archive=root/'research-2026-10-02-04.tar.gz'
index_path=root/'research-index.json'
meta=json.loads(index_path.read_text());index=dict(meta['files'])
assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['archive_sha256']
dirs=[root/'kv-partition-prototypes',root/'lowp-state-prototypes']
extras=sorted(f for d in dirs for f in d.rglob('*') if f.is_file())
assert len(extras)==68
shutil.copy2(archive,backup/'before-prototypes-research.tar.gz')
shutil.copy2(index_path,backup/'before-prototypes-research-index.json')
temporary=work/'research-with-prototypes.tar.gz'
with tarfile.open(archive) as old,tarfile.open(temporary,'w:gz') as new:
    for info in old:
        if info.isfile():
            data=old.extractfile(info).read()
            assert hashlib.sha256(data).hexdigest()==index[info.name],info.name
            new.addfile(info,io.BytesIO(data))
        else:new.addfile(info)
    for f in extras:
        name=str(f.relative_to(root))
        assert name not in index,name
        index[name]=hashlib.sha256(f.read_bytes()).hexdigest()
        new.add(f,arcname=name)
with tarfile.open(temporary) as check:
    for name,value in index.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==value,name
shutil.copy2(temporary,archive)
meta.update(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=index)
index_path.write_text(json.dumps(meta,indent=2)+'\n')
for d in dirs:
    destination=backup/('archived-'+d.name)
    assert not destination.exists()
    shutil.move(str(d),str(destination))
print('Research archive verified:',len(index),'files; loose prototype directories moved to private backup.')
