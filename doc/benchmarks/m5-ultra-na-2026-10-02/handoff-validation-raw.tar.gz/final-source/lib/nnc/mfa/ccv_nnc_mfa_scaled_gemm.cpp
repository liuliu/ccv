#include "ccv_nnc_mfa.hpp"
using namespace ccv::nnc;

#include "kernels/ShaderCache.hpp"
#include "kernels/NAInt8MatMulKernel.hpp"
#include "kernels/NAInt8MatMulKernelDescriptor.hpp"
#include "kernels/NAInt8MatMulDescriptor.hpp"
#include "kernels/NARegisterMatMulDescriptor.hpp"
#include "kernels/NARegisterMatMulKernel.hpp"
#include "kernels/NAMatMulTuning.hpp"
#include "kernels/NAInt8MatMulSmallMKernel.hpp"
#include "kernels/NAInt8MatMulSmallMKernelDescriptor.hpp"
#include "kernels/NAInt8MatMulSmallMDescriptor.hpp"
#include "kernels/Int8MatMulDescriptor.hpp"
#include "kernels/Int8MatMulKernel.hpp"

namespace {

static constexpr uint32_t kNAInt8MatMulSmallMLowKMaxM = 16;
static constexpr uint32_t kNAInt8MatMulSmallMReducedMaxM = 16;
static constexpr uint32_t kNAInt8MatMulSmallMHighK = 16384;
static constexpr uint32_t kNAInt8MatMulSmallMPack = 8;

static size_t align_up(const size_t value, const size_t alignment) noexcept {
  return (value + alignment - 1) & ~(alignment - 1);
}

typedef struct {
  size_t q_bytes;
  size_t scale_offset;
  size_t scale_bytes;
  size_t scratch_bytes;
} ccv_nnc_mfa_activation_quant_layout_t;

typedef struct {
  size_t activation_offset;
  size_t scale_offset;
  size_t weight_offset;
  size_t scratch_bytes;
} ccv_nnc_mfa_int8_matmul_layout_t;

static GEMMOperandPrecision io_precision(uint64_t data_type) noexcept {
  switch (data_type) {
    case MTL::DataTypeHalf:
      return GEMMOperandPrecision::FP16;
    case MTL::DataTypeBFloat:
      return GEMMOperandPrecision::BF16;
    case MTL::DataTypeFloat:
      return GEMMOperandPrecision::FP32;
    default:
      CCV_NNC_MFA_PRECONDITION(false);
      return GEMMOperandPrecision::FP16;
  }
}

static ccv_nnc_mfa_activation_quant_layout_t activation_quant_layout(ccv_nnc_mfa_scaled_gemm_params_t params) noexcept
{
  const size_t q_bytes = (size_t)params.batch_dimension * params.M * params.K * sizeof(int8_t);
  const size_t scale_offset = align_up(q_bytes, 256);
  const size_t scale_bytes = (size_t)params.batch_dimension * params.M * io_precision(params.data_type).size();
  return (ccv_nnc_mfa_activation_quant_layout_t){
    .q_bytes = q_bytes,
    .scale_offset = scale_offset,
    .scale_bytes = scale_bytes,
    .scratch_bytes = align_up(scale_offset + scale_bytes, 256),
  };
}

static size_t rowwise_8i_scale_offset(const size_t rows, const size_t cols) noexcept
{
  return align_up(rows * cols * sizeof(int8_t), 128);
}

static ccv_nnc_mfa_gemm_params_t int8_matmul_gemm_params(ccv_nnc_mfa_scaled_gemm_params_t params) noexcept
{
  return (ccv_nnc_mfa_gemm_params_t){
    .data_type = MTL::DataTypeHalf,
    .M = params.M,
    .N = params.N,
    .K = params.K,
    .A_trans = 0,
    .B_trans = 1,
    .D_trans = 0,
    .fused_bias = 0,
    .register_float = 1,
    .use_neural_accelerators = 0,
    .batch_dimension = 1,
    .loadM = params.loadM,
    .output_data_type = MTL::DataTypeFloat,
  };
}

static ccv_nnc_mfa_int8_matmul_layout_t int8_matmul_layout(ccv_nnc_mfa_scaled_gemm_params_t params) noexcept
{
  const ccv_nnc_mfa_gemm_params_t gemm_params = int8_matmul_gemm_params(params);
  const size_t activation_offset = align_up(ccv_nnc_mfa_gemm_reserved_scratch_size(gemm_params), 128);
  const size_t activation_bytes = (size_t)params.M * params.K * sizeof(uint16_t);
  const size_t scale_offset = align_up(activation_offset + activation_bytes, 128);
  const size_t scale_bytes = (size_t)params.M * sizeof(float);
  const size_t weight_offset = align_up(scale_offset + scale_bytes, 128);
  const size_t weight_bytes = (size_t)params.N * params.K * sizeof(uint16_t);
  return (ccv_nnc_mfa_int8_matmul_layout_t){
    .activation_offset = activation_offset,
    .scale_offset = scale_offset,
    .weight_offset = weight_offset,
    .scratch_bytes = weight_offset + weight_bytes,
  };
}

static NAInt8MatMulSmallMDescriptor make_na_int8_matmul_small_m_descriptor(ccv_nnc_mfa_scaled_gemm_params_t params) noexcept
{
  NAInt8MatMulSmallMDescriptor desc;
  desc.batchDimension = params.batch_dimension;
  desc.ioPrecision = io_precision(params.data_type);
  desc.matrixDimensions = simd::uint3 { params.M, params.N, params.K };
  desc.useBias = params.fused_bias;
  desc.loadM = params.loadM;
  return desc;
}

static bool use_na_int8_matmul_small_m(ccv_nnc_mfa_scaled_gemm_params_t params) noexcept
{
  NAInt8MatMulSmallMDescriptor splitDesc = make_na_int8_matmul_small_m_descriptor(params);
  const uint16_t splitK = splitDesc.splitK();
  const uint32_t high_k_max_m = splitK > 1 ? kNAInt8MatMulSmallMReducedMaxM : 8;
  const uint32_t max_m = params.K >= kNAInt8MatMulSmallMHighK ? high_k_max_m : kNAInt8MatMulSmallMLowKMaxM;
  return params.use_neural_accelerators &&
    !params.leading_dimension_a &&
    !params.leading_dimension_c &&
    params.M <= max_m &&
    params.batch_dimension == 1 &&
    (params.K % kNAInt8MatMulSmallMPack) == 0 &&
    params.K < 65536;
}

}

void ccv_nnc_mfa_prepare_scaled_gemm(mfa::context* context, ccv_nnc_mfa_scaled_gemm_params_t params)
{
  (void)context;
  (void)params;
}

size_t ccv_nnc_mfa_scaled_gemm_reserved_scratch_size(ccv_nnc_mfa_scaled_gemm_params_t params)
{
  CCV_NNC_MFA_PRECONDITION(params.use_neural_accelerators || !params.activation_hadamard_256);
  if (!params.use_neural_accelerators) {
    CCV_NNC_MFA_PRECONDITION(params.data_type == MTL::DataTypeFloat);
    CCV_NNC_MFA_PRECONDITION(!params.fused_bias && params.batch_dimension == 1);
    CCV_NNC_MFA_PRECONDITION(!params.leading_dimension_a && !params.leading_dimension_c);
    return int8_matmul_layout(params).scratch_bytes;
  }
  const ccv_nnc_mfa_activation_quant_layout_t a_layout = activation_quant_layout(params);
  if (use_na_int8_matmul_small_m(params)) {
    const NAInt8MatMulSmallMDescriptor desc = make_na_int8_matmul_small_m_descriptor(params);
    return align_up(align_up(a_layout.scratch_bytes, 256) + desc.scratchOffsets().total, 256);
  }
  return a_layout.scratch_bytes;
}

static bool use_register_matmul(mfa::context* context, const ccv_nnc_mfa_scaled_gemm_params_t params)
{
  // Register operands also help medium-row projections after the reduction
  // loop improvements. Preserve the previous minimum output area (768 full
  // 64x128 tiles) and keep deeper reductions on the native path below M4096:
  // K24576 and above still lost in the crossover sweep. Smaller selected
  // outputs have complete 64-row tiles; larger outputs amortize partial tiles.
  return params.use_neural_accelerators &&
      params.data_type == MTL::DataTypeHalf && params.batch_dimension == 1 &&
      !params.leading_dimension_a && !params.leading_dimension_c &&
      !params.activation_hadamard_256 &&
      params.M >= 2048 && params.N >= 1536 &&
      uint64_t(params.M) * params.N >= uint64_t(4096) * 1536 &&
      (params.M >= 4096 || params.K <= 20480) &&
      (params.M >= 8192 || params.M % 64 == 0) &&
      params.K >= 4096 && params.K <= 32768 && uint64_t(params.K) <= uint64_t(4) * params.N &&
      params.M <= INT32_MAX - 63 && params.N <= INT32_MAX - 127 &&
      uint64_t(params.M) * params.K <= UINT32_MAX &&
      useNeuralAcceleratorMatMulTuning(context->device.get());
}

static void encode_scaled_gemm(mfa::context* context, ccv_nnc_mfa_scaled_gemm_params_t params, MTL::CommandBatch* command_batch, MTL::Buffer** tensors, size_t* tensor_offsets, const bool cast_output_to_float)
{
  int num_tensors = 0;
  while (tensors[num_tensors] != nullptr)
    ++num_tensors;
  CCV_NNC_MFA_PRECONDITION((num_tensors == 3) || (num_tensors == 4));
  CCV_NNC_MFA_PRECONDITION(params.use_neural_accelerators || !params.activation_hadamard_256);
  const bool useRegisterMatMul = use_register_matmul(context, params) &&
      (cast_output_to_float || tensors[0] != tensors[2]);
  CCV_NNC_MFA_PRECONDITION(!cast_output_to_float || useRegisterMatMul);
  // Quantize and consume a bounded row range before moving to the next one.
  // Large activation and weight working sets benefit from this ordering; small
  // weight matrices and nearly single-chunk inputs can regress from the extra
  // dispatches. Require at least two full chunks. These are measured
  // footprint thresholds, not assumptions about the GPU's physical cache size.
  // Stay within the measured wide-projection surface (K/N <= 3); deeper,
  // narrower reductions favored the original traversal with dynamic M.
  // The K <= 8192 profile already uses a smaller 64-row kernel tile and does
  // not consistently benefit from adding this second level of partitioning.
  // Keep batching, strided views and rotated activations on their existing path.
  if (!useRegisterMatMul && params.use_neural_accelerators && params.data_type == MTL::DataTypeHalf &&
      params.batch_dimension == 1 && !params.leading_dimension_a && !params.leading_dimension_c &&
      !params.activation_hadamard_256 && params.M >= 16384 && params.K > 8192 &&
      uint64_t(params.K) <= uint64_t(3) * params.N &&
      uint64_t(params.M) * params.K > (uint64_t(128) << 20) &&
      uint64_t(params.N) * params.K > (uint64_t(64) << 20) &&
      tensors[0] != tensors[2] && useNeuralAcceleratorMatMulTuning(context->device.get())) {
    for (uint32_t row = 0; row < params.M;) {
      auto chunk = params;
      chunk.M = std::min<uint32_t>(8192, params.M - row);
      size_t offsets[4];
      for (int i = 0; i < num_tensors; ++i)
        offsets[i] = tensor_offsets[i];
      offsets[0] += size_t(row) * params.K * sizeof(uint16_t);
      offsets[2] += size_t(row) * params.N * sizeof(uint16_t);
      ccv_nnc_mfa_encode_scaled_gemm(context, chunk, command_batch, tensors, offsets);
      row += chunk.M;
    }
    return;
  }
  if (!params.use_neural_accelerators) {
    CCV_NNC_MFA_PRECONDITION(params.data_type == MTL::DataTypeFloat);
    CCV_NNC_MFA_PRECONDITION(!params.fused_bias && params.batch_dimension == 1 && num_tensors == 3);
    CCV_NNC_MFA_PRECONDITION(!params.leading_dimension_a && !params.leading_dimension_c);
    CCV_NNC_MFA_PRECONDITION((uint64_t)params.N * params.K <= UINT32_MAX);
    CCV_NNC_MFA_PRECONDITION((uint64_t)params.M * params.N <= UINT32_MAX);
    const Int8MatMulDescriptor descriptor = {
      .M = params.M,
      .N = params.N,
      .K = params.K,
      .expertCount = 1,
      .binCount = 0,
      .operation = Int8MatMulQuantizeActivation,
    };
    auto int8_matmul_pipeline = [&](const Int8MatMulOperation operation) {
      Int8MatMulDescriptor operation_descriptor = descriptor;
      operation_descriptor.operation = operation;
      auto pool = NS::AutoreleasePool::alloc()->init();
      auto pipeline = context->kernel_cache.findKernel<Int8MatMulKernel, Int8MatMulDescriptor, Int8MatMulKernelDescriptor>(
        operation_descriptor, context->device.get(), DeviceProperties());
      pool->drain();
      return pipeline;
    };
    auto quantize_pipeline = int8_matmul_pipeline(Int8MatMulQuantizeActivation);
    auto cast_pipeline = int8_matmul_pipeline(Int8MatMulCastWeights);
    auto dequantize_pipeline = int8_matmul_pipeline(Int8MatMulDequantizeOutput);
    const ccv_nnc_mfa_int8_matmul_layout_t layout = int8_matmul_layout(params);
    auto scratch = context->request_scratch(layout.scratch_bytes);
    const size_t weight_scale_offset = rowwise_8i_scale_offset(params.N, params.K);
    {
      auto encoder = command_batch->startCommand();
      encoder->setComputePipelineState(quantize_pipeline->pipeline.get());
      encoder->useResource(tensors[0], MTL::ResourceUsageRead);
      encoder->useResource(scratch, MTL::ResourceUsageWrite);
      encoder->setBuffer(tensors[0], tensor_offsets[0], 0);
      encoder->setBuffer(scratch, layout.activation_offset, 1);
      encoder->setBuffer(scratch, layout.scale_offset, 2);
      encoder->dispatchThreadgroups(MTL::Size(params.M, 1, 1), quantize_pipeline->kernel->threadgroupSize);
      command_batch->finishCommand(encoder);
    }
    {
      auto encoder = command_batch->startCommand();
      encoder->setComputePipelineState(cast_pipeline->pipeline.get());
      encoder->useResource(tensors[1], MTL::ResourceUsageRead);
      encoder->useResource(scratch, MTL::ResourceUsageWrite);
      encoder->setBuffer(tensors[1], tensor_offsets[1], 0);
      encoder->setBuffer(scratch, layout.weight_offset, 1);
      const uint64_t weight_count = (uint64_t)params.N * params.K;
      encoder->dispatchThreadgroups(MTL::Size((weight_count + 255) / 256, 1, 1), cast_pipeline->kernel->threadgroupSize);
      command_batch->finishCommand(encoder);
    }
    const ccv_nnc_mfa_gemm_params_t gemm_params = int8_matmul_gemm_params(params);
    MTL::Buffer* gemm_tensors[4] = { scratch, scratch, tensors[2], nullptr };
    size_t gemm_offsets[3] = { layout.activation_offset, layout.weight_offset, tensor_offsets[2] };
    ccv_nnc_mfa_encode_gemm(context, gemm_params, command_batch, gemm_tensors, gemm_offsets);
    {
      auto encoder = command_batch->startCommand();
      encoder->setComputePipelineState(dequantize_pipeline->pipeline.get());
      encoder->useResource(tensors[2], MTL::ResourceUsageRead | MTL::ResourceUsageWrite);
      encoder->useResource(scratch, MTL::ResourceUsageRead);
      encoder->useResource(tensors[1], MTL::ResourceUsageRead);
      encoder->setBuffer(tensors[2], tensor_offsets[2], 0);
      encoder->setBuffer(scratch, layout.scale_offset, 1);
      encoder->setBuffer(tensors[1], tensor_offsets[1] + weight_scale_offset, 2);
      const uint64_t output_count = (uint64_t)params.M * params.N;
      encoder->dispatchThreadgroups(MTL::Size((output_count + 255) / 256, 1, 1), dequantize_pipeline->kernel->threadgroupSize);
      command_batch->finishCommand(encoder);
    }
    return;
  }

  NAInt8MatMulDescriptor matmulDesc;
  matmulDesc.batchDimension = params.batch_dimension;
  matmulDesc.ioPrecision = io_precision(params.data_type);
  matmulDesc.matrixDimensions = simd::uint3 { params.M, params.N, params.K };
  matmulDesc.loadM = params.loadM;
  matmulDesc.activationHadamard256 = params.activation_hadamard_256;
  if (params.leading_dimension_a || params.leading_dimension_c) {
    CCV_NNC_MFA_PRECONDITION(params.leading_dimension_a && params.leading_dimension_c);
    matmulDesc.leadingDimensions = simd::uint2 {
      params.leading_dimension_a,
      params.leading_dimension_c,
    };
  } else {
    matmulDesc.leadingDimensions = std::nullopt;
  }
  if (params.batch_dimension > 1) {
    simd::uint4 batchStrides;
    batchStrides[0] = params.batch_stride_a;
    batchStrides[1] = params.batch_stride_b;
    batchStrides[2] = params.batch_stride_c;
    batchStrides[3] = params.batch_stride_d;
    matmulDesc.batchStrides = batchStrides;
    matmulDesc.packedABatchStride = params.M * params.K;
    matmulDesc.aScaleBatchStride = params.M;
  } else {
    matmulDesc.batchStrides = std::nullopt;
  }
  matmulDesc.useBias = params.fused_bias;
  // Source / output batches may be interleaved; packed activations are contiguous.
  const uint32_t dimensions[] = {
    params.M, params.batch_stride_a, params.batch_stride_c, params.M * params.K, params.M,
  };

  auto pool = NS::AutoreleasePool::alloc()->init();
  auto &shaderCache = context->kernel_cache;
  DeviceProperties dprops = DeviceProperties();
  auto pipelineValue = shaderCache.findKernel<NAInt8MatMulKernel, NAInt8MatMulDescriptor, NAInt8MatMulKernelDescriptor>(matmulDesc, context->device.get(), dprops);
  pool->drain();
  auto kernel = pipelineValue->kernel;
  auto matmulPipeline = pipelineValue->pipeline;
  auto quantizePipeline = pipelineValue->second;

  const bool useSmallM = use_na_int8_matmul_small_m(params);
  const ccv_nnc_mfa_activation_quant_layout_t a_layout = activation_quant_layout(params);
  size_t scratch_bytes = a_layout.scratch_bytes;
  NAInt8MatMulSmallMDescriptor smallDesc;
  NAInt8MatMulSmallMScratchOffsets smallOffsets = { 0, 0 };
  size_t small_scratch_base = 0;
  if (useSmallM) {
    smallDesc = make_na_int8_matmul_small_m_descriptor(params);
    smallOffsets = smallDesc.scratchOffsets();
    small_scratch_base = align_up(a_layout.scratch_bytes, 256);
    scratch_bytes = small_scratch_base + smallOffsets.total;
  }
  auto scratch = context->request_scratch(scratch_bytes);
  const uint32_t b_batches = (params.batch_dimension > 1 && params.batch_stride_b > 0) ? params.batch_dimension : 1;
  const size_t b_scale_offset = rowwise_8i_scale_offset((size_t)b_batches * params.N, params.K);

  {
    auto encoder = command_batch->startCommand();
    encoder->setComputePipelineState(quantizePipeline.get());
    encoder->useResource(tensors[0], MTL::ResourceUsageRead);
    encoder->useResource(scratch, MTL::ResourceUsageRead | MTL::ResourceUsageWrite);
    encoder->setBuffer(tensors[0], tensor_offsets[0], 0);
    encoder->setBuffer(scratch, 0, 1);
    encoder->setBuffer(scratch, a_layout.scale_offset, 2);
    if (matmulDesc.loadM) {
      encoder->setBytes(dimensions, sizeof(dimensions), 3);
    }
    encoder->dispatchThreadgroups(
        MTL::Size(params.M, 1, params.batch_dimension),
        MTL::Size(kernel->activationQuantizeThreads, 1, 1));
    command_batch->finishCommand(encoder);
  }

  if (useRegisterMatMul) {
    const NARegisterMatMulDescriptor descriptor {
      params.M % 64 == 0, params.N % 128 == 0, params.K % 512 == 0,
      bool(params.fused_bias), true, false, false, cast_output_to_float
    };
    auto registerPool = NS::AutoreleasePool::alloc()->init();
    auto* value = shaderCache.findKernel<NARegisterMatMulKernel,
        NARegisterMatMulDescriptor, NARegisterMatMulKernelDescriptor>(
            descriptor, context->device.get(), dprops);
    registerPool->drain();
    const int32_t M = params.M, N = params.N, K = params.K;
    const NARegisterMatMulParams arguments {
      M, N, K, K, K, N, (N + 127) / 128, (M + 63) / 64,
      0, 0, 0, 0, K / 512, 1
    };
    auto* encoder = command_batch->startCommand();
    encoder->setComputePipelineState(value->pipeline.get());
    encoder->setBuffer(scratch, 0, 0);
    encoder->setBuffer(tensors[1], tensor_offsets[1], 1);
    encoder->setBuffer(tensors[2], tensor_offsets[2], 3);
    encoder->setBytes(&arguments, sizeof(arguments), 4);
    encoder->setBuffer(scratch, a_layout.scale_offset, 8);
    encoder->setBuffer(tensors[1], tensor_offsets[1] + b_scale_offset, 9);
    encoder->useResource(scratch, MTL::ResourceUsageRead);
    encoder->useResource(tensors[1], MTL::ResourceUsageRead);
    encoder->useResource(tensors[2], MTL::ResourceUsageWrite);
    if (params.fused_bias) {
      CCV_NNC_MFA_PRECONDITION(num_tensors == 4);
      encoder->setBuffer(tensors[3], tensor_offsets[3], 2);
      encoder->useResource(tensors[3], MTL::ResourceUsageRead);
    }
    encoder->dispatchThreadgroups(MTL::Size(arguments.tiles_n, arguments.tiles_m, 1),
        MTL::Size(32, 4, 2));
    command_batch->finishCommand(encoder);
    return;
  }

  if (useSmallM) {
    CCV_NNC_MFA_PRECONDITION((params.fused_bias && num_tensors == 4) || (!params.fused_bias && num_tensors == 3));
    if (METAL_LOG_LEVEL(context) >= 1) {
      ccv_nnc_mfa_log_message("Using NAX small-M Int8 MatMul.");
    }
    auto smallPool = NS::AutoreleasePool::alloc()->init();
    auto smallPipelineValue = shaderCache.findKernel<NAInt8MatMulSmallMKernel, NAInt8MatMulSmallMDescriptor, NAInt8MatMulSmallMKernelDescriptor>(smallDesc, context->device.get(), dprops);
    smallPool->drain();
    auto smallKernel = smallPipelineValue->kernel;
    const size_t partials_offset = small_scratch_base + smallOffsets.partials;
    {
      auto encoder = command_batch->startCommand();
      encoder->setComputePipelineState(smallPipelineValue->pipeline.get());
      encoder->useResource(tensors[1], MTL::ResourceUsageRead);
      encoder->useResource(scratch, MTL::ResourceUsageRead | MTL::ResourceUsageWrite);
      encoder->setBuffer(tensors[1], tensor_offsets[1], 0);
      encoder->setBuffer(scratch, 0, 1);
      encoder->setBuffer(scratch, partials_offset, 2);
      if (smallDesc.loadM) {
        encoder->setBytes(&params.M, sizeof(params.M), 3);
      }
      encoder->dispatchThreadgroups(
          smallKernel->threadgroupsPerGrid(smallDesc),
          MTL::Size(smallKernel->threadgroupSize(smallPipelineValue->pipeline.get()), 1, 1));
      command_batch->finishCommand(encoder);
    }
    {
      auto encoder = command_batch->startCommand();
      encoder->setComputePipelineState(smallPipelineValue->second.get());
      encoder->useResource(scratch, MTL::ResourceUsageRead);
      encoder->useResource(tensors[2], MTL::ResourceUsageWrite);
      encoder->useResource(tensors[1], MTL::ResourceUsageRead);
      if (params.fused_bias) {
        encoder->useResource(tensors[3], MTL::ResourceUsageRead);
      }
      encoder->setBuffer(scratch, partials_offset, 0);
      encoder->setBuffer(tensors[2], tensor_offsets[2], 1);
      encoder->setBuffer(scratch, a_layout.scale_offset, 2);
      encoder->setBuffer(tensors[1], tensor_offsets[1] + b_scale_offset, 3);
      if (params.fused_bias) {
        encoder->setBuffer(tensors[3], tensor_offsets[3], 4);
      }
      if (smallDesc.loadM) {
        encoder->setBytes(&params.M, sizeof(params.M), params.fused_bias ? 5 : 4);
      }
      encoder->dispatchThreadgroups(
          MTL::Size((int64_t)(((uint64_t)params.M * params.N + 255) / 256), 1, 1),
          MTL::Size(256, 1, 1));
      command_batch->finishCommand(encoder);
    }
    return;
  }

  {
    auto encoder = command_batch->startCommand();
    encoder->setComputePipelineState(matmulPipeline.get());
    encoder->useResource(scratch, MTL::ResourceUsageRead);
    encoder->useResource(tensors[1], MTL::ResourceUsageRead);
    encoder->useResource(tensors[2], MTL::ResourceUsageWrite);
    if (num_tensors >= 4)
      encoder->useResource(tensors[3], MTL::ResourceUsageRead);
    encoder->setBuffer(scratch, 0, 0);
    encoder->setBuffer(tensors[1], tensor_offsets[1], 1);
    encoder->setBuffer(tensors[2], tensor_offsets[2], 2);
    encoder->setBuffer(scratch, a_layout.scale_offset, 3);
    encoder->setBuffer(tensors[1], tensor_offsets[1] + b_scale_offset, 4);
    if (num_tensors >= 4)
      encoder->setBuffer(tensors[3], tensor_offsets[3], 5);
    if (matmulDesc.loadM)
      encoder->setBytes(dimensions, sizeof(dimensions), params.fused_bias ? 6 : 5);
    encoder->dispatchThreadgroups(
        kernel->threadgroupsPerGrid(params.M, params.N, params.batch_dimension),
        MTL::Size(kernel->threadgroupSize(matmulPipeline.get()), 1, 1));
    command_batch->finishCommand(encoder);
  }
}

void ccv_nnc_mfa_encode_scaled_gemm(mfa::context* context, ccv_nnc_mfa_scaled_gemm_params_t params, MTL::CommandBatch* command_batch, MTL::Buffer** tensors, size_t* tensor_offsets)
{
  encode_scaled_gemm(context, params, command_batch, tensors, tensor_offsets, false);
}

int ccv_nnc_mfa_encode_scaled_gemm_cast(mfa::context* context, ccv_nnc_mfa_scaled_gemm_params_t params, MTL::CommandBatch* command_batch, MTL::Buffer** tensors, size_t* tensor_offsets)
{
  if (!use_register_matmul(context, params))
    return 0;
  // Unlike chunked GEMM, this path consumes the entire A into separate INT8
  // scratch before writing C. This remains safe when widening C reuses A.
  encode_scaled_gemm(context, params, command_batch, tensors, tensor_offsets, true);
  return 1;
}
