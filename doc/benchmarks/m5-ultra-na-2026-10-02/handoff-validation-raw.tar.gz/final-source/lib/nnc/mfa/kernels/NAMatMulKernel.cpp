#include "NAMatMulKernel.hpp"
#include "NAMatMulDescriptor.hpp"
#include "CodeWriter.hpp"
#include "../ccv_nnc_mfa.hpp"

#include <algorithm>

static uint32_t ceilLog2(uint64_t x) noexcept {
  if (x <= 1)
    return 0;
  --x;
  uint32_t bits = 0;
  while (x > 0) {
    x >>= 1;
    ++bits;
  }
  return bits;
}

std::string NAMatMulKernel::memoryName(char operand) const noexcept {
  switch (operand) {
  case 'A':
    return memoryPrecisions.A.name();
  case 'B':
    return memoryPrecisions.B.name();
  case 'C':
    return memoryPrecisions.C.name();
  case 'S':
    return memoryPrecisions.bias.name();
  default:
    return "";
  }
}

bool NAMatMulKernel::transposed(char operand) const noexcept {
  switch (operand) {
  case 'A':
    return transposeState[0];
  case 'B':
    return transposeState[1];
  case 'C':
    return false;
  default:
    return false;
  }
}

NAMatMulKernel::NAMatMulKernel(NAMatMulKernelDescriptor descriptor, MTL::Device *const device) {
  blockDimensions = descriptor.blockDimensions;
  memoryPrecisions = descriptor.memoryPrecisions;
  registerPrecisions = descriptor.registerPrecisions;
  splitK = descriptor.splitK;
  executionSIMDGroups = descriptor.executionSIMDGroups;
  threadBarrierOverK = descriptor.threadBarrierOverK;
  transposeState = descriptor.transposeState;
  useBias = descriptor.useBias;
  loadM = descriptor.loadM;
  useLeadingDimensions = descriptor.useLeadingDimensions;
  groupM = descriptor.groupM;
  groupN = descriptor.groupN;

  /// The number of threads per group.
  source = createSource();

  // Compile the shader source.
  auto string = NS::String::string(source.c_str(), NS::UTF8StringEncoding);
  NS::Error* error = nil;
  library = NS::TransferPtr(device->newLibrary(string, nil, &error));
  CCV_NNC_MFA_CHECK_ERROR(error);
}

uint16_t NAMatMulKernel::threadgroupSize(MTL::ComputePipelineState *const pipelineState, const NAMatMulDescriptor &descriptor) const noexcept {
  return pipelineState->threadExecutionWidth() * executionSIMDGroups;
}

MTL::Size NAMatMulKernel::threadgroupsPerGrid(const NAMatMulDescriptor &descriptor) const noexcept {
  auto ceilDivide =
  [=](int64_t target, uint16_t granularity) -> int64_t {
    return (target + int64_t(granularity) - 1) / int64_t(granularity);
  };
  const int64_t M_tiles =
      ceilDivide(int64_t(descriptor.matrixDimensions[0]), blockDimensions[0]);
  const int64_t N_tiles =
      ceilDivide(int64_t(descriptor.matrixDimensions[1]), blockDimensions[1]);
  const uint32_t M_bits = ceilLog2(M_tiles);
  const uint32_t N_bits = ceilLog2(N_tiles);
  return MTL::Size((int64_t(1) << (M_bits + N_bits)) * splitK, 1, descriptor.batchDimension);
}

#pragma mark - Source

std::string NAMatMulKernel::createSource() const noexcept {
  CodeWriter source;
  source += R"(
#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MPPTensorOpsMatMul2d.h>

using namespace metal;
using namespace mpp::tensor_ops;

)";
  source += R"(
inline uint compact_morton_even_bits(uint x) {
  x &= 0x55555555u;
  x = (x | (x >> 1)) & 0x33333333u;
  x = (x | (x >> 2)) & 0x0f0f0f0fu;
  x = (x | (x >> 4)) & 0x00ff00ffu;
  x = (x | (x >> 8)) & 0x0000ffffu;
  return x;
}

inline uint2 morton_decode_2d(uint code) {
  return uint2(compact_morton_even_bits(code),
               compact_morton_even_bits(code >> 1));
}

inline uint lower_bits_mask(uint bit_count) {
  if (bit_count == 0)
    return 0;
  return (1u << bit_count) - 1;
}

inline uint2 morton_decode_rectangular_2d(uint code,
                                          uint x_bits,
                                          uint y_bits) {
  const uint paired_bits = min(x_bits, y_bits);
  const uint paired_code = code & lower_bits_mask(paired_bits * 2);
  uint2 tile = morton_decode_2d(paired_code);
  uint tail = code >> (paired_bits * 2);
  if (x_bits > paired_bits) {
    const uint x_extra_bits = x_bits - paired_bits;
    tile.x |= (tail & lower_bits_mask(x_extra_bits)) << paired_bits;
    tail >>= x_extra_bits;
  }
  if (y_bits > paired_bits) {
    tile.y |= tail << paired_bits;
  }
  return tile;
}

)";

  source.SetValue("TRANSPOSE_STATE_A", std::to_string(bool(transposeState[0])));
  source.SetValue("TRANSPOSE_STATE_B", std::to_string(bool(transposeState[1])));
  source.SetValue("BLOCK_DIMENSIONS_M", std::to_string(blockDimensions[0]));
  source.SetValue("BLOCK_DIMENSIONS_N", std::to_string(blockDimensions[1]));
  source.SetValue("BLOCK_DIMENSIONS_K", std::to_string(blockDimensions[2]));
  source.SetValue("BLOCK_DIMENSIONS_K_2", std::to_string(blockDimensions[2] * 2));
  source.SetValue("SPLIT_K", std::to_string(splitK));
  source.SetValue("GROUP_M", std::to_string(groupM));
  source.SetValue("GROUP_N", std::to_string(groupN));
  source.SetValue("A_LEADING_DIMENSION", useLeadingDimensions ? "A_leading_dimension" : "K");
  source.SetValue("A_STRIDE_DECLARATION", useLeadingDimensions ? "  const array<uint, 2> A_strides = { 1, A_leading_dimension };\n" : "");
  source.SetValue("A_TENSOR_STRIDES", useLeadingDimensions ? ", A_strides" : "");
  if (useLeadingDimensions && splitK == 1) {
    source.SetValue("C_GROUP_OFFSET", "M_group_start * C_leading_dimension");
    source.SetValue("C_STRIDE_DECLARATION", "  const array<uint, 2> C_strides = { 1, C_leading_dimension };\n");
    source.SetValue("C_TENSOR_STRIDES", ", C_strides");
    source.SetValue("EDGE_C_BASE_OFFSET", "M_group_offset * C_leading_dimension");
    source.SetValue("EDGE_C_ROW_STRIDE", "C_leading_dimension");
  } else {
    const std::string splitKString = std::to_string(splitK);
    source.SetValue("C_GROUP_OFFSET", splitK > 1 ? "M_group_start * N * " + splitKString : "M_group_start * N");
    source.SetValue("C_STRIDE_DECLARATION", "");
    source.SetValue("C_TENSOR_STRIDES", "");
    source.SetValue("EDGE_C_BASE_OFFSET", "M_group_offset * " + splitKString + " * N");
    source.SetValue("EDGE_C_ROW_STRIDE", splitKString + " * N");
  }
  source.SetValue("REDUCE_SUM_2_DESTINATION", useLeadingDimensions ? "B_buf[tpig.x / (N / 2) * (C_leading_dimension / 2) + tpig.x % (N / 2)]" : "B_buf[tpig.x]");
  source.SetValue("REDUCE_SUM_DESTINATION", useLeadingDimensions ? "B_buf[tpig.x / N * C_leading_dimension + tpig.x % N]" : "B_buf[tpig.x]");

  source += createConstants();

  source.SetValue("MEMORY_NAME_A", memoryName('A'));
  source.SetValue("MEMORY_NAME_B", memoryName('B'));
  source.SetValue("MEMORY_NAME_C", memoryName('C'));
  source.SetValue("MEMORY_NAME_BIAS", memoryName('S'));
  if (registerPrecisions.C.value == GEMMOperandPrecision::FP32 && memoryPrecisions.C.value != GEMMOperandPrecision::FP32) {
    source.SetValue("RELAXED_PRECISION", "false");
  } else {
    source.SetValue("RELAXED_PRECISION", "true");
  }
  source.SetValue("EXECUTION_SIMD_GROUPS", std::to_string(executionSIMDGroups));
  source.SetValue("REGISTER_NAME_C", registerPrecisions.C.name());

  source += R"(

// Metal function arguments.
//
// A: the left-hand side matrix
// - dimensions: M x K
//               K x M (transposed)
// - memory precision: memA
//
// B: the right-hand side matrix
// - dimensions: K x N
//               N x K (transposed)
// - memory precision: memB
//
// C: the output matrix, alternatively the dot product accumulator
// - dimensions: M x N
// - memory precision: memC
//
// threadgroup_block: the chunk of threadgroup memory allocated at runtime
// - ideally 10 KB or less
// - precision: void/8-bit integer to make the pointer arithmetic more legible

kernel void matmul(device {{MEMORY_NAME_A}} *A_buf [[buffer(0)]],
                   device {{MEMORY_NAME_B}} *B_buf [[buffer(1)]],
                   device {{MEMORY_NAME_C}} *C_buf [[buffer(2)]],
)";
  if (useBias) {
    source += R"(
                   device {{MEMORY_NAME_BIAS}} *bias_buf [[buffer(3)]],
)";
    if (loadM) {
      source += R"(
                   const device uint *loadM [[buffer(4)]],
)";
    }
  } else {
    if (loadM) {
      source += R"(
                   const device uint *loadM [[buffer(3)]],
)";
    }
  }
  source += R"(
                 uint3 tgid [[threadgroup_position_in_grid]])
{
)";
  if (loadM) {
    source += R"(
  const uniform<uint> M = make_uniform(loadM[0]);
  const uniform<uint> A_batch_stride = make_uniform(batched ? loadM[1] : 0);
  const uniform<uint> B_batch_stride = make_uniform(batched ? loadM[2] : 0);
)";
    if (splitK <= 1) {
      source += R"(
  const uniform<uint> C_batch_stride = make_uniform(batched ? loadM[3] : 0);
)";
    }
    if (useBias) {
      source += R"(
  const uniform<uint> bias_batch_stride = make_uniform(batched ? loadM[4] : 0);
)";
    }
  }
  source += R"(
  if (batched) {
    A_buf = A_buf + A_batch_stride * tgid.z;
    B_buf = B_buf + B_batch_stride * tgid.z;
)";
  if (splitK > 1) {
    source += R"(
    C_buf = C_buf + M * N * {{SPLIT_K}} * tgid.z;
)";
  } else {
    source += R"(
    C_buf = C_buf + C_batch_stride * tgid.z;
)";
  }
  if (useBias) {
    source += R"(
    bias_buf = bias_buf + bias_batch_stride * tgid.z;
)";
  }
  source += R"(
  }
)";
  if (transposed('A')) {
    source.SetValue("A_SLICE", std::to_string(blockDimensions[0]) + ", " + std::to_string(blockDimensions[2]));
    source.SetValue("A_MATRIX_SIZE", "M, K");
    source.SetValue("A_TILE_0_SIZE", "tgid.y * " + std::to_string(blockDimensions[0]) + ", 0");
    source.SetValue("A_TILE_K1_SIZE", "tgid.y * " + std::to_string(blockDimensions[0]) + ", k");
    source.SetValue("A_TILE_K2_SIZE", "tgid.y * " + std::to_string(blockDimensions[0]) + ", k + " + std::to_string(blockDimensions[2]));
    source.SetValue("A_TILE_LAST_K2_SIZE", "tgid.y * " + std::to_string(blockDimensions[0]) + ", K / " + std::to_string(blockDimensions[2] * 2) + " * " + std::to_string(blockDimensions[2] * 2));
    source.SetValue("A_TILE_LAST_K_SIZE", "tgid.y * " + std::to_string(blockDimensions[0]) + ", K / " + std::to_string(blockDimensions[2]) + " * " + std::to_string(blockDimensions[2]));
    source.SetValue("A_RESIDUAL_SLICE", std::to_string(blockDimensions[0]) + ", dynamic_extent");
  } else {
    source.SetValue("A_SLICE", std::to_string(blockDimensions[2]) + ", " + std::to_string(blockDimensions[0]));
    source.SetValue("A_MATRIX_SIZE", "K, M");
    source.SetValue("A_TILE_0_SIZE", "0, M_group_offset");
    source.SetValue("A_TILE_K1_SIZE", "k, M_group_offset");
    source.SetValue("A_TILE_K2_SIZE", "k + " + std::to_string(blockDimensions[2]) + ", M_group_offset");
    source.SetValue("A_TILE_LAST_K2_SIZE", "K / " + std::to_string(blockDimensions[2] * 2) + " * " + std::to_string(blockDimensions[2] * 2) + ", M_group_offset");
    source.SetValue("A_TILE_LAST_K_SIZE", "K / " + std::to_string(blockDimensions[2]) + " * " + std::to_string(blockDimensions[2]) + ", M_group_offset");
    source.SetValue("A_RESIDUAL_SLICE", "dynamic_extent, " + std::to_string(blockDimensions[0]));
  }
  if (transposed('B')) {
    source.SetValue("B_SLICE", std::to_string(blockDimensions[2]) + ", " + std::to_string(blockDimensions[1]));
    source.SetValue("B_MATRIX_SIZE", "K, N_group_size");
    source.SetValue("B_TILE_0_SIZE", "0, N_group_offset");
    source.SetValue("B_TILE_K1_SIZE", "k, N_group_offset");
    source.SetValue("B_TILE_K2_SIZE", "k + " + std::to_string(blockDimensions[2]) + ", N_group_offset");
    source.SetValue("B_TILE_LAST_K2_SIZE", "K / " + std::to_string(blockDimensions[2] * 2) + " * " + std::to_string(blockDimensions[2] * 2) + ", N_group_offset");
    source.SetValue("B_TILE_LAST_K_SIZE", "K / " + std::to_string(blockDimensions[2]) + " * " + std::to_string(blockDimensions[2]) + ", N_group_offset");
    source.SetValue("B_RESIDUAL_SLICE", "dynamic_extent, " + std::to_string(blockDimensions[1]));
  } else {
    source.SetValue("B_SLICE", std::to_string(blockDimensions[1]) + ", " + std::to_string(blockDimensions[2]));
    source.SetValue("B_MATRIX_SIZE", "N, K");
    source.SetValue("B_TILE_0_SIZE", "tgid.x * " + std::to_string(blockDimensions[1]) + ", 0");
    source.SetValue("B_TILE_K1_SIZE", "tgid.x * " + std::to_string(blockDimensions[1]) + ", k");
    source.SetValue("B_TILE_K2_SIZE", "tgid.x * " + std::to_string(blockDimensions[1]) + ", k + " + std::to_string(blockDimensions[2]));
    source.SetValue("B_TILE_LAST_K2_SIZE", "tgid.x * " + std::to_string(blockDimensions[1]) + ", K / " + std::to_string(blockDimensions[2] * 2) + " * " + std::to_string(blockDimensions[2] * 2));
    source.SetValue("B_TILE_LAST_K_SIZE", "tgid.x * " + std::to_string(blockDimensions[1]) + ", K / " + std::to_string(blockDimensions[2]) + " * " + std::to_string(blockDimensions[2]));
    source.SetValue("B_RESIDUAL_SLICE", std::to_string(blockDimensions[1]) + ", dynamic_extent");
  }
  createInitializeC(&source);
  if (splitK > 1) {
    source.SetValue("SPLIT_K_STORE_OFFSET", "tgid.x * " + std::to_string(blockDimensions[1] * splitK) + " + k_split_idx * " + std::to_string(blockDimensions[1]));
  } else {
    source.SetValue("SPLIT_K_STORE_OFFSET", "tgid.x * " + std::to_string(blockDimensions[1]));
  }
  std::string barrierAfterFullChunk;
  const std::string blockDimensionsK2 = std::to_string(blockDimensions[2] * 2);
  if (threadBarrierOverK) {
    barrierAfterFullChunk =
        "        if (k + " + blockDimensionsK2 + " < K) {\n"
        "          threadgroup_barrier(mem_flags::mem_none);\n"
        "        }\n";
  }
  std::string barrierAfterLeadingSplitChunk;
  std::string barrierAfterMiddleSplitChunk;
  if (threadBarrierOverK) {
    barrierAfterLeadingSplitChunk =
        "        if (k + " + blockDimensionsK2 + " < K_split) {\n"
        "          threadgroup_barrier(mem_flags::mem_none);\n"
        "        }\n";
    barrierAfterMiddleSplitChunk =
        "        if (i_k + " + blockDimensionsK2 + " < K_split) {\n"
        "          threadgroup_barrier(mem_flags::mem_none);\n"
        "        }\n";
  }
  source.SetValue("BARRIER_AFTER_FULL_CHUNK", barrierAfterFullChunk);
  source.SetValue("BARRIER_AFTER_LEADING_SPLIT_CHUNK",
                  barrierAfterLeadingSplitChunk);
  source.SetValue("BARRIER_AFTER_MIDDLE_SPLIT_CHUNK",
                  barrierAfterMiddleSplitChunk);
  source += R"(

  // Construct shader allocated tensors. This is easier since we can just bind buffer directly with Metal 3 APIs.
)";
  if (splitK > 1) {
    source += R"(
  const uint M_tiles = (M + {{BLOCK_DIMENSIONS_M}} - 1) / {{BLOCK_DIMENSIONS_M}};
  const uint N_tiles = (N + {{BLOCK_DIMENSIONS_N}} - 1) / {{BLOCK_DIMENSIONS_N}};
  const uint M_tile_bits = M_tiles <= 1 ? 0 : 32 - clz(M_tiles - 1);
  const uint N_tile_bits = N_tiles <= 1 ? 0 : 32 - clz(N_tiles - 1);
  const uint tile_codes = 1u << (M_tile_bits + N_tile_bits);
  uint k_split_idx = tgid.x / tile_codes;
  uint2 morton_tile =
      morton_decode_rectangular_2d(tgid.x % tile_codes,
                                   N_tile_bits,
                                   M_tile_bits);
  tgid.x = morton_tile.x;
  tgid.y = morton_tile.y;
  if (tgid.x >= N_tiles || tgid.y >= M_tiles) {
    return;
  }
)";
  } else {
    source += R"(
  const uint M_tiles = (M + {{BLOCK_DIMENSIONS_M}} - 1) / {{BLOCK_DIMENSIONS_M}};
  const uint N_tiles = (N + {{BLOCK_DIMENSIONS_N}} - 1) / {{BLOCK_DIMENSIONS_N}};
  const uint M_tile_bits = M_tiles <= 1 ? 0 : 32 - clz(M_tiles - 1);
  const uint N_tile_bits = N_tiles <= 1 ? 0 : 32 - clz(N_tiles - 1);
  uint2 morton_tile =
      morton_decode_rectangular_2d(tgid.x, N_tile_bits, M_tile_bits);
  tgid.x = morton_tile.x;
  tgid.y = morton_tile.y;
  if (tgid.x >= N_tiles || tgid.y >= M_tiles) {
    return;
  }
)";
  }
  source += R"(
  const uint M_block_start = tgid.y * {{BLOCK_DIMENSIONS_M}};
  const uint M_block_size = M - M_block_start;
)";
  if (groupM > 0) {
    source += R"(
  // Rebase A / C to shared M-row groups so large-M threadgroups avoid the
  // 2^31 scratch-offset cliff without forcing every threadgroup onto a unique
  // base pointer.
  const uint M_group_start = M_block_start / {{GROUP_M}} * {{GROUP_M}};
  const uint M_group_offset = M_block_start - M_group_start;
  const uint M_group_size = M - M_group_start;
)";
  } else {
    source += R"(
  const uint M_group_start = M_block_start;
  const uint M_group_offset = 0;
  const uint M_group_size = M - M_group_start;
)";
  }
  if (transposed('B')) {
    if (groupN > 0) {
      source += R"(
  // Rebase transposed B to shared N-column groups for the same reason as
  // groupM: keep neighboring threadgroups on stable base pointers when N is
  // large without changing the global C layout.
  const uint N_block_start = tgid.x * {{BLOCK_DIMENSIONS_N}};
  const uint N_group_start = N_block_start / {{GROUP_N}} * {{GROUP_N}};
  const uint N_group_offset = N_block_start - N_group_start;
  const uint N_group_size = N - N_group_start;
)";
    } else {
      source += R"(
  const uint N_block_start = tgid.x * {{BLOCK_DIMENSIONS_N}};
  const uint N_group_start = N_block_start;
  const uint N_group_offset = 0;
  const uint N_group_size = N - N_group_start;
)";
    }
    source += R"(
  B_buf = B_buf + N_group_start * K;
)";
  }
  if (!transposed('A')) {
    source += R"(
  A_buf = A_buf + M_group_start * {{A_LEADING_DIMENSION}};
)";
  }
  source += R"(
  C_buf = C_buf + {{C_GROUP_OFFSET}};
)";
  if (!transposed('A')) {
    source += R"(
{{A_STRIDE_DECLARATION}}  auto A = tensor<device {{MEMORY_NAME_A}},  dextents<int32_t, 2>, tensor_inline>(A_buf, dextents<int32_t, 2>(K, M_group_size){{A_TENSOR_STRIDES}});
)";
  } else {
    source += R"(
  auto A = tensor<device {{MEMORY_NAME_A}},  dextents<int32_t, 2>, tensor_inline>(A_buf, dextents<int32_t, 2>({{A_MATRIX_SIZE}}));
)";
  }
  if (transposed('B')) {
    source += R"(
  auto B = tensor<device {{MEMORY_NAME_B}},  dextents<int32_t, 2>, tensor_inline>(B_buf, dextents<int32_t, 2>(K, N_group_size));
)";
  } else {
    source += R"(
  auto B = tensor<device {{MEMORY_NAME_B}},  dextents<int32_t, 2>, tensor_inline>(B_buf, dextents<int32_t, 2>({{B_MATRIX_SIZE}}));
)";
  }
  source += R"(
{{C_STRIDE_DECLARATION}}  auto C = tensor<device {{MEMORY_NAME_C}},  dextents<int32_t, 2>, tensor_inline>(C_buf, dextents<int32_t, 2>(N * {{SPLIT_K}}, M_group_size){{C_TENSOR_STRIDES}});
)";
  if (useBias) {
    if (transposeState[2]) {
      source += R"(
  bias_buf = bias_buf + M_block_start;
)";
    } else {
      source += R"(
  bias_buf = bias_buf + tgid.x * {{BLOCK_DIMENSIONS_N}};
)";
    }
  }
  source += R"(

  if (tgid.x * {{BLOCK_DIMENSIONS_N}} + {{BLOCK_DIMENSIONS_N}} - 1 < N && tgid.y * {{BLOCK_DIMENSIONS_M}} + {{BLOCK_DIMENSIONS_M}} - 1 < M) {
    // Use static slice.
    // descriptor to create matmul operation that does {{BLOCK_DIMENSIONS_K}}x{{BLOCK_DIMENSIONS_M}} times {{BLOCK_DIMENSIONS_N}}x{{BLOCK_DIMENSIONS_K}} producing {{BLOCK_DIMENSIONS_N}}x{{BLOCK_DIMENSIONS_M}}
    constexpr auto matmul_descriptor = matmul2d_descriptor({{BLOCK_DIMENSIONS_M}}, {{BLOCK_DIMENSIONS_N}}, {{BLOCK_DIMENSIONS_K}}, {{TRANSPOSE_STATE_A}}, {{TRANSPOSE_STATE_B}}, {{RELAXED_PRECISION}}, matmul2d_descriptor::mode::multiply_accumulate);

    // create matmul op from above descriptor with {{EXECUTION_SIMD_GROUPS}} SIMD-Groups.
    matmul2d<matmul_descriptor, execution_simdgroups<{{EXECUTION_SIMD_GROUPS}}>> matmul_op;

    auto mA = A.slice<{{A_SLICE}}>({{A_TILE_0_SIZE}});
    auto mB = B.slice<{{B_SLICE}}>({{B_TILE_0_SIZE}});
    auto cT = matmul_op.get_destination_cooperative_tensor<decltype(mA), decltype(mB), {{REGISTER_NAME_C}}>();
{{INITIALIZE_C}}
)";

  if (splitK > 1) {
    source += R"(
    if (k_split_idx == 0) {
      #pragma clang loop unroll(full)
      for (uint k = 0; k < K_split; k += {{BLOCK_DIMENSIONS_K_2}}) {
        // Create appropriate slice for this thread group to work on.
        auto mA0 = A.slice<{{A_SLICE}}>({{A_TILE_K1_SIZE}});
        auto mB0 = B.slice<{{B_SLICE}}>({{B_TILE_K1_SIZE}});
        auto mA1 = A.slice<{{A_SLICE}}>({{A_TILE_K2_SIZE}});
        auto mB1 = B.slice<{{B_SLICE}}>({{B_TILE_K2_SIZE}});
        matmul_op.run(mA0, mB0, cT);
        matmul_op.run(mA1, mB1, cT);
{{BARRIER_AFTER_LEADING_SPLIT_CHUNK}}
      }
    }
)";
    source.SetValue("SPLIT_K_1", std::to_string(splitK - 1));
    if (splitK > 2) {
      source += R"(
    else if (k_split_idx > 0 && k_split_idx < {{SPLIT_K_1}}) {
      const uint k_start = k_split_idx * K_split;
      #pragma clang loop unroll(full)
      for (uint i_k = 0; i_k < K_split; i_k += {{BLOCK_DIMENSIONS_K_2}}) {
        const uint k = k_start + i_k;
        // Create appropriate slice for this thread group to work on.
        auto mA0 = A.slice<{{A_SLICE}}>({{A_TILE_K1_SIZE}});
        auto mB0 = B.slice<{{B_SLICE}}>({{B_TILE_K1_SIZE}});
        auto mA1 = A.slice<{{A_SLICE}}>({{A_TILE_K2_SIZE}});
        auto mB1 = B.slice<{{B_SLICE}}>({{B_TILE_K2_SIZE}});
        matmul_op.run(mA0, mB0, cT);
        matmul_op.run(mA1, mB1, cT);
{{BARRIER_AFTER_MIDDLE_SPLIT_CHUNK}}
      }
    }
)";
	}
    source += R"(
    else {
      #pragma clang loop unroll(full)
      for (uint k = {{SPLIT_K_1}} * K_split; k < K_edge; k += {{BLOCK_DIMENSIONS_K_2}}) {
        // Create appropriate slice for this thread group to work on.
        auto mA0 = A.slice<{{A_SLICE}}>({{A_TILE_K1_SIZE}});
        auto mB0 = B.slice<{{B_SLICE}}>({{B_TILE_K1_SIZE}});
        auto mA1 = A.slice<{{A_SLICE}}>({{A_TILE_K2_SIZE}});
        auto mB1 = B.slice<{{B_SLICE}}>({{B_TILE_K2_SIZE}});
        matmul_op.run(mA0, mB0, cT);
        matmul_op.run(mA1, mB1, cT);
{{BARRIER_AFTER_FULL_CHUNK}}
      }
    }
)";
  } else {
    source += R"(
    #pragma clang loop unroll(full)
    for (uint k = 0; k < K_edge; k += {{BLOCK_DIMENSIONS_K_2}}) {
      // Create appropriate slice for this thread group to work on.
      auto mA0 = A.slice<{{A_SLICE}}>({{A_TILE_K1_SIZE}});
      auto mB0 = B.slice<{{B_SLICE}}>({{B_TILE_K1_SIZE}});
      auto mA1 = A.slice<{{A_SLICE}}>({{A_TILE_K2_SIZE}});
      auto mB1 = B.slice<{{B_SLICE}}>({{B_TILE_K2_SIZE}});
      matmul_op.run(mA0, mB0, cT);
      matmul_op.run(mA1, mB1, cT);
{{BARRIER_AFTER_FULL_CHUNK}}
    }
)";
  }
  if (splitK > 1) {
    // Leading partitions cover complete pairs of K tiles. Only the last
    // partition owns the global remainder; adding it to every partial output
    // repeats its contribution when the partials are reduced.
    source += R"(
    if (k_split_idx == {{SPLIT_K_1}}) {
)";
  }
  source += R"(
    if (K % ({{BLOCK_DIMENSIONS_K}} * 2) >= {{BLOCK_DIMENSIONS_K}}) {
      auto mA = A.slice<{{A_SLICE}}>({{A_TILE_LAST_K2_SIZE}});
      auto mB = B.slice<{{B_SLICE}}>({{B_TILE_LAST_K2_SIZE}});
      matmul_op.run(mA, mB, cT);
    }
    if (K % {{BLOCK_DIMENSIONS_K}} != 0) {
      constexpr auto matmul_descriptor = matmul2d_descriptor({{BLOCK_DIMENSIONS_M}}, {{BLOCK_DIMENSIONS_N}}, dynamic_length_v<int>, {{TRANSPOSE_STATE_A}}, {{TRANSPOSE_STATE_B}}, {{RELAXED_PRECISION}}, matmul2d_descriptor::mode::multiply_accumulate);
      // create matmul op from above descriptor with {{EXECUTION_SIMD_GROUPS}} SIMD-Groups.
      matmul2d<matmul_descriptor, execution_simdgroups<{{EXECUTION_SIMD_GROUPS}}>> matmul_op;
      auto mA = A.slice<{{A_RESIDUAL_SLICE}}>({{A_TILE_LAST_K_SIZE}});
      auto mB = B.slice<{{B_RESIDUAL_SLICE}}>({{B_TILE_LAST_K_SIZE}});
      matmul_op.run(mA, mB, cT);
    }
)";
  if (splitK > 1) {
    source += R"(
    }
)";
  }
  source += R"(
    auto mC = C.slice<{{BLOCK_DIMENSIONS_N}}, {{BLOCK_DIMENSIONS_M}}>({{SPLIT_K_STORE_OFFSET}}, M_group_offset);
)";
  if (registerPrecisions.C == memoryPrecisions.C) {
    source += "    cT.store(mC);\n";
  } else {
    // MPP stores require matching cooperative-tensor and memory element types.
    // Keep the requested accumulator precision until the final output cast.
    source += R"(
    auto outC = C_buf + {{EDGE_C_BASE_OFFSET}} + {{SPLIT_K_STORE_OFFSET}};
    #pragma clang loop unroll(full)
    for (unsigned short k = 0; k < cT.get_capacity(); ++k) {
      if (cT.is_valid_element(k)) {
        const auto idx = cT.get_multidimensional_index(k);
        outC[idx[1] * {{EDGE_C_ROW_STRIDE}} + idx[0]] = ({{MEMORY_NAME_C}})cT[k];
      }
    }
)";
  }
  source += R"(
  } else {
    // Use dynamic slice for this edge case.
    // descriptor to create matmul operation that does {{BLOCK_DIMENSIONS_K}}x{{BLOCK_DIMENSIONS_M}} times {{BLOCK_DIMENSIONS_N}}x{{BLOCK_DIMENSIONS_K}} producing {{BLOCK_DIMENSIONS_N}}x{{BLOCK_DIMENSIONS_M}}
    constexpr auto matmul_descriptor = matmul2d_descriptor({{BLOCK_DIMENSIONS_M}}, {{BLOCK_DIMENSIONS_N}}, dynamic_length_v<int>, {{TRANSPOSE_STATE_A}}, {{TRANSPOSE_STATE_B}}, {{RELAXED_PRECISION}}, matmul2d_descriptor::mode::multiply_accumulate);

    // create matmul op from above descriptor with {{EXECUTION_SIMD_GROUPS}} SIMD-Groups.
    matmul2d<matmul_descriptor, execution_simdgroups<{{EXECUTION_SIMD_GROUPS}}>> matmul_op;

    auto mA = A.slice({{A_TILE_0_SIZE}});
    auto mB = B.slice({{B_TILE_0_SIZE}});
    auto cT = matmul_op.get_destination_cooperative_tensor<decltype(mA), decltype(mB), {{REGISTER_NAME_C}}>();
{{INITIALIZE_C}}
)";
  if (splitK > 1) {
    source += R"(
    if (k_split_idx == 0) {
      matmul_op.run(mA, mB, cT);
    }
)";
  } else {
    source += R"(
    matmul_op.run(mA, mB, cT);
)";
  }
  source += R"(
    // Since OS 26.2, cT.store(mC) is no longer safe store (not respecting C size). Doing this manually.
)";
  source += R"(
    auto mC = C_buf + {{EDGE_C_BASE_OFFSET}} + {{SPLIT_K_STORE_OFFSET}};
)";
  source += R"(
    const int N_edge = N - tgid.x * {{BLOCK_DIMENSIONS_N}};
    const int M_edge = M_block_size;
    #pragma clang loop unroll(full)
    for (unsigned short k = 0; k < cT.get_capacity(); ++k) {
      if(cT.is_valid_element(k)) {
        auto idx = cT.get_multidimensional_index(k);
        if (idx[0] < N_edge && idx[1] < M_edge) {
          mC[idx[1] * {{EDGE_C_ROW_STRIDE}} + idx[0]] = cT[k];
        }
      }
    }
  }
}
)";

  if (splitK > 1) {
    source.SetValue("BLOCK_DIMENSIONS_N_DIV_2", std::to_string(blockDimensions[1] / 2));
    source.SetValue("BLOCK_DIMENSIONS_N_DIV_2_SPLIT_K", std::to_string(blockDimensions[1] / 2 * splitK));
    source.SetValue("BLOCK_DIMENSIONS_N_SPLIT_K", std::to_string(blockDimensions[1] * splitK));
    source += R"(
kernel void reduce_sum_2(device {{MEMORY_NAME_C}}2 *A_buf [[buffer(0)]],
                         device {{MEMORY_NAME_C}}2 *B_buf [[buffer(1)]],
)";
    if (loadM) {
      source += R"(
                         const device uint *loadM [[buffer(2)]],
)";
    }
    source += R"(
                         uint2 tpig [[thread_position_in_grid]]) {
)";
    if (loadM) {
      source += R"(
  const uniform<uint> M = make_uniform(loadM[0]);
  const uniform<uint> C_batch_stride = make_uniform(batched ? loadM[3] : 0);
)";
    }
    source += R"(
  if (tpig.x >= M * N / 2) {
    return;
  }
  if (batched) {
    A_buf = A_buf + M * N / 2 * {{SPLIT_K}} * tpig.y;
    B_buf = B_buf + C_batch_stride / 2 * tpig.y;
  }
  A_buf += tpig.x / {{BLOCK_DIMENSIONS_N_DIV_2}} * {{BLOCK_DIMENSIONS_N_DIV_2_SPLIT_K}} + tpig.x % {{BLOCK_DIMENSIONS_N_DIV_2}};
  {{MEMORY_NAME_C}}2 val = A_buf[0];
  #pragma clang loop unroll(full)
  for (unsigned int k = 1; k < {{SPLIT_K}}; k++) {
    val += A_buf[k * {{BLOCK_DIMENSIONS_N_DIV_2}}];
  }
  {{REDUCE_SUM_2_DESTINATION}} = val;
}

kernel void reduce_sum(device {{MEMORY_NAME_C}} *A_buf [[buffer(0)]],
                       device {{MEMORY_NAME_C}} *B_buf [[buffer(1)]],
)";
    if (loadM) {
      source += R"(
                       const device uint *loadM [[buffer(2)]],
)";
    }
    source += R"(
                       uint2 tpig [[thread_position_in_grid]]) {
)";
    if (loadM) {
      source += R"(
  const uniform<uint> M = make_uniform(loadM[0]);
  const uniform<uint> C_batch_stride = make_uniform(batched ? loadM[3] : 0);
)";
    }
    source += R"(
  if (tpig.x >= M * N) {
    return;
  }
  if (batched) {
    A_buf = A_buf + M * N * {{SPLIT_K}} * tpig.y;
    B_buf = B_buf + C_batch_stride * tpig.y;
  }
  A_buf += tpig.x / {{BLOCK_DIMENSIONS_N}} * {{BLOCK_DIMENSIONS_N_SPLIT_K}} + tpig.x % {{BLOCK_DIMENSIONS_N}};
  {{MEMORY_NAME_C}} val = A_buf[0];
  #pragma clang loop unroll(full)
  for (unsigned int k = 1; k < {{SPLIT_K}}; k++) {
    val += A_buf[k * {{BLOCK_DIMENSIONS_N}}];
  }
  {{REDUCE_SUM_DESTINATION}} = val;
}
)";
  }

  return source.ToString();
}

std::string NAMatMulKernel::createConstants() const noexcept {
  std::string constants = R"(
constant uint N [[function_constant(1)]];
constant uint K [[function_constant(2)]];
// Specify the batch / batch strides at PSO creation time.
constant bool batched [[function_constant(11)]];
)";
  if (useLeadingDimensions) {
    constants += R"(
constant uint A_leading_dimension [[function_constant(5)]];
constant uint C_leading_dimension [[function_constant(7)]];
)";
  }
  if (!loadM) {
    constants += R"(
constant uint M [[function_constant(0)]];
constant uint A_batch_stride [[function_constant(15)]];
constant uint B_batch_stride [[function_constant(16)]];
constant uint C_batch_stride [[function_constant(17)]];
constant uint bias_batch_stride [[function_constant(18)]];
)";
  }
  constants += R"(
constant uint K_edge = K > {{BLOCK_DIMENSIONS_K_2}} - 1 ? K + 1 - {{BLOCK_DIMENSIONS_K_2}} : 0;
)";
  if (splitK > 1) {
    constants += R"(
constant uint K_split = K / {{SPLIT_K}} / {{BLOCK_DIMENSIONS_K_2}} * {{BLOCK_DIMENSIONS_K_2}};
)";
  }
  return constants;
}

#pragma mark - Caching

void NAMatMulKernel::createInitializeC(CodeWriter *source) const noexcept {
  CodeWriter initializeC;
  if (useBias) {
    initializeC.SetValue("BIAS_INDEX", transposeState[2] ? "idx[1]" : "idx[0]");
    if (splitK > 1) {
      initializeC += R"(
        if (k_split_idx == 0) {
          #pragma clang loop unroll(full)
          for (unsigned short k = 0; k < cT.get_capacity(); ++k) {
            if(cT.is_valid_element(k)) {
              auto idx = cT.get_multidimensional_index(k);
              cT[k] = bias_buf[{{BIAS_INDEX}}];
            }
          }
        } else {
          #pragma clang loop unroll(full)
          for (unsigned short k = 0; k < cT.get_capacity(); ++k) {
            if(cT.is_valid_element(k)) {
              cT[k] = 0;
            }
          }
        }
)";
    } else {
      initializeC += R"(
        #pragma clang loop unroll(full)
        for (unsigned short k = 0; k < cT.get_capacity(); ++k) {
          if(cT.is_valid_element(k)) {
            auto idx = cT.get_multidimensional_index(k);
            cT[k] = bias_buf[{{BIAS_INDEX}}];
          }
        }
)";
    }
  } else {
    initializeC += R"(
    #pragma clang loop unroll(full)
    for (unsigned short k = 0; k < cT.get_capacity(); ++k) {
      if(cT.is_valid_element(k)) {
        cT[k] = 0;
      }
    }
)";
  }
  source->SetValue("INITIALIZE_C", initializeC.ToString());
}
