from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-m5-handoff')
paths=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=root,text=True).splitlines()
paths=sorted(set(n for n in paths if n.startswith(('lib/','bin/mfa/')) or n=='test/int/nnc/mpsblas.tests.c'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index={}
for name in paths:
 p=root/name
 if not p.is_file():continue
 index[name]=sha(p)
 target=out/'final-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
(out/'final-source-sha256.json').write_text(json.dumps(index,indent=2)+'\n')
(out/'final-tracked.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--','lib','bin/mfa','test/int/nnc/mpsblas.tests.c'],cwd=root))
names=['lib/libccv.a','bin/mfa/na_application_bench','bin/mfa/mlx_na_bench','test/int/nnc/mpsblas.tests','test/int/nnc/mpsdnn.tests']
meta={n:dict(sha256=sha(root/n),size=(root/n).stat().st_size) for n in names}
meta['baseline']={'path':str(out/'baseline-probe'),'sha256':sha(out/'baseline-probe'),'scope':'Frozen optimized checkpoint before Apple10 predicate cleanup and causal inference support.'}
(out/'retained-build-provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Recorded',len(index),'final source files and all retained validation binaries.')
