TEST_CASE("scaled dot product attention causal register inference preserves offsets cache modes and aliases")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2, Hq = 6, Hk = 2, D = 256, S = 8;
	const int shapes[][2] = { { 64, 257 }, { 65, 257 }, { 127, 257 }, { 128, 257 },
		{ 257, 257 }, { 257, 513 }, { 513, 1025 }, { 4097, 8193 } };
	for (int trial = 0; trial < sizeof(shapes) / sizeof(shapes[0]); ++trial)
	{
		const int R = shapes[trial][0], C = shapes[trial][1];
		const int rows[S] = { 0, 1, 31, 32, 63, R > 64 ? 64 : R - 1, R / 2, R - 1 };
		ccv_nnc_tensor_t* inputs[3];
		ccv_nnc_tensor_t* half_inputs[3];
		ccv_nnc_tensor_t* gpu_inputs[3];
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 2026 + trial);
		for (int j = 0; j < 3; ++j)
		{
			const int length = j == 0 ? R : C, heads = j == 0 ? Hq : Hk;
			const int count = B * length * heads * D;
			inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, length, heads, D), 0);
			half_inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, length, heads, D), 0);
			gpu_inputs[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, length, heads, D), 0);
			for (int i = 0; i < count; ++i)
				inputs[j]->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * (j == 2 ? 2 : 4);
			ccv_float_to_half_precision(inputs[j]->data.f32, (uint16_t*)half_inputs[j]->data.f16, count);
			ccv_half_precision_to_float((uint16_t*)half_inputs[j]->data.f16, inputs[j]->data.f32, count);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[j]), TENSOR_LIST(gpu_inputs[j]), 0);
		}
		ccv_nnc_tensor_t* const sampled_q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		ccv_nnc_tensor_t* const causal_mask = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, S, C), 0);
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				memcpy(sampled_q->data.f32 + (b * S + s) * Hq * D, inputs[0]->data.f32 + (b * R + rows[s]) * Hq * D, sizeof(float) * Hq * D);
		for (int s = 0; s < S; ++s)
			for (int c = 0; c < C; ++c)
				causal_mask->data.f32[s * C + c] = c <= rows[s] + C - R ? 0 : -FLT_MAX;
		const float scale = 1.0f / sqrtf(D);
		ccv_nnc_tensor_t* expected[2];
		for (int causal = 0; causal < 2; ++causal)
		{
			expected[causal] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
			// An explicit CPU mask preserves the original query positions after
			// sampling. A causal command on only S queries would use another offset.
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0,
				TENSOR_LIST(sampled_q, inputs[1], inputs[2], causal ? causal_mask : 0), TENSOR_LIST(expected[causal]), 0);
		}
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_l = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_tensor_t* const half_o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const raw_l = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, Hq, R), 0);
		float* const actual = (float*)ccmalloc(sizeof(float) * B * R * Hq * D);
		float* const lse = (float*)ccmalloc(sizeof(float) * B * R * Hq);
		const uint64_t old_flags = ccv_nnc_flags();
		if (trial > 0)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		for (int mode = 0; mode < 4; ++mode)
		{
			const int causal = mode != 0, no_backward = mode != 3;
			const int int8_preference = mode == 2;
			const int quantized = int8_preference && R <= 64;
			ccv_nnc_cmd_t command = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, causal);
			command.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | (int8_preference ? CCV_NNC_GEMM_8I : 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[0]), TENSOR_LIST(gpu_inputs[0]), 0);
			ccv_nnc_tensor_t* const output = mode == 2 ? gpu_inputs[0] : gpu_o;
			const int status = ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, no_backward ? CCV_NNC_NO_BACKWARD : 0,
				TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(output, gpu_l), 0);
			REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "causal inference and training controls should execute");
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(output, gpu_l), TENSOR_LIST(half_o, raw_l), 0);
			ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
			ccv_half_precision_to_float((uint16_t*)raw_l->data.f32, lse, B * R * Hq);
			for (int i = 0; i < B * R * Hq * D; ++i)
				REQUIRE(isfinite(actual[i]), "causal inference output should be finite");
			double error2 = 0, reference2 = 0;
			for (int b = 0; b < B; ++b)
				for (int s = 0; s < S; ++s)
					for (int h = 0; h < Hq; ++h)
					{
						for (int d = 0; d < D; ++d)
						{
							const float ref = expected[causal]->data.f32[((b * S + s) * Hq + h) * D + d];
							const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - ref;
							error2 += error * error;
							reference2 += ref * ref;
						}
						double sum = 0;
						const int cols = causal ? rows[s] + C - R + 1 : C;
						for (int c = 0; c < cols; ++c)
						{
							double dot = 0;
							for (int d = 0; d < D; ++d)
								dot += sampled_q->data.f32[((b * S + s) * Hq + h) * D + d] * inputs[1]->data.f32[((b * C + c) * Hk + h / (Hq / Hk)) * D + d];
							sum += exp(dot * scale);
						}
						REQUIRE(fabs(lse[(b * Hq + h) * R + rows[s]] - log2(sum)) < (quantized ? 0.1 : 0.03), "causal saved statistics should retain right-aligned query positions");
					}
			const double tolerance = quantized ? 0.05 : no_backward ? 0.003 : 0.01;
			REQUIRE(error2 < reference2 * tolerance * tolerance, "causal register inference should match sampled CPU attention (R=%d C=%d mode=%d relative L2=%g)", R, C, mode, sqrt(error2 / reference2));
		}
		if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccfree(actual);
		ccfree(lse);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_l);
		ccv_nnc_tensor_free(half_o);
		ccv_nnc_tensor_free(raw_l);
		ccv_nnc_tensor_free(expected[0]);
		ccv_nnc_tensor_free(expected[1]);
		ccv_nnc_tensor_free(sampled_q);
		ccv_nnc_tensor_free(causal_mask);
		for (int j = 0; j < 3; ++j)
		{
			ccv_nnc_tensor_free(inputs[j]);
			ccv_nnc_tensor_free(half_inputs[j]);
			ccv_nnc_tensor_free(gpu_inputs[j]);
		}
	}
}
