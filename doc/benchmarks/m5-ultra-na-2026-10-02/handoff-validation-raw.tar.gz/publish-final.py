from pathlib import Path
import json,csv,statistics,hashlib,tarfile,sys
root=Path('/Users/liu/workspace/ccv');p=Path('/private/tmp/ccv-m5-handoff');out=root/'doc/benchmarks/m5-ultra-na-2026-10-02'
sys.path.insert(0,str(root/'bin/mfa'))
from na_benchmark_manifest import manifest
from na_application_sweep import read_completed
key=lambda c:(c['operation'],tuple(c['shape']),c['dispatch_flags'],c['causal'],c['output_cast'])
final=manifest();canon={key(c):c for c in final['workloads']}
all_rows=[];tables=[];hash_pairs=[];failures=[]
confirmation_rows=[]
for phase in ['final-smoke','final-long','regression-repeat']:
 if (p/phase/'summary.json').exists():
  _,rows=read_completed(p/phase)
  if phase=='regression-repeat':confirmation_rows=rows
  for name in ['results.csv']:
   (out/(phase+'-'+name)).write_text((p/phase/name).read_text())
phases=['coverage','source-supplement','backward','stress','causal-final']
for phase in phases:
 meta,rows=read_completed(p/phase)
 cases={c['id']:c for c in meta['workloads']}
 lookup={(r['repeat'],r['id'],r['variant']):r for r in rows}
 for r in rows:
  c=canon[key(cases[r['id']])]
  record=dict(phase=phase,original_id=r['id'],**r);record['id']=c['id']
  record.update(operation=c['operation'],shape='x'.join(map(str,c['shape'])),flags=c['dispatch_flags'],output_cast=c['output_cast'])
  all_rows.append(record)
  if not r['ok']:failures.append(record)
  if c['operation']!='backward' and r['variant'].startswith('previous_'):
   other=lookup[(r['repeat'],r['id'],r['variant'][9:])]
   if r['output_sha256'] and other['output_sha256']:
    hash_pairs.append(dict(phase=phase,id=c['id'],repeat=r['repeat'],variant=r['variant'][9:],equal=r['output_sha256']==other['output_sha256']))
 for name in ['results.csv']:
  (out/(phase+'-'+name)).write_text((p/phase/name).read_text())
assert {r['id'] for r in all_rows} == {c['id'] for c in final['workloads']}
for c in final['workloads']:
 selected=[r for r in all_rows if r['id']==c['id']]
 initial_rows=[r for r in selected if r['phase']!='causal-final']
 if any(r['phase']=='causal-final' for r in selected):
  selected=[r for r in selected if r['phase']=='causal-final']
 d={v:[r for r in selected if r['variant']==v] for v in c['variants']}
 assert all(len(rows)==2 for rows in d.values()),c['id']
 vals={v:statistics.median(r['median_ms'] for r in rows) if all(r['ok'] for r in rows) else None for v,rows in d.items()}
 initial={}
 for v in c['variants']:
  rows=[r for r in initial_rows if r['variant']==v]
  initial[v]=statistics.median(r['median_ms'] for r in rows) if len(rows)==2 and all(r['ok'] for r in rows) else None
 if not initial_rows:initial=dict(vals)
 fallback={v:any(r.get('attention_fp16_fallback')=='1' for r in rows) for v,rows in d.items()}
 repeated={v:[r for r in confirmation_rows if r['id']==c['id'] and r['variant']==v] for v in c['variants']}
 if any(repeated.values()):
  assert all(len(rows)==4 for rows in repeated.values()),c['id']
  vals={v:statistics.median(r['median_ms'] for r in rows) if all(r['ok'] for r in rows) else None for v,rows in repeated.items()}
 tables.append(dict(**c,median_ms=vals,initial_median_ms=initial,attention_fp16_fallback=fallback,measurement_phase='regression-repeat' if any(repeated.values()) else d[c['variants'][0]][0]['phase']))
fields=['phase','repeat','id','original_id','operation','shape','flags','output_cast','variant','median_ms','ok','exit_code','cpu_l2','cpu_max_abs','output_sha256','cast_fused','attention_fp16_fallback','seconds','error']
with (out/'handoff-results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fields,extrasaction='ignore',lineterminator='\n');w.writeheader();w.writerows(all_rows)
(out/'handoff-workloads.json').write_text(json.dumps(final,indent=2)+'\n')
vjp_checks=[{k:r[k] for k in ['phase','id','repeat','variant','ok','vjp_errors']} for r in all_rows if 'vjp_errors' in r]
(out/'handoff-summary.json').write_text(json.dumps(dict(records=len(all_rows),failed=failures,hash_pairs=hash_pairs,vjp_checks=vjp_checks,cases=tables),indent=2)+'\n')
# Full shape-by-shape comparisons, with failures explicitly excluded.
lines=['Final application / boundary / MLX VJP timings (milliseconds)','',
'Two reversed process orders, seven samples each. Rows marked regression-repeat',
'use four orders, 31 samples, and two GPU seconds warmup after an initial flag.',
'The original measurements remain in handoff-results.csv / initial_median_ms.',
'FP16 and FP32 columns both have half inputs and',
'output; FP32 explicitly requests FP32 accumulation. INT8 includes preparation.',
'Cast cases include half-rounded Float32 output. D256 short or causal INT8 requests can',
'fall back to FP16. FAIL marks a failed/missing check; a dash means unrequested.',
'Raw orders, source mappings and known failures are in the companion CSV/JSON.','',
'Case | operation | M/R x N/C x K/D x B x Hq x Hkv | FP16 FP32 INT8-request MLX | MLX/INT8-request | INT8 uses FP16 | measurement phase']
for c in tables:
 v=c['median_ms'];fmt=lambda x:'FAIL' if x is None else f'{x:.5f}'
 ratio=f"{v['mlx']/v['int8']:.3f}x" if v.get('mlx') and v.get('int8') else 'FAIL'
 lines.append(f"{c['id']} | {c['operation']} | {'x'.join(map(str,c['shape']))} | {' '.join(fmt(v.get(k)) if k in v else '-' for k in ['fp16','fp32','int8','mlx'])} | {ratio} | {c['attention_fp16_fallback'].get('int8',False)} | {c['measurement_phase']}")
(out/'handoff-all-shapes.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(records=len(all_rows),cases=len(tables),failed=len(failures),hash_pairs=len(hash_pairs),equal=sum(x['equal'] for x in hash_pairs)),indent=2))
# Preserve original metadata and labels. Source corrections are represented by
# original_id plus final canonical geometry in the consolidated table.
files=sorted(f for f in p.rglob('*') if f.is_file() and f.suffix in ['.json','.jsonl','.csv','.txt','.log','.c','.m','.mm','.cpp','.hpp','.h','.inc','.py','.diff','.patch'] and not any(part in ['research-loose-backup','pycache'] for part in f.relative_to(p).parts) and f.name not in ['validation-index.json','pending.txt','handoff-draft.txt','resume-state.txt'])
index={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(p/'validation-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=out/'handoff-validation-raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in files+[p/'validation-index.json']:t.add(f,arcname=str(f.relative_to(p)))
with tarfile.open(archive) as t:
 for name,h in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
(out/'handoff-validation-index.json').write_text(json.dumps(dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=index),indent=2)+'\n')
print('Archive verified:',len(index),'entries')
