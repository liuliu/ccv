from pathlib import Path
import hashlib,json,shutil,subprocess,time

root=Path('/Users/liu/workspace/ccv')
out=Path('/private/tmp/ccv-m5-handoff')
assert len(json.loads((out/'validation.json').read_text()))==4
assert len(json.loads((out/'supplement-validation.json').read_text()))==2
snapshot=out/'before-probe-guards'
snapshot.mkdir()
for name in ['na_application_bench','mlx_na_bench','na_application_bench.cpp','mlx_na_bench.cpp',
             'na_application_sweep.py','na_benchmark_manifest.py']:
    shutil.copy2(root/'bin/mfa'/name,snapshot/name)
shutil.copy2(out/'baseline-probe',snapshot/'baseline-probe')
inc=root/'lib/nnc/mfa/3rdparty/mlx/gemm.metal.inc'
shutil.copy2(inc,snapshot/'gemm.metal.inc')
original_inc=inc.read_text()
assert original_inc.count('    const short sgp_sm, \n')==1
clean_inc=original_inc.replace('    const short sgp_sm, \n','    const short sgp_sm,\n')
inc.write_text(clean_inc)
(out/'final-source-cleanup.json').write_text(json.dumps(dict(
    file=str(inc.relative_to(root)),change='Remove one trailing space from an embedded upstream Metal argument line; no token or arithmetic changes.',
    before_sha256=hashlib.sha256(original_inc.encode()).hexdigest(),
    after_sha256=hashlib.sha256(clean_inc.encode()).hexdigest()),indent=2)+'\n')

def replace(path,before,after):
    text=path.read_text()
    assert text.count(before)==1,(path,before)
    path.write_text(text.replace(before,after))

mlx=root/'bin/mfa/mlx_na_bench.cpp'
replace(mlx,'  // Materialize O and LSE (and any views) before timing the VJP primitive.', '''  // Reject an unexpected backward lowering before evaluating its inputs: a
  // fallback graph could otherwise run backward work outside the timed region.
  if (backward && (outputs.size() != 3 || !outputs[0].has_primitive() ||
      std::string(outputs[0].primitive().name()) != "ScaledDotProductAttentionVJP")) {
    std::cerr << "Expected the three-output MLX SDPA VJP primitive\\n";
    return 5;
  }
  // Materialize O and LSE (and any views) before timing the VJP primitive.''')
replace(mlx,'''    for (auto& stage : stages) stage[0].primitive().eval_gpu(stage[0].inputs(), stage);
    auto& encoder = mx::metal::get_command_encoder(stream);
    auto cb = NS::RetainPtr(encoder.get_command_buffer());''','''    auto& encoder = mx::metal::get_command_encoder(stream);
    auto cb = NS::RetainPtr(encoder.get_command_buffer());
    for (auto& stage : stages) stage[0].primitive().eval_gpu(stage[0].inputs(), stage);
    // These direct primitives encode into one buffer at the recorded revision.
    // Reject future internal commits instead of reporting only the last buffer.
    if (cb.get() != encoder.get_command_buffer()) {
      std::cerr << "Primitive changed the timed command buffer\\n";
      return 5;
    }''')
replace(mlx,'      const auto qs = a.strides(), ks = b.strides(), vs = v.strides(), os = outputs[0].strides();','''      const auto qs = a.strides(), ks = b.strides(), vs = v.strides(), os = outputs[0].strides();
      for (int z=0;z<batch;++z) for (int h=0;h<hq;++h)
        for (int r=0;r<m;++r) for (int d=0;d<k;++d)
          if (!std::isfinite(float(result[z*os[0]+h*os[1]+r*os[2]+d*os[3]]))) return 6;
      std::cout << "all_finite=1" << std::endl;''')
replace(mlx,'  std::sort(samples.begin(), samples.end());','''  std::cout << "gpu_samples_ms=";
  for (size_t i=0;i<samples.size();++i) std::cout << (i ? "," : "") << samples[i];
  std::cout << std::endl;
  std::sort(samples.begin(), samples.end());''')
ccv=root/'bin/mfa/na_application_bench.cpp'
replace(ccv,'  const bool accurate = l2 <= (quantized ? 0.05 : 0.01);','  const bool accurate = l2 <= (quantized && !prefer_fp16 ? 0.05 : 0.01);')
replace(ccv,'  std::sort(samples.begin(),samples.end());','''  printf("gpu_samples_ms=");
  for (size_t i=0;i<samples.size();++i) printf("%s%.9g",i ? "," : "",samples[i]);
  printf("\\n");
  std::sort(samples.begin(),samples.end());''')
runner=root/'bin/mfa/na_application_sweep.py'
replace(runner,"                    checked.write_text(''.join(json.dumps(r)+'\\n' for r in rows))", "                    pending=checked.with_suffix('.pending')\n                    pending.write_text(''.join(json.dumps(r)+'\\n' for r in rows))\n                    pending.replace(checked)")
replace(runner,"    records.write_text(''.join(json.dumps(r)+'\\n' for r in rows))", "    pending=records.with_suffix('.pending')\n    pending.write_text(''.join(json.dumps(r)+'\\n' for r in rows))\n    pending.replace(records)")

build=['make','-C','bin/mfa','-o','libccv.a','na_application_bench','mlx_na_bench',
       'na_attention_backward_bench','na_gemm_splitk_bench','na_int8_attention_backward_probe',
       'na_int8_attention_bench','na_int8_matmul_bench',
       'MLX_ROOT=/Users/liu/workspace/mlx','MLX_BUILD=/private/tmp/ccv-mlx-m5-build',
       'MLX_LIBRARY=/private/tmp/ccv-mlx-dsplit-fix/libmlx.a',
       'MLX_METAL_CPP=/private/tmp/ccv-mlx-m5-build/_deps/metal_cpp-src',
       'MLX_FMT=/private/tmp/ccv-mlx-m5-build/_deps/fmt-src/include']
baseline=json.loads((out/'baseline-probe-build-command.json').read_text())
records=[]
jobs=[('final-library-build',['make','-C','lib','lib','DEBUG=1','-j4']),
      ('final-integration-link',['make','-C','test/int/nnc','DEBUG=1','-o','libccv.a',
                                 '-W','mpsblas.tests.o','-W','mpsdnn.tests.o','mpsblas.tests','mpsdnn.tests']),
      ('final-probe-build',build),('final-baseline-build',baseline)]
for name,args in jobs:
    start=time.time()
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=args,exit=result.returncode,seconds=time.time()-start))
    (out/'final-probe-build.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==0,name

original=json.loads((out/'build-provenance.json').read_text())
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in original}
(out/'final-build-provenance.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('Final probes built; library/integration binaries relinked for whitespace-only embedded-source cleanup.',flush=True)
