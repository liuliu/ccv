import json,statistics
from pathlib import Path
p=Path('/private/tmp/ccv-m5-handoff')
for phase in ['coverage','backward','source-supplement','stress']:
    records=p/phase/'records.jsonl'
    if not records.exists():continue
    rows=[json.loads(line) for line in records.read_text().splitlines()]
    lookup={(r['repeat'],r['id'],r['variant']):r for r in rows}
    pairs=[];groups={};flags=[]
    for r in rows:
        groups.setdefault((r['id'],r['variant']),[]).append(r)
        if r['variant'].startswith('previous_'):
            other=lookup.get((r['repeat'],r['id'],r['variant'][9:]))
            if other and other.get('output_sha256') and r.get('output_sha256'):
                pairs.append(other['output_sha256']==r['output_sha256'])
    for (case,variant),a in groups.items():
        b=groups.get((case,'previous_'+variant),[])
        if len(a)==len(b)==2 and all(r['ok'] for r in a+b):
            current=statistics.median(r['median_ms'] for r in a)
            baseline=statistics.median(r['median_ms'] for r in b)
            if current-baseline>max(.02,.05*baseline):flags.append((case,variant,round(current/baseline,3)))
    print(phase,len(rows),'records;',sum(not r['ok'] for r in rows),'failed;',sum(pairs),'/',len(pairs),'matching hashes;',len(flags),'provisional regression flags')
    if flags:print(flags)
    if rows:print('last',rows[-1]['repeat'],rows[-1]['id'],rows[-1]['variant'])
for name in ['validation','supplement-validation']:
    if (p/(name+'.json')).exists():print(name,[(r['name'],r['exit']) for r in json.loads((p/(name+'.json')).read_text())])
