from pathlib import Path
import json,shutil
root=Path('/Users/liu/workspace/ccv');work=Path('/private/tmp/ccv-m5-handoff')
assert len(json.loads((work/'supplement-validation.json').read_text()))==2
assert (work/'final-build-provenance.json').exists()
backup=work/'before-causal';backup.mkdir()
def replace(name,before,after):
    p=root/name;s=p.read_text();assert s.count(before)==1,(name,before)
    dest=backup/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    p.write_text(s.replace(before,after))
replace('lib/nnc/mfa/kernels/NARegisterAttentionDescriptor.hpp',
'''  bool saveL;

  bool operator==''','''  bool saveL;
  bool causal;

  bool operator==''')
p=root/'lib/nnc/mfa/kernels/NARegisterAttentionDescriptor.hpp';s=p.read_text()
s=s.replace('alignedK == rhs.alignedK && saveL == rhs.saveL;','alignedK == rhs.alignedK && saveL == rhs.saveL && causal == rhs.causal;')
s=s.replace('(size_t(value.D) << 3) | (value.alignedQ << 2) |\n        (value.alignedK << 1) | value.saveL;',
            '(size_t(value.D) << 4) | (value.alignedQ << 3) |\n        (value.alignedK << 2) | (value.saveL << 1) | value.causal;')
s=s.replace('alignment / saved statistics are constants.','alignment, causal masking and saved statistics are constants.')
p.write_text(s)
replace('lib/nnc/mfa/kernels/NARegisterAttentionDescriptor.cpp',
'''  for (const auto index : {300, 301, 302})
    constants->setConstantValue(&disabled, MTL::DataTypeBool, NS::UInteger(index));''',
'''  for (const auto index : {300, 302})
    constants->setConstantValue(&disabled, MTL::DataTypeBool, NS::UInteger(index));
  constants->setConstantValue(&causal, MTL::DataTypeBool, NS::UInteger(301));''')
replace('lib/nnc/mfa/ccv_nnc_mfa_attention.cpp',
'''          ((hash.D == 128 && hash.R >= 256) || (hash.D == 256 && hash.R > 64)) && hash.C > 0 &&
          !hash.is_causal && !hash.masked && !hash.is_varlen && !hash.attention_sinks &&''',
'''          ((hash.D == 128 && hash.R >= 256) || (hash.D == 256 && hash.R > 64)) && hash.C > 0 &&
          // Wide-head causal inference uses the same split accumulators. Keep
          // training and empty causal rows on their established paths. The
          // extra index bound covers a padded query tile plus KV-tile rounding.
          (!hash.is_causal || (hash.D == 256 && hash.is_inference && hash.R <= hash.C &&
              uint64_t(hash.C) + 64 + 32 <= INT32_MAX)) &&
          !hash.masked && !hash.is_varlen && !hash.attention_sinks &&''')
p=root/'lib/nnc/mfa/ccv_nnc_mfa_attention.cpp';s=p.read_text()
s=s.replace('hash.D, hash.R % 64 == 0, hash.C % 32 == 0, tensors[5] != nullptr',
            'hash.D, hash.R % 64 == 0, hash.C % 32 == 0, tensors[5] != nullptr, bool(hash.is_causal)')
s=s.replace('(R + 63) / 64, (C + 31) / 32, R / 64, C / 32, R % 64, C % 32, 0,',
            '(R + 63) / 64, (C + 31) / 32, R / 64, C / 32, R % 64, C % 32, hash.is_causal ? C - R : 0,')
p.write_text(s)
replace('lib/nnc/cmd/scaled_dot_product_attention/mps/ccv_nnc_scaled_dot_product_attention_mps.m',
'''\t\tconst int prefer_fp16_attention = is_downcast && D == 256 && R > 64 && C > 0 &&
\t\t\t!ccv_nnc_mfa_attention_split_output_shape(R, C, D) &&
\t\t\t((flags & CCV_NNC_NO_BACKWARD) || !lse) &&
\t\t\t!attn_mask && !cmd.info.scaled_dot_product_attention.is_causal &&''',
'''\t\t// INT8 output partitioning does not support causal masks. For wide-head
\t\t// causal inference, use the register kernel's split FP32 accumulators.
\t\t// Its triangular traversal is right-aligned to the growing KV cache.
\t\tconst int register_causal_inference = cmd.info.scaled_dot_product_attention.is_causal &&
\t\t\t(flags & CCV_NNC_NO_BACKWARD) && R <= C && C <= INT32_MAX - 96;
\t\tconst int prefer_fp16_attention = is_downcast && D == 256 && R > 64 && C > 0 &&
\t\t\t(register_causal_inference || (!cmd.info.scaled_dot_product_attention.is_causal &&
\t\t\t\t!ccv_nnc_mfa_attention_split_output_shape(R, C, D))) &&
\t\t\t((flags & CCV_NNC_NO_BACKWARD) || !lse) &&
\t\t\t!attn_mask &&''')
replace('bin/mfa/na_application_bench.cpp',
'''      k == 256 && m > 64 && !causal &&
      !ccv_nnc_mfa_attention_split_output_shape(m, n, k);''',
'''      k == 256 && m > 64 &&
      ((causal && m <= n && n <= INT32_MAX - 96) ||
       (!causal && !ccv_nnc_mfa_attention_split_output_shape(m, n, k)));''')
p=root/'test/int/nnc/mpsblas.tests.c';shutil.copy2(p,backup/'mpsblas.tests.c')
p.write_text(p.read_text()+'\n'+(work/'causal-test.c').read_text())
print('Applied inference-only D256 causal register proposal. Baseline probe remains frozen before this change.')
