from pathlib import Path
import json,subprocess,time
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-m5-handoff')
summary=json.loads((out/'causal-final/summary.json').read_text())
assert summary['failed_records']==0
jobs=[('final-mpsblas',['./mpsblas.tests']),('final-mpsdnn',['./mpsdnn.tests'])]
results=[]
for name,args in jobs:
 start=time.time();print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as log:
  r=subprocess.run(args,cwd=root/'test/int/nnc',stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,args=args,exit=r.returncode,seconds=time.time()-start)
 results.append(record);(out/'final-tests.json').write_text(json.dumps(results,indent=2)+'\n')
 print('DONE',record,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['python3',str(out/'final-confirmations.py')],cwd=root,check=True)
# Resume must run before staging changes metadata; no GPU work should repeat.
args=['python3','bin/mfa/na_application_sweep.py','--suite','smoke','--baseline-frontend',str(out/'baseline-probe'),'--output',str(out/'final-smoke'),'--resume']
with (out/'final-resume.log').open('w') as log:
 r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
(out/'final-resume.json').write_text(json.dumps(dict(args=args,exit=r.returncode),indent=2)+'\n')
if r.returncode:raise SystemExit(r.returncode)
