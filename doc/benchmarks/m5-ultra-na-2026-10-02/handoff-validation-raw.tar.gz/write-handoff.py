from pathlib import Path
import json,re,statistics
root=Path('/Users/liu/workspace/ccv');p=Path('/private/tmp/ccv-m5-handoff');out=root/'doc/benchmarks/m5-ultra-na-2026-10-02'
s=json.loads((out/'handoff-summary.json').read_text());cases={c['id']:c for c in s['cases']}
lines=['M5 NA inference handoff, 2026-10-04','',
'Branch: m5-na-inference-benchmarks. Commit: see git history for this report.',
'Measured device: Apple M5 Ultra, 80 GPU cores, 256 GiB, macOS 27.0.1.',
'MLX: 25532871329fe4cafdada9fa0941a1cdbfb3a9f2, static Metal-JIT build with',
'the documented D256 template-signature fix only. Draw Things geometry revision:',
'afed99ce5981875e3b3aa7d19059a516c73c5f2f. CCV starting revision:',
'6a611be1aab6470ae279115ae4eaf7e01bc87135. Work is committed locally, not pushed.','',
'The retained implementation combines register-fragment FP16 GEMM and attention,',
'INT8 register GEMM/remainder improvements, compact attention dispatch, D256',
'output partitioning, and long D128 KV partitioning. Inference GEMM followed by',
'a Float32 conversion can store a half-rounded Float32 result directly; the CNNP',
'rewrite preserves allocation, alias/dependency checks and reinitialization.',
'The final performance phase extends medium-row FP16 register selection while',
'retaining native wins for compact moderate reductions. It also enables D256',
'causal inference using split accumulators and a right-aligned KV-cache offset.',
'Two broader GEMM experiments were rejected after neighborhood sweeps.','',
'All five former exact-Ultra GEMM gates now share the Apple10 capability check.',
'There is no new model-name attention gate or attention storage transpose.',
'Geometry, precision, layout, index and scratch limits are in gating-review.txt.',
'Other M5 devices share the required capability; their throughput is unmeasured.',
'Thresholds are measured bounds with resource/geometry explanations, not claims',
'about physical cache sizes or guaranteed cross-device performance.','',
'Selected final comparisons (GPU milliseconds; lower is better)',
'Case | FP16 | INT8 request | MLX | MLX / INT8 request | INT8 uses FP16']
selected=['h3-480p-ui-10s','h3-720p-ui-10s','h3-480p-ui-10s-output-cast','h3-720p-ui-10s-output-cast',
'h3-480p-ui-10s-ffn-down-cast','h3-720p-ui-10s-ffn-down-cast',
'flux2-512-attention','flux2-1024-attention','flux2-2048-attention',
'ideogram4-512-attention','ideogram4-1024-attention','ideogram4-2048-attention',
'krea2-1024-ffn-down','qwen21-1024-attention','local-qwen35-4b-m3072-down',
'local-gqa-r2048-c8192','local-27b-gqa-r2048-c8192']
for name in selected:
 c=cases[name];v=c['median_ms']
 lines.append(f"{name} | {v['fp16']:.4f} | {v['int8']:.4f} | {v['mlx']:.4f} | {v['mlx']/v['int8']:.3f}x | {c['attention_fp16_fallback'].get('int8',False)}")
lines += ['',
'D256 causal Local Code Hq24/Hkv4, R2048/C8192 drops from 8.9774 to 4.5711 ms',
'FP16, versus actual MLX 4.6559 ms. R4096/C8192 drops from 18.4725 to 8.1431 ms',
'versus MLX 8.0499 ms. INT8 preferences use FP16 here; these gains are not',
'INT8 arithmetic speedups. See inference-causal-d256.txt for bounds and tests.','',
'Actual MLX SDPA VJP (saved forward excluded, GPU milliseconds)',
'Case | CCV FP16 | CCV INT8 request | MLX VJP']
for c in s['cases']:
 if c['operation']=='backward':
  v=c['median_ms'];lines.append(f"{c['id']} | {v['fp16']:.4f} | {v['int8']:.4f} | {v['mlx']:.4f}")
lines += ['',
'Backward optimization remains deferred. There are substantial D256 and H3',
'backward gaps; no universal parity or 2x INT8 claim is made. D256 backward',
'uses the existing generic MFA fallback even for INT8 requests. MLX is verified',
'as the three-output ScaledDotProductAttentionVJP primitive, including its',
'internal layout copies. A guard rejects unexpected lowering or command-buffer',
'changes that would otherwise omit work from GPU timestamps.','',
f"The permanent manifest has {len(cases)} distinct requests: 257 source-derived application",
'cases plus overlapping geometric coverage, eight backward requests and two',
'known stress cases. Image models cover five resolutions; Local Code covers',
'Qwen3.5 4B/9B/27B projections and causal growing-cache attention. All shapes,',
'source references, protocol, precision and fallback labels are retained.','',
'H3 UI geometry is R=C=31018 for 832x512 and 70186 for 1280x768, 56 heads, D128,',
'including 256 text + 810 audio tokens and no references. The requested 240',
'frames round to 72 latent / 243 decoded frames. Video tokens are',
'72*(height/32)*(width/32). These are dense SDPA comparisons, not Sol attention.',
'Inputs remain in B/S/H/D storage in both probes. MLX gets metadata views;',
'no explicit S/H storage copy is introduced by the benchmark.','',
'The matmul matrix uses B=1; integration tests cover batched/broadcast correctness.',
'FP16 and FP32-accumulator columns both have half inputs/output. Cast cases',
'include half-rounded Float32 output. INT8 includes activation quantization,',
'with persistent weights already expanded. Packed-weight decoding and full',
'generation are outside these timings. D256 short or supported causal INT8',
'requests can use the FP16 fallback, recorded explicitly in the result tables.','',
'Validation and regression checks']
for name in ['final-mpsblas','final-mpsdnn']:
 data=(p/(name+'.log')).read_text();assert 'all test case(s) passed, congratulations!' in data
 counts=re.findall(r'\[(\d+)/(\d+)\] \[PASS\]',data);last=counts[-1]
 lines.append(f"{name}: {last[0]}/{last[1]}, exit 0.")
lines.append('CNNP core: 61/61 at the fusion checkpoint; unchanged core code since that run.')
lines.append('Benchmark harness CPU tests: 5/5. Completed smoke resume succeeds without rerunning GPU work.')
lines.append(f"Primary and causal matrices: {s['records']} records across {len(cases)} distinct requests.")
lines.append(f"Numerical failures: {len(s['failed'])} records, all from the two pre-existing FP16 stress shapes.")
checks=[e for row in s['vjp_checks'] for e in row['vjp_errors']]
lines.append(f"Actual MLX VJP: {len(checks)} dQ/dK/dV checks including frozen/current CCV; largest normalized L2 {max(e['normalized_l2'] for e in checks):.5%}.")
for phase in ['final-smoke','final-long','regression-repeat']:
 x=json.loads((p/phase/'summary.json').read_text());flags=[r for r in x['live_baseline_comparison'] if r['status']!='pass']
 lines.append(f"{phase}: {x['records']} records, {x['failed_records']} numerical failures, {len(flags)} timing flags.")
 assert x['failed_records']==0 and not flags,(phase,flags)
lines += [
'Seven original timing flags are retained. Longer confirmation uses four',
'reversed orders, 31 samples/order and two GPU seconds warmup per process.',
'The complete shape table labels these confirmation rows and preserves the',
'initial values. Final-long separately rechecks both exact long H3 attention',
'cases, selected cast projections and medium/deep GEMM controls.','',
'The Apple10-gate/cleanup checkpoint matched 2666 full forward output hashes',
'against its frozen optimized baseline (including the known stress cases).',
'The subsequent causal algorithm changes rounding within the CPU tolerances;',
'bitwise identity is not claimed for changed causal outputs.','',
'The paired cleanup baseline is the optimized checkpoint before the hardware',
'predicate cleanup and final causal change, not the initial repository.',
'Earlier improvement measurements and rejected trials remain in the historical',
'reports and verified research archive.','',
'The original coverage manifest labeled some Local Code hidden-size squares as',
'projections. Source review corrected Q/KV/output dimensions and retained those',
'squares as synthetic controls. The source supplement runs all 76 added shapes.',
'Consolidated records map IDs by exact geometry/flags. Causal-final adds twelve',
'new boundaries and supersedes eleven existing timing rows; all older results',
'remain in the CSV and raw archive.','',
'Known numerical limit: M512/N12287 or N12289/K24576 native half accumulation',
'exceeds the 1% sampled CPU-L2 check (1.1554% and 1.0620%). Current and baseline',
'fail identically in both orders; FP32 accumulation, INT8 and MLX pass. These',
'rows are marked failed, excluded from speedups, and remain in --suite stress.',
'No tolerance was relaxed or numerical repair claimed for those two shapes.','',
'Benchmarks use reproducible periodic data and sampled independent CPU checks',
'(1% FP16 / 5% INT8 normalized L2). VJP checks sample 16384 positions per',
'gradient; probes scan full outputs/gradients for finiteness. Randomized, shifted,',
'larger-magnitude, bias, decoded-weight, alias, dynamic-cache and graph-reinit',
'checks are in mpsblas.tests.c. These checks do not establish generated-media',
'quality. BF16 and every mask/training mode are outside the performance matrix.','',
'Use bin/mfa/README.na-benchmarks.txt to build and run smoke, inference, coverage',
'and backward on the next M5, against its actual MLX. Retain metadata. The',
'stress suite intentionally exposes known failures; --suite all includes it.',
'Do not compile or run other GPU work concurrently with timing.','',
'handoff-all-shapes.txt / handoff-summary.json: complete comparison matrix.',
'handoff-results.csv: original orders, checks, hashes, source and phase mapping.',
'handoff-validation-raw.tar.gz: exact commands, logs, source snapshots and builds.',
'handoff-validation-index.json: verified per-file and archive SHA256 values.',
'research-2026-10-02-04.tar.gz / research-index.json: 629 preceding exploration',
'files, including rejected and noisy trials. Extract into separate directories.',
'Historical reports describe their checkpoints; this handoff supersedes their',
'commit-status and exact-Ultra gating statements.']
(out/'handoff.txt').write_text('\n'.join(lines)+'\n')
print('Wrote handoff report:',len(lines),'lines')
