from pathlib import Path
import subprocess,time,json
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-m5-handoff');records=[]
base=['python3','bin/mfa/na_application_sweep.py','--baseline-frontend',str(out/'baseline-probe')]
jobs=[('coverage',base+['--suite','coverage','--output',str(out/'coverage')],root),
      ('backward',base+['--suite','backward','--output',str(out/'backward')],root),
      ('mpsblas',['./mpsblas.tests'],root/'test/int/nnc'),
      ('mpsdnn',['./mpsdnn.tests'],root/'test/int/nnc')]
for name,cmd,cwd in jobs:
 start=time.time();print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,args=cmd,cwd=str(cwd),start=start,seconds=time.time()-start,exit=r.returncode))
 (out/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE',records[-1],flush=True)
