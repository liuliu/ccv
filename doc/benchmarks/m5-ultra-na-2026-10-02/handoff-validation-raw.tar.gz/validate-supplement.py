from pathlib import Path
import json,subprocess,time
root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-m5-handoff')
# Wait for the serial coverage/VJP/MPS supervisor to finish all four jobs.
while True:
 try:
  prior=json.loads((out/'validation.json').read_text())
  if len(prior)==4:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
records=[]
base=['python3','bin/mfa/na_application_sweep.py','--baseline-frontend',str(out/'baseline-probe')]
jobs=[('source-supplement',base+['--suite','coverage','--manifest',str(out/'source-supplement-manifest.json'),'--output',str(out/'source-supplement')]),
      ('stress',base+['--suite','stress','--output',str(out/'stress')])]
for name,cmd in jobs:
 start=time.time();print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,args=cmd,cwd=str(root),start=start,seconds=time.time()-start,exit=r.returncode))
 (out/'supplement-validation.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE',records[-1],flush=True)
