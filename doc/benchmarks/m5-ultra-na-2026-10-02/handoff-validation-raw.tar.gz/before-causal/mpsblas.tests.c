#include "case.h"
#include "ccv_case.h"
#include "ccv_nnc_case.h"
#include <ccv.h>
#include <nnc/ccv_nnc.h>
#include <nnc/ccv_nnc_easy.h>
#include <nnc/ccv_nnc_internal.h>
#include <nnc/mps/ccv_nnc_mps.h>
#include <3rdparty/dsfmt/dSFMT.h>
#ifdef HAVE_MPS
#include <dispatch/dispatch.h>
#include <nnc/_ccv_cnnp_model.h>
#include <nnc/_ccv_nnc_graph.h>
#endif
#include <float.h>
#include <math.h>
#include <stdlib.h>

TEST_SETUP()
{
	ccv_nnc_init();
}

static float _mps_forward_na_gemm_a_value(const int row, const int k)
{
	return (float)(((row * 17 + k * 13) % 23) + 1) / 512.0f;
}

static float _mps_forward_na_gemm_b_value(const int col, const int k)
{
	return (float)(((col * 19 + k * 7) % 29) + 1) / 512.0f;
}

static float _mps_forward_na_gemm_signed_a_value(const int row, const int k)
{
	return (float)(((row * 31 + k * 17) % 257) - 128) / 128.0f;
}

static float _mps_forward_na_gemm_signed_b_value(const int col, const int k)
{
	return (float)(((col * 13 + k * 29) % 251) - 125) / 128.0f;
}

static float _mps_forward_na_gemm_bias_value(const int col)
{
	return (float)(((col * 5) % 17) - 8) / 256.0f;
}

static void _mps_forward_na_gemm_fill_half(ccv_float16_t* const data, const int rows, const int cols, const int for_a)
{
	float* const row_buffer = (float*)ccmalloc(sizeof(float) * cols);
	int i, j;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
			row_buffer[j] = for_a ? _mps_forward_na_gemm_a_value(i, j) : _mps_forward_na_gemm_b_value(i, j);
		ccv_float_to_half_precision(row_buffer, (uint16_t*)data + (size_t)i * cols, cols);
	}
	ccfree(row_buffer);
}

static void _mps_forward_scaled_gemm_to_float(const int datatype, const void* const data, const int count, float* const values);

static float _mps_forward_na_gemm_round_value(const int datatype, const float value)
{
	if (datatype == CCV_16F)
	{
		uint16_t h;
		float f;
		ccv_float_to_half_precision(&value, &h, 1);
		ccv_half_precision_to_float(&h, &f, 1);
		return f;
	} else if (datatype == CCV_16BF) {
		uint16_t h;
		float f;
		ccv_float_to_bfloat(&value, &h, 1);
		ccv_bfloat_to_float(&h, &f, 1);
		return f;
	}
	return value;
}

static void _mps_forward_na_gemm_fill(const int datatype, void* const data, const int rows, const int cols, const int for_a)
{
	float* const values = (float*)ccmalloc(sizeof(float) * rows * cols);
	int i, j;
	for (i = 0; i < rows; i++)
		for (j = 0; j < cols; j++)
			values[i * cols + j] = for_a ? _mps_forward_na_gemm_a_value(i, j) : _mps_forward_na_gemm_b_value(i, j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, rows * cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, rows * cols);
	else
		memcpy(data, values, sizeof(float) * rows * cols);
	ccfree(values);
}

static void _mps_forward_na_gemm_fill_signed(const int datatype, void* const data, const int rows, const int cols, const int for_a)
{
	float* const values = (float*)ccmalloc(sizeof(float) * rows * cols);
	int i, j;
	for (i = 0; i < rows; i++)
		for (j = 0; j < cols; j++)
			values[i * cols + j] = for_a ? _mps_forward_na_gemm_signed_a_value(i, j) : _mps_forward_na_gemm_signed_b_value(i, j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, rows * cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, rows * cols);
	else
		memcpy(data, values, sizeof(float) * rows * cols);
	ccfree(values);
}

static void _mps_forward_na_gemm_fill_bias(const int datatype, void* const data, const int cols)
{
	float* const values = (float*)ccmalloc(sizeof(float) * cols);
	int j;
	for (j = 0; j < cols; j++)
		values[j] = _mps_forward_na_gemm_bias_value(j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, cols);
	else
		memcpy(data, values, sizeof(float) * cols);
	ccfree(values);
}

static float _mps_forward_na_gemm_expected(const int datatype, const int row, const int col, const int k_dim, const int use_bias)
{
	float sum = 0;
	int k;
	for (k = 0; k < k_dim; k++)
		sum += _mps_forward_na_gemm_round_value(datatype, _mps_forward_na_gemm_a_value(row, k)) *
			_mps_forward_na_gemm_round_value(datatype, _mps_forward_na_gemm_b_value(col, k));
	if (use_bias)
		sum += _mps_forward_na_gemm_round_value(datatype, _mps_forward_na_gemm_bias_value(col));
	return sum;
}

static float _mps_forward_na_gemm_expected_signed(const int datatype, const int row, const int col, const int k_dim, const int use_bias)
{
	float sum = 0;
	int k;
	for (k = 0; k < k_dim; k++)
		sum += _mps_forward_na_gemm_round_value(datatype, _mps_forward_na_gemm_signed_a_value(row, k)) *
			_mps_forward_na_gemm_round_value(datatype, _mps_forward_na_gemm_signed_b_value(col, k));
	if (use_bias)
		sum += _mps_forward_na_gemm_round_value(datatype, _mps_forward_na_gemm_bias_value(col));
	return sum;
}

static int _mps_forward_na_gemm_sample_indices(const int dim, const int boundary, const int include_large_m_boundary, int indices[8])
{
	const int candidates[] = {
		0, 1, boundary - 1, boundary,
		include_large_m_boundary ? 32767 : -1,
		include_large_m_boundary ? 32768 : -1,
		dim / 2, dim - 1,
	};
	int i, j;
	int count = 0;
	for (i = 0; i < 8; i++)
	{
		if (candidates[i] < 0 || candidates[i] >= dim)
			continue;
		for (j = 0; j < count; j++)
			if (indices[j] == candidates[i])
				break;
		if (j < count)
			continue;
		indices[count++] = candidates[i];
	}
	return count;
}

typedef struct {
	int row;
	int col;
	float actual;
	float expected;
	float max_abs;
	float max_rel;
} _mps_forward_na_gemm_mismatch_t;

static float _mps_forward_na_gemm_abs_tolerance(const int datatype)
{
	return datatype == CCV_16BF ? 2e-1f : 5e-2f;
}

static float _mps_forward_na_gemm_rel_tolerance(const int datatype)
{
	return datatype == CCV_16BF ? 5e-3f : 2e-3f;
}

static int _mps_forward_na_gemm_validate_shape_for_datatype(const int datatype, const int use_bias, const int m_dim, const int n_dim, const int k_dim, _mps_forward_na_gemm_mismatch_t* const mismatch)
{
	ccv_nnc_tensor_param_t ga_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gw_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t a_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t w_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t bias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t sample_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { 1, 1, 0 },
	};
	ccv_nnc_tensor_param_t gsample_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { 1, 1, 0 },
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, ga_params, 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, gw_params, 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, a_params, 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, w_params, 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, bias_params, 0) : 0;
	_mps_forward_na_gemm_fill(datatype, ha->data.u8, m_dim, k_dim, 1);
	_mps_forward_na_gemm_fill(datatype, hw->data.u8, n_dim, k_dim, 0);
	if (use_bias)
		_mps_forward_na_gemm_fill_bias(datatype, hbias->data.u8, n_dim);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(a, w, bias), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	else
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);

	int row_samples[8];
	int col_samples[8];
	const int row_sample_size = _mps_forward_na_gemm_sample_indices(m_dim, 128, 1, row_samples);
	const int col_sample_size = _mps_forward_na_gemm_sample_indices(n_dim, 64, 0, col_samples);
	ccv_nnc_tensor_t* const sample_h = ccv_nnc_tensor_new(0, sample_params, 0);
	int ok = 1;
	int i, j;
	for (i = 0; i < row_sample_size; i++)
		for (j = 0; j < col_sample_size; j++)
		{
			ccv_nnc_tensor_view_t* const bv = ccv_nnc_tensor_view_new(b, gsample_params, DIM_ALLOC(row_samples[i], col_samples[j]), DIM_ALLOC(n_dim, 1));
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)bv), TENSOR_LIST(sample_h), 0);
			mismatch->row = row_samples[i];
			mismatch->col = col_samples[j];
			_mps_forward_scaled_gemm_to_float(datatype, sample_h->data.u8, 1, &mismatch->actual);
			mismatch->expected = _mps_forward_na_gemm_expected(datatype, row_samples[i], col_samples[j], k_dim, use_bias);
			ccv_nnc_tensor_view_free(bv);
			const float abs_diff = fabsf(mismatch->actual - mismatch->expected);
			const float denom = fmaxf(fmaxf(fabsf(mismatch->actual), fabsf(mismatch->expected)), 1.0f);
			const float rel_diff = abs_diff / denom;
			if (abs_diff > mismatch->max_abs)
				mismatch->max_abs = abs_diff;
			if (rel_diff > mismatch->max_rel)
				mismatch->max_rel = rel_diff;
			if (abs_diff > _mps_forward_na_gemm_abs_tolerance(datatype) &&
				rel_diff > _mps_forward_na_gemm_rel_tolerance(datatype))
			{
				ok = 0;
				goto cleanup;
			}
		}

cleanup:
	ccv_nnc_tensor_free(sample_h);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	return ok;
}

static int _mps_forward_na_gemm_validate_full_shape_for_datatype(const int datatype, const int use_bias, const int signed_values, const int m_dim, const int n_dim, const int k_dim, _mps_forward_na_gemm_mismatch_t* const mismatch)
{
	ccv_nnc_tensor_param_t ga_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gw_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t a_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t w_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t bias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t b_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, ga_params, 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, gw_params, 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, a_params, 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, w_params, 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, bias_params, 0) : 0;
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, b_params, 0);
	if (signed_values)
	{
		_mps_forward_na_gemm_fill_signed(datatype, ha->data.u8, m_dim, k_dim, 1);
		_mps_forward_na_gemm_fill_signed(datatype, hw->data.u8, n_dim, k_dim, 0);
	} else {
		_mps_forward_na_gemm_fill(datatype, ha->data.u8, m_dim, k_dim, 1);
		_mps_forward_na_gemm_fill(datatype, hw->data.u8, n_dim, k_dim, 0);
	}
	if (use_bias)
		_mps_forward_na_gemm_fill_bias(datatype, hbias->data.u8, n_dim);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(a, w, bias), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	else
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	float* const actual = (float*)ccmalloc(sizeof(float) * m_dim * n_dim);
	_mps_forward_scaled_gemm_to_float(datatype, hb->data.u8, m_dim * n_dim, actual);
	int ok = 1;
	int i, j;
	for (i = 0; i < m_dim; i++)
		for (j = 0; j < n_dim; j++)
		{
			const float expected = signed_values ? _mps_forward_na_gemm_expected_signed(datatype, i, j, k_dim, use_bias) : _mps_forward_na_gemm_expected(datatype, i, j, k_dim, use_bias);
			const float abs_diff = fabsf(actual[i * n_dim + j] - expected);
			const float denom = fmaxf(fmaxf(fabsf(actual[i * n_dim + j]), fabsf(expected)), 1.0f);
			const float rel_diff = abs_diff / denom;
			if (abs_diff > mismatch->max_abs)
			{
				mismatch->row = i;
				mismatch->col = j;
				mismatch->actual = actual[i * n_dim + j];
				mismatch->expected = expected;
				mismatch->max_abs = abs_diff;
			}
			if (rel_diff > mismatch->max_rel)
				mismatch->max_rel = rel_diff;
			if (abs_diff > _mps_forward_na_gemm_abs_tolerance(datatype) &&
				rel_diff > _mps_forward_na_gemm_rel_tolerance(datatype))
				ok = 0;
		}
	ccfree(actual);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	return ok;
}

static int _mps_forward_na_gemm_validate_shape(const int m_dim, const int n_dim, const int k_dim, _mps_forward_na_gemm_mismatch_t* const mismatch)
{
	return _mps_forward_na_gemm_validate_shape_for_datatype(CCV_16F, 0, m_dim, n_dim, k_dim, mismatch);
}

static int _mps_forward_na_gemm_validate_shape_with_bias(const int m_dim, const int n_dim, const int k_dim, _mps_forward_na_gemm_mismatch_t* const mismatch)
{
	return _mps_forward_na_gemm_validate_shape_for_datatype(CCV_16F, 1, m_dim, n_dim, k_dim, mismatch);
}

static float _mps_forward_ane_stream_lhs_value(const int row, const int k, const int variant)
{
	return (float)((((row * 31 + k * 17 + variant * 19) % 97) - 48)) / 64.0f;
}

static float _mps_forward_ane_stream_rhs_value(const int row, const int k, const int variant)
{
	return (float)((((row * 13 + k * 29 + variant * 23) % 89) - 44)) / 64.0f;
}

static void _mps_forward_ane_stream_fill_half(ccv_float16_t* const data, const int rows, const int cols, const int variant, const int for_lhs)
{
	float* const row_buffer = (float*)ccmalloc(sizeof(float) * cols);
	int i, j;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
			row_buffer[j] = for_lhs ? _mps_forward_ane_stream_lhs_value(i, j, variant) : _mps_forward_ane_stream_rhs_value(i, j, variant);
		ccv_float_to_half_precision(row_buffer, (uint16_t*)data + (size_t)i * cols, cols);
	}
	ccfree(row_buffer);
}

static int _mps_forward_ane_rowwise_gemm_stream_sync_validate(double* const max_abs_ref, double* const max_rel_ref)
{
	const int m_dim = 512;
	const int n_dim = 768;
	const int k_dim = 1024;
	const int writer_k = 4096;
	ccv_nnc_tensor_t* const hlhs_old = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, writer_k), 0);
	ccv_nnc_tensor_t* const hrhs_old = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, k_dim, writer_k), 0);
	ccv_nnc_tensor_t* const hlhs_new = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, writer_k), 0);
	ccv_nnc_tensor_t* const hrhs_new = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, k_dim, writer_k), 0);
	ccv_nnc_tensor_t* const hw_dense = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n_dim, k_dim), 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16F, n_dim, k_dim)), 0);
	ccv_nnc_tensor_t* const lhs = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, writer_k), 0);
	ccv_nnc_tensor_t* const rhs = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, k_dim, writer_k), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, k_dim), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16F, n_dim, k_dim)), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const bref = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const hbref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, n_dim), 0);
	ccv_nnc_stream_context_t* const stream_context = ccv_nnc_stream_context_new(CCV_STREAM_CONTEXT_GPU);
	float* const actual = (float*)ccmalloc(sizeof(float) * m_dim * n_dim);
	float* const expected = (float*)ccmalloc(sizeof(float) * m_dim * n_dim);
	_mps_forward_ane_stream_fill_half(hlhs_old->data.f16, m_dim, writer_k, 0, 1);
	_mps_forward_ane_stream_fill_half(hrhs_old->data.f16, k_dim, writer_k, 0, 0);
	_mps_forward_ane_stream_fill_half(hlhs_new->data.f16, m_dim, writer_k, 1, 1);
	_mps_forward_ane_stream_fill_half(hrhs_new->data.f16, k_dim, writer_k, 1, 0);
	_mps_forward_na_gemm_fill_half(hw_dense->data.f16, n_dim, k_dim, 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(hw_dense->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	if (qsize != ccv_nnc_tensor_data_size_without_padding(hwq->info))
	{
		ccv_nnc_stream_context_free(stream_context);
		ccfree(expected);
		ccfree(actual);
		ccv_nnc_tensor_free(hbref);
		ccv_nnc_tensor_free(hb);
		ccv_nnc_tensor_free(bref);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(w);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(rhs);
		ccv_nnc_tensor_free(lhs);
		ccv_nnc_tensor_free(hwq);
		ccv_nnc_tensor_free(hw_dense);
		ccv_nnc_tensor_free(hrhs_new);
		ccv_nnc_tensor_free(hlhs_new);
		ccv_nnc_tensor_free(hrhs_old);
		ccv_nnc_tensor_free(hlhs_old);
		return -1;
	}
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hlhs_old, hrhs_old, hwq), TENSOR_LIST(lhs, rhs, w), stream_context);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(lhs, rhs), TENSOR_LIST(a), stream_context);
	ccv_nnc_synchronize_stream_context(stream_context);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), stream_context);
	ccv_nnc_synchronize_stream_context(stream_context);

	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hlhs_new, hrhs_new), TENSOR_LIST(lhs, rhs), stream_context);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(lhs, rhs), TENSOR_LIST(a), stream_context);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), stream_context);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), stream_context);
	ccv_nnc_synchronize_stream_context(stream_context);

	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hlhs_new, hrhs_new), TENSOR_LIST(lhs, rhs), stream_context);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(lhs, rhs), TENSOR_LIST(a), stream_context);
	ccv_nnc_synchronize_stream_context(stream_context);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(bref), stream_context);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(bref), TENSOR_LIST(hbref), stream_context);
	ccv_nnc_synchronize_stream_context(stream_context);

	_mps_forward_scaled_gemm_to_float(CCV_16F, hb->data.f16, m_dim * n_dim, actual);
	_mps_forward_scaled_gemm_to_float(CCV_16F, hbref->data.f16, m_dim * n_dim, expected);
	double max_abs = 0;
	double max_rel = 0;
	int i;
	for (i = 0; i < m_dim * n_dim; i++)
	{
		const double diff = fabs((double)actual[i] - (double)expected[i]);
		const double denom = ccv_max(1.0, ccv_max(fabs((double)actual[i]), fabs((double)expected[i])));
		max_abs = ccv_max(max_abs, diff);
		max_rel = ccv_max(max_rel, diff / denom);
	}
	if (max_abs_ref)
		*max_abs_ref = max_abs;
	if (max_rel_ref)
		*max_rel_ref = max_rel;
	ccfree(expected);
	ccfree(actual);
	ccv_nnc_stream_context_free(stream_context);
	ccv_nnc_tensor_free(hbref);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bref);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(rhs);
	ccv_nnc_tensor_free(lhs);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(hw_dense);
	ccv_nnc_tensor_free(hrhs_new);
	ccv_nnc_tensor_free(hlhs_new);
	ccv_nnc_tensor_free(hrhs_old);
	ccv_nnc_tensor_free(hlhs_old);
	return 0;
}

static void _mps_forward_scaled_gemm_fill_matrix(const int datatype, void* const data, const int rows, const int cols, const int for_a)
{
	float* const values = (float*)ccmalloc(sizeof(float) * rows * cols);
	int i, j;
	for (i = 0; i < rows; i++)
		for (j = 0; j < cols; j++)
			values[i * cols + j] = for_a ? _mps_forward_na_gemm_a_value(i, j) : _mps_forward_na_gemm_b_value(i, j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, rows * cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, rows * cols);
	else
		memcpy(data, values, sizeof(float) * rows * cols);
	ccfree(values);
}

static void _mps_forward_scaled_gemm_fill_bias(const int datatype, void* const data, const int cols)
{
	float* const values = (float*)ccmalloc(sizeof(float) * cols);
	int j;
	for (j = 0; j < cols; j++)
		values[j] = _mps_forward_na_gemm_bias_value(j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, cols);
	else
		memcpy(data, values, sizeof(float) * cols);
	ccfree(values);
}

static void _mps_forward_scaled_gemm_to_float(const int datatype, const void* const data, const int count, float* const values)
{
	if (datatype == CCV_16F)
		ccv_half_precision_to_float((const uint16_t*)data, values, count);
	else if (datatype == CCV_16BF)
		ccv_bfloat_to_float((const uint16_t*)data, values, count);
	else
		memcpy(values, data, sizeof(float) * count);
}

static void _mps_sdpa_store_float_as_datatype(const int datatype, const float* const values, void* const data, const int count)
{
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, count);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, count);
	else
		memcpy(data, values, sizeof(float) * count);
}

static void _mps_sdpa_round_to_datatype(const int datatype, const float* const values, float* const rounded, const int count)
{
	void* const data = ccmalloc((size_t)CCV_GET_DATA_TYPE_SIZE(datatype) * count);
	_mps_sdpa_store_float_as_datatype(datatype, values, data, count);
	_mps_forward_scaled_gemm_to_float(datatype, data, count, rounded);
	ccfree(data);
}

static int _mps_dequantize_8i_rowwise_x_compare(const int datatype, const int format, const int rows, const int cols, const double tolerance, double* const max_abs_ref)
{
	ccv_nnc_tensor_param_t host_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { rows, cols, 0 },
	};
	ccv_nnc_tensor_param_t gpu_params = host_params;
	gpu_params.type = CCV_TENSOR_GPU_MEMORY | 000;
	ccv_nnc_tensor_t* const source = ccv_nnc_tensor_new(0, host_params, 0);
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(host_params, format), 0);
	ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, host_params, 0);
	ccv_nnc_tensor_t* const gq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(gpu_params, format), 0);
	ccv_nnc_tensor_t* const gout = ccv_nnc_tensor_new(0, gpu_params, 0);
	ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, host_params, 0);
	_mps_forward_na_gemm_fill_signed(datatype, source->data.u8, rows, cols, 1);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise_x(source->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, (size_t)rows * cols, cols, format, 0, 0, q->data.u8, ccv_nnc_tensor_data_size_without_padding(q->info));
	int status = 0;
	if (qsize != ccv_nnc_tensor_data_size_without_padding(q->info))
	{
		status = -1;
		goto cleanup;
	}
	ccv_nnc_dequantize_8i_rowwise_x(q->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, qsize, cols, format, expected->data.u8, (size_t)rows * cols);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q), TENSOR_LIST(gq), 0);
	ccv_nnc_dequantize_8i_rowwise_x(gq->data.u8, datatype, CCV_TENSOR_GPU_MEMORY, qsize, cols, format, gout->data.u8, (size_t)rows * cols);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gout), TENSOR_LIST(actual), 0);
	float* const expected_f32 = (float*)ccmalloc(sizeof(float) * (size_t)rows * cols);
	float* const actual_f32 = (float*)ccmalloc(sizeof(float) * (size_t)rows * cols);
	_mps_forward_scaled_gemm_to_float(datatype, expected->data.u8, rows * cols, expected_f32);
	_mps_forward_scaled_gemm_to_float(datatype, actual->data.u8, rows * cols, actual_f32);
	double max_abs = 0;
	int i;
	for (i = 0; i < rows * cols; i++)
		max_abs = ccv_max(max_abs, fabs((double)expected_f32[i] - (double)actual_f32[i]));
	if (max_abs > tolerance)
		status = 1;
	if (max_abs_ref)
		*max_abs_ref = max_abs;
	ccfree(actual_f32);
	ccfree(expected_f32);
cleanup:
	ccv_nnc_tensor_free(actual);
	ccv_nnc_tensor_free(gout);
	ccv_nnc_tensor_free(gq);
	ccv_nnc_tensor_free(expected);
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(source);
	return status;
}

static int _mps_sdpa_attention_sinks_compare(const int datatype, const int force_generic, const int gpu_flags, const int B, const int R, const int C, const int Hq, const int Hk, const int D, const int is_causal, const int sink_count, const int sliding_window, const float tolerance, float* const max_abs_ref, float* const max_relative_ref, int* const max_idx_ref, float* const expected_ref, float* const actual_ref)
{
	const int q_count = B * R * Hq * D;
	const int kv_count = B * C * Hk * D;
	const float scale = 1.0 / sqrtf((float)D);
	const ccv_nnc_tensor_param_t q_ref_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = CCV_32F,
		.dim = { B, R, Hq, D },
	};
	const ccv_nnc_tensor_param_t kv_ref_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = CCV_32F,
		.dim = { B, C, Hk, D },
	};
	const ccv_nnc_tensor_param_t sink_ref_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = CCV_32F,
		.dim = { sink_count },
	};
	ccv_nnc_tensor_param_t q_input_params = q_ref_params;
	q_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t kv_input_params = kv_ref_params;
	kv_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t sink_input_params = sink_ref_params;
	sink_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t gpu_q_params = q_input_params;
	gpu_q_params.type = CCV_TENSOR_GPU_MEMORY | 000;
	ccv_nnc_tensor_param_t gpu_kv_params = kv_input_params;
	gpu_kv_params.type = CCV_TENSOR_GPU_MEMORY | 000;
	ccv_nnc_tensor_param_t gpu_sink_params = sink_input_params;
	gpu_sink_params.type = CCV_TENSOR_GPU_MEMORY | 000;
	ccv_nnc_tensor_t* const q_ref = ccv_nnc_tensor_new(0, q_ref_params, 0);
	ccv_nnc_tensor_t* const k_ref = ccv_nnc_tensor_new(0, kv_ref_params, 0);
	ccv_nnc_tensor_t* const v_ref = ccv_nnc_tensor_new(0, kv_ref_params, 0);
	ccv_nnc_tensor_t* const sinks_ref = ccv_nnc_tensor_new(0, sink_ref_params, 0);
	ccv_nnc_tensor_t* const q_input = ccv_nnc_tensor_new(0, q_input_params, 0);
	ccv_nnc_tensor_t* const k_input = ccv_nnc_tensor_new(0, kv_input_params, 0);
	ccv_nnc_tensor_t* const v_input = ccv_nnc_tensor_new(0, kv_input_params, 0);
	ccv_nnc_tensor_t* const sinks_input = ccv_nnc_tensor_new(0, sink_input_params, 0);
	for (int i = 0; i < q_count; ++i)
		q_ref->data.f32[i] = (float)(((i * 17 + R * 5 + is_causal * 11) % 97) - 48) / 256;
	for (int i = 0; i < kv_count; ++i)
	{
		k_ref->data.f32[i] = (float)(((i * 19 + C * 3) % 89) - 44) / 256;
		v_ref->data.f32[i] = (float)(((i * 23 + Hq * 7) % 101) - 50) / 128;
	}
	for (int i = 0; i < sink_count; ++i)
		sinks_ref->data.f32[i] = (float)(((i * 7 + D) % 13) - 6) / 32;
	_mps_sdpa_store_float_as_datatype(datatype, q_ref->data.f32, q_input->data.u8, q_count);
	_mps_sdpa_store_float_as_datatype(datatype, k_ref->data.f32, k_input->data.u8, kv_count);
	_mps_sdpa_store_float_as_datatype(datatype, v_ref->data.f32, v_input->data.u8, kv_count);
	_mps_sdpa_store_float_as_datatype(datatype, sinks_ref->data.f32, sinks_input->data.u8, sink_count);
	_mps_forward_scaled_gemm_to_float(datatype, q_input->data.u8, q_count, q_ref->data.f32);
	_mps_forward_scaled_gemm_to_float(datatype, k_input->data.u8, kv_count, k_ref->data.f32);
	_mps_forward_scaled_gemm_to_float(datatype, v_input->data.u8, kv_count, v_ref->data.f32);
	_mps_forward_scaled_gemm_to_float(datatype, sinks_input->data.u8, sink_count, sinks_ref->data.f32);

	ccv_nnc_tensor_t* const o_ref = ccv_nnc_tensor_new(0, q_ref_params, 0);
	ccv_nnc_cmd_t cpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
	cpu_cmd.info.scaled_dot_product_attention.attention_sinks = 1;
	cpu_cmd.info.scaled_dot_product_attention.sliding_window = sliding_window;
	if (ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_ref, k_ref, v_ref, NULL, NULL, NULL, NULL, NULL, sinks_ref), TENSOR_LIST(o_ref), 0) != CCV_NNC_EXEC_SUCCESS)
		return -1;

	ccv_nnc_tensor_t* const gpu_q = ccv_nnc_tensor_new(0, gpu_q_params, 0);
	ccv_nnc_tensor_t* const gpu_k = ccv_nnc_tensor_new(0, gpu_kv_params, 0);
	ccv_nnc_tensor_t* const gpu_v = ccv_nnc_tensor_new(0, gpu_kv_params, 0);
	ccv_nnc_tensor_t* const gpu_sinks = ccv_nnc_tensor_new(0, gpu_sink_params, 0);
	ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, gpu_q_params, 0);
	ccv_nnc_tensor_t* const o_actual = ccv_nnc_tensor_new(0, q_input_params, 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_input, k_input, v_input, sinks_input), TENSOR_LIST(gpu_q, gpu_k, gpu_v, gpu_sinks), 0);
	ccv_nnc_cmd_t gpu_cmd = cpu_cmd;
	gpu_cmd.info.scaled_dot_product_attention.flags = gpu_flags;
	const uint64_t old_flags = ccv_nnc_flags();
	if (force_generic)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int exec_status = ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q, gpu_k, gpu_v, NULL, NULL, NULL, NULL, NULL, gpu_sinks), TENSOR_LIST(gpu_o), 0);
	if (force_generic && !(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	if (exec_status != CCV_NNC_EXEC_SUCCESS)
		return -2;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o), TENSOR_LIST(o_actual), 0);

	float* const expected = (float*)ccmalloc(sizeof(float) * q_count);
	float* const actual = (float*)ccmalloc(sizeof(float) * q_count);
	_mps_sdpa_round_to_datatype(datatype, o_ref->data.f32, expected, q_count);
	_mps_forward_scaled_gemm_to_float(datatype, o_actual->data.u8, q_count, actual);
	float max_abs = 0;
	float max_relative = 0;
	int max_idx = 0;
	int status = 0;
	for (int i = 0; i < q_count; ++i)
	{
		if (!isfinite(actual[i]))
		{
			status = -3;
			max_idx = i;
			break;
		}
		const float abs_diff = fabsf(expected[i] - actual[i]);
		const float denom = fmaxf(fmaxf(fabsf(expected[i]), fabsf(actual[i])), 1.0f);
		const float relative = abs_diff / denom;
		if (relative > max_relative)
			max_relative = relative, max_abs = abs_diff, max_idx = i;
	}
	if (status == 0 && max_relative > tolerance)
		status = 1;
	*max_abs_ref = max_abs;
	*max_relative_ref = max_relative;
	*max_idx_ref = max_idx;
	*expected_ref = expected[max_idx];
	*actual_ref = actual[max_idx];

	ccfree(expected);
	ccfree(actual);
	ccv_nnc_tensor_free(o_actual);
	ccv_nnc_tensor_free(gpu_o);
	ccv_nnc_tensor_free(gpu_sinks);
	ccv_nnc_tensor_free(gpu_v);
	ccv_nnc_tensor_free(gpu_k);
	ccv_nnc_tensor_free(gpu_q);
	ccv_nnc_tensor_free(o_ref);
	ccv_nnc_tensor_free(sinks_input);
	ccv_nnc_tensor_free(v_input);
	ccv_nnc_tensor_free(k_input);
	ccv_nnc_tensor_free(q_input);
	ccv_nnc_tensor_free(sinks_ref);
	ccv_nnc_tensor_free(v_ref);
	ccv_nnc_tensor_free(k_ref);
	ccv_nnc_tensor_free(q_ref);
	return status;
}

static void _mps_forward_scaled_gemm_compare_rows(const int datatype, const void* const actual_data, const void* const expected_data, const int rows, const int cols, double* const max_abs_ref, double* const max_rel_ref)
{
	float* const actual_row = (float*)ccmalloc(sizeof(float) * cols);
	float* const expected_row = (float*)ccmalloc(sizeof(float) * cols);
	const size_t element_size = CCV_GET_DATA_TYPE_SIZE(datatype);
	const uint8_t* const actual_bytes = (const uint8_t*)actual_data;
	const uint8_t* const expected_bytes = (const uint8_t*)expected_data;
	double max_abs = 0;
	double max_rel = 0;
	int i, j;
	for (i = 0; i < rows; i++)
	{
		_mps_forward_scaled_gemm_to_float(datatype, actual_bytes + (size_t)i * cols * element_size, cols, actual_row);
		_mps_forward_scaled_gemm_to_float(datatype, expected_bytes + (size_t)i * cols * element_size, cols, expected_row);
		for (j = 0; j < cols; j++)
		{
			const double diff = fabs((double)actual_row[j] - (double)expected_row[j]);
			const double denom = ccv_max(1.0, ccv_max(fabs((double)actual_row[j]), fabs((double)expected_row[j])));
			max_abs = ccv_max(max_abs, diff);
			max_rel = ccv_max(max_rel, diff / denom);
		}
	}
	ccfree(expected_row);
	ccfree(actual_row);
	if (max_abs_ref)
		*max_abs_ref = max_abs;
	if (max_rel_ref)
		*max_rel_ref = max_rel;
}

static void _mps_forward_scaled_gemm_quantized_reference(const int datatype, const void* const data, const int rows, const int cols, float* const values)
{
	ccv_nnc_tensor_param_t params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { rows, cols, 0 },
	};
	const ccv_nnc_tensor_param_t qparams = ccv_nnc_tensor_8i_rowwise(params);
	const size_t qsize = ccv_nnc_tensor_data_size_without_padding(qparams);
	uint8_t* const qdata = (uint8_t*)ccmalloc(qsize);
	const size_t encoded = ccv_nnc_quantize_8i_rowwise(data, datatype, CCV_TENSOR_CPU_MEMORY, rows * cols, cols, 0, 0, qdata, qsize);
	void* dequantized = 0;
	if (datatype == CCV_16F || datatype == CCV_16BF)
		dequantized = ccmalloc(sizeof(uint16_t) * rows * cols);
	else
		dequantized = ccmalloc(sizeof(float) * rows * cols);
	ccv_nnc_dequantize_8i_rowwise(qdata, datatype, CCV_TENSOR_CPU_MEMORY, encoded, cols, dequantized, rows * cols);
	_mps_forward_scaled_gemm_to_float(datatype, dequantized, rows * cols, values);
	ccfree(dequantized);
	ccfree(qdata);
}

static void _mps_forward_scaled_gemm_reference(const float* const a, const float* const w, const float* const bias, const int m_dim, const int n_dim, const int k_dim, float* const out)
{
	int i, j, k;
	for (i = 0; i < m_dim; i++)
		for (j = 0; j < n_dim; j++)
		{
			float sum = bias ? bias[j] : 0;
			for (k = 0; k < k_dim; k++)
				sum += a[i * k_dim + k] * w[j * k_dim + k];
			out[i * n_dim + j] = sum;
		}
}

static float _mps_forward_scaled_gemm_a_batched_value(const int batch, const int row, const int k)
{
	return (float)(((batch * 11 + row * 17 + k * 13) % 41) - 20) / 256.0f;
}

static float _mps_forward_scaled_gemm_w_batched_value(const int batch, const int col, const int k)
{
	return (float)(((batch * 7 + col * 19 + k * 5) % 43) - 21) / 256.0f;
}

static float _mps_forward_scaled_gemm_bias_batched_value(const int batch, const int col)
{
	return (float)(((batch * 3 + col * 5) % 23) - 11) / 256.0f;
}

static void _mps_forward_scaled_gemm_fill_matrix_batched(const int datatype, void* const data, const int batch_dim, const int rows, const int cols, const int for_a)
{
	float* const values = (float*)ccmalloc(sizeof(float) * batch_dim * rows * cols);
	int b, i, j;
	for (b = 0; b < batch_dim; b++)
		for (i = 0; i < rows; i++)
			for (j = 0; j < cols; j++)
				values[((b * rows) + i) * cols + j] = for_a ? _mps_forward_scaled_gemm_a_batched_value(b, i, j) : _mps_forward_scaled_gemm_w_batched_value(b, i, j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, batch_dim * rows * cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, batch_dim * rows * cols);
	else
		memcpy(data, values, sizeof(float) * batch_dim * rows * cols);
	ccfree(values);
}

static void _mps_forward_scaled_gemm_fill_bias_batched(const int datatype, void* const data, const int batch_dim, const int cols)
{
	float* const values = (float*)ccmalloc(sizeof(float) * batch_dim * cols);
	int b, j;
	for (b = 0; b < batch_dim; b++)
		for (j = 0; j < cols; j++)
			values[b * cols + j] = _mps_forward_scaled_gemm_bias_batched_value(b, j);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(values, (uint16_t*)data, batch_dim * cols);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(values, (uint16_t*)data, batch_dim * cols);
	else
		memcpy(data, values, sizeof(float) * batch_dim * cols);
	ccfree(values);
}

static void _mps_forward_scaled_gemm_reference_batched(const float* const a, const float* const w, const float* const bias, const int batch_dim, const int w_batch_dim, const int bias_batch_dim, const int m_dim, const int n_dim, const int k_dim, float* const out)
{
	int b, i, j, k;
	for (b = 0; b < batch_dim; b++)
		for (i = 0; i < m_dim; i++)
			for (j = 0; j < n_dim; j++)
			{
				const int w_batch = (w_batch_dim > 1) ? b : 0;
				const int bias_batch = (bias_batch_dim > 1) ? b : 0;
				float sum = bias ? bias[bias_batch * n_dim + j] : 0;
				for (k = 0; k < k_dim; k++)
					sum += a[((b * m_dim) + i) * k_dim + k] * w[((w_batch * n_dim) + j) * k_dim + k];
				out[((b * m_dim) + i) * n_dim + j] = sum;
			}
}

static int _mps_forward_scaled_gemm_validate_shape(const int datatype, const int use_bias, const int m_dim, const int n_dim, const int k_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	ccv_nnc_tensor_param_t ga_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gw_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t a_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t w_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t b_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t bias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, a_params, 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(w_params), 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, bias_params, 0) : 0;
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, ga_params, 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(gw_params), 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, b_params, 0);
	_mps_forward_scaled_gemm_fill_matrix(datatype, ha->data.u8, m_dim, k_dim, 1);
	if (use_bias)
		_mps_forward_scaled_gemm_fill_bias(datatype, hbias->data.u8, n_dim);
	void* const w_dense = ccmalloc(CCV_GET_DATA_TYPE_SIZE(datatype) * n_dim * k_dim);
	_mps_forward_scaled_gemm_fill_matrix(datatype, w_dense, n_dim, k_dim, 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(w_dense, datatype, CCV_TENSOR_CPU_MEMORY, n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	if (qsize != ccv_nnc_tensor_data_size_without_padding(hwq->info))
	{
		ccfree(w_dense);
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(hwq);
		if (hbias)
			ccv_nnc_tensor_free(hbias);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(w);
		if (bias)
			ccv_nnc_tensor_free(bias);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(hb);
		return -1;
	}
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq, hbias), TENSOR_LIST(a, w, bias), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq), TENSOR_LIST(a, w), 0);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	else
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);

	float* const a_ref = (float*)ccmalloc(sizeof(float) * m_dim * k_dim);
	float* const w_ref = (float*)ccmalloc(sizeof(float) * n_dim * k_dim);
	float* const bias_ref = use_bias ? (float*)ccmalloc(sizeof(float) * n_dim) : 0;
	float* const actual = (float*)ccmalloc(sizeof(float) * m_dim * n_dim);
	float* const expected = (float*)ccmalloc(sizeof(float) * m_dim * n_dim);
	_mps_forward_scaled_gemm_quantized_reference(datatype, ha->data.u8, m_dim, k_dim, a_ref);
	_mps_forward_scaled_gemm_quantized_reference(datatype, w_dense, n_dim, k_dim, w_ref);
	if (use_bias)
		_mps_forward_scaled_gemm_to_float(datatype, hbias->data.u8, n_dim, bias_ref);
	_mps_forward_scaled_gemm_to_float(datatype, hb->data.u8, m_dim * n_dim, actual);
	_mps_forward_scaled_gemm_reference(a_ref, w_ref, bias_ref, m_dim, n_dim, k_dim, expected);
	double max_abs = 0;
	double max_rel = 0;
	int i;
	for (i = 0; i < m_dim * n_dim; i++)
	{
		const double diff = fabs((double)actual[i] - (double)expected[i]);
		const double denom = ccv_max(1.0, ccv_max(fabs((double)actual[i]), fabs((double)expected[i])));
		max_abs = ccv_max(max_abs, diff);
		max_rel = ccv_max(max_rel, diff / denom);
	}
	if (max_abs_ref)
		*max_abs_ref = max_abs;
	if (max_rel_ref)
		*max_rel_ref = max_rel;

	ccfree(expected);
	ccfree(actual);
	if (bias_ref)
		ccfree(bias_ref);
	ccfree(w_ref);
	ccfree(a_ref);
	ccfree(w_dense);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hwq);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(hb);
	return 0;
}

static int _mps_forward_scaled_gemm_validate(const int datatype, const int use_bias, double* const max_abs_ref, double* const max_rel_ref)
{
	return _mps_forward_scaled_gemm_validate_shape(datatype, use_bias, 257, 384, 128, max_abs_ref, max_rel_ref);
}

static int _mps_forward_scaled_gemm_validate_aligned_m(const int datatype, const int use_bias, double* const max_abs_ref, double* const max_rel_ref)
{
	return _mps_forward_scaled_gemm_validate_shape(datatype, use_bias, 384, 384, 128, max_abs_ref, max_rel_ref);
}

static int _mps_forward_ane_k_split_validate_shape(const int m_dim, const int n_dim, const int k_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, k_dim), 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16F, n_dim, k_dim)), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, k_dim), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16F, n_dim, k_dim)), 0);
	ccv_nnc_tensor_t* const baseline_b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const ane_b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const baseline_h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const ane_h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m_dim, n_dim), 0);
	_mps_forward_scaled_gemm_fill_matrix(CCV_16F, ha->data.f16, m_dim, k_dim, 1);
	void* const w_dense = ccmalloc(sizeof(ccv_float16_t) * (size_t)n_dim * k_dim);
	_mps_forward_scaled_gemm_fill_matrix(CCV_16F, w_dense, n_dim, k_dim, 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(w_dense, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	int status = qsize == ccv_nnc_tensor_data_size_without_padding(hwq->info) ? CCV_NNC_EXEC_SUCCESS : CCV_NNC_EXEC_INVALID;
	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq), TENSOR_LIST(a, w), 0);

	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(baseline_b), 0);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(ane_b), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (old_flags & CCV_NNC_DISABLE_MFA_ANE)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);

	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(baseline_b, ane_b), TENSOR_LIST(baseline_h, ane_h), 0);
	float* const baseline = (float*)ccmalloc(sizeof(float) * (size_t)m_dim * n_dim);
	float* const ane = (float*)ccmalloc(sizeof(float) * (size_t)m_dim * n_dim);
	if (status == CCV_NNC_EXEC_SUCCESS)
	{
		_mps_forward_scaled_gemm_to_float(CCV_16F, baseline_h->data.f16, m_dim * n_dim, baseline);
		_mps_forward_scaled_gemm_to_float(CCV_16F, ane_h->data.f16, m_dim * n_dim, ane);
		double max_abs = 0;
		double max_rel = 0;
		int i;
		for (i = 0; i < m_dim * n_dim; i++)
		{
			const double diff = fabs((double)ane[i] - (double)baseline[i]);
			const double denom = ccv_max(1.0, ccv_max(fabs((double)ane[i]), fabs((double)baseline[i])));
			max_abs = ccv_max(max_abs, diff);
			max_rel = ccv_max(max_rel, diff / denom);
		}
		if (max_abs_ref)
			*max_abs_ref = max_abs;
		if (max_rel_ref)
			*max_rel_ref = max_rel;
	}
	ccfree(ane);
	ccfree(baseline);
	ccfree(w_dense);
	ccv_nnc_tensor_free(ane_h);
	ccv_nnc_tensor_free(baseline_h);
	ccv_nnc_tensor_free(ane_b);
	ccv_nnc_tensor_free(baseline_b);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(ha);
	return status == CCV_NNC_EXEC_SUCCESS ? 0 : -1;
}

static int _mps_forward_scaled_gemm_validate_batched(const int datatype, const int use_bias, const int weight_batched, const int bias_batched, double* const max_abs_ref, double* const max_rel_ref)
{
	const int batch_dim = 2;
	const int m_dim = 129;
	const int n_dim = 384;
	const int k_dim = 128;
	ccv_nnc_tensor_param_t ga_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gw_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { weight_batched ? batch_dim : n_dim, weight_batched ? n_dim : k_dim, weight_batched ? k_dim : 0, 0 },
	};
	ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { bias_batched ? batch_dim : n_dim, bias_batched ? n_dim : 0, 0, 0 },
	};
	ccv_nnc_tensor_param_t a_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t w_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { weight_batched ? batch_dim : n_dim, weight_batched ? n_dim : k_dim, weight_batched ? k_dim : 0, 0 },
	};
	ccv_nnc_tensor_param_t b_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t bias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { bias_batched ? batch_dim : n_dim, bias_batched ? n_dim : 0, 0, 0 },
	};
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, a_params, 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(w_params), 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, bias_params, 0) : 0;
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, ga_params, 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(gw_params), 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, b_params, 0);
	_mps_forward_scaled_gemm_fill_matrix_batched(datatype, ha->data.u8, batch_dim, m_dim, k_dim, 1);
	if (use_bias)
	{
		if (bias_batched)
			_mps_forward_scaled_gemm_fill_bias_batched(datatype, hbias->data.u8, batch_dim, n_dim);
		else
			_mps_forward_scaled_gemm_fill_bias(datatype, hbias->data.u8, n_dim);
	}
	const int w_batch_dim = weight_batched ? batch_dim : 1;
	void* const w_dense = ccmalloc(CCV_GET_DATA_TYPE_SIZE(datatype) * w_batch_dim * n_dim * k_dim);
	if (weight_batched)
		_mps_forward_scaled_gemm_fill_matrix_batched(datatype, w_dense, batch_dim, n_dim, k_dim, 0);
	else
		_mps_forward_scaled_gemm_fill_matrix(datatype, w_dense, n_dim, k_dim, 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(w_dense, datatype, CCV_TENSOR_CPU_MEMORY, w_batch_dim * n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	if (qsize != ccv_nnc_tensor_data_size_without_padding(hwq->info))
	{
		ccfree(w_dense);
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(hwq);
		if (hbias)
			ccv_nnc_tensor_free(hbias);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(w);
		if (bias)
			ccv_nnc_tensor_free(bias);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(hb);
		return -1;
	}
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq, hbias), TENSOR_LIST(a, w, bias), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq), TENSOR_LIST(a, w), 0);
	if (weight_batched)
	{
		if (use_bias)
			ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
		else
			ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	} else {
		if (use_bias)
			ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
		else
			ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	}
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);

	float* const a_ref = (float*)ccmalloc(sizeof(float) * batch_dim * m_dim * k_dim);
	float* const w_ref = (float*)ccmalloc(sizeof(float) * w_batch_dim * n_dim * k_dim);
	float* const bias_ref = use_bias ? (float*)ccmalloc(sizeof(float) * (bias_batched ? batch_dim : 1) * n_dim) : 0;
	float* const actual = (float*)ccmalloc(sizeof(float) * batch_dim * m_dim * n_dim);
	float* const expected = (float*)ccmalloc(sizeof(float) * batch_dim * m_dim * n_dim);
	_mps_forward_scaled_gemm_quantized_reference(datatype, ha->data.u8, batch_dim * m_dim, k_dim, a_ref);
	_mps_forward_scaled_gemm_quantized_reference(datatype, w_dense, w_batch_dim * n_dim, k_dim, w_ref);
	if (use_bias)
		_mps_forward_scaled_gemm_to_float(datatype, hbias->data.u8, (bias_batched ? batch_dim : 1) * n_dim, bias_ref);
	_mps_forward_scaled_gemm_to_float(datatype, hb->data.u8, batch_dim * m_dim * n_dim, actual);
	_mps_forward_scaled_gemm_reference_batched(a_ref, w_ref, bias_ref, batch_dim, w_batch_dim, bias_batched ? batch_dim : 1, m_dim, n_dim, k_dim, expected);
	double max_abs = 0;
	double max_rel = 0;
	int i;
	for (i = 0; i < batch_dim * m_dim * n_dim; i++)
	{
		const double diff = fabs((double)actual[i] - (double)expected[i]);
		const double denom = ccv_max(1.0, ccv_max(fabs((double)actual[i]), fabs((double)expected[i])));
		max_abs = ccv_max(max_abs, diff);
		max_rel = ccv_max(max_rel, diff / denom);
	}
	if (max_abs_ref)
		*max_abs_ref = max_abs;
	if (max_rel_ref)
		*max_rel_ref = max_rel;

	ccfree(expected);
	ccfree(actual);
	if (bias_ref)
		ccfree(bias_ref);
	ccfree(w_ref);
	ccfree(a_ref);
	ccfree(w_dense);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hwq);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(hb);
	return 0;
}

static int _mps_forward_scaled_gemm_validate_interleaved_batched(const int token_dim, const int n_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	const int datatype = CCV_16F;
	const int format = CCV_NNC_QX_8I_ROWWISE_IQ2_XXS;
	const int group_dim = 3;
	const int k_dim = 256;
	const ccv_nnc_tensor_param_t ha_params = CPU_TENSOR_NHWC(16F, token_dim, group_dim, 1, k_dim);
	const ccv_nnc_tensor_param_t hwd_params = CPU_TENSOR_NHWC(16F, group_dim, n_dim, k_dim);
	const ccv_nnc_tensor_param_t hb_params = CPU_TENSOR_NHWC(16F, token_dim, group_dim, 1, n_dim);
	const ccv_nnc_tensor_param_t a_params = GPU_TENSOR_NHWC(000, 16F, token_dim, group_dim, 1, k_dim);
	const ccv_nnc_tensor_param_t w_params = GPU_TENSOR_NHWC(000, 16F, group_dim, n_dim, k_dim);
	const ccv_nnc_tensor_param_t b_params = GPU_TENSOR_NHWC(000, 16F, token_dim, group_dim, 1, n_dim);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, ha_params, 0);
	ccv_nnc_tensor_t* const hwd = ccv_nnc_tensor_new(0, hwd_params, 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(hwd_params, format), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, hb_params, 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, a_params, 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(w_params, format), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, b_params, 0);
	float* const a_values = (float*)ccmalloc(sizeof(float) * token_dim * group_dim * k_dim);
	float* const w_values = (float*)ccmalloc(sizeof(float) * group_dim * n_dim * k_dim);
	int t, g, j, k;
	for (t = 0; t < token_dim; t++)
		for (g = 0; g < group_dim; g++)
			for (k = 0; k < k_dim; k++)
				a_values[((t * group_dim + g) * k_dim) + k] = _mps_forward_scaled_gemm_a_batched_value(g, t, k);
	for (g = 0; g < group_dim; g++)
		for (j = 0; j < n_dim; j++)
			for (k = 0; k < k_dim; k++)
				w_values[((g * n_dim + j) * k_dim) + k] = _mps_forward_scaled_gemm_w_batched_value(g, j, k);
	ccv_float_to_half_precision(a_values, (uint16_t*)ha->data.u8, token_dim * group_dim * k_dim);
	ccv_float_to_half_precision(w_values, (uint16_t*)hwd->data.u8, group_dim * n_dim * k_dim);
	ccfree(w_values);
	ccfree(a_values);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise_x(hwd->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, (size_t)group_dim * n_dim * k_dim, k_dim, format, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	int status = qsize == ccv_nnc_tensor_data_size_without_padding(hwq->info) ? CCV_NNC_EXEC_SUCCESS : CCV_NNC_EXEC_INVALID;
	if (status == CCV_NNC_EXEC_SUCCESS)
		ccv_nnc_dequantize_8i_rowwise_x(hwq->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, qsize, k_dim, format, hwd->data.u8, (size_t)group_dim * n_dim * k_dim);
	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq), TENSOR_LIST(a, w), 0);
	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	if (status == CCV_NNC_EXEC_SUCCESS)
		status = ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	if (status == CCV_NNC_EXEC_SUCCESS)
	{
		float* const a_ref = (float*)ccmalloc(sizeof(float) * token_dim * group_dim * k_dim);
		float* const w_ref = (float*)ccmalloc(sizeof(float) * group_dim * n_dim * k_dim);
		float* const actual = (float*)ccmalloc(sizeof(float) * token_dim * group_dim * n_dim);
		_mps_forward_scaled_gemm_quantized_reference(datatype, ha->data.u8, token_dim * group_dim, k_dim, a_ref);
		_mps_forward_scaled_gemm_to_float(datatype, hwd->data.u8, group_dim * n_dim * k_dim, w_ref);
		_mps_forward_scaled_gemm_to_float(datatype, hb->data.u8, token_dim * group_dim * n_dim, actual);
		double max_abs = 0;
		double max_rel = 0;
		for (t = 0; t < token_dim; t++)
			for (g = 0; g < group_dim; g++)
				for (j = 0; j < n_dim; j++)
				{
					float expected = 0;
					for (k = 0; k < k_dim; k++)
						expected += a_ref[((t * group_dim + g) * k_dim) + k] * w_ref[((g * n_dim + j) * k_dim) + k];
					const float value = actual[((t * group_dim + g) * n_dim) + j];
					const double diff = fabs((double)value - (double)expected);
					const double denom = ccv_max(1.0, ccv_max(fabs((double)value), fabs((double)expected)));
					max_abs = ccv_max(max_abs, diff);
					max_rel = ccv_max(max_rel, diff / denom);
				}
		if (max_abs_ref)
			*max_abs_ref = max_abs;
		if (max_rel_ref)
			*max_rel_ref = max_rel;
		ccfree(actual);
		ccfree(w_ref);
		ccfree(a_ref);
	}
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(hwd);
	ccv_nnc_tensor_free(ha);
	return status == CCV_NNC_EXEC_SUCCESS ? 0 : -1;
}

static int _mps_forward_scaled_gemm_compare_dense_format(const int datatype, const int use_bias, const int m_dim, const int n_dim, const int k_dim, const int format, double* const max_abs_ref, double* const max_rel_ref)
{
	ccv_nnc_tensor_param_t ga_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gwq_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = ((datatype >> 12) & 0xff) | CCV_QX | (format ? CCV_NNC_QX_8I_ROWWISE_X : CCV_NNC_QX_8I_ROWWISE),
		.dim = { n_dim, k_dim, 0 },
		.reserved = format,
	};
	ccv_nnc_tensor_param_t gwd_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t a_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t wd_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t b_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t bias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, a_params, 0);
	ccv_nnc_tensor_t* const hwd = ccv_nnc_tensor_new(0, wd_params, 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, format ? ccv_nnc_tensor_8i_rowwise_x(wd_params, format) : ccv_nnc_tensor_8i_rowwise(wd_params), 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, bias_params, 0) : 0;
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, ga_params, 0);
	ccv_nnc_tensor_t* const wq = ccv_nnc_tensor_new(0, gwq_params, 0);
	ccv_nnc_tensor_t* const wd = ccv_nnc_tensor_new(0, gwd_params, 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const bq = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const bd = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const hbq = ccv_nnc_tensor_new(0, b_params, 0);
	ccv_nnc_tensor_t* const hbd = ccv_nnc_tensor_new(0, b_params, 0);
	_mps_forward_scaled_gemm_fill_matrix(datatype, ha->data.u8, m_dim, k_dim, 1);
	_mps_forward_scaled_gemm_fill_matrix(datatype, hwd->data.u8, n_dim, k_dim, 0);
	if (use_bias)
		_mps_forward_scaled_gemm_fill_bias(datatype, hbias->data.u8, n_dim);
	const size_t qsize = format ? ccv_nnc_quantize_8i_rowwise_x(hwd->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, n_dim * k_dim, k_dim, format, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info)) : ccv_nnc_quantize_8i_rowwise(hwd->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	if (qsize != ccv_nnc_tensor_data_size_without_padding(hwq->info))
		return -1;
	if (format)
		ccv_nnc_dequantize_8i_rowwise_x(hwq->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, qsize, k_dim, format, hwd->data.u8, n_dim * k_dim);
	if (use_bias)
	{
		if (format)
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq, hwd, hbias), TENSOR_LIST(a, wq, wd, bias), 0);
		else
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq, hbias), TENSOR_LIST(a, wq, bias), 0);
	} else {
		if (format)
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq, hwd), TENSOR_LIST(a, wq, wd), 0);
		else
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq), TENSOR_LIST(a, wq), 0);
	}
	if (!format)
		ccv_nnc_dequantize_8i_rowwise(wq->data.u8, datatype, CCV_TENSOR_GPU_MEMORY, qsize, k_dim, wd->data.u8, n_dim * k_dim);
	if (use_bias) {
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, wq, bias), TENSOR_LIST(bq), 0);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, wd, bias), TENSOR_LIST(bd), 0);
	} else {
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, wq), TENSOR_LIST(bq), 0);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, wd), TENSOR_LIST(bd), 0);
	}
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(bq, bd), TENSOR_LIST(hbq, hbd), 0);
	_mps_forward_scaled_gemm_compare_rows(datatype, hbq->data.u8, hbd->data.u8, m_dim, n_dim, max_abs_ref, max_rel_ref);
	ccv_nnc_tensor_free(hbq);
	ccv_nnc_tensor_free(hbd);
	ccv_nnc_tensor_free(bq);
	ccv_nnc_tensor_free(bd);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(wq);
	ccv_nnc_tensor_free(wd);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hwd);
	ccv_nnc_tensor_free(hwq);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	if (bias)
		ccv_nnc_tensor_free(bias);
	return 0;
}

static int _mps_forward_scaled_gemm_compare_dense(const int datatype, const int use_bias, const int m_dim, const int n_dim, const int k_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	return _mps_forward_scaled_gemm_compare_dense_format(datatype, use_bias, m_dim, n_dim, k_dim, 0, max_abs_ref, max_rel_ref);
}

static void _mps_forward_fp32_gemv_compare_cpu(const int use_bias, const int n_dim, const int k_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, k_dim), 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n_dim, k_dim), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, n_dim), 0);
	ccv_nnc_tensor_t* const hb_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, n_dim), 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n_dim), 0) : 0;
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, k_dim), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, n_dim, k_dim), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, n_dim), 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, n_dim), 0) : 0;
	_mps_forward_scaled_gemm_fill_matrix(CCV_32F, ha->data.u8, 1, k_dim, 1);
	_mps_forward_scaled_gemm_fill_matrix(CCV_32F, hw->data.u8, n_dim, k_dim, 0);
	if (use_bias)
	{
		_mps_forward_scaled_gemm_fill_bias(CCV_32F, hbias->data.u8, n_dim);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(a, w, bias), 0);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb_ref), 0);
	} else {
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb_ref), 0);
	}
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	double max_abs = 0;
	double max_rel = 0;
	int i;
	for (i = 0; i < n_dim; i++)
	{
		const double diff = fabs((double)hb->data.f32[i] - (double)hb_ref->data.f32[i]);
		const double denom = ccv_max(1.0, ccv_max(fabs((double)hb->data.f32[i]), fabs((double)hb_ref->data.f32[i])));
		max_abs = ccv_max(max_abs, diff);
		max_rel = ccv_max(max_rel, diff / denom);
	}
	*max_abs_ref = max_abs;
	*max_rel_ref = max_rel;
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(a);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb_ref);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(ha);
}

static int _mps_forward_scaled_gemm_compare_dense_batched_padded_a_shape(const int datatype, const int use_bias, const int batch_dim, const int m_dim, const int n_dim, const int k_dim, const int padded_m_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	ccv_nnc_tensor_param_t ga_storage_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, padded_m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t ga_view_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gwq_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = ((datatype >> 12) & 0xff) | CCV_QX | CCV_NNC_QX_8I_ROWWISE,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_param_t ha_storage_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, padded_m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t ha_view_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t wd_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, k_dim, 0 },
	};
	ccv_nnc_tensor_param_t b_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { batch_dim, m_dim, n_dim, 0 },
	};
	ccv_nnc_tensor_param_t bias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { n_dim, 0 },
	};
	ccv_nnc_tensor_t* const ha_storage = ccv_nnc_tensor_new(0, ha_storage_params, 0);
	ccv_nnc_tensor_t* const hwd = ccv_nnc_tensor_new(0, wd_params, 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(wd_params), 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, bias_params, 0) : 0;
	ccv_nnc_tensor_t* const a_storage = ccv_nnc_tensor_new(0, ga_storage_params, 0);
	ccv_nnc_tensor_t* const wq = ccv_nnc_tensor_new(0, gwq_params, 0);
	ccv_nnc_tensor_t* const bq = ccv_nnc_tensor_new(0, gb_params, 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const hbq = ccv_nnc_tensor_new(0, b_params, 0);
	ccv_nnc_tensor_view_t* const ha = ccv_nnc_tensor_view_new(ha_storage, ha_view_params, ccv_nnc_no_ofs, DIM_ALLOC(padded_m_dim * k_dim, k_dim, 1));
	ccv_nnc_tensor_view_t* const a = ccv_nnc_tensor_view_new(a_storage, ga_view_params, ccv_nnc_no_ofs, DIM_ALLOC(padded_m_dim * k_dim, k_dim, 1));
	float* const a_ref = (float*)ccmalloc(sizeof(float) * batch_dim * m_dim * k_dim);
	float* const w_ref = (float*)ccmalloc(sizeof(float) * n_dim * k_dim);
	float* const bias_ref = use_bias ? (float*)ccmalloc(sizeof(float) * n_dim) : 0;
	float* const out_ref = (float*)ccmalloc(sizeof(float) * batch_dim * m_dim * n_dim);
	int bch, i, j;
	for (bch = 0; bch < batch_dim; bch++)
		for (i = 0; i < padded_m_dim; i++)
			for (j = 0; j < k_dim; j++)
			{
				const int dst = ((bch * padded_m_dim) + i) * k_dim + j;
				float value = 0;
				if (i < m_dim)
				{
					value = _mps_forward_scaled_gemm_a_batched_value(bch, i, j);
					a_ref[((bch * m_dim) + i) * k_dim + j] = value;
				}
				if (datatype == CCV_16F)
					ccv_float_to_half_precision(&value, ((uint16_t*)ha_storage->data.u8) + dst, 1);
				else if (datatype == CCV_16BF)
					ccv_float_to_bfloat(&value, ((uint16_t*)ha_storage->data.u8) + dst, 1);
				else
					((float*)ha_storage->data.f32)[dst] = value;
			}
	_mps_forward_scaled_gemm_fill_matrix(datatype, hwd->data.u8, n_dim, k_dim, 0);
	_mps_forward_scaled_gemm_to_float(datatype, hwd->data.u8, n_dim * k_dim, w_ref);
	if (use_bias)
	{
		_mps_forward_scaled_gemm_fill_bias(datatype, hbias->data.u8, n_dim);
		_mps_forward_scaled_gemm_to_float(datatype, hbias->data.u8, n_dim, bias_ref);
	}
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(hwd->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	if (qsize != ccv_nnc_tensor_data_size_without_padding(hwq->info))
		return -1;
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha_storage, hwq, hbias), TENSOR_LIST(a_storage, wq, bias), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha_storage, hwq), TENSOR_LIST(a_storage, wq), 0);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)a, wq, bias), TENSOR_LIST(bq), 0);
	else
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)a, wq), TENSOR_LIST(bq), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(bq), TENSOR_LIST(hbq), 0);
	_mps_forward_scaled_gemm_reference_batched(a_ref, w_ref, bias_ref, batch_dim, 1, use_bias ? 1 : 0, m_dim, n_dim, k_dim, out_ref);
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(out_ref, (uint16_t*)ha_storage->data.u8, batch_dim * m_dim * n_dim);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(out_ref, (uint16_t*)ha_storage->data.u8, batch_dim * m_dim * n_dim);
	else
		memcpy(ha_storage->data.f32, out_ref, sizeof(float) * batch_dim * m_dim * n_dim);
	_mps_forward_scaled_gemm_compare_rows(datatype, hbq->data.u8, ha_storage->data.u8, batch_dim * m_dim, n_dim, max_abs_ref, max_rel_ref);
	ccfree(out_ref);
	if (bias_ref)
		ccfree(bias_ref);
	ccfree(w_ref);
	ccfree(a_ref);
	ccv_nnc_tensor_view_free(ha);
	ccv_nnc_tensor_view_free(a);
	ccv_nnc_tensor_free(ha_storage);
	ccv_nnc_tensor_free(hwd);
	ccv_nnc_tensor_free(hwq);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(a_storage);
	ccv_nnc_tensor_free(wq);
	ccv_nnc_tensor_free(bq);
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(hbq);
	return 0;
}

static float _mps_segmented_scaled_gemm_a_value(const int row, const int k)
{
	return (float)(((row * 17 + k * 13) % 61) - 30) / 128.0f;
}

static float _mps_segmented_scaled_gemm_w_value(const int expert, const int col, const int k)
{
	return (float)(((expert * 23 + col * 11 + k * 7) % 67) - 33) / 256.0f;
}

static float _mps_segmented_scaled_gemm_bias_value(const int expert, const int col)
{
	return (float)(((expert * 5 + col * 3) % 29) - 14) / 256.0f;
}

static int _mps_segmented_scaled_gemm_validate_format_shape_experts_dims(const int datatype, const int use_bias, const int force_fallback, const int format, const int total_m, const int expert_count, const int bincount, const int guard_output, const int n_dim, const int k_dim, double* const max_abs_ref, double* const max_rel_ref)
{
	assert(bincount > 0);
	assert(expert_count >= bincount);
	int* const counts_data = (int*)cccalloc(expert_count, sizeof(int));
	int* const indices_data = (int*)ccmalloc(sizeof(int) * expert_count);
	int remaining = total_m;
	int i;
	for (i = 0; i < bincount; i++)
	{
		const int remaining_bins = bincount - i;
		counts_data[i] = (remaining + remaining_bins - 1) / remaining_bins;
		remaining -= counts_data[i];
		indices_data[i] = (i * 13 + 7) % expert_count;
	}
	// These entries are outside the declared views. They make an accidental
	// expert-count loop deterministic and expose writes beyond the output view.
	for (i = bincount; i < expert_count; i++)
	{
		counts_data[i] = guard_output;
		indices_data[i] = i;
	}
	const int output_storage_rows = total_m + (guard_output ? expert_count - bincount : 0);
	const ccv_nnc_tensor_param_t ha_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { total_m, k_dim, 0 },
	};
	const ccv_nnc_tensor_param_t hwd_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { expert_count, n_dim, k_dim, 0 },
	};
	const ccv_nnc_tensor_param_t hbias_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { expert_count, n_dim, 0 },
	};
	const ccv_nnc_tensor_param_t ga_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { total_m, k_dim, 0 },
	};
	const ccv_nnc_tensor_param_t gw_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { expert_count, n_dim, k_dim, 0 },
	};
	const ccv_nnc_tensor_param_t gbias_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { expert_count, n_dim, 0 },
	};
	const ccv_nnc_tensor_param_t gb_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { total_m, n_dim, 0 },
	};
	const ccv_nnc_tensor_param_t hb_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { total_m, n_dim, 0 },
	};
	const ccv_nnc_tensor_param_t gb_storage_params = {
		.type = CCV_TENSOR_GPU_MEMORY | 000,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { output_storage_rows, n_dim, 0 },
	};
	const ccv_nnc_tensor_param_t hb_storage_params = {
		.type = CCV_TENSOR_CPU_MEMORY,
		.format = CCV_TENSOR_FORMAT_NHWC,
		.datatype = datatype,
		.dim = { output_storage_rows, n_dim, 0 },
	};
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, ha_params, 0);
	ccv_nnc_tensor_t* const hindices_storage = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, expert_count), 0);
	ccv_nnc_tensor_t* const hcounts_storage = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, expert_count), 0);
	ccv_nnc_tensor_view_t* const hindices = ccv_nnc_tensor_view_new(hindices_storage, CPU_TENSOR_NHWC(32S, bincount), ccv_nnc_no_ofs, DIM_ALLOC(1));
	ccv_nnc_tensor_view_t* const hcounts = ccv_nnc_tensor_view_new(hcounts_storage, CPU_TENSOR_NHWC(32S, bincount), ccv_nnc_no_ofs, DIM_ALLOC(1));
	ccv_nnc_tensor_t* const hwd = ccv_nnc_tensor_new(0, hwd_params, 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, format ? ccv_nnc_tensor_8i_rowwise_x(hwd_params, format) : ccv_nnc_tensor_8i_rowwise(hwd_params), 0);
	ccv_nnc_tensor_t* const hbias = use_bias ? ccv_nnc_tensor_new(0, hbias_params, 0) : 0;
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, ga_params, 0);
	ccv_nnc_tensor_t* const indices_storage = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, expert_count), 0);
	ccv_nnc_tensor_t* const counts_storage = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, expert_count), 0);
	ccv_nnc_tensor_view_t* const indices = ccv_nnc_tensor_view_new(indices_storage, GPU_TENSOR_NHWC(000, 32S, bincount), ccv_nnc_no_ofs, DIM_ALLOC(1));
	ccv_nnc_tensor_view_t* const counts = ccv_nnc_tensor_view_new(counts_storage, GPU_TENSOR_NHWC(000, 32S, bincount), ccv_nnc_no_ofs, DIM_ALLOC(1));
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, format ? ccv_nnc_tensor_8i_rowwise_x(gw_params, format) : ccv_nnc_tensor_8i_rowwise(gw_params), 0);
	ccv_nnc_tensor_t* const bias = use_bias ? ccv_nnc_tensor_new(0, gbias_params, 0) : 0;
	ccv_nnc_tensor_t* const b_storage = ccv_nnc_tensor_new(0, gb_storage_params, 0);
	ccv_nnc_tensor_view_t* const b = ccv_nnc_tensor_view_new(b_storage, gb_params, ccv_nnc_no_ofs, DIM_ALLOC(n_dim, 1));
	ccv_nnc_tensor_t* const hb_storage = ccv_nnc_tensor_new(0, hb_storage_params, 0);
	float* const a_values = (float*)ccmalloc(sizeof(float) * total_m * k_dim);
	float* const w_values = (float*)ccmalloc(sizeof(float) * expert_count * n_dim * k_dim);
	float* const bias_values = use_bias ? (float*)ccmalloc(sizeof(float) * expert_count * n_dim) : 0;
	int j, k;
	for (i = 0; i < total_m; i++)
		for (k = 0; k < k_dim; k++)
			a_values[i * k_dim + k] = _mps_segmented_scaled_gemm_a_value(i, k);
	if (force_fallback && datatype == CCV_32F && !use_bias)
	{
		// Avoid pervasive half-integer quantization ties in the periodic fixture
		// when comparing CPU division with Metal's fast-math reciprocal.
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 0);
		for (i = 0; i < total_m * k_dim; i++)
			a_values[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
		if (total_m / bincount >= 64)
		{
			// Make the larger 32-row-tile fixture unambiguous under either CPU
			// or Metal reciprocal rounding, without making quantization a no-op.
			for (i = 0; i < total_m * k_dim; i++)
				a_values[i] = (floorf(a_values[i] * 252) + 0.25f) / 128;
			for (i = 0; i < total_m; i++)
				a_values[i * k_dim] = 127.0f / 128;
		}
	}
	for (i = 0; i < expert_count; i++)
		for (j = 0; j < n_dim; j++)
			for (k = 0; k < k_dim; k++)
				w_values[((i * n_dim) + j) * k_dim + k] = _mps_segmented_scaled_gemm_w_value(i, j, k);
	if (use_bias)
		for (i = 0; i < expert_count; i++)
			for (j = 0; j < n_dim; j++)
				bias_values[i * n_dim + j] = _mps_segmented_scaled_gemm_bias_value(i, j);
	if (datatype == CCV_16F)
	{
		ccv_float_to_half_precision(a_values, (uint16_t*)ha->data.u8, total_m * k_dim);
		ccv_float_to_half_precision(w_values, (uint16_t*)hwd->data.u8, expert_count * n_dim * k_dim);
		if (use_bias)
			ccv_float_to_half_precision(bias_values, (uint16_t*)hbias->data.u8, expert_count * n_dim);
	} else if (datatype == CCV_16BF) {
		ccv_float_to_bfloat(a_values, (uint16_t*)ha->data.u8, total_m * k_dim);
		ccv_float_to_bfloat(w_values, (uint16_t*)hwd->data.u8, expert_count * n_dim * k_dim);
		if (use_bias)
			ccv_float_to_bfloat(bias_values, (uint16_t*)hbias->data.u8, expert_count * n_dim);
	} else {
		memcpy(ha->data.f32, a_values, sizeof(float) * total_m * k_dim);
		memcpy(hwd->data.f32, w_values, sizeof(float) * expert_count * n_dim * k_dim);
		if (use_bias)
			memcpy(hbias->data.f32, bias_values, sizeof(float) * expert_count * n_dim);
	}
	memcpy(hindices_storage->data.i32, indices_data, sizeof(int) * expert_count);
	memcpy(hcounts_storage->data.i32, counts_data, sizeof(int) * expert_count);
	const size_t qsize = format ? ccv_nnc_quantize_8i_rowwise_x(hwd->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, (size_t)expert_count * n_dim * k_dim, k_dim, format, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info)) : ccv_nnc_quantize_8i_rowwise(hwd->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, (size_t)expert_count * n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	if (qsize != ccv_nnc_tensor_data_size_without_padding(hwq->info))
		return -1;
	if (format)
		ccv_nnc_dequantize_8i_rowwise_x(hwq->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, qsize, k_dim, format, hwd->data.u8, (size_t)expert_count * n_dim * k_dim);
	const float guard_value = 7;
	float* const guard_values = (float*)ccmalloc(sizeof(float) * output_storage_rows * n_dim);
	for (i = 0; i < output_storage_rows * n_dim; i++)
		guard_values[i] = guard_value;
	if (datatype == CCV_16F)
		ccv_float_to_half_precision(guard_values, (uint16_t*)hb_storage->data.u8, output_storage_rows * n_dim);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(guard_values, (uint16_t*)hb_storage->data.u8, output_storage_rows * n_dim);
	else
		memcpy(hb_storage->data.f32, guard_values, sizeof(float) * output_storage_rows * n_dim);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hb_storage), TENSOR_LIST(b_storage), 0);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hindices_storage, hcounts_storage, hwq, hbias), TENSOR_LIST(a, indices_storage, counts_storage, w, bias), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hindices_storage, hcounts_storage, hwq), TENSOR_LIST(a, indices_storage, counts_storage, w), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	if (force_fallback)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	int exec_status;
	if (use_bias)
		exec_status = ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, (ccv_nnc_tensor_t*)indices, (ccv_nnc_tensor_t*)counts, w, bias), TENSOR_LIST((ccv_nnc_tensor_t*)b), 0);
	else
		exec_status = ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, (ccv_nnc_tensor_t*)indices, (ccv_nnc_tensor_t*)counts, w), TENSOR_LIST((ccv_nnc_tensor_t*)b), 0);
	if (force_fallback && !(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b_storage), TENSOR_LIST(hb_storage), 0);

	float* const a_ref = (float*)ccmalloc(sizeof(float) * total_m * k_dim);
	float* const w_ref = (float*)ccmalloc(sizeof(float) * expert_count * n_dim * k_dim);
	float* const bias_ref = use_bias ? (float*)ccmalloc(sizeof(float) * expert_count * n_dim) : 0;
	float* const actual = (float*)ccmalloc(sizeof(float) * total_m * n_dim);
	ccv_nnc_tensor_t* const ha_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, total_m, k_dim), 0);
	ccv_nnc_tensor_t* const hw_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, expert_count, n_dim, k_dim), 0);
	ccv_nnc_tensor_t* const hbias_ref = use_bias ? ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, expert_count, n_dim), 0) : 0;
	ccv_nnc_tensor_t* const bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, total_m, n_dim), 0);
	if (force_fallback && datatype == CCV_32F && !use_bias && total_m != bincount)
	{
		// Int8MatMul quantizes activations with absmax rather than the offline
		// weight quantizer's iteratively fitted scale.
		for (i = 0; i < total_m; i++)
		{
			float max_abs = 0;
			for (k = 0; k < k_dim; k++)
				max_abs = ccv_max(max_abs, fabsf(ha->data.f32[i * k_dim + k]));
			const float scale = max_abs > 0 ? max_abs / 127.0f : 1.0f / 127.0f;
			const float inv_scale = max_abs > 0 ? 127.0f / max_abs : 127.0f;
			for (k = 0; k < k_dim; k++)
				a_ref[i * k_dim + k] = scale *
					ccv_clamp((int)lrintf(ha->data.f32[i * k_dim + k] * inv_scale), -127, 127);
		}
	} else if (force_fallback)
		_mps_forward_scaled_gemm_to_float(datatype, ha->data.u8, total_m * k_dim, a_ref);
	else
		_mps_forward_scaled_gemm_quantized_reference(datatype, ha->data.u8, total_m, k_dim, a_ref);
	if (format)
		_mps_forward_scaled_gemm_to_float(datatype, hwd->data.u8, expert_count * n_dim * k_dim, w_ref);
	else
		_mps_forward_scaled_gemm_quantized_reference(datatype, hwd->data.u8, expert_count * n_dim, k_dim, w_ref);
	if (use_bias)
		_mps_forward_scaled_gemm_to_float(datatype, hbias->data.u8, expert_count * n_dim, bias_ref);
	_mps_forward_scaled_gemm_to_float(datatype, hb_storage->data.u8, total_m * n_dim, actual);
	memcpy(ha_ref->data.f32, a_ref, sizeof(float) * total_m * k_dim);
	memcpy(hw_ref->data.f32, w_ref, sizeof(float) * expert_count * n_dim * k_dim);
	if (use_bias)
		memcpy(hbias_ref->data.f32, bias_ref, sizeof(float) * expert_count * n_dim);
	if (use_bias)
		ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha_ref, (ccv_nnc_tensor_t*)hindices, (ccv_nnc_tensor_t*)hcounts, hw_ref, hbias_ref), TENSOR_LIST(bt), 0);
	else
		ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha_ref, (ccv_nnc_tensor_t*)hindices, (ccv_nnc_tensor_t*)hcounts, hw_ref), TENSOR_LIST(bt), 0);
	double max_abs = 0;
	double max_rel = 0;
	for (i = 0; i < total_m * n_dim; i++)
	{
		// A later finite element must not hide NaNs through ccv_max.
		if (!isfinite(actual[i]) || !isfinite(bt->data.f32[i]))
		{
			max_abs = max_rel = INFINITY;
			break;
		}
		const double diff = fabs((double)actual[i] - (double)bt->data.f32[i]);
		const double denom = ccv_max(1.0, ccv_max(fabs((double)actual[i]), fabs((double)bt->data.f32[i])));
		max_abs = ccv_max(max_abs, diff);
		max_rel = ccv_max(max_rel, diff / denom);
	}
	if (max_abs_ref)
		*max_abs_ref = max_abs;
	if (max_rel_ref)
		*max_rel_ref = max_rel;
	int guard_status = 0;
	if (guard_output)
	{
		float* const guarded = (float*)ccmalloc(sizeof(float) * (output_storage_rows - total_m) * n_dim);
		_mps_forward_scaled_gemm_to_float(datatype, hb_storage->data.u8 + ccv_nnc_tensor_data_size(hb_params), (output_storage_rows - total_m) * n_dim, guarded);
		for (i = 0; i < (output_storage_rows - total_m) * n_dim; i++)
			if (guarded[i] != guard_value)
			{
				guard_status = -2;
				break;
			}
		ccfree(guarded);
	}
	ccv_nnc_tensor_free(bt);
	if (hbias_ref)
		ccv_nnc_tensor_free(hbias_ref);
	ccv_nnc_tensor_free(hw_ref);
	ccv_nnc_tensor_free(ha_ref);
	ccfree(actual);
	if (bias_ref)
		ccfree(bias_ref);
	ccfree(w_ref);
	ccfree(a_ref);
	ccfree(a_values);
	ccfree(w_values);
	if (bias_values)
		ccfree(bias_values);
	ccfree(guard_values);
	ccv_nnc_tensor_free(hb_storage);
	ccv_nnc_tensor_view_free(b);
	ccv_nnc_tensor_free(b_storage);
	if (bias)
		ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_view_free(counts);
	ccv_nnc_tensor_view_free(indices);
	ccv_nnc_tensor_free(counts_storage);
	ccv_nnc_tensor_free(indices_storage);
	ccv_nnc_tensor_free(a);
	if (hbias)
		ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(hwd);
	ccv_nnc_tensor_view_free(hcounts);
	ccv_nnc_tensor_view_free(hindices);
	ccv_nnc_tensor_free(hcounts_storage);
	ccv_nnc_tensor_free(hindices_storage);
	ccv_nnc_tensor_free(ha);
	ccfree(indices_data);
	ccfree(counts_data);
	return exec_status != CCV_NNC_EXEC_SUCCESS ? exec_status : guard_status;
}

static int _mps_segmented_scaled_gemm_validate_format_shape_experts(const int datatype, const int use_bias, const int force_fallback, const int format, const int total_m, const int expert_count, const int bincount, const int guard_output, double* const max_abs_ref, double* const max_rel_ref)
{
	return _mps_segmented_scaled_gemm_validate_format_shape_experts_dims(datatype, use_bias, force_fallback, format, total_m, expert_count, bincount, guard_output, 128, 256, max_abs_ref, max_rel_ref);
}

static int _mps_segmented_scaled_gemm_validate_format_shape(const int datatype, const int use_bias, const int force_fallback, const int format, const int total_m, double* const max_abs_ref, double* const max_rel_ref)
{
	const int expert_count = format ? 4 : 3;
	return _mps_segmented_scaled_gemm_validate_format_shape_experts(datatype, use_bias, force_fallback, format, total_m, expert_count, expert_count, 0, max_abs_ref, max_rel_ref);
}

static int _mps_segmented_scaled_gemm_validate_format(const int datatype, const int use_bias, const int force_fallback, const int format, double* const max_abs_ref, double* const max_rel_ref)
{
	return _mps_segmented_scaled_gemm_validate_format_shape(datatype, use_bias, force_fallback, format, 384, max_abs_ref, max_rel_ref);
}

static int _mps_segmented_scaled_gemm_validate(const int datatype, const int use_bias, const int force_fallback, double* const max_abs_ref, double* const max_rel_ref)
{
	return _mps_segmented_scaled_gemm_validate_format(datatype, use_bias, force_fallback, 0, max_abs_ref, max_rel_ref);
}

TEST_CASE("mps H256 rowwise-x dequantization matches CPU across codecs precisions and cached shapes")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	const int datatypes[] = {CCV_32F, CCV_16F, CCV_16BF};
	int d, codec, shape;
	for (d = 0; d < 3; d++)
		for (codec = CCV_NNC_QX_8I_ROWWISE_Q4_K; codec <= CCV_NNC_QX_8I_ROWWISE_Q6_K; codec++)
			for (shape = 0; shape < 3; shape++)
			{
				// Ordinary / H256 / larger H256 descriptors share the base codec,
				// but must not reuse a shader or dispatch from the wrong variant.
				const int format = codec | (shape ? CCV_NNC_QX_8I_ROWWISE_HADAMARD_256 : 0);
				double max_abs = 0;
				const int status = _mps_dequantize_8i_rowwise_x_compare(datatypes[d], format, shape == 2 ? 29 : 13, shape == 2 ? 768 : 256, d == 0 ? 1e-6 : d == 1 ? 1e-3 : 1e-2, &max_abs);
				REQUIRE_EQ(status, 0, "logical dequantization matches CPU: codec=%d dtype=%d shape=%d max_abs=%g", codec, datatypes[d], shape, max_abs);
			}
	// Dense fallback is not limited by the activation quantizer's K <= 65536.
	double max_abs = 0;
	REQUIRE_EQ(_mps_dequantize_8i_rowwise_x_compare(CCV_32F, CCV_NNC_QX_8I_ROWWISE_Q6_K | CCV_NNC_QX_8I_ROWWISE_HADAMARD_256, 1, 65792, 1e-6, &max_abs), 0, "wide logical weight decode matches CPU");
}

TEST_CASE("mps H256 rowwise-x GEMM dense fallback preserves logical weights")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int datatypes[] = {CCV_32F, CCV_16F, CCV_16BF};
	const int codecs[] = {CCV_NNC_QX_8I_ROWWISE_Q6_K, CCV_NNC_QX_8I_ROWWISE_Q4_K, CCV_NNC_QX_8I_ROWWISE_IQ2_XXS};
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 257);
	int d, shape, path;
	for (d = 0; d < 3; d++)
		for (shape = 0; shape < 6; shape++)
		{
			// Cover GEMV, ordinary GEMM, transposed activations, batched weights,
			// untransposed weights (whose stored row length is N, not K),
			// and K beyond the activation quantizer limit.
			const int m = shape == 0 || shape == 5 ? 1 : 37;
			const int batches = shape == 3 ? 2 : 1;
			const int n = shape == 4 ? 256 : shape == 5 ? 3 : 73;
			const int k = shape == 4 ? 513 : shape == 5 ? 65792 : 512;
			const int transpose_a = shape == 2;
			const int transpose_w = shape != 4;
			const int datatype = datatypes[d];
			ccv_nnc_tensor_param_t a_params = CPU_TENSOR_NHWC(32F, batches, transpose_a ? k : m, transpose_a ? m : k);
			ccv_nnc_tensor_param_t w_params = CPU_TENSOR_NHWC(32F, batches, transpose_w ? n : k, transpose_w ? k : n);
			ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, a_params, 0);
			ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, w_params, 0);
			ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
			ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, batches, m, n), 0);
			ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, href->info, 0);
			a_params.datatype = w_params.datatype = datatype;
			ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, a_params, 0);
			ccv_nnc_tensor_t* const weights = ccv_nnc_tensor_new(0, w_params, 0);
			ccv_nnc_tensor_param_t bias_params = hbias->info;
			bias_params.datatype = datatype;
			ccv_nnc_tensor_t* const input_bias = ccv_nnc_tensor_new(0, bias_params, 0);
			const int format = codecs[shape == 5 ? 0 : shape % 3] | CCV_NNC_QX_8I_ROWWISE_HADAMARD_256;
			ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(w_params, format), 0);
			ccv_nnc_tensor_param_t q_params = hq->info;
			q_params.type = a_params.type = bias_params.type = CCV_TENSOR_GPU_MEMORY;
			ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, q_params, 0);
			ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, a_params, 0);
			ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, bias_params, 0);
			ccv_nnc_tensor_param_t b_params = href->info;
			b_params.datatype = datatype;
			ccv_nnc_tensor_t* const result = ccv_nnc_tensor_new(0, b_params, 0);
			b_params.type = CCV_TENSOR_GPU_MEMORY;
			ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, b_params, 0);
			int i;
			for (i = 0; i < batches * m * k; i++)
				ha->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) / 4;
			for (i = 0; i < batches * n * k; i++)
				hw->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) / 4;
			for (i = 0; i < n; i++)
				hbias->data.f32[i] = (i % 11 - 5) / 128.f;
			ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(input, weights, input_bias), 0);
			const size_t size = ccv_nnc_tensor_data_size_without_padding(hq->info);
			const int row_length = transpose_w ? k : n;
			REQUIRE_EQ(ccv_nnc_quantize_8i_rowwise_x(weights->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, batches * n * k, row_length, format, 0, 0, hq->data.u8, size), size, "H256 weights quantize");
			ccv_nnc_dequantize_8i_rowwise_x(hq->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, size, row_length, format, weights->data.u8, batches * n * k);
			ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(input, weights, input_bias), TENSOR_LIST(ha, hw, hbias), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(input, hq, input_bias), TENSOR_LIST(a, q, bias), 0);
			const ccv_nnc_cmd_t cmd = CMD_GEMM_FORWARD(TRANSPOSE(transpose_a ? 1 : 0, transpose_a ? 2 : 0), TRANSPOSE(transpose_w ? 1 : 0, transpose_w ? 2 : 0));
			REQUIRE_EQ(ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, shape == 0 ? 0 : hbias), TENSOR_LIST(href), 0), CCV_NNC_EXEC_SUCCESS, "CPU logical weight GEMM succeeds");
			for (path = 0; path < 2; path++)
			{
				const uint64_t old_flags = ccv_nnc_flags();
				const uint64_t fallback_flags = CCV_NNC_DISABLE_MFA_ANE | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS | (path ? CCV_NNC_DISABLE_MFA : 0);
				ccv_nnc_enable_flag(fallback_flags);
				const int status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, q, shape == 0 ? 0 : bias), TENSOR_LIST(b), 0);
				ccv_nnc_disable_flag(fallback_flags & ~old_flags);
				REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "dense fallback succeeds: dtype=%d shape=%d path=%d", datatype, shape, path);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(result), 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(result), TENSOR_LIST(actual), 0);
				for (i = 0; i < batches * m * n; i++)
					REQUIRE(fabsf(actual->data.f32[i] - href->data.f32[i]) < (datatype == CCV_16BF ? (shape == 5 ? 8e-3 : 4e-3) : datatype == CCV_16F ? 1e-3 : 1e-5), "logical weight GEMM: dtype=%d shape=%d path=%d i=%d actual=%g expected=%g", datatype, shape, path, i, actual->data.f32[i], href->data.f32[i]);
			}
			ccv_nnc_tensor_free(ha); ccv_nnc_tensor_free(hw); ccv_nnc_tensor_free(hbias);
			ccv_nnc_tensor_free(href); ccv_nnc_tensor_free(actual); ccv_nnc_tensor_free(input);
			ccv_nnc_tensor_free(weights); ccv_nnc_tensor_free(input_bias); ccv_nnc_tensor_free(hq);
			ccv_nnc_tensor_free(q); ccv_nnc_tensor_free(a); ccv_nnc_tensor_free(bias);
			ccv_nnc_tensor_free(result); ccv_nnc_tensor_free(b);
		}
}

TEST_CASE("mps H256 rowwise-x GEMM rejects malformed K metadata")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 384), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(GPU_TENSOR_NHWC(000, 32F, 73, 384), CCV_NNC_QX_8I_ROWWISE_Q6_K), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 73), 0);
	// Bypass the constructor's rejection to exercise backend validation too.
	w->info.reserved |= CCV_NNC_QX_8I_ROWWISE_HADAMARD_256;
	REQUIRE_EQ(ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0), CCV_NNC_EXEC_INVALID, "invalid K must not dispatch");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
}

TEST_CASE("mps H256 rowwise-x GEMM uses rotated activations and ordinary output")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
#ifdef HAVE_MPS
	extern uint8_t ccv_nnc_mfa_has_neural_accelerators(ccv_nnc_mfa_context_t* context);
	GUARD_ELSE_RETURN(ccv_nnc_mfa_has_neural_accelerators(ccv_nnc_default_mfa_context()));
	const uint64_t entry_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	enum { n = 73, k = 512 };
	const int codecs[] = {CCV_NNC_QX_8I_ROWWISE_IQ2_XXS, CCV_NNC_QX_8I_ROWWISE_Q6_K};
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 256);
	int f, shape;
	for (f = 0; f < 2; f++)
		for (shape = 0; shape < 3; shape++)
		{
			const int m = shape == 0 ? 3 : 37;
			const int batches = shape == 2 ? 2 : 1;
			ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, batches, m, k), 0);
			ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
			ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
			ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, batches, m, n), 0);
			ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, href->info, 0);
			const int format = codecs[f] | CCV_NNC_QX_8I_ROWWISE_HADAMARD_256;
			ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(hw->info, format), 0);
			ccv_nnc_tensor_param_t q_params = hq->info;
			q_params.type = CCV_TENSOR_GPU_MEMORY;
			ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, q_params, 0);
			ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, batches, m, k), 0);
			ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, n), 0);
			ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, batches, m, n), 0);
			int i, j, l, shift;
			for (i = 0; i < batches * m * k; i++)
				ha->data.f32[i] = ((int)(dsfmt_genrand_open_close(&dsfmt) * 255) - 127) / 128.f;
			for (i = 0; i < n * k; i++)
				hw->data.f32[i] = ((int)(dsfmt_genrand_open_close(&dsfmt) * 255) - 127) / 128.f;
			for (i = 0; i < n; i++)
				hbias->data.f32[i] = (i % 11 - 5) / 128.f;
			const size_t size = ccv_nnc_tensor_data_size_without_padding(hq->info);
			REQUIRE_EQ(ccv_nnc_quantize_8i_rowwise_x(hw->data.f32, CCV_32F, CCV_TENSOR_CPU_MEMORY, n * k, k, format, 0, 0, hq->data.u8, size), size, "offline H256 quantization succeeds with N not divisible by 256");
			// Explicit raw base-codec decode gives stored rotated weights.
			ccv_nnc_dequantize_8i_rowwise_x(hq->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, size, k, codecs[f], hw->data.f32, n * k);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hq, hbias), TENSOR_LIST(a, q, bias), 0);
			// Independent dense transform followed by the runtime absmax INT8 rule.
			float rotated[k];
			for (i = 0; i < batches * m; i++)
			{
				float max_abs = 0;
				for (j = 0; j < k; j++)
				{
					double sum = 0;
					for (l = 0; l < 256; l++)
					{
						int sign = 1;
						for (shift = 0; shift < 8; shift += 2)
							if (((j >> shift) & 3) + ((l >> shift) & 3) == 3)
								sign = -sign;
						sum += sign * ha->data.f32[i * k + (j / 256) * 256 + l];
					}
					rotated[j] = sum / 16;
					max_abs = ccv_max(max_abs, fabsf(rotated[j]));
				}
				const float scale = max_abs > 0 ? max_abs / 127.f : 1.f / 127.f;
				const float inv_scale = max_abs > 0 ? 127.f / max_abs : 127.f;
				for (j = 0; j < k; j++)
					ha->data.f32[i * k + j] = scale * ccv_clamp((int)lrintf(rotated[j] * inv_scale), -127, 127);
			}
			REQUIRE_EQ(ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(href), 0), CCV_NNC_EXEC_SUCCESS, "CPU reference succeeds");
			const uint64_t old_flags = ccv_nnc_flags();
			if (shape == 1)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			const int status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, q, bias), TENSOR_LIST(b), 0);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "flagged GEMM succeeds");
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(actual), 0);
			for (i = 0; i < batches * m * n; i++)
				REQUIRE(fabsf(actual->data.f32[i] - href->data.f32[i]) / ccv_max(1.f, fabsf(href->data.f32[i])) < 5e-4, "rotated INT8 reference matches without output inverse at %d: %g vs %g", i, actual->data.f32[i], href->data.f32[i]);
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
			const int fallback_status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, q, bias), TENSOR_LIST(b), 0);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
			REQUIRE_EQ(fallback_status, CCV_NNC_EXEC_SUCCESS, "dense fallback accepts rotated weights");
			ccv_nnc_tensor_free(ha); ccv_nnc_tensor_free(hw); ccv_nnc_tensor_free(hbias);
			ccv_nnc_tensor_free(href); ccv_nnc_tensor_free(actual); ccv_nnc_tensor_free(hq);
			ccv_nnc_tensor_free(q); ccv_nnc_tensor_free(a); ccv_nnc_tensor_free(bias); ccv_nnc_tensor_free(b);
		}
	if (!(entry_flags & CCV_NNC_DISABLE_MFA_ANE))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
#endif
}


TEST_CASE("mps H256 rowwise-x GEMM ANE fused activation quantization")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
#ifdef HAVE_MPS
	extern uint8_t ccv_nnc_mfa_supports_int8_ane(ccv_nnc_mfa_context_t* context);
	GUARD_ELSE_RETURN(ccv_nnc_mfa_supports_int8_ane(ccv_nnc_default_mfa_context()));
	const uint64_t entry_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	enum { n = 256 };
	const int datatypes[] = {CCV_32F, CCV_16F, CCV_16BF};
	const int codecs[] = {CCV_NNC_QX_8I_ROWWISE_IQ2_XXS, CCV_NNC_QX_8I_ROWWISE_Q6_K};
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 256);
	int f, shape, d;
	for (d = 0; d < 3; d++)
		for (f = 0; f < 2; f++)
			for (shape = 0; shape < 7; shape++)
			{
				// Q6_K additionally covers the single-pass boundary and wide-row
				// recomputation, including batched scales, padded rows, and the
				// three-SIMD-group layout for K=5376 with model-like M and ANE K splits.
				if (shape >= 3 && f == 0)
					continue;
				const int k = shape < 3 ? 1024 : shape == 3 ? 8192 : shape == 4 ? 8448 : shape == 5 ? 14336 : 5376;
				const int m = shape == 0 || shape == 3 ? 3 : shape < 3 ? 129 : shape == 6 ? 513 : 17;
				const int datatype = datatypes[d];
				const int batches = shape == 2 || shape == 4 ? 2 : 1;
				ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, batches, m, k), 0);
				ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
				ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
				ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, batches, m, n), 0);
				ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, href->info, 0);
				ccv_nnc_tensor_param_t source_params = ha->info;
				source_params.datatype = datatype;
				ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, source_params, 0);
				ccv_nnc_tensor_param_t weight_params = hw->info;
				weight_params.datatype = datatype;
				ccv_nnc_tensor_t* const weights = ccv_nnc_tensor_new(0, weight_params, 0);
				ccv_nnc_tensor_param_t bias_params = hbias->info;
				bias_params.datatype = datatype;
				ccv_nnc_tensor_t* const input_bias = ccv_nnc_tensor_new(0, bias_params, 0);
				const int format = codecs[f] | CCV_NNC_QX_8I_ROWWISE_HADAMARD_256;
				ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise_x(weights->info, format), 0);
				ccv_nnc_tensor_param_t q_params = hq->info;
				q_params.type = CCV_TENSOR_GPU_MEMORY;
				ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, q_params, 0);
				source_params.type = bias_params.type = CCV_TENSOR_GPU_MEMORY;
				ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, source_params, 0);
				ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, bias_params, 0);
				ccv_nnc_tensor_param_t result_params = actual->info;
				result_params.datatype = datatype;
				ccv_nnc_tensor_t* const result = ccv_nnc_tensor_new(0, result_params, 0);
				result_params.type = CCV_TENSOR_GPU_MEMORY;
				ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, result_params, 0);
				int i, j, l, shift;
				for (i = 0; i < batches * m * k; i++)
					ha->data.f32[i] = ((int)(dsfmt_genrand_open_close(&dsfmt) * 255) - 127) / 128.f;
				for (i = 0; i < n * k; i++)
					hw->data.f32[i] = ((int)(dsfmt_genrand_open_close(&dsfmt) * 255) - 127) / 128.f;
				for (i = 0; i < n; i++)
					hbias->data.f32[i] = (i % 11 - 5) / 128.f;
				// Include a zero row and an activation outlier in every precision.
				memset(ha->data.f32, 0, sizeof(float) * k);
				ha->data.f32[k + 17] = 8;
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(input, weights, input_bias), 0);
				const size_t size = ccv_nnc_tensor_data_size_without_padding(hq->info);
				REQUIRE_EQ(ccv_nnc_quantize_8i_rowwise_x(weights->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, n * k, k, format, 0, 0, hq->data.u8, size), size, "offline H256 quantization succeeds");
				// Explicit raw base-codec decode gives stored rotated weights.
				ccv_nnc_dequantize_8i_rowwise_x(hq->data.u8, datatype, CCV_TENSOR_CPU_MEMORY, size, k, codecs[f], weights->data.u8, n * k);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(input, hq, input_bias), TENSOR_LIST(a, q, bias), 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(weights), TENSOR_LIST(hw), 0);
				// Independent dense transform followed by the runtime absmax INT8 rule.
				float rotated[k];
				for (i = 0; i < batches * m; i++)
				{
					float max_abs = 0;
					for (j = 0; j < k; j++)
					{
						double sum = 0;
						for (l = 0; l < 256; l++)
						{
							int sign = 1;
							for (shift = 0; shift < 8; shift += 2)
								if (((j >> shift) & 3) + ((l >> shift) & 3) == 3)
									sign = -sign;
							sum += sign * ha->data.f32[i * k + (j / 256) * 256 + l];
						}
						rotated[j] = sum / 16;
						max_abs = ccv_max(max_abs, fabsf(rotated[j]));
					}
					float scale = max_abs > 0 ? max_abs / 127.f : 1.f / 127.f;
					const float inv_scale = max_abs > 0 ? 127.f / max_abs : 127.f;
					if (datatype == CCV_16F) {
						uint16_t h;
						ccv_float_to_half_precision(&scale, &h, 1);
						ccv_half_precision_to_float(&h, &scale, 1);
					} else if (datatype == CCV_16BF) {
						uint16_t h;
						ccv_float_to_bfloat(&scale, &h, 1);
						ccv_bfloat_to_float(&h, &scale, 1);
					}
					for (j = 0; j < k; j++)
						ha->data.f32[i * k + j] = scale * ccv_clamp((int)lrintf(rotated[j] * inv_scale), -127, 127);
				}
				REQUIRE_EQ(ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, shape == 0 ? 0 : hbias), TENSOR_LIST(href), 0), CCV_NNC_EXEC_SUCCESS, "CPU reference succeeds");
				const uint64_t old_flags = ccv_nnc_flags();
				if (shape == 1)
					ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
				const int status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, q, shape == 0 ? 0 : bias), TENSOR_LIST(b), 0);
				if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
					ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
				REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "flagged GEMM succeeds");
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(result), 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(result), TENSOR_LIST(actual), 0);
				double error_sq = 0, reference_sq = 0, max_abs = 0;
				for (i = 0; i < batches * m * n; i++) {
					const double diff = actual->data.f32[i] - href->data.f32[i];
					error_sq += diff * diff;
					reference_sq += (double)href->data.f32[i] * href->data.f32[i];
					max_abs = ccv_max(max_abs, fabs(diff));
				}
				// ANE accumulates through its existing FP16 CoreML path. Signed random
				// inputs have cancellation, so bound relative L2 error against CPU GEMM.
				REQUIRE(sqrt(error_sq / reference_sq) < (datatype == CCV_16BF ? 1e-2 : 5e-3), "ANE H256 output matches CPU GEMM: dtype=%d codec=%d shape=%d relative_l2=%g max_abs=%g", datatype, codecs[f], shape, sqrt(error_sq / reference_sq), max_abs);

				if (datatype == CCV_32F && (shape == 1 || shape == 6)) {
					// Feed the independently rotated / quantized activation into ordinary
					// ANE GEMM too. This isolates fusion from CoreML accumulation error
					// and exercises both transform cache entries at the same shape.
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
					q->info.reserved = codecs[f];
					REQUIRE_EQ(ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, q, bias), TENSOR_LIST(b), 0), CCV_NNC_EXEC_SUCCESS, "ordinary ANE reference succeeds");
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(result), 0);
					error_sq = reference_sq = 0;
					for (i = 0; i < batches * m * n; i++) {
						const double diff = actual->data.f32[i] - result->data.f32[i];
						error_sq += diff * diff;
						reference_sq += (double)result->data.f32[i] * result->data.f32[i];
					}
					REQUIRE(sqrt(error_sq / reference_sq) < 1e-3, "fused and explicitly rotated ANE GEMM match: relative_l2=%g", sqrt(error_sq / reference_sq));
				}

				ccv_nnc_tensor_free(input); ccv_nnc_tensor_free(weights); ccv_nnc_tensor_free(input_bias); ccv_nnc_tensor_free(result);
				ccv_nnc_tensor_free(ha); ccv_nnc_tensor_free(hw); ccv_nnc_tensor_free(hbias);
				ccv_nnc_tensor_free(href); ccv_nnc_tensor_free(actual); ccv_nnc_tensor_free(hq);
				ccv_nnc_tensor_free(q); ccv_nnc_tensor_free(a); ccv_nnc_tensor_free(bias); ccv_nnc_tensor_free(b);
			}
	if (entry_flags & CCV_NNC_DISABLE_MFA_ANE)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	if (!(entry_flags & CCV_NNC_DISABLE_MFA_GEMM))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (!(entry_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
#endif
}

TEST_CASE("mps forward gemm with row-wise 8i weight NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate(CCV_16F, 0, &max_abs, &max_rel), 0, "scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul should match row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate(CCV_32F, 0, &max_abs, &max_rel), 0, "scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul should match row-wise quantized fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate(CCV_16BF, 0, &max_abs, &max_rel), 0, "scaled GEMM validation should run");
	REQUIRE(max_rel < 5e-3, "quantized NAInt8MatMul should match row-wise quantized bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with row-wise 8i weight and bias NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate(CCV_16F, 1, &max_abs, &max_rel), 0, "scaled GEMM validation with bias should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul with bias should match row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate(CCV_32F, 1, &max_abs, &max_rel), 0, "scaled GEMM validation with bias should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul with bias should match row-wise quantized fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate(CCV_16BF, 1, &max_abs, &max_rel), 0, "scaled GEMM validation with bias should run");
	REQUIRE(max_rel < 5e-3, "quantized NAInt8MatMul with bias should match row-wise quantized bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with row-wise 8i weight NA aligned M")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_aligned_m(CCV_16F, 0, &max_abs, &max_rel), 0, "scaled GEMM aligned-M validation should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul should match aligned-M row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_aligned_m(CCV_32F, 0, &max_abs, &max_rel), 0, "scaled GEMM aligned-M validation should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul should match aligned-M row-wise quantized fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_aligned_m(CCV_16BF, 0, &max_abs, &max_rel), 0, "scaled GEMM aligned-M validation should run");
	REQUIRE(max_rel < 5e-3, "quantized NAInt8MatMul should match aligned-M row-wise quantized bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with row-wise 8i weight and bias NA aligned M")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_aligned_m(CCV_16F, 1, &max_abs, &max_rel), 0, "scaled GEMM aligned-M validation with bias should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul with bias should match aligned-M row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_aligned_m(CCV_32F, 1, &max_abs, &max_rel), 0, "scaled GEMM aligned-M validation with bias should run");
	REQUIRE(max_rel < 2e-3, "quantized NAInt8MatMul with bias should match aligned-M row-wise quantized fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_aligned_m(CCV_16BF, 1, &max_abs, &max_rel), 0, "scaled GEMM aligned-M validation with bias should run");
	REQUIRE(max_rel < 5e-3, "quantized NAInt8MatMul with bias should match aligned-M row-wise quantized bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with fp32 row-wise 8i weight ANE")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	double max_abs = 0;
	double max_rel = 0;
	const int status = _mps_forward_scaled_gemm_validate(CCV_32F, 0, &max_abs, &max_rel);
	double bias_max_abs = 0;
	double bias_max_rel = 0;
	const int bias_status = _mps_forward_scaled_gemm_validate(CCV_32F, 1, &bias_max_abs, &bias_max_rel);
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (old_flags & CCV_NNC_DISABLE_MFA_ANE)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	REQUIRE_EQ(status, 0, "FP32 ANE row-wise 8i GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "FP32 ANE row-wise 8i GEMM should match the quantized reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	REQUIRE_EQ(bias_status, 0, "FP32 ANE row-wise 8i GEMM validation with bias should run");
	REQUIRE(bias_max_rel < 2e-3, "FP32 ANE row-wise 8i GEMM with bias should match the quantized reference, max_abs=%g max_rel=%g", bias_max_abs, bias_max_rel);
}

TEST_CASE("mps forward gemm with row-wise 8i weight ANE surface row pitch")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	// Exercise padded and packed pitches, then revisit the H3 audio projection
	// shape after changing the scratch cache. Include the i8x decode path.
	const int widths[] = { 32, 64, 96, 128, 32 };
	const int formats[] = { 0, CCV_NNC_QX_8I_ROWWISE_Q6_K };
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 42);
	int f, shape;
	for (f = 0; f < 2; f++)
		for (shape = 0; shape < 5; shape++)
		{
			const int m_dim = 414;
			const int n_dim = widths[shape] == 32 ? 5376 : 768;
			const int k_dim = widths[shape];
			ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m_dim, k_dim), 0);
			ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n_dim, k_dim), 0);
			ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n_dim), 0);
			ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m_dim, n_dim), 0);
			ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m_dim, n_dim), 0);
			ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, formats[f] ? ccv_nnc_tensor_8i_rowwise_x(hw->info, formats[f]) : ccv_nnc_tensor_8i_rowwise(hw->info), 0);
			ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m_dim, k_dim), 0);
			ccv_nnc_tensor_param_t w_params = hwq->info;
			w_params.type = CCV_TENSOR_GPU_MEMORY;
			ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, w_params, 0);
			ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, n_dim), 0);
			ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m_dim, n_dim), 0);
			int i;
			for (i = 0; i < m_dim * k_dim; i++)
				ha->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			for (i = 0; i < n_dim * k_dim; i++)
				hw->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			for (i = 0; i < n_dim; i++)
				hbias->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			const size_t qsize = formats[f] ?
				ccv_nnc_quantize_8i_rowwise_x(hw->data.f32, CCV_32F, CCV_TENSOR_CPU_MEMORY, n_dim * k_dim, k_dim, formats[f], 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info)) :
				ccv_nnc_quantize_8i_rowwise(hw->data.f32, CCV_32F, CCV_TENSOR_CPU_MEMORY, n_dim * k_dim, k_dim, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
			REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(hwq->info), "rowwise weights should quantize");
			if (formats[f])
				ccv_nnc_dequantize_8i_rowwise_x(hwq->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, qsize, k_dim, formats[f], hw->data.f32, n_dim * k_dim);
			else
				ccv_nnc_dequantize_8i_rowwise(hwq->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, qsize, k_dim, hw->data.f32, n_dim * k_dim);
			ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(href), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hwq, hbias), TENSOR_LIST(a, w, bias), 0);
			const uint64_t old_flags = ccv_nnc_flags();
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
			const int status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(actual), 0);
			if (old_flags & CCV_NNC_DISABLE_MFA_ANE)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
			REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "ANE or its layout fallback should execute");
			for (i = 0; i < m_dim * n_dim; i++)
				{ REQUIRE(isfinite(actual->data.f32[i]), "ANE or its layout fallback should produce finite values"); }
			REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, href->data.f32, m_dim * n_dim, 3e-3, "ANE or its layout fallback should match CPU GEMM on decoded weights");
			ccv_nnc_tensor_free(b);
			ccv_nnc_tensor_free(bias);
			ccv_nnc_tensor_free(w);
			ccv_nnc_tensor_free(a);
			ccv_nnc_tensor_free(hwq);
			ccv_nnc_tensor_free(actual);
			ccv_nnc_tensor_free(href);
			ccv_nnc_tensor_free(hbias);
			ccv_nnc_tensor_free(hw);
			ccv_nnc_tensor_free(ha);
		}
}

TEST_CASE("mps forward gemm with row-wise 8i weight NA small M")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	double max_abs16f = 0;
	double max_rel16f = 0;
	const int status16f = _mps_forward_scaled_gemm_validate_shape(CCV_16F, 0, 16, 384, 1024, &max_abs16f, &max_rel16f);
	double max_abs16f_bias = 0;
	double max_rel16f_bias = 0;
	const int status16f_bias = _mps_forward_scaled_gemm_validate_shape(CCV_16F, 1, 6, 384, 1536, &max_abs16f_bias, &max_rel16f_bias);
	double max_abs16bf = 0;
	double max_rel16bf = 0;
	const int status16bf = _mps_forward_scaled_gemm_validate_shape(CCV_16BF, 0, 8, 384, 1024, &max_abs16bf, &max_rel16bf);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_ANE)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	}
	REQUIRE_EQ(status16f, 0, "small-M scaled GEMM validation should run");
	REQUIRE(max_rel16f < 2e-3, "small-M NAInt8MatMul should match row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs16f, max_rel16f);
	REQUIRE_EQ(status16f_bias, 0, "small-M scaled GEMM validation with bias should run");
	REQUIRE(max_rel16f_bias < 2e-3, "small-M NAInt8MatMul with bias should match row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs16f_bias, max_rel16f_bias);
	REQUIRE_EQ(status16bf, 0, "small-M scaled GEMM bf16 validation should run");
	REQUIRE(max_rel16bf < 8e-3, "small-M NAInt8MatMul should match row-wise quantized bf16 reference, max_abs=%g max_rel=%g", max_abs16bf, max_rel16bf);
}

TEST_CASE("mps forward gemm with row-wise 8i weight ANE stream ordering")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_ane_rowwise_gemm_stream_sync_validate(&max_abs, &max_rel), 0, "ANE row-wise 8i stream-ordering validation should run");
	REQUIRE(max_rel < 2e-3, "ANE row-wise 8i GEMM should respect queued Metal writer work before quant/evaluate, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with row-wise 8i weight ANE K split")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double k2_max_abs = 0;
	double k2_max_rel = 0;
	const int k2_status = _mps_forward_ane_k_split_validate_shape(512, 128, 4096, &k2_max_abs, &k2_max_rel);
	double k4_max_abs = 0;
	double k4_max_rel = 0;
	const int k4_status = _mps_forward_ane_k_split_validate_shape(512, 128, 8192, &k4_max_abs, &k4_max_rel);
	REQUIRE_EQ(k2_status, 0, "ANE row-wise 8i K/2 split validation should run");
	REQUIRE(k2_max_rel < 2e-3, "ANE row-wise 8i K/2 split should match Metal, max_abs=%g max_rel=%g", k2_max_abs, k2_max_rel);
	REQUIRE_EQ(k4_status, 0, "ANE row-wise 8i K/4 split validation should run");
	REQUIRE(k4_max_rel < 2e-3, "ANE row-wise 8i K/4 split should match Metal, max_abs=%g max_rel=%g", k4_max_abs, k4_max_rel);
}

TEST_CASE("mps generic fp32 gemm with runtime rows and read-only parameters")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	const int row_counts[] = {37, 1, 9, 37};
	int with_bias, step;
	for (with_bias = 0; with_bias < 2; with_bias++)
		for (step = 0; step < 4; step++)
		{
			const int rows = row_counts[step];
			ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, rows, 32), 0);
			ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 24, 32), 0);
			ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 24), 0);
			ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, rows, 24), 0);
			ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, rows, 24), 0);
			ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, rows, 32), 0);
			ccv_nnc_tensor_t* const gw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 24, 32), 0);
			ccv_nnc_tensor_t* const gbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 24), 0);
			ccv_nnc_tensor_t* const output = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, rows, 24), 0);
			int j;
			for (j = 0; j < 2 * rows * 32; j++)
				a->data.f32[j] = ((j * 17 + step * 11) % 101 - 50) / 101.f;
			for (j = 0; j < 2 * 24 * 32; j++)
				w->data.f32[j] = ((j * 13 + 7) % 97 - 48) / 97.f;
			for (j = 0; j < 24; j++)
				bias->data.f32[j] = (j - 12) / 32.f;
			const ccv_nnc_cmd_t cmd = CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2));
			ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, with_bias ? bias : 0), TENSOR_LIST(expected), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(ga, gw, gbias), 0);
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS | CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			const int status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gw, with_bias ? gbias : 0), TENSOR_LIST(output), 0);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "generic runtime-row GEMM should run with read-only parameters");
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(output), TENSOR_LIST(actual), 0);
			REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, expected->data.f32, 2 * rows * 24, 1e-5,
				"runtime row counts and batch strides should match CPU GEMM with and without bias");
			ccv_nnc_tensor_free(a);
			ccv_nnc_tensor_free(w);
			ccv_nnc_tensor_free(bias);
			ccv_nnc_tensor_free(expected);
			ccv_nnc_tensor_free(actual);
			ccv_nnc_tensor_free(ga);
			ccv_nnc_tensor_free(gw);
			ccv_nnc_tensor_free(gbias);
			ccv_nnc_tensor_free(output);
		}
}

TEST_CASE("mps forward gemm with loadM flag")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	double max_abs_scaled = 0;
	double max_rel_scaled = 0;
	const int status_scaled = _mps_forward_scaled_gemm_validate_shape(CCV_16F, 0, 257, 384, 128, &max_abs_scaled, &max_rel_scaled);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	double max_abs_generic = 0;
	double max_rel_generic = 0;
	const int status_generic = _mps_forward_scaled_gemm_compare_dense(CCV_16F, 0, 257, 384, 128, &max_abs_generic, &max_rel_generic);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_ANE))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	REQUIRE_EQ(status_scaled, 0, "loadM scaled GEMM validation should run");
	REQUIRE(max_rel_scaled < 2e-3, "loadM scaled GEMM should match row-wise quantized fp16 reference, max_abs=%g max_rel=%g", max_abs_scaled, max_rel_scaled);
	REQUIRE_EQ(status_generic, 0, "loadM generic GEMM fallback validation should run");
	REQUIRE(max_rel_generic < 2e-3, "loadM generic GEMM fallback should match dense GPU fp16 reference, max_abs=%g max_rel=%g", max_abs_generic, max_rel_generic);
}

TEST_CASE("mps segmented int8 gemv with row-wise 8i weight, bias, and direct routes")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format_shape_experts_dims(
		CCV_16F, 1, 1, 0, 8, 11, 8, 0, 129, 256, &max_abs, &max_rel), 0, "row-wise 8i segmented Int8 GEMV validation should run");
	REQUIRE(max_rel < 3e-3, "row-wise 8i segmented Int8 GEMV should match the dense-A reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps segmented int8 gemv with packed row-wise 8i-x weights")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q5_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
		CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS,
		CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS,
	};
	int i;
	for (i = 0; i < sizeof(formats) / sizeof(formats[0]); i++)
	{
		double max_abs = 0;
		double max_rel = 0;
		REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format_shape_experts_dims(
			CCV_16F, 0, 1, formats[i], 1, 2, 1, 0, 256, 256, &max_abs, &max_rel), 0, "packed segmented Int8 GEMV validation should run for format=%d", formats[i]);
		REQUIRE(max_rel < 3e-3, "packed segmented Int8 GEMV should match the dense-A reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs, max_rel);
	}
}

TEST_CASE("mps segmented gemm with row-wise 8i weight NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_16F, 0, 0, &max_abs, &max_rel), 0, "segmented row-wise 8i NA validation should run");
	REQUIRE(max_rel < 3e-3, "segmented row-wise 8i NA fp16 should match quantized reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_32F, 0, 0, &max_abs, &max_rel), 0, "segmented row-wise 8i NA validation should run");
	REQUIRE(max_rel < 3e-3, "segmented row-wise 8i NA fp32 should match quantized reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_16BF, 0, 0, &max_abs, &max_rel), 0, "segmented row-wise 8i NA validation should run");
	REQUIRE(max_rel < 6e-3, "segmented row-wise 8i NA bf16 should match quantized reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps segmented gemm with row-wise 8i weight loadM")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	double small_max_abs = 0;
	double small_max_rel = 0;
	const int small_status = _mps_segmented_scaled_gemm_validate_format_shape(CCV_16F, 0, 0, 0, 257, &small_max_abs, &small_max_rel);
	double large_max_abs = 0;
	double large_max_rel = 0;
	const int large_status = _mps_segmented_scaled_gemm_validate_format_shape(CCV_16F, 0, 0, 0, 1537, &large_max_abs, &large_max_rel);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	REQUIRE_EQ(small_status, 0, "small loadM segmented row-wise 8i validation should run");
	REQUIRE(small_max_rel < 3e-3, "small loadM segmented row-wise 8i should match quantized reference, max_abs=%g max_rel=%g", small_max_abs, small_max_rel);
	REQUIRE_EQ(large_status, 0, "large loadM segmented row-wise 8i validation should run");
	REQUIRE(large_max_rel < 3e-3, "large loadM segmented row-wise 8i should match quantized reference, max_abs=%g max_rel=%g", large_max_abs, large_max_rel);
}

TEST_CASE("mps segmented gemm with row-wise 8i-x weight NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q5_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
		CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS,
		CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS,
	};
	int i;
	for (i = 0; i < sizeof(formats) / sizeof(formats[0]); i++)
	{
		double max_abs = 0;
		double max_rel = 0;
		REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format(CCV_16F, 0, 0, formats[i], &max_abs, &max_rel), 0, "segmented row-wise 8i-x NA validation should run for format=%d", formats[i]);
		REQUIRE(max_rel < 3e-3, "segmented row-wise 8i-x fp16 should match selected-decode quantized reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs, max_rel);
	}
}

TEST_CASE("mps segmented gemm uses the declared bincount with a larger expert table")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	const int status = _mps_segmented_scaled_gemm_validate_format_shape_experts(
		CCV_16F, 0, 0, 0, 18, 256, 18, 1, &max_abs, &max_rel);
	REQUIRE_EQ(status, 0, "segmented row-wise 8i should not read routing metadata or write output rows beyond the declared 18 bins");
	REQUIRE(max_rel < 3e-3, "segmented row-wise 8i with 18 bins should match the quantized reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps segmented gemm with row-wise 8i-x weight fallback dequantize")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q5_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
		CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS,
		CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS,
	};
	int i;
	for (i = 0; i < sizeof(formats) / sizeof(formats[0]); i++)
	{
		double max_abs = 0;
		double max_rel = 0;
		REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format(CCV_16F, 0, 1, formats[i], &max_abs, &max_rel), 0, "segmented fallback row-wise 8i-x validation should run for format=%d", formats[i]);
		REQUIRE(max_rel < 3e-3, "segmented fallback row-wise 8i-x fp16 should match dense reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs, max_rel);
	}
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format(CCV_32F, 0, 1, CCV_NNC_QX_8I_ROWWISE_Q5_K, &max_abs, &max_rel), 0, "segmented Int8MatMul row-wise 8i-x fp32 validation should run");
	REQUIRE(max_rel < 3e-3, "segmented Int8MatMul row-wise 8i-x fp32 should match quantized reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format(CCV_16BF, 0, 1, CCV_NNC_QX_8I_ROWWISE_Q5_K, &max_abs, &max_rel), 0, "segmented fallback row-wise 8i-x bf16 validation should run");
	REQUIRE(max_rel < 6e-3, "segmented fallback row-wise 8i-x bf16 should match dense reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format(CCV_16F, 1, 1, CCV_NNC_QX_8I_ROWWISE_Q5_K, &max_abs, &max_rel), 0, "segmented fallback row-wise 8i-x validation with bias should run");
	REQUIRE(max_rel < 3e-3, "segmented fallback row-wise 8i-x fp16 with bias should match dense reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps segmented gemm with row-wise 8i weight and bias fallback dequantize")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_16F, 1, 1, &max_abs, &max_rel), 0, "segmented fallback row-wise 8i validation should run");
	REQUIRE(max_rel < 3e-3, "segmented fallback row-wise 8i fp16 should match dense-A reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_32F, 1, 1, &max_abs, &max_rel), 0, "segmented fallback row-wise 8i validation should run");
	REQUIRE(max_rel < 3e-3, "segmented fallback row-wise 8i fp32 should match dense-A reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_16BF, 1, 1, &max_abs, &max_rel), 0, "segmented fallback row-wise 8i validation should run");
	REQUIRE(max_rel < 6e-3, "segmented fallback row-wise 8i bf16 should match dense-A reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps segmented gemm emulates int8 with normalized half values and float scales")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_segmented_scaled_gemm_validate(CCV_32F, 0, 1, &max_abs, &max_rel), 0,
		"segmented Int8MatMul validation should run");
	REQUIRE(max_rel < 3e-3,
		"segmented Int8MatMul should match the quantized activation reference, max_abs=%g max_rel=%g",
		max_abs, max_rel);
}

TEST_CASE("mps segmented gemm uses Int8MatMul for packed weights and float scales")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q4_K, CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K, CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS, CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS, CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
		CCV_NNC_QX_8I_ROWWISE_Q5_K, CCV_NNC_QX_8I_ROWWISE_Q6_K,
	};
	int i, shape;
	for (i = 0; i < sizeof(formats) / sizeof(formats[0]); i++)
		for (shape = 0; shape < 3; shape++)
		{
			double max_abs = 0;
			double max_rel = 0;
			// The smaller shape has an empty bin; the larger has full tiles plus tails.
			// Guard rows and fewer bins than experts check selected-decode bounds.
			REQUIRE_EQ(_mps_segmented_scaled_gemm_validate_format_shape_experts_dims(
				CCV_32F, 0, 1, formats[i], shape == 2 ? 513 : (shape ? 97 : 5), 8, 6, 1,
				shape ? 256 : 128, shape ? 512 : 256, &max_abs, &max_rel), 0,
				"packed Int8MatMul should execute for format=%d shape=%d", formats[i], shape);
			REQUIRE(max_rel < 1e-4,
				"packed Int8MatMul should match quantized CPU reference: format=%d shape=%d max_abs=%g max_rel=%g",
				formats[i], shape, max_abs, max_rel);
		}
}

TEST_CASE("mps fp32 row-wise 8i fallback quantizes values outside the fp16 range")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int m_dim = 5;
	const int n_dim = 32;
	const int k_dim = 128;
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m_dim, k_dim), 0);
	ccv_nnc_tensor_t* const hwd = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n_dim, k_dim), 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(hwd->info), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m_dim, n_dim), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m_dim, k_dim), 0);
	ccv_nnc_tensor_param_t wq_params = hwq->info;
	wq_params.type = CCV_TENSOR_GPU_MEMORY | 000;
	ccv_nnc_tensor_t* const wq = ccv_nnc_tensor_new(0, wq_params, 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m_dim, n_dim), 0);
	_mps_forward_scaled_gemm_fill_matrix(CCV_32F, ha->data.u8, m_dim, k_dim, 1);
	_mps_forward_scaled_gemm_fill_matrix(CCV_32F, hwd->data.u8, n_dim, k_dim, 0);
	int i;
	for (i = 0; i < m_dim; i++)
		ha->data.f32[i * k_dim] = (i & 1) ? -1e8f : 1e8f;
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(
		hwd->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, (size_t)n_dim * k_dim, k_dim, 0, 0,
		hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(hwq->info),
		"float weights should quantize to the declared rowwise size");
	float* const a_ref = (float*)ccmalloc(sizeof(float) * m_dim * k_dim);
	float* const w_ref = (float*)ccmalloc(sizeof(float) * n_dim * k_dim);
	float* const expected = (float*)ccmalloc(sizeof(float) * m_dim * n_dim);
	_mps_forward_scaled_gemm_quantized_reference(CCV_32F, ha->data.u8, m_dim, k_dim, a_ref);
	ccv_nnc_dequantize_8i_rowwise(
		hwq->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, qsize, k_dim,
		w_ref, (size_t)n_dim * k_dim);
	_mps_forward_scaled_gemm_reference(a_ref, w_ref, 0, m_dim, n_dim, k_dim, expected);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0,
		TENSOR_LIST(ha, hwq), TENSOR_LIST(a, wq), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	const int exec_status = ccv_nnc_cmd_exec(
		CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0,
		TENSOR_LIST(a, wq), TENSOR_LIST(b), 0);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_ANE))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	REQUIRE_EQ(exec_status, CCV_NNC_EXEC_SUCCESS, "Int8MatMul should execute");
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0,
		TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	double max_rel = 0;
	for (i = 0; i < m_dim * n_dim; i++)
	{
		REQUIRE(isfinite(hb->data.f32[i]), "quantized activation output should remain finite");
		const double diff = fabs((double)hb->data.f32[i] - expected[i]);
		const double denom = ccv_max(1.0, ccv_max(fabs((double)hb->data.f32[i]), fabs((double)expected[i])));
		max_rel = ccv_max(max_rel, diff / denom);
	}
	REQUIRE(max_rel < 5e-4, "Int8MatMul should match the quantized FP32 reference, max_rel=%g", max_rel);
	ccfree(expected);
	ccfree(w_ref);
	ccfree(a_ref);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(wq);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(hwd);
	ccv_nnc_tensor_free(ha);
}

TEST_CASE("mps forward gemm with row-wise 8i weight fallback dequantize")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	double max_abs = 0;
	double max_rel = 0;
	const int status16f = _mps_forward_scaled_gemm_compare_dense(CCV_16F, 0, 257, 384, 128, &max_abs, &max_rel);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	REQUIRE_EQ(status16f, 0, "fallback row-wise 8i GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "fallback row-wise 8i GEMM should match dense GPU fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);

	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	max_abs = 0;
	max_rel = 0;
	const int status32f = _mps_forward_scaled_gemm_compare_dense(CCV_32F, 0, 257, 384, 128, &max_abs, &max_rel);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	REQUIRE_EQ(status32f, 0, "fallback row-wise 8i GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "fallback row-wise 8i GEMM should match dense GPU fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);

	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	max_abs = 0;
	max_rel = 0;
	const int status16bf = _mps_forward_scaled_gemm_compare_dense(CCV_16BF, 0, 257, 384, 128, &max_abs, &max_rel);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	REQUIRE_EQ(status16bf, 0, "fallback row-wise 8i GEMM validation should run");
	REQUIRE(max_rel < 5e-3, "fallback row-wise 8i GEMM should match dense GPU bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with packed row-wise 8i-x weight fallback fp dequantize")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q5_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS,
		CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
	};
	int status[sizeof(formats) / sizeof(formats[0])];
	double max_abs[sizeof(formats) / sizeof(formats[0])];
	double max_rel[sizeof(formats) / sizeof(formats[0])];
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	int i;
	for (i = 0; i < (int)(sizeof(formats) / sizeof(formats[0])); i++)
	{
		max_abs[i] = 0;
		max_rel[i] = 0;
		status[i] = _mps_forward_scaled_gemm_compare_dense_format(CCV_16F, 0, 257, 384, 128, formats[i], &max_abs[i], &max_rel[i]);
	}
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_ANE))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	for (i = 0; i < (int)(sizeof(formats) / sizeof(formats[0])); i++)
	{
		REQUIRE_EQ(status[i], 0, "fallback packed row-wise 8i-x GEMM validation should run for format=%d", formats[i]);
		REQUIRE(max_rel[i] < 2e-3, "fallback packed row-wise 8i-x GEMM should match GPU fp16 reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs[i], max_rel[i]);
	}
}

TEST_CASE("mps forward gemm with packed Q6K weight at checkpoint row width")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	double max_abs_4608 = 0;
	double max_rel_4608 = 0;
	const int status_4608 = _mps_forward_scaled_gemm_compare_dense_format(CCV_16F, 0, 16, 384, 4608, CCV_NNC_QX_8I_ROWWISE_Q6_K, &max_abs_4608, &max_rel_4608);
	double max_abs_6144 = 0;
	double max_rel_6144 = 0;
	const int status_6144 = _mps_forward_scaled_gemm_compare_dense_format(CCV_16F, 0, 16, 384, 6144, CCV_NNC_QX_8I_ROWWISE_Q6_K, &max_abs_6144, &max_rel_6144);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_ANE))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ANE);
	REQUIRE_EQ(status_4608, 0, "Ideogram-width packed Q6K GEMM validation should run");
	REQUIRE(max_rel_4608 < 2e-3, "Ideogram-width packed Q6K GEMM should match dequantized dense GPU reference, max_abs=%g max_rel=%g", max_abs_4608, max_rel_4608);
	REQUIRE_EQ(status_6144, 0, "Krea-width packed Q6K GEMM validation should run");
	REQUIRE(max_rel_6144 < 2e-3, "Krea-width packed Q6K GEMM should match dequantized dense GPU reference, max_abs=%g max_rel=%g", max_abs_6144, max_rel_6144);
}

TEST_CASE("mps forward gemv with row-wise 8i weight scaled gemv")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 0, 1, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV fp16 validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV fp16 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 0, 1, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV fp32 validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV fp32 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 0, 1, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV bf16 validation should run");
	REQUIRE(max_abs < 4e-2 || max_rel < 1e-2, "row-wise 8i GEMV bf16 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 0, 2, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=2 fp16 validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=2 fp16 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 0, 2, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=2 fp32 validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=2 fp32 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 0, 2, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=2 bf16 validation should run");
	REQUIRE(max_abs < 4e-2 || max_rel < 1e-2, "row-wise 8i GEMV M=2 bf16 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 0, 3, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=3 fp16 validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=3 fp16 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 0, 3, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=3 fp32 validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=3 fp32 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 0, 3, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=3 bf16 validation should run");
	REQUIRE(max_abs < 4e-2 || max_rel < 1e-2, "row-wise 8i GEMV M=3 bf16 should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward cooperative fp32 gemv")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int shapes[][3] = {
		{ 23, 512, 0 },
		{ 24, 1024, 1 },
		{ 24, 2048, 0 },
		{ 24, 16384, 0 },
	};
	int i;
	for (i = 0; i < (int)(sizeof(shapes) / sizeof(shapes[0])); i++)
	{
		double max_abs = 0;
		double max_rel = 0;
		const int n_dim = shapes[i][0];
		const int k_dim = shapes[i][1];
		const int use_bias = shapes[i][2];
		_mps_forward_fp32_gemv_compare_cpu(use_bias, n_dim, k_dim, &max_abs, &max_rel);
		REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "cooperative fp32 GEMV should match the dense reference for N=%d K=%d bias=%d, max_abs=%g max_rel=%g", n_dim, k_dim, use_bias, max_abs, max_rel);
	}
}

TEST_CASE("mps forward gemv with row-wise 8i weight and bias scaled gemv")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 1, 1, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV fp16 with bias validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV fp16 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 1, 1, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV fp32 with bias validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV fp32 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 1, 1, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV bf16 with bias validation should run");
	REQUIRE(max_abs < 4e-2 || max_rel < 1e-2, "row-wise 8i GEMV bf16 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 1, 2, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=2 fp16 with bias validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=2 fp16 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 1, 2, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=2 fp32 with bias validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=2 fp32 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 1, 2, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=2 bf16 with bias validation should run");
	REQUIRE(max_abs < 4e-2 || max_rel < 1e-2, "row-wise 8i GEMV M=2 bf16 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 1, 3, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=3 fp16 with bias validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=3 fp16 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 1, 3, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=3 fp32 with bias validation should run");
	REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "row-wise 8i GEMV M=3 fp32 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 1, 3, 1024, 2560, &max_abs, &max_rel), 0, "row-wise 8i GEMV M=3 bf16 with bias validation should run");
	REQUIRE(max_abs < 4e-2 || max_rel < 1e-2, "row-wise 8i GEMV M=3 bf16 with bias should match dense GPU reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemv with packed row-wise 8i weight scaled gemv")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q5_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS,
		CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS,
	};
	int i;
	for (i = 0; i < sizeof(formats) / sizeof(formats[0]); i++)
	{
		double max_abs = 0;
		double max_rel = 0;
		REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense_format(CCV_16F, 0, 1, 256, 256, formats[i], &max_abs, &max_rel), 0, "packed row-wise 8i GEMV fp16 validation should run for format=%d", formats[i]);
		REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "packed row-wise 8i GEMV fp16 should match dequantized dense GPU reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs, max_rel);
		max_abs = 0;
		max_rel = 0;
		REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense_format(CCV_16F, 1, 2, 256, 256, formats[i], &max_abs, &max_rel), 0, "packed row-wise 8i GEMV M=2 fp16 with bias validation should run for format=%d", formats[i]);
		REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "packed row-wise 8i GEMV M=2 fp16 with bias should match dequantized dense GPU reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs, max_rel);
		max_abs = 0;
		max_rel = 0;
		REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense_format(CCV_16F, 1, 3, 256, 256, formats[i], &max_abs, &max_rel), 0, "packed row-wise 8i GEMV M=3 fp16 with bias validation should run for format=%d", formats[i]);
		REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "packed row-wise 8i GEMV M=3 fp16 with bias should match dequantized dense GPU reference for format=%d, max_abs=%g max_rel=%g", formats[i], max_abs, max_rel);
	}
}

TEST_CASE("mps forward gemm with row-wise 8i weight and bias fallback dequantize")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	double max_abs = 0;
	double max_rel = 0;
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16F, 1, 257, 384, 128, &max_abs, &max_rel), 0, "fallback row-wise 8i GEMM with bias validation should run");
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	REQUIRE(max_rel < 2e-3, "fallback row-wise 8i GEMM with bias should match dense GPU fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_32F, 1, 257, 384, 128, &max_abs, &max_rel), 0, "fallback row-wise 8i GEMM with bias validation should run");
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	REQUIRE(max_rel < 2e-3, "fallback row-wise 8i GEMM with bias should match dense GPU fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 1, 257, 384, 128, &max_abs, &max_rel), 0, "fallback row-wise 8i GEMM with bias validation should run");
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	REQUIRE(max_rel < 5e-3, "fallback row-wise 8i GEMM with bias should match dense GPU bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward gemm with row-wise 8i weight and bias fallback dequantize large shapes")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	static const int shapes[][3] = {
		{32, 3840, 3840},
		{32, 10240, 3840},
		{32, 3840, 10240},
	};
	int i;
	for (i = 0; i < (int)(sizeof(shapes) / sizeof(shapes[0])); i++)
	{
		double max_abs = 0;
		double max_rel = 0;
		REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense(CCV_16BF, 1, shapes[i][0], shapes[i][1], shapes[i][2], &max_abs, &max_rel), 0, "large fallback row-wise 8i GEMM with bias validation should run");
		REQUIRE(max_abs < 2e-2 || max_rel < 5e-3, "large fallback row-wise 8i GEMM with bias should match dense GPU bf16 reference for shape %d x %d x %d, max_abs=%g max_rel=%g", shapes[i][0], shapes[i][1], shapes[i][2], max_abs, max_rel);
	}
	if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
}

TEST_CASE("mps forward batched gemm with broadcast row-wise 8i weight NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_batched(CCV_16F, 0, 0, 0, &max_abs, &max_rel), 0, "batched scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "batched quantized NAInt8MatMul should match broadcast-weight fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_batched(CCV_32F, 0, 0, 0, &max_abs, &max_rel), 0, "batched scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "batched quantized NAInt8MatMul should match broadcast-weight fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_batched(CCV_16BF, 0, 0, 0, &max_abs, &max_rel), 0, "batched scaled GEMM validation should run");
	REQUIRE(max_rel < 5e-3, "batched quantized NAInt8MatMul should match broadcast-weight bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward batched gemm with batched row-wise 8i weight and bias NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_batched(CCV_16F, 1, 1, 1, &max_abs, &max_rel), 0, "batched scaled GEMM validation with batched weight and bias should run");
	REQUIRE(max_rel < 2e-3, "batched quantized NAInt8MatMul should match batched-weight fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_batched(CCV_32F, 1, 1, 1, &max_abs, &max_rel), 0, "batched scaled GEMM validation with batched weight and bias should run");
	REQUIRE(max_rel < 2e-3, "batched quantized NAInt8MatMul should match batched-weight fp32 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_batched(CCV_16BF, 1, 1, 1, &max_abs, &max_rel), 0, "batched scaled GEMM validation with batched weight and bias should run");
	REQUIRE(max_rel < 5e-3, "batched quantized NAInt8MatMul should match batched-weight bf16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward interleaved batched gemm with row-wise 8i-x weight NAInt8MatMul")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_validate_interleaved_batched(17, 64, &max_abs, &max_rel), 0, "multi-token interleaved batched scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "multi-token interleaved batched NAInt8MatMul should match the fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward interleaved batched gemv with row-wise 8i-x weight Int8Gemv")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	double max_abs = 0;
	double max_rel = 0;
	const int status = _mps_forward_scaled_gemm_validate_interleaved_batched(1, 256, &max_abs, &max_rel);
	if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM)) {
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	}
	REQUIRE_EQ(status, 0, "single-token interleaved batched scaled GEMV validation should run");
	REQUIRE(max_rel < 2e-3, "single-token interleaved batched Int8Gemv should match the fp16 reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

TEST_CASE("mps forward batched gemm with padded A view and broadcast row-wise 8i weight NA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	double max_abs = 0;
	double max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense_batched_padded_a_shape(CCV_16F, 0, 1, 512, 3072, 3072, 513, &max_abs, &max_rel), 0, "single-batch padded-A scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "single-batch padded-A scaled GEMM without bias should match dense reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense_batched_padded_a_shape(CCV_16F, 0, 2, 512, 3072, 3072, 513, &max_abs, &max_rel), 0, "batched padded-A scaled GEMM validation should run");
	REQUIRE(max_rel < 2e-3, "batched padded-A scaled GEMM without bias should match dense reference, max_abs=%g max_rel=%g", max_abs, max_rel);
	max_abs = 0;
	max_rel = 0;
	REQUIRE_EQ(_mps_forward_scaled_gemm_compare_dense_batched_padded_a_shape(CCV_16F, 1, 2, 512, 3072, 3072, 513, &max_abs, &max_rel), 0, "batched padded-A scaled GEMM with bias validation should run");
	REQUIRE(max_rel < 2e-3, "batched padded-A scaled GEMM with bias should match dense reference, max_abs=%g max_rel=%g", max_abs, max_rel);
}

#define _STRINGIFY(x) #x
#define STRINGIFY(x) _STRINGIFY(x)
#define NA_GEMM_SHAPE_TEST(M, N, K) \
	TEST_CASE("mps forward gemm no bias NA shape " STRINGIFY(M) "x" STRINGIFY(N) "x" STRINGIFY(K)) \
	{ \
		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS)); \
		_mps_forward_na_gemm_mismatch_t mismatch = {}; \
		REQUIRE(_mps_forward_na_gemm_validate_shape(M, N, K, &mismatch), "sampled GEMM result should match reference for shape (%d, %d, %d) at (%d, %d): %g vs %g, max_abs=%g max_rel=%g", M, N, K, mismatch.row, mismatch.col, mismatch.actual, mismatch.expected, mismatch.max_abs, mismatch.max_rel); \
	}

#define NA_GEMM_BIAS_SHAPE_TEST(M, N, K) \
	TEST_CASE("mps forward gemm with bias NA shape " STRINGIFY(M) "x" STRINGIFY(N) "x" STRINGIFY(K)) \
	{ \
		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS)); \
		_mps_forward_na_gemm_mismatch_t mismatch = {}; \
		REQUIRE(_mps_forward_na_gemm_validate_shape_with_bias(M, N, K, &mismatch), "sampled GEMM result with bias should match reference for shape (%d, %d, %d) at (%d, %d): %g vs %g, max_abs=%g max_rel=%g", M, N, K, mismatch.row, mismatch.col, mismatch.actual, mismatch.expected, mismatch.max_abs, mismatch.max_rel); \
	}

#define NA_GEMM_BFLOAT_SHAPE_TEST(M, N, K) \
	TEST_CASE("mps forward gemm no bias bfloat NA shape " STRINGIFY(M) "x" STRINGIFY(N) "x" STRINGIFY(K)) \
	{ \
		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS)); \
		_mps_forward_na_gemm_mismatch_t mismatch = {}; \
		REQUIRE(_mps_forward_na_gemm_validate_shape_for_datatype(CCV_16BF, 0, M, N, K, &mismatch), "sampled bfloat GEMM result should match reference for shape (%d, %d, %d) at (%d, %d): %g vs %g, max_abs=%g max_rel=%g", M, N, K, mismatch.row, mismatch.col, mismatch.actual, mismatch.expected, mismatch.max_abs, mismatch.max_rel); \
	}

#define NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(M, N, K) \
	TEST_CASE("mps forward gemm with bias bfloat NA shape " STRINGIFY(M) "x" STRINGIFY(N) "x" STRINGIFY(K)) \
	{ \
		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS)); \
		_mps_forward_na_gemm_mismatch_t mismatch = {}; \
		REQUIRE(_mps_forward_na_gemm_validate_shape_for_datatype(CCV_16BF, 1, M, N, K, &mismatch), "sampled bfloat GEMM result with bias should match reference for shape (%d, %d, %d) at (%d, %d): %g vs %g, max_abs=%g max_rel=%g", M, N, K, mismatch.row, mismatch.col, mismatch.actual, mismatch.expected, mismatch.max_abs, mismatch.max_rel); \
	}

TEST_CASE("mps forward gemm no bias NA full shape 6x1024x3072")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	_mps_forward_na_gemm_mismatch_t mismatch = {};
	REQUIRE(_mps_forward_na_gemm_validate_full_shape_for_datatype(CCV_16F, 0, 0, 6, 1024, 3072, &mismatch), "full GEMM result should match reference for shape (6, 1024, 3072) at (%d, %d): %g vs %g, max_abs=%g max_rel=%g", mismatch.row, mismatch.col, mismatch.actual, mismatch.expected, mismatch.max_abs, mismatch.max_rel);
}

TEST_CASE("mps forward gemm no bias NA full signed shape 6x1024x3072")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	_mps_forward_na_gemm_mismatch_t mismatch = {};
	REQUIRE(_mps_forward_na_gemm_validate_full_shape_for_datatype(CCV_16F, 0, 1, 6, 1024, 3072, &mismatch), "full signed GEMM result should match reference for shape (6, 1024, 3072) at (%d, %d): %g vs %g, max_abs=%g max_rel=%g", mismatch.row, mismatch.col, mismatch.actual, mismatch.expected, mismatch.max_abs, mismatch.max_rel);
}

TEST_CASE("gemm no transpose")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm transpose a")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 3, 5, 7,
		2, 4, 6, 8,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm transpose b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	float bp[] = {
		7, 10,
		8, 11,
		9, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm transpose a and b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 3, 5, 7,
		2, 4, 6, 8,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	float bp[] = {
		7, 10,
		8, 11,
		9, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(TRANSPOSE(0, 1), TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm no transpose with bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	float dp[] = {
		1, -1, 1,
		1, -1, 1,
		1, -1, 1,
		1, -1, 1,
	};
	ccv_nnc_tensor_t* const d = ccv_nnc_tensor_new(dp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gd = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b, d), TENSOR_LIST(ga, gb, gd), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb, gd), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10 + 1, 1 * 8 + 2 * 11 - 1, 1 * 9 + 2 * 12 + 1,
		3 * 7 + 4 * 10 + 1, 3 * 8 + 4 * 11 - 1, 3 * 9 + 4 * 12 + 1,
		5 * 7 + 6 * 10 + 1, 5 * 8 + 6 * 11 - 1, 5 * 9 + 6 * 12 + 1,
		7 * 7 + 8 * 10 + 1, 7 * 8 + 8 * 11 - 1, 7 * 9 + 8 * 12 + 1,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(d);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
	ccv_nnc_tensor_free(gd);
}

TEST_CASE("gemm no transpose batch 2, no batch b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
		2, 3,
		4, 5,
		6, 7,
		8, 9
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
		2 * 7 + 3 * 10, 2 * 8 + 3 * 11, 2 * 9 + 3 * 12,
		4 * 7 + 5 * 10, 4 * 8 + 5 * 11, 4 * 9 + 5 * 12,
		6 * 7 + 7 * 10, 6 * 8 + 7 * 11, 6 * 9 + 7 * 12,
		8 * 7 + 9 * 10, 8 * 8 + 9 * 11, 8 * 9 + 9 * 12,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm no transpose batch 2")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
		2, 3,
		4, 5,
		6, 7,
		8, 9
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
		8, 9, 10,
		11, 12, 13,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
		2 * 8 + 3 * 11, 2 * 9 + 3 * 12, 2 * 10 + 3 * 13,
		4 * 8 + 5 * 11, 4 * 9 + 5 * 12, 4 * 10 + 5 * 13,
		6 * 8 + 7 * 11, 6 * 9 + 7 * 12, 6 * 10 + 7 * 13,
		8 * 8 + 9 * 11, 8 * 9 + 9 * 12, 8 * 10 + 9 * 13,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm transpose a batch 2, no batch b, with bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 3, 5, 7,
		2, 4, 6, 8,
		2, 4, 6, 8,
		3, 5, 7, 9,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	float dp[] = {
		-1, 0, 1,
	};
	ccv_nnc_tensor_t* const d = ccv_nnc_tensor_new(dp, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* gd = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b, d), TENSOR_LIST(ga, gb, gd), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb, gd), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10 - 1, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12 + 1,
		3 * 7 + 4 * 10 - 1, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12 + 1,
		5 * 7 + 6 * 10 - 1, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12 + 1,
		7 * 7 + 8 * 10 - 1, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12 + 1,
		2 * 7 + 3 * 10 - 1, 2 * 8 + 3 * 11, 2 * 9 + 3 * 12 + 1,
		4 * 7 + 5 * 10 - 1, 4 * 8 + 5 * 11, 4 * 9 + 5 * 12 + 1,
		6 * 7 + 7 * 10 - 1, 6 * 8 + 7 * 11, 6 * 9 + 7 * 12 + 1,
		8 * 7 + 9 * 10 - 1, 8 * 8 + 9 * 11, 8 * 9 + 9 * 12 + 1,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(d);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
	ccv_nnc_tensor_free(gd);
}

TEST_CASE("gemm transpose a batch 2, with bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 3, 5, 7,
		2, 4, 6, 8,
		2, 4, 6, 8,
		3, 5, 7, 9,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	float bp[] = {
		7, 8, 9,
		10, 11, 12,
		8, 9, 10,
		11, 12, 13,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
		2 * 8 + 3 * 11, 2 * 9 + 3 * 12, 2 * 10 + 3 * 13,
		4 * 8 + 5 * 11, 4 * 9 + 5 * 12, 4 * 10 + 5 * 13,
		6 * 8 + 7 * 11, 6 * 9 + 7 * 12, 6 * 10 + 7 * 13,
		8 * 8 + 9 * 11, 8 * 9 + 9 * 12, 8 * 10 + 9 * 13,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("gemm transpose b batch 2, with bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
		2, 3,
		4, 5,
		6, 7,
		8, 9
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		7, 10,
		8, 11,
		9, 12,
		80, 110,
		90, 120,
		10, 13,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	float dp[] = {
		-1, 0, 1,
		2, 3, -4,
	};
	ccv_nnc_tensor_t* const d = ccv_nnc_tensor_new(dp, CPU_TENSOR_NHWC(32F, 2, 1, 3), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* gd = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 1, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b, d), TENSOR_LIST(ga, gb, gd), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb, gd), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10 - 1, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12 + 1,
		3 * 7 + 4 * 10 - 1, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12 + 1,
		5 * 7 + 6 * 10 - 1, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12 + 1,
		7 * 7 + 8 * 10 - 1, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12 + 1,
		2 * 80 + 3 * 110 + 2, 2 * 90 + 3 * 120 + 3, 2 * 10 + 3 * 13 - 4,
		4 * 80 + 5 * 110 + 2, 4 * 90 + 5 * 120 + 3, 4 * 10 + 5 * 13 - 4,
		6 * 80 + 7 * 110 + 2, 6 * 90 + 7 * 120 + 3, 6 * 10 + 7 * 13 - 4,
		8 * 80 + 9 * 110 + 2, 8 * 90 + 9 * 120 + 3, 8 * 10 + 9 * 13 - 4,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(d);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
	ccv_nnc_tensor_free(gd);
}

TEST_CASE("gemm transpose b batch 2")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	float ap[] = {
		1, 2,
		3, 4,
		5, 6,
		7, 8,
		2, 3,
		4, 5,
		6, 7,
		8, 9
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		7, 10,
		8, 11,
		9, 12,
		80, 110,
		90, 120,
		10, 13,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const c = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* gc = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(gc), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gc), TENSOR_LIST(c), 0);
	float ctp[] = {
		1 * 7 + 2 * 10, 1 * 8 + 2 * 11, 1 * 9 + 2 * 12,
		3 * 7 + 4 * 10, 3 * 8 + 4 * 11, 3 * 9 + 4 * 12,
		5 * 7 + 6 * 10, 5 * 8 + 6 * 11, 5 * 9 + 6 * 12,
		7 * 7 + 8 * 10, 7 * 8 + 8 * 11, 7 * 9 + 8 * 12,
		2 * 80 + 3 * 110, 2 * 90 + 3 * 120, 2 * 10 + 3 * 13,
		4 * 80 + 5 * 110, 4 * 90 + 5 * 120, 4 * 10 + 5 * 13,
		6 * 80 + 7 * 110, 6 * 90 + 7 * 120, 6 * 10 + 7 * 13,
		8 * 80 + 9 * 110, 8 * 90 + 9 * 120, 8 * 10 + 9 * 13,
	};
	ccv_nnc_tensor_t ct = ccv_nnc_tensor(ctp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	REQUIRE_TENSOR_EQ(c, &ct, "result should be equal");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gc);
}

TEST_CASE("mps forward gemm")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	for (i = 0; i < 10 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw, hbias), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	for (i = 0; i < 64; i++)
		tb1->data.f32[i] = tb->data.f32[i];
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 5e-6, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
}

TEST_CASE("mps forward gemm in half precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 10, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	for (i = 0; i < 10 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 10, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw, hbias), TENSOR_LIST(ha2, hw2, hbias2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2, hbias2), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 5e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
	ccv_nnc_tensor_free(hbias2);
}

TEST_CASE("mps forward gemm in bfloat precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 10, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	for (i = 0; i < 10 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 10, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 64, 128), 0);
	ccv_nnc_tensor_t* hbias2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw, hbias), TENSOR_LIST(ha2, hw2, hbias2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2, hbias2), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 8e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
	ccv_nnc_tensor_free(hbias2);
}

TEST_CASE("mps forward gemv in half precision, variant 1")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	for (i = 0; i < 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw, hbias), TENSOR_LIST(ha2, hw2, hbias2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2, hbias2), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
	ccv_nnc_tensor_free(hbias2);
}

TEST_CASE("mps forward gemv in half precision with M=2")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 1);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 2, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 2, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 128), 0);
	for (i = 0; i < 2 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 2 * 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 2, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw, hbias), TENSOR_LIST(ha2, hw2, hbias2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2, hbias2), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 2, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 2 * 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
	ccv_nnc_tensor_free(hbias2);
}

TEST_CASE("mps forward gemv in bfloat precision, variant 1")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 1, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 1, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	for (i = 0; i < 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 1, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 64, 128), 0);
	ccv_nnc_tensor_t* hbias2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw, hbias), TENSOR_LIST(ha2, hw2, hbias2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2, hbias2), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 1, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 8e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
	ccv_nnc_tensor_free(hbias2);
}

TEST_CASE("mps depalettize 5-bit half precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	float lut_f32[32] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, -1.0, -2.0, -3.0, -4.0, -5.0, -6.0, -7.0, -8.0, -9.0, -10.0, -11.0, -12.0, -13.0, -14.0, -15.0};
	uint16_t lut[32];
	ccv_float_to_half_precision(lut_f32, lut, 32);
	uint16_t* const values = ccmalloc(sizeof(uint16_t) * 3072);
	int i;
	for (i = 0; i < 3072; i++)
		values[i] = lut[i % 32];
	ccv_nnc_tensor_t* tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, (2112 + 3) / 4), 0);
	uint8_t* compressed = tensor->data.u8;
	const size_t output_size = ccv_nnc_palettize(values, CCV_16F, CCV_TENSOR_CPU_MEMORY, 3072, 5, 1024, compressed, 2112);
	REQUIRE_EQ(output_size, 2112, "output size should match");
	ccv_nnc_tensor_t* g_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, (2112 + 3) / 4), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tensor), TENSOR_LIST(g_tensor), 0);
	ccv_nnc_tensor_t* gv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 16F, 3072), 0);
	ccv_nnc_depalettize(g_tensor->data.u8, CCV_16F, CCV_TENSOR_GPU_MEMORY, output_size, 5, 1024, gv_tensor->data.u8, 3072);
	ccv_nnc_tensor_t* v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(16F, 3072), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gv_tensor), TENSOR_LIST(v_tensor), 0);
	REQUIRE_ARRAY_EQ(uint16_t, values, v_tensor->data.f16, 3072, "GPU computed output should match CPU depalettize");
	ccfree(values);
	ccv_nnc_tensor_free(tensor);
	ccv_nnc_tensor_free(g_tensor);
	ccv_nnc_tensor_free(gv_tensor);
	ccv_nnc_tensor_free(v_tensor);
}

TEST_CASE("mps depalettize 6-bit float precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	float lut[64];
	int i;
	for (i = 0; i < 64; i++)
		lut[i] = (float)i;
	float* const values = ccmalloc(sizeof(float) * 8192);
	for (i = 0; i < 8192; i++)
		values[i] = lut[i % 64];
	ccv_nnc_tensor_t* tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, (6144 + 2 * 64 * 4 + 3) / 4), 0);
	uint8_t* compressed = tensor->data.u8;
	const size_t output_size = ccv_nnc_palettize(values, CCV_32F, CCV_TENSOR_CPU_MEMORY, 8192, 6, 4096, compressed, 6144 + 2 * 64 * 4);
	REQUIRE_EQ(output_size, 6144 + 2 * 64 * 4, "output size should match");
	ccv_nnc_tensor_t* g_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, (6144 + 2 * 64 * 4 + 3) / 4), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tensor), TENSOR_LIST(g_tensor), 0);
	ccv_nnc_tensor_t* gv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 8192), 0);
	ccv_nnc_depalettize(g_tensor->data.u8, CCV_32F, CCV_TENSOR_GPU_MEMORY, output_size, 6, 4096, gv_tensor->data.u8, 8192);
	ccv_nnc_tensor_t* v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 8192), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gv_tensor), TENSOR_LIST(v_tensor), 0);
	REQUIRE_ARRAY_EQ(float, values, v_tensor->data.f32, 8192, "GPU computed output should match CPU depalettize");
	ccfree(values);
	ccv_nnc_tensor_free(tensor);
	ccv_nnc_tensor_free(g_tensor);
	ccv_nnc_tensor_free(gv_tensor);
	ccv_nnc_tensor_free(v_tensor);
}

TEST_CASE("mps depalettize 8-bit float precision with partial block")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	float lut[256];
	int i;
	for (i = 0; i < 256; i++)
		lut[i] = (float)i;
	float* const values = ccmalloc(sizeof(float) * 3072);
	for (i = 0; i < 3072; i++)
		values[i] = lut[i % 256];
	ccv_nnc_tensor_t* tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, (6144 + 3) / 4), 0);
	uint8_t* compressed = tensor->data.u8;
	const size_t output_size = ccv_nnc_palettize(values, CCV_32F, CCV_TENSOR_CPU_MEMORY, 3072, 8, 2048, compressed, 6144);
	REQUIRE(output_size <= 6144, "output size should fit the allocated buffer");
	ccv_nnc_tensor_t* g_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, (6144 + 3) / 4), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tensor), TENSOR_LIST(g_tensor), 0);
	ccv_nnc_tensor_t* gv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 3072), 0);
	ccv_nnc_depalettize(g_tensor->data.u8, CCV_32F, CCV_TENSOR_GPU_MEMORY, output_size, 8, 2048, gv_tensor->data.u8, 3072);
	ccv_nnc_tensor_t* v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 3072), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gv_tensor), TENSOR_LIST(v_tensor), 0);
	REQUIRE_ARRAY_EQ(float, values, v_tensor->data.f32, 3072, "GPU computed output should match CPU depalettize");
	ccfree(values);
	ccv_nnc_tensor_free(tensor);
	ccv_nnc_tensor_free(g_tensor);
	ccv_nnc_tensor_free(gv_tensor);
	ccv_nnc_tensor_free(v_tensor);
}

TEST_CASE("mps dequantize row-wise 8i half precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	const int rows = 17;
	const int cols = 64;
	float* const values = ccmalloc(sizeof(float) * rows * cols);
	int i;
	for (i = 0; i < rows * cols; i++)
		values[i] = ((i * 13) % 41 - 20) / 32.0f;
	ccv_nnc_tensor_t* const source = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, rows, cols), 0);
	ccv_float_to_half_precision(values, (uint16_t*)source->data.f16, rows * cols);
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16F, rows, cols)), 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(source->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, rows * cols, cols, 0, 0, q->data.u8, ccv_nnc_tensor_data_size_without_padding(q->info));
	REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(q->info), "quantized row-wise 8i size should match");
	ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, rows, cols), 0);
	ccv_nnc_dequantize_8i_rowwise(q->data.u8, CCV_16F, CCV_TENSOR_CPU_MEMORY, qsize, cols, expected->data.f16, rows * cols);
	ccv_nnc_tensor_t* const gq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16F, rows, cols)), 0);
	ccv_nnc_tensor_t* const gout = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, rows, cols), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q), TENSOR_LIST(gq), 0);
	ccv_nnc_dequantize_8i_rowwise(gq->data.u8, CCV_16F, CCV_TENSOR_GPU_MEMORY, qsize, cols, gout->data.u8, rows * cols);
	ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, rows, cols), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gout), TENSOR_LIST(actual), 0);
	float* const expected_f32 = (float*)ccmalloc(sizeof(float) * rows * cols);
	float* const actual_f32 = (float*)ccmalloc(sizeof(float) * rows * cols);
	ccv_half_precision_to_float((uint16_t*)expected->data.f16, expected_f32, rows * cols);
	ccv_half_precision_to_float((uint16_t*)actual->data.f16, actual_f32, rows * cols);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, expected_f32, actual_f32, rows * cols, 1e-3, "GPU row-wise 8i dequantize should match CPU dequantize");
	ccfree(actual_f32);
	ccfree(expected_f32);
	ccv_nnc_tensor_free(actual);
	ccv_nnc_tensor_free(gout);
	ccv_nnc_tensor_free(gq);
	ccv_nnc_tensor_free(expected);
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(source);
	ccfree(values);
}

TEST_CASE("mps dequantize row-wise 8i float precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	const int rows = 11;
	const int cols = 128;
	ccv_nnc_tensor_t* const source = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, rows, cols), 0);
	int i;
	for (i = 0; i < rows * cols; i++)
		source->data.f32[i] = ((i * 17) % 53 - 26) / 64.0f;
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(32F, rows, cols)), 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(source->data.f32, CCV_32F, CCV_TENSOR_CPU_MEMORY, rows * cols, cols, 0, 0, q->data.u8, ccv_nnc_tensor_data_size_without_padding(q->info));
	REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(q->info), "quantized row-wise 8i size should match");
	ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, rows, cols), 0);
	ccv_nnc_dequantize_8i_rowwise(q->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, qsize, cols, expected->data.f32, rows * cols);
	ccv_nnc_tensor_t* const gq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 32F, rows, cols)), 0);
	ccv_nnc_tensor_t* const gout = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, rows, cols), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q), TENSOR_LIST(gq), 0);
	ccv_nnc_dequantize_8i_rowwise(gq->data.u8, CCV_32F, CCV_TENSOR_GPU_MEMORY, qsize, cols, gout->data.u8, rows * cols);
	ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, rows, cols), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gout), TENSOR_LIST(actual), 0);
	REQUIRE_ARRAY_EQ(float, expected->data.f32, actual->data.f32, rows * cols, "GPU row-wise 8i dequantize should match CPU dequantize");
	ccv_nnc_tensor_free(actual);
	ccv_nnc_tensor_free(gout);
	ccv_nnc_tensor_free(gq);
	ccv_nnc_tensor_free(expected);
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(source);
}

TEST_CASE("mps dequantize row-wise 8i bfloat precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	const int rows = 257;
	const int cols = 130;
	float* const values = ccmalloc(sizeof(float) * rows * cols);
	int i;
	for (i = 0; i < rows * cols; i++)
		values[i] = ((i * 29) % 97 - 48) / 64.0f;
	ccv_nnc_tensor_t* const source = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, rows, cols), 0);
	ccv_float_to_bfloat(values, (uint16_t*)source->data.f16, rows * cols);
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16BF, rows, cols)), 0);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(source->data.f16, CCV_16BF, CCV_TENSOR_CPU_MEMORY, rows * cols, cols, 0, 0, q->data.u8, ccv_nnc_tensor_data_size_without_padding(q->info));
	REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(q->info), "quantized row-wise 8i size should match");
	ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, rows, cols), 0);
	ccv_nnc_dequantize_8i_rowwise(q->data.u8, CCV_16BF, CCV_TENSOR_CPU_MEMORY, qsize, cols, expected->data.f16, rows * cols);
	ccv_nnc_tensor_t* const gq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16BF, rows, cols)), 0);
	ccv_nnc_tensor_t* const gout = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, rows, cols), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q), TENSOR_LIST(gq), 0);
	ccv_nnc_dequantize_8i_rowwise(gq->data.u8, CCV_16BF, CCV_TENSOR_GPU_MEMORY, qsize, cols, gout->data.u8, rows * cols);
	ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, rows, cols), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gout), TENSOR_LIST(actual), 0);
	float* const expected_f32 = (float*)ccmalloc(sizeof(float) * rows * cols);
	float* const actual_f32 = (float*)ccmalloc(sizeof(float) * rows * cols);
	ccv_bfloat_to_float((uint16_t*)expected->data.f16, expected_f32, rows * cols);
	ccv_bfloat_to_float((uint16_t*)actual->data.f16, actual_f32, rows * cols);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, expected_f32, actual_f32, rows * cols, 5e-3, "GPU row-wise 8i bf16 dequantize should match CPU dequantize");
	ccfree(actual_f32);
	ccfree(expected_f32);
	ccv_nnc_tensor_free(actual);
	ccv_nnc_tensor_free(gout);
	ccv_nnc_tensor_free(gq);
	ccv_nnc_tensor_free(expected);
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(source);
	ccfree(values);
}

TEST_CASE("mps dequantize row-wise 8i bfloat precision large shapes")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	static const int shapes[][2] = {
		{3840, 3840},
		{10240, 3840},
		{3840, 10240},
	};
	int s;
	for (s = 0; s < (int)(sizeof(shapes) / sizeof(shapes[0])); s++)
	{
		const int rows = shapes[s][0];
		const int cols = shapes[s][1];
		float* const values = ccmalloc(sizeof(float) * (size_t)rows * cols);
		int i;
		for (i = 0; i < rows * cols; i++)
			values[i] = ((i * 29) % 97 - 48) / 64.0f;
		ccv_nnc_tensor_t* const source = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, rows, cols), 0);
		ccv_float_to_bfloat(values, (uint16_t*)source->data.f16, rows * cols);
		ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16BF, rows, cols)), 0);
		const size_t qsize = ccv_nnc_quantize_8i_rowwise(source->data.f16, CCV_16BF, CCV_TENSOR_CPU_MEMORY, (size_t)rows * cols, cols, 0, 0, q->data.u8, ccv_nnc_tensor_data_size_without_padding(q->info));
		REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(q->info), "quantized row-wise 8i size should match");
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, rows, cols), 0);
		ccv_nnc_dequantize_8i_rowwise(q->data.u8, CCV_16BF, CCV_TENSOR_CPU_MEMORY, qsize, cols, expected->data.f16, (size_t)rows * cols);
		ccv_nnc_tensor_t* const gq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16BF, rows, cols)), 0);
		ccv_nnc_tensor_t* const gout = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, rows, cols), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q), TENSOR_LIST(gq), 0);
		ccv_nnc_dequantize_8i_rowwise(gq->data.u8, CCV_16BF, CCV_TENSOR_GPU_MEMORY, qsize, cols, gout->data.u8, (size_t)rows * cols);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, rows, cols), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gout), TENSOR_LIST(actual), 0);
		float* const expected_f32 = (float*)ccmalloc(sizeof(float) * (size_t)rows * cols);
		float* const actual_f32 = (float*)ccmalloc(sizeof(float) * (size_t)rows * cols);
		ccv_bfloat_to_float((uint16_t*)expected->data.f16, expected_f32, rows * cols);
		ccv_bfloat_to_float((uint16_t*)actual->data.f16, actual_f32, rows * cols);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, expected_f32, actual_f32, rows * cols, 5e-3, "GPU row-wise 8i bf16 dequantize should match CPU dequantize on large shape");
		ccfree(actual_f32);
		ccfree(expected_f32);
		ccv_nnc_tensor_free(actual);
		ccv_nnc_tensor_free(gout);
		ccv_nnc_tensor_free(gq);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(q);
		ccv_nnc_tensor_free(source);
		ccfree(values);
	}
}

TEST_CASE("mps dequantize packed row-wise 8i-x half precision all formats")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q5_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q3_K,
		CCV_NNC_QX_8I_ROWWISE_Q2_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_S,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XS,
		CCV_NNC_QX_8I_ROWWISE_IQ3_S,
		CCV_NNC_QX_8I_ROWWISE_IQ3_XXS,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
	};
	int i;
	for (i = 0; i < (int)(sizeof(formats) / sizeof(formats[0])); i++)
	{
		double max_abs = 0;
		const int status = _mps_dequantize_8i_rowwise_x_compare(CCV_16F, formats[i], 17, 130, 1e-3, &max_abs);
		REQUIRE_EQ(status, 0, "GPU packed row-wise 8i-x fp16 dequantize should match CPU for format=%d, max_abs=%g", formats[i], max_abs);
	}
}

TEST_CASE("mps dequantize packed row-wise 8i-x float and bfloat precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_DATA_TRANSFER_FORWARD, CCV_NNC_BACKEND_MPS));
	const int formats[] = {
		CCV_NNC_QX_8I_ROWWISE_Q4_K,
		CCV_NNC_QX_8I_ROWWISE_Q6_K,
		CCV_NNC_QX_8I_ROWWISE_IQ2_XXS,
	};
	int i;
	for (i = 0; i < (int)(sizeof(formats) / sizeof(formats[0])); i++)
	{
		double max_abs = 0;
		int status = _mps_dequantize_8i_rowwise_x_compare(CCV_32F, formats[i], 13, 131, 1e-5, &max_abs);
		REQUIRE_EQ(status, 0, "GPU packed row-wise 8i-x fp32 dequantize should match CPU for format=%d, max_abs=%g", formats[i], max_abs);
		max_abs = 0;
		status = _mps_dequantize_8i_rowwise_x_compare(CCV_16BF, formats[i], 13, 131, 1e-2, &max_abs);
		REQUIRE_EQ(status, 0, "GPU packed row-wise 8i-x bf16 dequantize should match CPU for format=%d, max_abs=%g", formats[i], max_abs);
	}
}

TEST_CASE("mps forward gemm no bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	for (i = 0; i < 10 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	for (i = 0; i < 64; i++)
		tb1->data.f32[i] = tb->data.f32[i];
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 5e-6, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
}

TEST_CASE("mps forward gemm no bias in half precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 10, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	for (i = 0; i < 10 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 10, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw), TENSOR_LIST(ha2, hw2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
}

TEST_CASE("mps large half gemm reuses its pipeline across row counts")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int matrix_dimensions[][3] = {
		{512, 4096, 4096}, {1024, 4096, 4096}, {1025, 4096, 4096},
		{4096, 4096, 4096}, {4161, 4096, 4096},
		// Cross the large-output tile boundary in both directions with dynamic M.
		// K=512 keeps split-K at one on both sides, isolating the tile cache key.
		{4096, 32768, 512}, {4097, 32768, 512}, {4096, 32768, 512},
	};
	int shape;
	for (shape = 0; shape < sizeof(matrix_dimensions) / sizeof(matrix_dimensions[0]); shape++)
	{
		const int m = matrix_dimensions[shape][0], n = matrix_dimensions[shape][1], k = matrix_dimensions[shape][2];
		const int reference_rows = 64;
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 71);
		ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m, k), 0);
		ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
		ccv_nnc_tensor_t* const ha16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
		ccv_nnc_tensor_t* const hw16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
		ccv_nnc_tensor_t* const ref_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, reference_rows, k), 0);
		ccv_nnc_tensor_t* const ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, reference_rows, n), 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m, n), 0);
		ccv_nnc_tensor_t* const hb16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
		ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
		ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n, k), 0);
		ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, n), 0);
		int i;
		for (i = 0; i < m * k; i++)
			ha->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		for (i = 0; i < n * k; i++)
			hw->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(ha16, hw16), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha16, hw16), TENSOR_LIST(ha, hw), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha16, hw16), TENSOR_LIST(a, w), 0);
		int reference_row_indices[64];
		for (i = 0; i < reference_rows; i++)
		{
			const int row = i == 0 ? 0 : i == 1 ? m - 1 : i == 2 ? ccv_min(4095, m - 1) : i == 3 ? ccv_min(4096, m - 1) : (int)((int64_t)(i - 4) * (m - 1) / (reference_rows - 5));
			reference_row_indices[i] = row;
			memcpy(ref_a->data.f32 + i * k, ha->data.f32 + row * k, sizeof(float) * k);
		}
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ref_a, hw), TENSOR_LIST(ref), 0);
		ccv_nnc_cmd_t cmd = CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1));
		cmd.info.blas.flags = CCV_NNC_GEMM_16F;
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb16), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hb16), TENSOR_LIST(actual), 0);
		int all_finite = 1;
		for (i = 0; i < m * n; i++)
			if (!isfinite(actual->data.f32[i]))
			{
				all_finite = 0;
				break;
			}
		REQUIRE(all_finite, "every output tile should contain finite values");
		for (i = 0; i < reference_rows; i++)
			REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32 + reference_row_indices[i] * n, ref->data.f32 + i * n, n, 3e-3, "large FP16 GEMM should match CPU at distributed rows, pointer boundaries and the tail");
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(hw);
		ccv_nnc_tensor_free(ha16);
		ccv_nnc_tensor_free(hw16);
		ccv_nnc_tensor_free(ref_a);
		ccv_nnc_tensor_free(ref);
		ccv_nnc_tensor_free(actual);
		ccv_nnc_tensor_free(hb16);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(w);
		ccv_nnc_tensor_free(b);
	}
}

TEST_CASE("mps register gemm preserves bias and dynamic rows across the large-output boundary")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int n = 5376, k = 9216, samples = 16;
	const int row_counts[] = {24960, 24961, 25088, 24960, 24961};
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 918);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n, k), 0);
	ccv_nnc_tensor_t* const ref_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
	ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
	ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
	ccv_nnc_tensor_t* const ref_bias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
	float row_values[k];
	for (int row = 0; row < n; ++row)
	{
		for (int d = 0; d < k; ++d)
			row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		ccv_float_to_half_precision(row_values, (uint16_t*)hw->data.f16 + (size_t)row * k, k);
		ref_bias->data.f32[row] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
	}
	ccv_half_precision_to_float((uint16_t*)hw->data.f16, ref_w->data.f32, n * k);
	ccv_float_to_half_precision(ref_bias->data.f32, (uint16_t*)hbias->data.f16, n);
	ccv_half_precision_to_float((uint16_t*)hbias->data.f16, ref_bias->data.f32, n);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hw, hbias), TENSOR_LIST(w, bias), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA | CCV_NNC_DISABLE_MFA_GEMM | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	for (int trial = 0; trial < 5; ++trial)
	{
		const int m = row_counts[trial], use_bias = trial % 2;
		if (trial > 0 && trial < 4)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
		ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
		ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, n), 0);
		ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
		ccv_nnc_tensor_t* const ref_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, k), 0);
		ccv_nnc_tensor_t* const ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, n), 0);
		int rows[samples];
		for (int i = 0; i < samples; ++i)
			rows[i] = i == 0 ? 0 : i == 1 ? m - 1 : i == 2 ? 24959 : i == 3 ? 24960 - (m == 24960) : (int)((int64_t)(i - 4) * (m - 1) / (samples - 5));
		for (int row = 0; row < m; ++row)
		{
			for (int d = 0; d < k; ++d)
				row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			ccv_float_to_half_precision(row_values, (uint16_t*)ha->data.f16 + (size_t)row * k, k);
		}
		for (int i = 0; i < samples; ++i)
			ccv_half_precision_to_float((uint16_t*)ha->data.f16 + (size_t)rows[i] * k, ref_a->data.f32 + i * k, k);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
		ccv_nnc_cmd_t cmd = CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1));
		cmd.info.blas.flags = CCV_NNC_GEMM_16F;
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, use_bias ? bias : 0), TENSOR_LIST(b), 0), "register GEMM and its fallback should execute");
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ref_a, ref_w, use_bias ? ref_bias : 0), TENSOR_LIST(ref), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
		int all_finite = 1;
		for (size_t i = 0; i < (size_t)m * n; ++i)
			if ((((uint16_t*)hb->data.f16)[i] & 0x7c00) == 0x7c00)
			{
				all_finite = 0;
				break;
			}
		REQUIRE(all_finite, "all register GEMM output values should be finite");
		float actual[n];
		for (int i = 0; i < samples; ++i)
		{
			ccv_half_precision_to_float((uint16_t*)hb->data.f16 + (size_t)rows[i] * n, actual, n);
			REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual, ref->data.f32 + i * n, n, 3e-3, "register GEMM should preserve bias, dynamic shape changes and partial output tiles");
		}
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(hb);
		ccv_nnc_tensor_free(ref_a);
		ccv_nnc_tensor_free(ref);
	}
	const uint64_t flags[] = {CCV_NNC_DISABLE_MFA_ANE, CCV_NNC_DISABLE_MFA, CCV_NNC_DISABLE_MFA_GEMM, CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS, CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M};
	for (int i = 0; i < 5; ++i)
		if (old_flags & flags[i])
			ccv_nnc_enable_flag(flags[i]);
		else
			ccv_nnc_disable_flag(flags[i]);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(ref_w);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(ref_bias);
}

TEST_CASE("mps register gemm preserves orientations split reductions and partial tiles")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int shapes[][4] = {
		{4095, 1536, 2048}, {4096, 1536, 2048}, {4097, 1537, 2049},
		{4096, 4097, 4096}, {4097, 4097, 4096}, {4098, 4097, 4097},
		{4096, 4608, 9216}, {4097, 4609, 9219}, {4352, 4608, 12288},
		{4096, 4096, 8192}, {4097, 4096, 8193}, {4352, 6144, 16384},
		{4097, 4609, 9219}, {4096, 4608, 9216}, {4096, 4097, 4096},
		{256, 128, 65536}, {511, 1536, 13824}, {512, 1536, 13824},
		{513, 1536, 13824}, {513, 1536, 8191}, {513, 1536, 12287},
		// Explicit FP32 accumulation: full / partial tiles and a split reduction.
		{255, 65, 24576}, {256, 65, 24576}, {257, 65, 24577}, {513, 1536, 8191},
		// Medium-row dispatch: the fourth field requests FP32 accumulation.
		{511, 2560, 9216, 1}, {512, 2560, 9216, 1}, {513, 2561, 9217, 1},
		{2047, 6144, 18432}, {2048, 6144, 18432}, {2049, 6144, 18432},
		{3071, 2048, 2048}, {3072, 2048, 2048}, {3073, 2048, 2048},
		{3072, 3072, 6143}, {3072, 3072, 6144}, {3072, 3072, 6145},
		{3072, 3073, 8192}, {3072, 4096, 8192}, {3072, 4096, 8193},
		// Source-derived 768px down, up and projection dimensions.
		{2304, 6144, 18432}, {2560, 4608, 12288, 1}, {2304, 4096, 12288},
		{2560, 6144, 16384, 1}, {2304, 18432, 6144}, {2560, 12288, 4608, 1},
		{2304, 6144, 6144}, {2560, 4608, 4608, 1},
		// Decoded weights follow the enlarged FP32 split scratch; repeat the cache entry.
		{512, 4096, 12288, 1}, {512, 4096, 12288, 1}
	};
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA | CCV_NNC_DISABLE_MFA_GEMM | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	for (int trial = 0; trial < sizeof(shapes) / sizeof(shapes[0]); ++trial)
	{
		const int m = shapes[trial][0], n = shapes[trial][1], k = shapes[trial][2], samples = 16, use_bias = trial % 2;
		const int use_palettized = trial == 13 || trial == 48;
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 918);
		ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
		ccv_nnc_tensor_t* const hwq = use_palettized ? ccv_nnc_tensor_new(0, ccv_nnc_tensor_palettize(CPU_TENSOR_NHWC(16F, n, k), 5, 1024), 0) : 0;
		const ccv_nnc_tensor_param_t w_params = GPU_TENSOR_NHWC(000, 16F, n, k);
		ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, use_palettized ? ccv_nnc_tensor_palettize(w_params, 5, 1024) : w_params, 0);
		ccv_nnc_tensor_t* const ref_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
		ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
		ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
		ccv_nnc_tensor_t* const ref_bias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
		float row_values[k];
		const int positive_stress = trial >= 15 && trial < 25;
		const float center = positive_stress ? 0 : 0.5f;
		const float amplitude = positive_stress ? 1.0f / 64 : 0.25f;
		for (int row = 0; row < n; ++row)
		{
			for (int d = 0; d < k; ++d)
				row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - center) * amplitude;
			ccv_float_to_half_precision(row_values, (uint16_t*)hw->data.f16 + (size_t)row * k, k);
			ref_bias->data.f32[row] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		}
		if (use_palettized)
		{
			const size_t size = ccv_nnc_tensor_data_size_without_padding(hwq->info);
			REQUIRE_EQ(size, ccv_nnc_palettize(hw->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n * k, 5, 1024, hwq->data.u8, size), "palettized weights should encode completely");
			ccv_nnc_depalettize(hwq->data.u8, CCV_16F, CCV_TENSOR_CPU_MEMORY, size, 5, 1024, hw->data.f16, (size_t)n * k);
		}
		ccv_half_precision_to_float((uint16_t*)hw->data.f16, ref_w->data.f32, n * k);
		ccv_float_to_half_precision(ref_bias->data.f32, (uint16_t*)hbias->data.f16, n);
		ccv_half_precision_to_float((uint16_t*)hbias->data.f16, ref_bias->data.f32, n);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(use_palettized ? hwq : hw, hbias), TENSOR_LIST(w, bias), 0);
		if (trial % 3)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
		ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
		ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, n), 0);
		ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
		ccv_nnc_tensor_t* const ref_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, k), 0);
		ccv_nnc_tensor_t* const ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, n), 0);
		int rows[samples];
		for (int i = 0; i < samples; ++i)
			rows[i] = i == 0 ? 0 : i == 1 ? m - 1 : i == 2 ? 127 : i == 3 ? 128 : (int)((int64_t)(i - 4) * (m - 1) / (samples - 5));
		for (int row = 0; row < m; ++row)
		{
			for (int d = 0; d < k; ++d)
				row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - center) * amplitude;
			ccv_float_to_half_precision(row_values, (uint16_t*)ha->data.f16 + (size_t)row * k, k);
		}
		for (int i = 0; i < samples; ++i)
			ccv_half_precision_to_float((uint16_t*)ha->data.f16 + (size_t)rows[i] * k, ref_a->data.f32 + i * k, k);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
		ccv_nnc_cmd_t cmd = CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1));
		cmd.info.blas.flags = (trial >= 21 && trial < 25) || shapes[trial][3] ? 0 : CCV_NNC_GEMM_16F;
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, use_bias ? bias : 0), TENSOR_LIST(b), 0), "register GEMM and its fallback should execute");
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ref_a, ref_w, use_bias ? ref_bias : 0), TENSOR_LIST(ref), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
		int all_finite = 1;
		for (size_t i = 0; i < (size_t)m * n; ++i)
			if ((((uint16_t*)hb->data.f16)[i] & 0x7c00) == 0x7c00)
			{
				all_finite = 0;
				break;
			}
		REQUIRE(all_finite, "all register GEMM output values should be finite");
		float actual[n];
		for (int i = 0; i < samples; ++i)
		{
			ccv_half_precision_to_float((uint16_t*)hb->data.f16 + (size_t)rows[i] * n, actual, n);
			REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual, ref->data.f32 + i * n, n, 3e-3, "register GEMM should preserve bias, dynamic shape changes and partial output tiles");
		}
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(hb);
		ccv_nnc_tensor_free(ref_a);
		ccv_nnc_tensor_free(ref);
		if (hwq)
			ccv_nnc_tensor_free(hwq);
		ccv_nnc_tensor_free(hw);
		ccv_nnc_tensor_free(w);
		ccv_nnc_tensor_free(ref_w);
		ccv_nnc_tensor_free(hbias);
		ccv_nnc_tensor_free(bias);
		ccv_nnc_tensor_free(ref_bias);
	}
	const uint64_t flags[] = {CCV_NNC_DISABLE_MFA_ANE, CCV_NNC_DISABLE_MFA, CCV_NNC_DISABLE_MFA_GEMM, CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS, CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M};
	for (int i = 0; i < 5; ++i)
		if (old_flags & flags[i])
			ccv_nnc_enable_flag(flags[i]);
		else
			ccv_nnc_disable_flag(flags[i]);
}

TEST_CASE("mps large rowwise int8 gemm preserves dynamic rows and fused bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int n = 5376, k = 14336, samples = 16;
	const int row_counts[] = {16384, 16401, 16383, 16401};
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 917);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16F, n, k)), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16F, n, k)), 0);
	ccv_nnc_tensor_t* const ref_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
	ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
	ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
	ccv_nnc_tensor_t* const ref_bias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
	float row_values[k];
	for (int row = 0; row < n; ++row)
	{
		for (int d = 0; d < k; ++d)
			row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		ccv_float_to_half_precision(row_values, (uint16_t*)hw->data.f16 + (size_t)row * k, k);
		ref_bias->data.f32[row] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
	}
	ccv_float_to_half_precision(ref_bias->data.f32, (uint16_t*)hbias->data.f16, n);
	ccv_half_precision_to_float((uint16_t*)hbias->data.f16, ref_bias->data.f32, n);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(hw->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n * k, k, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	REQUIRE(qsize == ccv_nnc_tensor_data_size_without_padding(hwq->info), "rowwise weights should encode completely");
	const uint16_t* const weight_scales = (const uint16_t*)(hwq->data.u8 + (((size_t)n * k + 127) & ~(size_t)127));
	for (int row = 0; row < n; ++row)
	{
		float scale;
		ccv_half_precision_to_float(weight_scales + row, &scale, 1);
		for (int d = 0; d < k; ++d)
			ref_w->data.f32[(size_t)row * k + d] = ((int8_t*)hwq->data.u8)[(size_t)row * k + d] * scale;
	}
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hwq, hbias), TENSOR_LIST(w, bias), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA | CCV_NNC_DISABLE_MFA_GEMM | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	for (int trial = 0; trial < 4; ++trial)
	{
		const int m = row_counts[trial];
		ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
		ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
		ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, n), 0);
		ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
		ccv_nnc_tensor_t* const sample_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, samples, k), 0);
		ccv_nnc_tensor_t* const ref_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, k), 0);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, n), 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, n), 0);
		for (int row = 0; row < m; ++row)
		{
			for (int d = 0; d < k; ++d)
				row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			ccv_float_to_half_precision(row_values, (uint16_t*)ha->data.f16 + (size_t)row * k, k);
		}
		int rows[samples];
		const int boundaries[] = {0, 8191, 8192, 16383, 16384};
		for (int s = 0; s < samples; ++s)
		{
			rows[s] = s < 5 ? ccv_min(boundaries[s], m - 1) : (s - 5) * (m - 1) / (samples - 6);
			memcpy(sample_a->data.f16 + s * k, ha->data.f16 + (size_t)rows[s] * k, sizeof(uint16_t) * k);
		}
		// Runtime activations use abs-max scaling; the offline weight quantizer
		// also refits its scale, so it is not an activation reference.
		for (int s = 0; s < samples; ++s)
		{
			float* const values = ref_a->data.f32 + s * k;
			ccv_half_precision_to_float((uint16_t*)sample_a->data.f16 + s * k, values, k);
			float maximum = 0;
			for (int d = 0; d < k; ++d)
				maximum = ccv_max(maximum, fabsf(values[d]));
			const float inv_scale = maximum > 0 ? 127.0f / maximum : 127.0f;
			float scale = maximum > 0 ? maximum / 127.0f : 1.0f / 127.0f;
			uint16_t stored_scale;
			ccv_float_to_half_precision(&scale, &stored_scale, 1);
			// The CPU conversion truncates; Metal's half store rounds to nearest.
			float lower, upper;
			const uint16_t next_scale = stored_scale + 1;
			ccv_half_precision_to_float(&stored_scale, &lower, 1);
			ccv_half_precision_to_float(&next_scale, &upper, 1);
			if (scale - lower > upper - scale || (scale - lower == upper - scale && (stored_scale & 1)))
				stored_scale = next_scale;
			ccv_half_precision_to_float(&stored_scale, &scale, 1);
			for (int d = 0; d < k; ++d)
				values[d] = ccv_max(-127, ccv_min(127, (int)lrintf(values[d] * inv_scale))) * scale;
		}
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ref_a, ref_w, trial ? ref_bias : 0), TENSOR_LIST(expected), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
		if (trial)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, trial ? bias : 0), TENSOR_LIST(b), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
		int all_finite = 1;
		for (size_t i = 0; i < (size_t)m * n; ++i)
			if ((((uint16_t*)hb->data.f16)[i] & 0x7c00) == 0x7c00)
				all_finite = 0;
		REQUIRE(all_finite, "every chunk output should be finite");
		for (int s = 0; s < samples; ++s)
			ccv_half_precision_to_float((uint16_t*)hb->data.f16 + (size_t)rows[s] * n, actual->data.f32 + s * n, n);
		double error = 0, norm = 0, max_error = 0;
		for (int i = 0; i < samples * n; ++i)
		{
			const double diff = actual->data.f32[i] - expected->data.f32[i];
			error += diff * diff;
			norm += (double)expected->data.f32[i] * expected->data.f32[i];
			max_error = ccv_max(max_error, fabs(diff));
		}
		REQUIRE(sqrt(error / norm) < 5e-4, "quantized CPU GEMM relative L2=%g max_abs=%g at trial %d", sqrt(error / norm), max_error, trial);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, expected->data.f32, samples * n, 3e-3, "chunk boundaries, tail rows and fused bias should match quantized CPU GEMM");
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(hb);
		ccv_nnc_tensor_free(sample_a);
		ccv_nnc_tensor_free(ref_a);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(actual);
	}
	const uint64_t flags[] = {CCV_NNC_DISABLE_MFA_ANE, CCV_NNC_DISABLE_MFA, CCV_NNC_DISABLE_MFA_GEMM, CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS, CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M};
	for (int i = 0; i < 5; ++i)
		if (old_flags & flags[i])
			ccv_nnc_enable_flag(flags[i]);
		else
			ccv_nnc_disable_flag(flags[i]);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(ref_w);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(ref_bias);
}

TEST_CASE("mps rowwise int8 register gemm preserves selection boundaries and partial tiles")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA | CCV_NNC_DISABLE_MFA_GEMM | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int shapes[][3] = {
		{4096, 1536, 6144}, {4097, 1536, 6144}, {8191, 1536, 6144},
		{8192, 1536, 6144}, {8193, 1536, 6144}, {8193, 1537, 6145},
		{8193, 1535, 6144}, {8193, 1536, 6145}, {8193, 1536, 4095},
		{8193, 1536, 4096}, {8192, 1536, 4096}, {8193, 1537, 6145},
		{8193, 1537, 4127}, {8193, 1537, 4128}, {8193, 1537, 4129},
		{8192, 7168, 5376},
		// Medium-row crossover: output area, reduction depth and complete-row tiles.
		{1984, 4096, 12288}, {2048, 4096, 12288}, {2049, 4096, 12288},
		{2048, 3071, 8193}, {2048, 3072, 8193}, {2112, 4097, 12289},
		{2048, 5121, 20480}, {2048, 5121, 20481}, {4096, 5121, 20481},
		{2048, 2048, 4096}, {3072, 2048, 4096}, {2560, 6144, 16384},
		{2304, 6144, 18432}, {2304, 4096, 12288},
	};
	for (int trial = 0; trial < sizeof(shapes) / sizeof(shapes[0]); ++trial)
	{
		const int m = shapes[trial][0], n = shapes[trial][1], k = shapes[trial][2], samples = 16;
		const int use_bias = trial % 3 != 0;
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 918 + trial);
		ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
		ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(16F, n, k)), 0);
		ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16F, n, k)), 0);
		ccv_nnc_tensor_t* const ref_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
		ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
		ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
		ccv_nnc_tensor_t* const ref_bias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
		float row_values[k];
		for (int row = 0; row < n; ++row)
		{
			for (int d = 0; d < k; ++d)
				row_values[d] = row == 0 ? 0 : (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			ccv_float_to_half_precision(row_values, (uint16_t*)hw->data.f16 + (size_t)row * k, k);
			ref_bias->data.f32[row] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		}
		ccv_float_to_half_precision(ref_bias->data.f32, (uint16_t*)hbias->data.f16, n);
		ccv_half_precision_to_float((uint16_t*)hbias->data.f16, ref_bias->data.f32, n);
		const size_t qsize = ccv_nnc_quantize_8i_rowwise(hw->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n * k, k, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
		REQUIRE(qsize == ccv_nnc_tensor_data_size_without_padding(hwq->info), "rowwise weights should encode completely");
		const uint16_t* const weight_scales = (const uint16_t*)(hwq->data.u8 + (((size_t)n * k + 127) & ~(size_t)127));
		for (int row = 0; row < n; ++row)
		{
			float scale;
			ccv_half_precision_to_float(weight_scales + row, &scale, 1);
			for (int d = 0; d < k; ++d)
				ref_w->data.f32[(size_t)row * k + d] = ((int8_t*)hwq->data.u8)[(size_t)row * k + d] * scale;
		}
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hwq, hbias), TENSOR_LIST(w, bias), 0);
		ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
		ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
		ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, n), 0);
		ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
		ccv_nnc_tensor_t* const sample_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, samples, k), 0);
		ccv_nnc_tensor_t* const ref_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, k), 0);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, n), 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, samples, n), 0);
		for (int row = 0; row < m; ++row)
		{
			for (int d = 0; d < k; ++d)
				row_values[d] = row == 0 ? 0 : (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
			ccv_float_to_half_precision(row_values, (uint16_t*)ha->data.f16 + (size_t)row * k, k);
		}
		int rows[samples];
		const int boundaries[] = {0, 63, 64, m - 2, m - 1};
		for (int s = 0; s < samples; ++s)
		{
			rows[s] = s < 5 ? ccv_min(boundaries[s], m - 1) : (s - 5) * (m - 1) / (samples - 6);
			memcpy(sample_a->data.f16 + s * k, ha->data.f16 + (size_t)rows[s] * k, sizeof(uint16_t) * k);
		}
		// Runtime activations use abs-max scaling; the offline weight quantizer
		// also refits its scale, so it is not an activation reference.
		for (int s = 0; s < samples; ++s)
		{
			float* const values = ref_a->data.f32 + s * k;
			ccv_half_precision_to_float((uint16_t*)sample_a->data.f16 + s * k, values, k);
			float maximum = 0;
			for (int d = 0; d < k; ++d)
				maximum = ccv_max(maximum, fabsf(values[d]));
			const float inv_scale = maximum > 0 ? 127.0f / maximum : 127.0f;
			float scale = maximum > 0 ? maximum / 127.0f : 1.0f / 127.0f;
			uint16_t stored_scale;
			ccv_float_to_half_precision(&scale, &stored_scale, 1);
			// The CPU conversion truncates; Metal's half store rounds to nearest.
			float lower, upper;
			const uint16_t next_scale = stored_scale + 1;
			ccv_half_precision_to_float(&stored_scale, &lower, 1);
			ccv_half_precision_to_float(&next_scale, &upper, 1);
			if (scale - lower > upper - scale || (scale - lower == upper - scale && (stored_scale & 1)))
				stored_scale = next_scale;
			ccv_half_precision_to_float(&stored_scale, &scale, 1);
			for (int d = 0; d < k; ++d)
				values[d] = ccv_max(-127, ccv_min(127, (int)lrintf(values[d] * inv_scale))) * scale;
		}
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ref_a, ref_w, use_bias ? ref_bias : 0), TENSOR_LIST(expected), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
		if (trial % 2)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, use_bias ? bias : 0), TENSOR_LIST(b), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
		int all_finite = 1;
		for (size_t i = 0; i < (size_t)m * n; ++i)
			if ((((uint16_t*)hb->data.f16)[i] & 0x7c00) == 0x7c00)
				all_finite = 0;
		REQUIRE(all_finite, "every selected and fallback output should be finite");
		for (int s = 0; s < samples; ++s)
			ccv_half_precision_to_float((uint16_t*)hb->data.f16 + (size_t)rows[s] * n, actual->data.f32 + s * n, n);
		double error = 0, norm = 0, max_error = 0;
		for (int i = 0; i < samples * n; ++i)
		{
			const double diff = actual->data.f32[i] - expected->data.f32[i];
			error += diff * diff;
			norm += (double)expected->data.f32[i] * expected->data.f32[i];
			max_error = ccv_max(max_error, fabs(diff));
		}
		REQUIRE(sqrt(error / norm) < 5e-4, "quantized CPU GEMM relative L2=%g max_abs=%g at trial %d", sqrt(error / norm), max_error, trial);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, expected->data.f32, samples * n, 3e-3, "register tiles, tail rows and fused bias should match quantized CPU GEMM");
		ccv_nnc_tensor_free(ha);
		ccv_nnc_tensor_free(a);
		ccv_nnc_tensor_free(b);
		ccv_nnc_tensor_free(hb);
		ccv_nnc_tensor_free(sample_a);
		ccv_nnc_tensor_free(ref_a);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(actual);
		ccv_nnc_tensor_free(hw);
		ccv_nnc_tensor_free(hwq);
		ccv_nnc_tensor_free(w);
		ccv_nnc_tensor_free(ref_w);
		ccv_nnc_tensor_free(hbias);
		ccv_nnc_tensor_free(bias);
		ccv_nnc_tensor_free(ref_bias);
	}
	const uint64_t flags[] = {CCV_NNC_DISABLE_MFA_ANE, CCV_NNC_DISABLE_MFA, CCV_NNC_DISABLE_MFA_GEMM, CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS, CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M};
	for (int i = 0; i < 5; ++i)
		if (old_flags & flags[i])
			ccv_nnc_enable_flag(flags[i]);
		else
			ccv_nnc_disable_flag(flags[i]);
}

TEST_CASE("mps gemm cast composite preserves half rounding, aliases and fallback")
{
#ifdef HAVE_MPS
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA | CCV_NNC_DISABLE_MFA_GEMM | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int shapes[][4] = {
		{4096, 2048, 4096, 0}, {8193, 1537, 4097, 0},
		{2048, 3072, 8192, 0}, {1984, 3072, 8192, 0},
		{4096, 1536, 4096, CCV_NNC_QX_8I_ROWWISE_Q5_K},
		{64, 256, 256, CCV_NNC_QX_8I_ROWWISE_Q5_K | CCV_NNC_QX_8I_ROWWISE_HADAMARD_256},
		{37, 257, 511, -1}, {33, 257, 511, 0},
	};
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 91);
	for (int trial = 0; trial < 8; trial++)
	{
		const int m = shapes[trial][0], n = shapes[trial][1], k = shapes[trial][2], format = shapes[trial][3];
		ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
		ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
		ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
		float values[ccv_max(n, k)];
		for (int row = 0; row < m + n; row++)
		{
			for (int d = 0; d < k; d++)
				values[d] = row == 0 ? 0 : (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.125;
			ccv_float_to_half_precision(values, (uint16_t*)(row < m ? ha->data.f16 + (size_t)row * k : hw->data.f16 + (size_t)(row - m) * k), k);
		}
		for (int i = 0; i < n; i++)
			values[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		ccv_float_to_half_precision(values, (uint16_t*)hbias->data.f16, n);
		ccv_nnc_tensor_param_t qw_info = format < 0 ? hw->info : format ? ccv_nnc_tensor_8i_rowwise_x(hw->info, format) : ccv_nnc_tensor_8i_rowwise(hw->info);
		ccv_nnc_tensor_t* const hqw = format < 0 ? hw : ccv_nnc_tensor_new(0, qw_info, 0);
		if (format >= 0)
		{
			const size_t size = ccv_nnc_tensor_data_size_without_padding(qw_info);
			const size_t encoded = format ? ccv_nnc_quantize_8i_rowwise_x(hw->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n * k, k, format, 0, 0, hqw->data.u8, size) : ccv_nnc_quantize_8i_rowwise(hw->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n * k, k, 0, 0, hqw->data.u8, size);
			REQUIRE_EQ(encoded, size, "quantized weights should be complete");
		}
		qw_info.type = CCV_TENSOR_GPU_MEMORY;
		ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, qw_info, 0);
		ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
		// Extra room permits the wider Float32 result to overlap A with offsets.
		ccv_nnc_tensor_t* const storage = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m * ccv_max(k, 2 * n) + 256), 0);
		ccv_nnc_tensor_t a = *storage;
		a.info = GPU_TENSOR_NHWC(000, 16F, m, k);
		a.dataof = 128;
		ccv_nnc_tensor_t* const half_output = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, n), 0);
		ccv_nnc_tensor_t* const output = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m, n), 0);
		ccv_nnc_tensor_t* const hhalf = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m, n), 0);
		float* const expected = ccmalloc(sizeof(float) * (size_t)m * n);
		ccv_nnc_stream_context_t* const stream = ccv_nnc_stream_context_new(CCV_STREAM_CONTEXT_GPU);
		const size_t weight_storage_bytes = ccv_max(ccv_nnc_tensor_data_size_without_padding(qw_info), (size_t)m * n * sizeof(float)) + 512;
		ccv_nnc_tensor_t* const weight_storage = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 8U, weight_storage_bytes), 0);
		ccv_nnc_tensor_t weight_alias = *weight_storage;
		weight_alias.info = qw_info;
		weight_alias.dataof = 128;
		const ccv_nnc_cmd_t gemm = CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1));
		for (int mode = 0; mode < 5; mode++)
		{
			const ccv_nnc_cmd_t composite = ccv_nnc_mps_gemm_cast_cmd(gemm, mode != 1);
			if (mode % 2)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			else
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			// The last small-shape trial also exercises a globally disabled MFA.
			if (trial == 7 && mode == 3)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
			ccv_nnc_tensor_t alias = mode == 4 ? *weight_storage : *storage;
			ccv_nnc_tensor_t* const used_w = mode == 4 ? &weight_alias : w;
			alias.info = output->info;
			alias.dataof = mode == 2 || mode == 4 ? 256 : 128;
			ccv_nnc_tensor_t* const destination = mode ? &alias : output;
			ccv_nnc_tensor_t bias_alias = *storage;
			bias_alias.info = bias->info;
			bias_alias.dataof = 256;
			ccv_nnc_tensor_t* const used_bias = mode == 3 ? &bias_alias : mode == 1 || mode == 2 ? 0 : bias;
			// Mode 3 must fall back: Float32 output overlaps a live bias. This
			// also changes A's first row, identically for reference and composite.
			for (int pass = 0; pass < 3; pass++)
			{
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hqw), TENSOR_LIST(&a, used_w), stream);
				if (used_bias)
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hbias), TENSOR_LIST(used_bias), stream);
				if (pass != 1)
				{
					ccv_nnc_cmd_exec(gemm, ccv_nnc_no_hint, 0, TENSOR_LIST(&a, used_w, used_bias), TENSOR_LIST(half_output), stream);
					ccv_nnc_stream_context_wait(stream);
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_output), TENSOR_LIST(hhalf), 0);
					ccv_half_precision_to_float((uint16_t*)hhalf->data.f16, expected, (size_t)m * n);
				} else {
					REQUIRE_EQ(ccv_nnc_cmd_exec(composite, ccv_nnc_no_hint, CCV_NNC_NO_BACKWARD, TENSOR_LIST(&a, used_w, used_bias), TENSOR_LIST(half_output, destination), stream), CCV_NNC_EXEC_SUCCESS, "composite should execute");
					ccv_nnc_stream_context_wait(stream);
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(destination), TENSOR_LIST(actual), 0);
				}
				if (pass > 0)
					REQUIRE_ARRAY_EQ(float, actual->data.f32, expected, (size_t)m * n, "widened epilogue and fallback must preserve every half-rounded output and cache entry (trial=%d mode=%d pass=%d)", trial, mode, pass);
			}
			for (size_t i = 0; i < (size_t)m * n; i++)
				REQUIRE(isfinite(actual->data.f32[i]), "all composite outputs should be finite");
			if (trial == 7 && mode == 4)
			{
				// MPSGraph used to describe this decoded operand using the packed
				// weight's nonzero offset, producing an incompatible placeholder.
				ccv_nnc_tensor_t* const ref_a = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m, k), 0);
				ccv_nnc_tensor_t* const ref_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n, k), 0);
				ccv_nnc_tensor_t* const ref_bias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, n), 0);
				ccv_nnc_tensor_t* const ref_y = ccv_nnc_tensor_new(0, actual->info, 0);
				ccv_nnc_dequantize_8i_rowwise(hqw->data.u8, CCV_16F, CCV_TENSOR_CPU_MEMORY, ccv_nnc_tensor_data_size_without_padding(hqw->info), k, hw->data.u8, (size_t)n * k);
				ccv_half_precision_to_float((uint16_t*)ha->data.f16, ref_a->data.f32, (size_t)m * k);
				ccv_half_precision_to_float((uint16_t*)hw->data.f16, ref_w->data.f32, (size_t)n * k);
				ccv_half_precision_to_float((uint16_t*)hbias->data.f16, ref_bias->data.f32, n);
				ccv_nnc_cmd_exec(gemm, ccv_nnc_no_hint, 0, TENSOR_LIST(ref_a, ref_w, ref_bias), TENSOR_LIST(ref_y), 0);
				REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, ref_y->data.f32, (size_t)m * n, 1e-3, "decoded offset fallback should match CPU GEMM");
				ccv_nnc_tensor_free(ref_a); ccv_nnc_tensor_free(ref_w); ccv_nnc_tensor_free(ref_bias); ccv_nnc_tensor_free(ref_y);
			}
		}
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
		ccv_nnc_stream_context_free(stream);
		ccv_nnc_tensor_free(weight_storage);
		ccfree(expected);
		ccv_nnc_tensor_free(ha); ccv_nnc_tensor_free(hw); if (format >= 0) ccv_nnc_tensor_free(hqw);
		ccv_nnc_tensor_free(hbias); ccv_nnc_tensor_free(w); ccv_nnc_tensor_free(bias); ccv_nnc_tensor_free(storage);
		ccv_nnc_tensor_free(half_output); ccv_nnc_tensor_free(output); ccv_nnc_tensor_free(hhalf); ccv_nnc_tensor_free(actual);
	}
	ccv_nnc_enable_flag(old_flags);
	ccv_nnc_disable_flag(~old_flags);
#endif
}

#ifdef HAVE_MPS
static ccv_cnnp_model_t* _mps_gemm_cast_model(const int variant, const int m, const int n, const int k)
{
	ccv_cnnp_model_io_t x = ccv_cnnp_input(), w = ccv_cnnp_input(), bias = ccv_cnnp_input();
	ccv_cnnp_model_io_t a = ccv_cnnp_model_apply(ccv_cnnp_scalar_mul(0.75, "producer"), MODEL_IO_LIST(x));
	if (variant == 5)
	{
		a = ccv_cnnp_model_apply(ccv_cnnp_reshape(0, DIM_ALLOC(1, m, k), DIM_ALLOC(), DIM_ALLOC(), "heads_flattened"), MODEL_IO_LIST(a));
		a = ccv_cnnp_model_apply(ccv_cnnp_reshape(0, DIM_ALLOC(m, k), DIM_ALLOC(), DIM_ALLOC(), "rows_flattened"), MODEL_IO_LIST(a));
	}
	ccv_cnnp_model_t* const gemm = ccv_cnnp_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0,
		MODEL_CMD_EXEC_IO_MAP(KV(CCV_CNNP_IO), KV(CCV_CNNP_IO), KV(CCV_CNNP_IO)), MODEL_CMD_EXEC_IO_LIST(CCV_CNNP_IO), 1, "gemm");
	if (variant == 1)
		ccv_cnnp_model_set_flags(gemm, CCV_NNC_GRAPH_EXEC_DISABLE_OPT);
	ccv_cnnp_model_io_t h = ccv_cnnp_model_apply(gemm, MODEL_IO_LIST(a, w, bias));
	ccv_cnnp_model_io_t f = ccv_cnnp_model_apply(ccv_cnnp_datatype_conversion(CCV_32F, 0, "cast"), MODEL_IO_LIST(h));
	ccv_cnnp_model_io_t y = ccv_cnnp_model_apply(ccv_cnnp_scalar_mul(0.875, "consumer"), MODEL_IO_LIST(f));
	if (variant == 2)
		return ccv_cnnp_model_new(MODEL_IO_LIST(x, w, bias), MODEL_IO_LIST(y, h), 1, "projection_cast");
	if (variant == 3)
	{
		ccv_cnnp_model_io_t branch = ccv_cnnp_model_apply(ccv_cnnp_scalar_mul(0.5, "second_consumer"), MODEL_IO_LIST(h));
		return ccv_cnnp_model_new(MODEL_IO_LIST(x, w, bias), MODEL_IO_LIST(y, branch), 1, "projection_cast");
	}
	if (variant == 4)
	{
		ccv_cnnp_model_io_t alias = ccv_cnnp_model_apply(ccv_cnnp_reshape(0, DIM_ALLOC(1, m, n), DIM_ALLOC(), DIM_ALLOC(), "exposed_alias"), MODEL_IO_LIST(h));
		return ccv_cnnp_model_new(MODEL_IO_LIST(x, w, bias), MODEL_IO_LIST(y, alias), 1, "projection_cast");
	}
	return ccv_cnnp_model_new(MODEL_IO_LIST(x, w, bias), MODEL_IO_LIST(y), 1, "projection_cast");
}

static int _mps_gemm_cast_model_composites(const ccv_cnnp_model_t* const model)
{
	int count = 0;
	for (int i = 0; i < model->compiled_data->graph->exec_info->rnum; i++)
	{
		const ccv_nnc_graph_exec_info_t* const node = ccv_array_get(model->compiled_data->graph->exec_info, i);
		count += ccv_nnc_mps_is_gemm_cast_cmd(node->cmd);
	}
	return count;
}
#endif

TEST_CASE("mps gemm cast inference graph preserves exposed tensors and reinitialization")
{
#ifdef HAVE_MPS
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ANE);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA | CCV_NNC_DISABLE_MFA_GEMM | CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int max_m = 2112, n = 3072, k = 4096;
	ccv_nnc_tensor_t* const hx = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, max_m, k), 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
	ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 97);
	float row_values[k];
	for (int row = 0; row < max_m + n; row++)
	{
		for (int d = 0; d < k; d++)
			row_values[d] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.125;
		ccv_float_to_half_precision(row_values, (uint16_t*)(row < max_m ? hx->data.f16 + (size_t)row * k : hw->data.f16 + (size_t)(row - max_m) * k), k);
	}
	for (int i = 0; i < n; i++)
		row_values[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
	ccv_float_to_half_precision(row_values, (uint16_t*)hbias->data.f16, n);
	ccv_nnc_tensor_t* const hqw = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(hw->info), 0);
	const size_t qsize = ccv_nnc_tensor_data_size_without_padding(hqw->info);
	REQUIRE_EQ(ccv_nnc_quantize_8i_rowwise(hw->data.f16, CCV_16F, CCV_TENSOR_CPU_MEMORY, (size_t)n * k, k, 0, 0, hqw->data.u8, qsize), qsize, "all weights should encode");
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 16F, n, k)), 0);
	ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hqw, hbias), TENSOR_LIST(w, bias), 0);
	ccv_cnnp_model_t* model = 0;
	uint64_t retained_arena_size = 0;
	const int rows[] = {2112, 2048, 1984, 4096}; // Reuse, cross selection boundary, then grow allocation.
	for (int shape = 0; shape < 4; shape++)
	{
		const int m = rows[shape];
		ccv_nnc_tensor_t* const x = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
		ccv_nnc_tensor_t* const y = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m, n), 0);
		ccv_nnc_tensor_t* const rebound = ccv_nnc_tensor_new(0, y->info, 0);
		ccv_nnc_tensor_t* const reference = ccv_nnc_tensor_new(0, y->info, 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m, n), 0);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, actual->info, 0);
		if (m <= max_m)
		{
			ccv_nnc_tensor_t prefix = *hx;
			prefix.info.dim[0] = m;
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(&prefix), TENSOR_LIST(x), 0);
		} else
			ccv_nnc_cmd_exec(CMD_SET_FORWARD(0.125), ccv_nnc_no_hint, 0, 0, 0, TENSOR_LIST(x), 0);
		ccv_cnnp_model_t* const baseline = _mps_gemm_cast_model(1, m, n, k);
		ccv_cnnp_model_compile(baseline, TENSOR_PARAM_LIST(x->info, w->info, bias->info), CMD_NOOP(), CMD_NOOP());
		ccv_cnnp_model_evaluate(baseline, (ccv_cnnp_evaluate_param_t){ .requires_grad = 0 }, TENSOR_LIST(x, w, bias), TENSOR_LIST(reference), 0, 0);
		REQUIRE_EQ(_mps_gemm_cast_model_composites(baseline), 0, "disableOpt should preserve the pair");
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(reference), TENSOR_LIST(expected), 0);
		if (!model)
		{
			model = _mps_gemm_cast_model(0, m, n, k);
			ccv_cnnp_model_compile(model, TENSOR_PARAM_LIST(x->info, w->info, bias->info), CMD_NOOP(), CMD_NOOP());
		} else {
			ccv_nnc_graph_t* const previous = model->compiled_data->graph;
			ccv_cnnp_model_absorb(model, _mps_gemm_cast_model(0, m, n, k), TENSOR_PARAM_LIST(x->info, w->info, bias->info));
			if (shape < 3)
				REQUIRE(model->compiled_data->graph == previous, "smaller shapes should exercise graph reinitialization");
		}
		ccv_nnc_stream_context_t* const stream = ccv_nnc_stream_context_new(CCV_STREAM_CONTEXT_GPU);
		for (int bind = 0; bind < 2; bind++)
		{
			ccv_nnc_tensor_t* const destination = bind ? rebound : y;
			ccv_cnnp_model_evaluate(model, (ccv_cnnp_evaluate_param_t){ .requires_grad = 0 }, TENSOR_LIST(x, w, bias), TENSOR_LIST(destination), 0, stream);
			ccv_nnc_stream_context_wait(stream);
			REQUIRE_EQ(_mps_gemm_cast_model_composites(model), 1, "inference graph should keep its guarded composite across shapes / bindings");
			if (shape == 0 || shape == 3)
			{
				retained_arena_size = ccv_nnc_tensor_arena_size(baseline->compiled_data->tensor_arena);
			}
			REQUIRE_EQ(ccv_nnc_tensor_arena_size(model->compiled_data->tensor_arena), retained_arena_size, "fusion and reinitialization should preserve planned memory");
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(destination), TENSOR_LIST(actual), 0);
			REQUIRE_ARRAY_EQ(float, actual->data.f32, expected->data.f32, (size_t)m * n, "compiled inference and its fallback should preserve all outputs after reinitialization / rebinding");
		}
		if (shape == 0)
		{
			ccv_cnnp_model_t* const reshaped = _mps_gemm_cast_model(5, m, n, k);
			ccv_cnnp_model_compile(reshaped, TENSOR_PARAM_LIST(x->info, w->info, bias->info), CMD_NOOP(), CMD_NOOP());
			ccv_cnnp_model_evaluate(reshaped, (ccv_cnnp_evaluate_param_t){ .requires_grad = 0 }, TENSOR_LIST(x, w, bias), TENSOR_LIST(y), 0, stream);
			ccv_nnc_stream_context_wait(stream);
			REQUIRE_EQ(_mps_gemm_cast_model_composites(reshaped), 1, "private activation reshapes should preserve fusion");
			REQUIRE_EQ(ccv_nnc_tensor_arena_size(reshaped->compiled_data->tensor_arena), retained_arena_size, "private activation reshapes should not grow memory");
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(y), TENSOR_LIST(actual), 0);
			REQUIRE_ARRAY_EQ(float, actual->data.f32, expected->data.f32, (size_t)m * n, "private activation reshapes should preserve all projection outputs");
			ccv_cnnp_model_free(reshaped);
		}
		if (shape == 0)
			for (int variant = 2; variant <= 4; variant++)
			{
				ccv_cnnp_model_t* const exposed = _mps_gemm_cast_model(variant, m, n, k);
				ccv_cnnp_model_compile(exposed, TENSOR_PARAM_LIST(x->info, w->info, bias->info), CMD_NOOP(), CMD_NOOP());
				ccv_nnc_tensor_param_t extra_info = variant == 4 ? GPU_TENSOR_NHWC(000, 16F, 1, m, n) : GPU_TENSOR_NHWC(000, 16F, m, n);
				ccv_nnc_tensor_t* const extra = ccv_nnc_tensor_new(0, extra_info, 0);
				ccv_cnnp_model_evaluate(exposed, (ccv_cnnp_evaluate_param_t){ .requires_grad = 0 }, TENSOR_LIST(x, w, bias), TENSOR_LIST(y, extra), 0, stream);
				ccv_nnc_stream_context_wait(stream);
				REQUIRE_EQ(_mps_gemm_cast_model_composites(exposed), 0, "exposed half results, additional consumers and aliases must retain the original pair");
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(y), TENSOR_LIST(actual), 0);
				REQUIRE_ARRAY_EQ(float, actual->data.f32, expected->data.f32, (size_t)m * n, "protected graphs should retain the projection output");
				ccv_nnc_tensor_t* const h_extra = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, n), 0);
				ccv_nnc_tensor_t extra_flat = *extra;
				extra_flat.info.dim[0] = m; extra_flat.info.dim[1] = n; extra_flat.info.dim[2] = 0;
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(&extra_flat), TENSOR_LIST(h_extra), 0);
				ccv_half_precision_to_float((uint16_t*)h_extra->data.f16, actual->data.f32, (size_t)m * n);
				for (size_t i = 0; i < (size_t)m * n; i++)
					REQUIRE(fabsf(actual->data.f32[i] * (variant == 3 ? 1.75f : 0.875f) - expected->data.f32[i]) < 1e-6f, "the exposed half result must still be materialized");
				ccv_nnc_tensor_free(h_extra); ccv_nnc_tensor_free(extra); ccv_cnnp_model_free(exposed);
			}
		ccv_nnc_stream_context_free(stream); ccv_cnnp_model_free(baseline);
		ccv_nnc_tensor_free(x); ccv_nnc_tensor_free(y); ccv_nnc_tensor_free(rebound); ccv_nnc_tensor_free(reference); ccv_nnc_tensor_free(actual); ccv_nnc_tensor_free(expected);
	}
	ccv_cnnp_model_free(model);
	ccv_nnc_tensor_free(hx); ccv_nnc_tensor_free(hw); ccv_nnc_tensor_free(hbias); ccv_nnc_tensor_free(hqw); ccv_nnc_tensor_free(w); ccv_nnc_tensor_free(bias);
	ccv_nnc_enable_flag(old_flags); ccv_nnc_disable_flag(~old_flags);
#endif
}

TEST_CASE("mps gemm cast inference graph leaves training semantics intact")
{
#ifdef HAVE_MPS
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int m = 48, n = 64, k = 128;
	ccv_nnc_tensor_t* const hx = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, m, k), 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n, k), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, n), 0);
	float values[ccv_max(m, n) * k];
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 103);
	ccv_nnc_tensor_t* const hosts[] = {hx, hw, hb};
	for (int t = 0; t < 3; t++)
	{
		const size_t count = ccv_nnc_tensor_count(hosts[t]->info);
		for (size_t i = 0; i < count; i++)
			values[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25;
		ccv_float_to_half_precision(values, (uint16_t*)hosts[t]->data.f16, count);
	}
	ccv_nnc_tensor_t* const x = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, m, k), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n, k), 0);
	ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, n), 0);
	ccv_nnc_tensor_t* const y = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, m, n), 0);
	ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, m, n), 0);
	ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, actual->info, 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hx, hw, hb), TENSOR_LIST(x, w, bias), 0);
	ccv_cnnp_model_t* const model = _mps_gemm_cast_model(0, m, n, k);
	ccv_cnnp_model_compile(model, TENSOR_PARAM_LIST(x->info, w->info, bias->info), CMD_NOOP(), CMD_NOOP());
	for (int mode = 0; mode < 3; mode++)
	{
		ccv_cnnp_model_evaluate(model, (ccv_cnnp_evaluate_param_t){ .requires_grad = mode == 1 }, TENSOR_LIST(x, w, bias), TENSOR_LIST(y), 0, 0);
		// CNNP reuses the training graph for later no-gradient evaluations.
		REQUIRE_EQ(_mps_gemm_cast_model_composites(model), mode == 0 ? 1 : 0, "training and reused training graphs must retain the original pair");
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(y), TENSOR_LIST(mode ? actual : expected), 0);
		if (mode)
			REQUIRE_ARRAY_EQ(float, actual->data.f32, expected->data.f32, m * n, "training transitions must retain half rounding and outputs");
	}
	ccv_cnnp_model_free(model);
	ccv_nnc_tensor_free(hx); ccv_nnc_tensor_free(hw); ccv_nnc_tensor_free(hb); ccv_nnc_tensor_free(x); ccv_nnc_tensor_free(w); ccv_nnc_tensor_free(bias); ccv_nnc_tensor_free(y); ccv_nnc_tensor_free(actual); ccv_nnc_tensor_free(expected);
#endif
}

TEST_CASE("mps forward gemm no bias in bfloat precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, 10, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	for (i = 0; i < 10 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 10, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 64, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw), TENSOR_LIST(ha2, hw2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
}

TEST_CASE("mps forward gemv in half precision no bias, variant 1")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 128), 0);
	for (i = 0; i < 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw), TENSOR_LIST(ha2, hw2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
}

TEST_CASE("mps forward gemv in half precision no bias with M=2")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 1);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 2, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 2, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 128), 0);
	for (i = 0; i < 2 * 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 2 * 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 2, 128), 0);
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw), TENSOR_LIST(ha2, hw2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 2, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 2 * 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
}

TEST_CASE("mps forward gemv in half precision no bias, variant 2")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 128), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 128, 1), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 64, 1), 0);

	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 128, 1), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 1), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	ccv_nnc_tensor_t* ha1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 128, 1), 0);
	for (i = 0; i < 128; i++)
		ha1->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 128; i++)
		ha->data.f32[i] = ha1->data.f32[i];
	ccv_nnc_tensor_t* hw2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 128), 0);
	ccv_nnc_tensor_t* ha2 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 128, 1), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha1, hw), TENSOR_LIST(ha2, hw2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha2, hw2), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, NO_TRANSPOSE), ccv_nnc_no_hint, 0, TENSOR_LIST(hw, ha), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, NO_TRANSPOSE), ccv_nnc_no_hint, 0, TENSOR_LIST(w, a), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 64, 1), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(tb), 0);
	ccv_nnc_tensor_t* tb1 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 1), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(tb), TENSOR_LIST(tb1), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb1->data.f32, hb->data.f32, 64, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ha1);
	ccv_nnc_tensor_free(tb1);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(ha2);
	ccv_nnc_tensor_free(hw2);
}

TEST_CASE("mps handle permute")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 2, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 2, 128), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 2, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 2, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 128), 0);
	ccv_nnc_tensor_t* wt = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 128), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 64), 0);
	int i;
	for (i = 0; i < 2 * 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 2 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(0, 1), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(0, 1), ccv_nnc_no_hint, 0, TENSOR_LIST(w), TENSOR_LIST(wt), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(at, wt), TENSOR_LIST(bt), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(128, 2 * 128, 1));
	ccv_nnc_tensor_view_t* wv = ccv_nnc_tensor_view_new(w, GPU_TENSOR_NHWC(000, 32F, 2, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(128, 2 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)av, (ccv_nnc_tensor_t*)wv), TENSOR_LIST(b), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 64), 0);
	ccv_nnc_tensor_t* hbt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b, bt), TENSOR_LIST(hb, hbt), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, hb->data.f32, hbt->data.f32, 2 * 10 * 64, 1e-5, "permute computed output should be numerically close to non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(wv);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(wt);
	ccv_nnc_tensor_free(bt);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hbt);
}

TEST_CASE("generalized batched gemm with batch (2, 4) compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* wt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 64, 128), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	int i;
	for (i = 0; i < 8 * 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(hw), TENSOR_LIST(wt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* wv = ccv_nnc_tensor_view_new(w, GPU_TENSOR_NHWC(000, 32F, 2, 4, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(64 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)av, (ccv_nnc_tensor_t*)wv), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST(at, wt), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(hb, bt, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(wv);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(wt);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("mps forward interleaved batched dense gemv")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int T = 1;
	const int G = 3;
	const int N = 67;
	const int K = 260;
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, G, 1, K), 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, G, N, K), 0);
	ccv_nnc_tensor_t* const a_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, T, K), 0);
	ccv_nnc_tensor_t* const w_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, N, K), 0);
	ccv_nnc_tensor_t* const b_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, T, N), 0);
	float* const a_values = (float*)ccmalloc(sizeof(float) * T * G * K);
	float* const w_values = (float*)ccmalloc(sizeof(float) * G * N * K);
	int t, g, n, k;
	for (t = 0; t < T; t++)
		for (g = 0; g < G; g++)
			for (k = 0; k < K; k++)
			{
				const float value = (float)(((t * 5 + g * 11 + k * 7) % 17) - 8) / 64.0f;
				a_values[(t * G + g) * K + k] = value;
				a_ref->data.f32[(g * T + t) * K + k] = value;
			}
	for (g = 0; g < G; g++)
		for (n = 0; n < N; n++)
			for (k = 0; k < K; k++)
			{
				const float value = (float)(((g * 13 + n * 5 + k * 3) % 19) - 9) / 128.0f;
				w_values[(g * N + n) * K + k] = value;
				w_ref->data.f32[(g * N + n) * K + k] = value;
			}
	ccv_float_to_half_precision(a_values, (uint16_t*)ha->data.f16, T * G * K);
	ccv_float_to_half_precision(w_values, (uint16_t*)hw->data.f16, G * N * K);
	ccfree(a_values);
	ccfree(w_values);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a_ref, w_ref), TENSOR_LIST(b_ref), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, G, 1, K), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, G, N, K), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, G, 1, N), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "interleaved batched dense GEMV should execute through MFA");
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, G, 1, N), 0);
	ccv_nnc_tensor_t* const b_actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, G, 1, N), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hb), TENSOR_LIST(b_actual), 0);
	float max_relative_diff = 0;
	int max_diff_idx = 0;
	for (t = 0; t < T; t++)
		for (g = 0; g < G; g++)
			for (n = 0; n < N; n++)
			{
				const int actual_idx = (t * G + g) * N + n;
				const int expected_idx = (g * T + t) * N + n;
				const float actual = b_actual->data.f32[actual_idx];
				const float expected = b_ref->data.f32[expected_idx];
				const float denom = ccv_max(ccv_max(fabsf(actual), fabsf(expected)), 1);
				const float relative_diff = fabsf(actual - expected) / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_diff_idx = actual_idx;
			}
	REQUIRE(max_relative_diff <= 2e-3, "interleaved batched dense GEMV should match CPU reference (max relative diff %g at %d)", max_relative_diff, max_diff_idx);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(a_ref);
	ccv_nnc_tensor_free(w_ref);
	ccv_nnc_tensor_free(b_ref);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(b_actual);
}

TEST_CASE("mps forward interleaved batched dense gemm generic")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int T = 17;
	const int G = 3;
	const int N = 64;
	const int K = 128;
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, G, 1, K), 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, G, N, K), 0);
	ccv_nnc_tensor_t* const a_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, T, K), 0);
	ccv_nnc_tensor_t* const w_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, N, K), 0);
	ccv_nnc_tensor_t* const b_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, T, N), 0);
	float* const a_values = (float*)ccmalloc(sizeof(float) * T * G * K);
	float* const w_values = (float*)ccmalloc(sizeof(float) * G * N * K);
	int t, g, n, k;
	for (t = 0; t < T; t++)
		for (g = 0; g < G; g++)
			for (k = 0; k < K; k++)
			{
				const float value = (float)(((t * 5 + g * 11 + k * 7) % 17) - 8) / 64.0f;
				a_values[(t * G + g) * K + k] = value;
				a_ref->data.f32[(g * T + t) * K + k] = value;
			}
	for (g = 0; g < G; g++)
		for (n = 0; n < N; n++)
			for (k = 0; k < K; k++)
			{
				const float value = (float)(((g * 13 + n * 5 + k * 3) % 19) - 9) / 128.0f;
				w_values[(g * N + n) * K + k] = value;
				w_ref->data.f32[(g * N + n) * K + k] = value;
			}
	ccv_float_to_half_precision(a_values, (uint16_t*)ha->data.f16, T * G * K);
	ccv_float_to_half_precision(w_values, (uint16_t*)hw->data.f16, G * N * K);
	ccfree(a_values);
	ccfree(w_values);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a_ref, w_ref), TENSOR_LIST(b_ref), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, G, 1, K), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, G, N, K), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, G, 1, N), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "interleaved batched dense GEMM should execute through generic MFA");
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, G, 1, N), 0);
	ccv_nnc_tensor_t* const b_actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, G, 1, N), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hb), TENSOR_LIST(b_actual), 0);
	float max_relative_diff = 0;
	int max_diff_idx = 0;
	for (t = 0; t < T; t++)
		for (g = 0; g < G; g++)
			for (n = 0; n < N; n++)
			{
				const int actual_idx = (t * G + g) * N + n;
				const int expected_idx = (g * T + t) * N + n;
				const float actual = b_actual->data.f32[actual_idx];
				const float expected = b_ref->data.f32[expected_idx];
				const float denom = ccv_max(ccv_max(fabsf(actual), fabsf(expected)), 1);
				const float relative_diff = fabsf(actual - expected) / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_diff_idx = actual_idx;
			}
	REQUIRE(max_relative_diff <= 2e-3, "interleaved batched dense GEMM should match CPU reference (max relative diff %g at %d)", max_relative_diff, max_diff_idx);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(a_ref);
	ccv_nnc_tensor_free(w_ref);
	ccv_nnc_tensor_free(b_ref);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(b_actual);
}

TEST_CASE("mps forward interleaved batched dense gemm NAMatMul split K")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	const int T = 17;
	const int G = 3;
	const int N = 64;
	const int K = 4096;
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, G, 1, K), 0);
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, G, N, K), 0);
	ccv_nnc_tensor_t* const a_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, T, K), 0);
	ccv_nnc_tensor_t* const w_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, N, K), 0);
	ccv_nnc_tensor_t* const b_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, G, T, N), 0);
	float* const a_values = (float*)ccmalloc(sizeof(float) * T * G * K);
	float* const w_values = (float*)ccmalloc(sizeof(float) * G * N * K);
	int t, g, n, k;
	for (t = 0; t < T; t++)
		for (g = 0; g < G; g++)
			for (k = 0; k < K; k++)
			{
				const float value = (float)(((t * 5 + g * 11 + k * 7) % 17) - 8) / 64.0f;
				a_values[(t * G + g) * K + k] = value;
				a_ref->data.f32[(g * T + t) * K + k] = value;
			}
	for (g = 0; g < G; g++)
		for (n = 0; n < N; n++)
			for (k = 0; k < K; k++)
			{
				const float value = (float)(((g * 13 + n * 5 + k * 3) % 19) - 9) / 128.0f;
				w_values[(g * N + n) * K + k] = value;
				w_ref->data.f32[(g * N + n) * K + k] = value;
			}
	ccv_float_to_half_precision(a_values, (uint16_t*)ha->data.f16, T * G * K);
	ccv_float_to_half_precision(w_values, (uint16_t*)hw->data.f16, G * N * K);
	ccfree(a_values);
	ccfree(w_values);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a_ref, w_ref), TENSOR_LIST(b_ref), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, G, 1, K), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, G, N, K), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, G, 1, N), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	const int status = ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM);
	if (old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "interleaved batched dense GEMM should execute through NAMatMul");
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, G, 1, N), 0);
	ccv_nnc_tensor_t* const b_actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, G, 1, N), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hb), TENSOR_LIST(b_actual), 0);
	float max_relative_diff = 0;
	int max_diff_idx = 0;
	for (t = 0; t < T; t++)
		for (g = 0; g < G; g++)
			for (n = 0; n < N; n++)
			{
				const int actual_idx = (t * G + g) * N + n;
				const int expected_idx = (g * T + t) * N + n;
				const float actual = b_actual->data.f32[actual_idx];
				const float expected = b_ref->data.f32[expected_idx];
				const float denom = ccv_max(ccv_max(fabsf(actual), fabsf(expected)), 1);
				const float relative_diff = fabsf(actual - expected) / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_diff_idx = actual_idx;
			}
	REQUIRE(max_relative_diff <= 2e-3, "interleaved batched dense NAMatMul should match CPU reference (max relative diff %g at %d)", max_relative_diff, max_diff_idx);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(a_ref);
	ccv_nnc_tensor_free(w_ref);
	ccv_nnc_tensor_free(b_ref);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(b_actual);
}

TEST_CASE("generalized batched gemm with batch (2, 4) and broadcast compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(a, w), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)av, w), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(at, hw), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(hb, bt, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("generalized batched gemm with batch (2, 4) with bias compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* wt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 64, 128), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	int i;
	for (i = 0; i < 8 * 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / 64;
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(hw), TENSOR_LIST(wt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* wv = ccv_nnc_tensor_view_new(w, GPU_TENSOR_NHWC(000, 32F, 2, 4, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(64 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)av, (ccv_nnc_tensor_t*)wv, bias), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST(at, wt, hbias), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(hb, bt, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(wv);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(wt);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("generalized batched gemm with batch (2, 4) with bias and broadcast compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / 64;
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(a, w, bias), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)av, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(at, hw, hbias), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(hb, bt, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("generalized batched backward gemm with batch (2, 4) compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* hda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* da = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* wt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 64, 128), 0);
	ccv_nnc_tensor_t* dat = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* dwt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 64, 128), 0);
	ccv_nnc_tensor_t* tda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	int i;
	for (i = 0; i < 8 * 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 2 * 4 * 10 * 64; i++)
		hb->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(hw), TENSOR_LIST(wt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hb), TENSOR_LIST(a, w, b), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* wv = ccv_nnc_tensor_view_new(w, GPU_TENSOR_NHWC(000, 32F, 2, 4, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(64 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* dav = ccv_nnc_tensor_view_new(da, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* dwv = ccv_nnc_tensor_view_new(dw, GPU_TENSOR_NHWC(000, 32F, 2, 4, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(64 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST(b, (ccv_nnc_tensor_t*)av, (ccv_nnc_tensor_t*)wv), TENSOR_LIST((ccv_nnc_tensor_t*)dav, (ccv_nnc_tensor_t*)dwv), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST(hb, at, wt), TENSOR_LIST(dat, dwt), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(dat), TENSOR_LIST(tda), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(dwt), TENSOR_LIST(tdw), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(da, dw), TENSOR_LIST(hda, hdw), 0);
	REQUIRE_TENSOR_EQ(hda, tda, "permute computed output should be the same as non-permute computed ones");
	REQUIRE_TENSOR_EQ(hdw, tdw, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hda);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(da);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(wv);
	ccv_nnc_tensor_view_free(dav);
	ccv_nnc_tensor_view_free(dwv);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(wt);
	ccv_nnc_tensor_free(dat);
	ccv_nnc_tensor_free(tda);
	ccv_nnc_tensor_free(dwt);
	ccv_nnc_tensor_free(tdw);
}

TEST_CASE("generalized batched backward gemm with batch (2, 4) and broadcast compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* da = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* dat = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* tda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 2 * 4 * 10 * 64; i++)
		hb->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hb), TENSOR_LIST(a, w, b), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* dav = ccv_nnc_tensor_view_new(da, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(b, (ccv_nnc_tensor_t*)av, w), TENSOR_LIST((ccv_nnc_tensor_t*)dav, dw), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(hb, at, hw), TENSOR_LIST(dat, tdw), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(dat), TENSOR_LIST(tda), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(da, dw), TENSOR_LIST(hda, hdw), 0);
	REQUIRE_TENSOR_EQ(hda, tda, "permute computed output should be the same as non-permute computed ones");
	REQUIRE_TENSOR_EQ(hdw, tdw, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hda);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(da);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(dav);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(dat);
	ccv_nnc_tensor_free(tda);
	ccv_nnc_tensor_free(tdw);
}

TEST_CASE("generalized batched backward gemm with batch (2, 4) with bias compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* hda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* hdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* da = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* dbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* wt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 64, 128), 0);
	ccv_nnc_tensor_t* dat = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* dwt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 64, 128), 0);
	ccv_nnc_tensor_t* tda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 64, 4, 128), 0);
	ccv_nnc_tensor_t* tdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	int i;
	for (i = 0; i < 8 * 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 2 * 4 * 10 * 64; i++)
		hb->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(hw), TENSOR_LIST(wt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hb), TENSOR_LIST(a, w, b), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* wv = ccv_nnc_tensor_view_new(w, GPU_TENSOR_NHWC(000, 32F, 2, 4, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(64 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* dav = ccv_nnc_tensor_view_new(da, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* dwv = ccv_nnc_tensor_view_new(dw, GPU_TENSOR_NHWC(000, 32F, 2, 4, 64, 128), ccv_nnc_no_ofs, DIM_ALLOC(64 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST(b, (ccv_nnc_tensor_t*)av, (ccv_nnc_tensor_t*)wv), TENSOR_LIST((ccv_nnc_tensor_t*)dav, (ccv_nnc_tensor_t*)dwv, dbias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(2, 3)), ccv_nnc_no_hint, 0, TENSOR_LIST(hb, at, wt), TENSOR_LIST(dat, dwt, tdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(da, dw, dbias), TENSOR_LIST(hda, hdw, hdbias), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(dat), TENSOR_LIST(tda), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(dwt), TENSOR_LIST(tdw), 0);
	REQUIRE_TENSOR_EQ(hda, tda, "permute computed output should be the same as non-permute computed ones");
	REQUIRE_TENSOR_EQ(hdw, tdw, "permute computed output should be the same as non-permute computed ones");
	REQUIRE_TENSOR_EQ(hdbias, tdbias, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hda);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hdbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(da);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(wv);
	ccv_nnc_tensor_view_free(dav);
	ccv_nnc_tensor_view_free(dwv);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(wt);
	ccv_nnc_tensor_free(dat);
	ccv_nnc_tensor_free(dwt);
	ccv_nnc_tensor_free(tda);
	ccv_nnc_tensor_free(tdw);
	ccv_nnc_tensor_free(tdbias);
}

TEST_CASE("generalized batched backward gemm with batch (2, 4) with bias and broadcast compare mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	// This is a particular batched gemm which treat every dimensions other than the last two as batching.
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 64), 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* da = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* dbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 64), 0);

	ccv_nnc_tensor_t* at = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* dat = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 10, 128), 0);
	ccv_nnc_tensor_t* tda = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 10, 4, 128), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* tdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 8 * 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 2 * 4 * 10 * 64; i++)
		hb->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(at), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hb), TENSOR_LIST(a, w, b), 0);
	ccv_nnc_tensor_view_t* av = ccv_nnc_tensor_view_new(a, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_tensor_view_t* dav = ccv_nnc_tensor_view_new(da, GPU_TENSOR_NHWC(000, 32F, 2, 4, 10, 128), ccv_nnc_no_ofs, DIM_ALLOC(10 * 4 * 128, 128, 4 * 128, 1));
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(b, (ccv_nnc_tensor_t*)av, w, dbias), TENSOR_LIST((ccv_nnc_tensor_t*)dav, dw, dbias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(hb, at, hw, hdbias), TENSOR_LIST(dat, tdw, tdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(da, dw, dbias), TENSOR_LIST(hda, hdw, hdbias), 0);
	ccv_nnc_cmd_exec(CMD_TRANSPOSE_FORWARD(1, 2), ccv_nnc_no_hint, 0, TENSOR_LIST(dat), TENSOR_LIST(tda), 0);
	REQUIRE_TENSOR_EQ(hda, tda, "permute computed output should be the same as non-permute computed ones");
	REQUIRE_TENSOR_EQ(hdw, tdw, "permute computed output should be the same as non-permute computed ones");
	REQUIRE_TENSOR_EQ(hdbias, tdbias, "permute computed output should be the same as non-permute computed ones");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hda);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hdbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(da);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_view_free(av);
	ccv_nnc_tensor_view_free(dav);
	ccv_nnc_tensor_free(at);
	ccv_nnc_tensor_free(dat);
	ccv_nnc_tensor_free(tdw);
	ccv_nnc_tensor_free(tdbias);
}

TEST_CASE("ewdiv forward with reciprocal")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWDIV_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 0.01;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWDIV_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(0, a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWDIV_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(0, ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("ewdiv forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWDIV_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* c = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hc = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* ct = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 0.01;
	for (i = 0; i < 1000; i++)
		hb->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 0.01;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hb), TENSOR_LIST(a, b), 0);
	ccv_nnc_cmd_exec(CMD_EWDIV_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(c), 0);
	ccv_nnc_cmd_exec(CMD_EWDIV_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hb), TENSOR_LIST(ct), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(c), TENSOR_LIST(hc), 0);
	REQUIRE_TENSOR_EQ(ct, hc, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hc);
	ccv_nnc_tensor_free(ct);
}

TEST_CASE("exp forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWEXP_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 1;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWEXP_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWEXP_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, bt->data.f32, hb->data.f32, 10 * 100, 2e-3, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("softplus forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWSOFTPLUS_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 101), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 101), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 101), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 101), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 101), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1010; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 40 - 20;
	ha->data.f32[0] = -100;
	ha->data.f32[1] = -40;
	ha->data.f32[2] = 0;
	ha->data.f32[3] = 40;
	ha->data.f32[4] = 100;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWSOFTPLUS_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWSOFTPLUS_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, bt->data.f32, hb->data.f32, 10 * 101, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("ewpow forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWPOW_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* c = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hc = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* ct = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 2 + 0.1;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWPOW_FORWARD(3), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(c), 0);
	ccv_nnc_cmd_exec(CMD_EWPOW_FORWARD(3), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(ct), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(c), TENSOR_LIST(hc), 0);
	REQUIRE_TENSOR_EQ(ct, hc, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(c);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hc);
	ccv_nnc_tensor_free(ct);
}

TEST_CASE("ewsin forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWSIN_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 5;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWSIN_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWSIN_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, bt->data.f32, hb->data.f32, 10 * 100, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("ewcos forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWCOS_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 5;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWCOS_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWCOS_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, bt->data.f32, hb->data.f32, 10 * 100, 1e-3, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("ewlog forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWLOG_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 + 0.0001;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWLOG_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWLOG_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("ewsqrt forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWSQRT_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 + 0.0001;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWSQRT_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWSQRT_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("ewabs forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWABS_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 5 + 0.0001;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_EWABS_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_EWABS_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("clamp forward")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_CLAMP_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 1;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_CLAMP_FORWARD(0, 6), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_CLAMP_FORWARD(0, 6), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("clamp forward with only max")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_CLAMP_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 1;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_CLAMP_FORWARD(NAN, 6), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_CLAMP_FORWARD(NAN, 6), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("clamp forward with only min")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_CLAMP_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NCHW(000, 32F, 10, 100), 0);
	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	ccv_nnc_tensor_t* bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 10, 100), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 1000; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 1;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_CLAMP_FORWARD(0, NAN), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_CLAMP_FORWARD(0, NAN), ccv_nnc_no_hint, 0, TENSOR_LIST(ha), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "GPU computed output should be the same as CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("MFA row broadcast add and multiply match CPU with offset outputs, in-place inputs, specialized and dynamic lengths")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_MUL_FORWARD, CCV_NNC_BACKEND_MPS) && ccv_nnc_cmd_ok(CCV_NNC_ADD_FORWARD, CCV_NNC_BACKEND_MPS));
	const struct {
		int m, h, width;
		int a_nd, b_nd;
		int offsets[3];
	} shapes[] = {
		{1, 28, 5376, 2, 1, {4, 4, 4}},
		{1, 414, 5376, 3, 2, {4, 4, 4}},
		{2, 37, 513, 4, 3, {4, 4, 4}},
		{1, 4, 128, 3, 1, {3, 4, 4}}, // Only the full input is unaligned.
		{1, 7, 132, 2, 2, {4, 3, 4}}, // Only the row vector is unaligned.
		{1, 4, 127, 3, 3, {4, 4, 4}}, // Total length is divisible by four, row length is not.
		{1, 33, 257, 4, 1, {4, 4, 4}},
		{1, 129, 257, 3, 2, {3, 3, 3}},
		{1, 4, 128, 2, 2, {4, 4, 3}}, // Only the output is unaligned.
		{1, 4, 128, 3, 3, {4, 4, 4}},
		{1, 2, 256, 2, 1, {4, 4, 4}}, // Same total length, different row-length specialization.
		{1, 128, 5376, 3, 2, {4, 4, 4}}, // Larger dispatch without bounds checks.
	};
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const int formats[] = { CCV_TENSOR_FORMAT_NHWC, CCV_TENSOR_FORMAT_NCHW };
	const ccv_nnc_cmd_t cmds[] = { CMD_MUL_FORWARD(1), CMD_ADD_FORWARD(1, 1), CMD_ADD_FORWARD(-1, 1), CMD_ADD_FORWARD(1, -1), CMD_ADD_FORWARD(-1, -1) };
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 17);
	int f, d, s, i, j, op, reverse, dynamic, inplace;
	for (f = 0; f < 2; f++)
		for (d = 0; d < 3; d++)
			for (s = 0; s < sizeof(shapes) / sizeof(shapes[0]); s++)
			{
				const int m = shapes[s].m, h = shapes[s].h, width = shapes[s].width;
				ccv_nnc_tensor_param_t params[] = { CPU_TENSOR_NHWC(32F, m, h, width), CPU_TENSOR_NHWC(32F, 1, 1, width), CPU_TENSOR_NHWC(32F, m, h, width) };
				if (shapes[s].a_nd == 2)
					params[0] = params[2] = CPU_TENSOR_NHWC(32F, m * h, width);
				else if (shapes[s].a_nd == 4)
					params[0] = params[2] = CPU_TENSOR_NHWC(32F, 1, m, h, width);
				if (shapes[s].b_nd == 1)
					params[1] = CPU_TENSOR_NHWC(32F, width);
				else if (shapes[s].b_nd == 2)
					params[1] = CPU_TENSOR_NHWC(32F, 1, width);
				ccv_nnc_tensor_t* cpu[3];
				ccv_nnc_tensor_t* host[3];
				ccv_nnc_tensor_t* storage[3];
				ccv_nnc_tensor_view_t* gpu[3];
				for (i = 0; i < 3; i++)
				{
					params[i].format = formats[f];
					cpu[i] = ccv_nnc_tensor_new(0, params[i], 0);
					const int count = ccv_nnc_tensor_count(params[i]);
					if (i < 2)
						for (j = 0; j < count; j++)
							cpu[i]->data.f32[j] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
					params[i].datatype = datatypes[d];
					host[i] = ccv_nnc_tensor_new(0, params[i], 0);
					params[i].type = CCV_TENSOR_GPU_MEMORY;
					ccv_nnc_tensor_param_t storage_params = params[i];
					memset(storage_params.dim, 0, sizeof(storage_params.dim));
					storage_params.dim[0] = count + 8;
					storage[i] = ccv_nnc_tensor_new(0, storage_params, 0);
					int stride[CCV_NNC_MAX_DIM_ALLOC];
					ccv_nnc_tensor_get_stride(params[i].dim, stride);
					int ofs[CCV_NNC_MAX_DIM_ALLOC] = {};
					ofs[ccv_nnc_tensor_nd(params[i].dim) - 1] = shapes[s].offsets[i];
					gpu[i] = ccv_nnc_tensor_view_new(storage[i], params[i], ofs, stride);
				}
				ccv_nnc_tensor_t* const result = ccv_nnc_tensor_new(0, cpu[2]->info, 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(cpu[0], cpu[1]), TENSOR_LIST(host[0], host[1]), 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[0], host[1]), TENSOR_LIST(cpu[0], cpu[1]), 0);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[0], host[1]), TENSOR_LIST((ccv_nnc_tensor_t*)gpu[0], (ccv_nnc_tensor_t*)gpu[1]), 0);
				for (op = 0; op < 5; op++)
					for (reverse = 0; reverse < 2; reverse++)
					{
						ccv_nnc_cmd_exec(cmds[op], ccv_nnc_no_hint, 0, TENSOR_LIST(cpu[reverse], cpu[1 - reverse]), TENSOR_LIST(cpu[2]), 0);
						for (dynamic = 0; dynamic < 2; dynamic++)
						{
							if (dynamic)
								ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
							else
								ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
							for (inplace = 0; inplace < 2; inplace++)
							{
								ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[0]), TENSOR_LIST((ccv_nnc_tensor_t*)gpu[0]), 0);
								ccv_nnc_tensor_view_t* const output = inplace ? gpu[0] : gpu[2];
								REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmds[op], ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)gpu[reverse], (ccv_nnc_tensor_t*)gpu[1 - reverse]), TENSOR_LIST((ccv_nnc_tensor_t*)output), 0), "row broadcast should execute");
								ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)output), TENSOR_LIST(host[2]), 0);
								ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[2]), TENSOR_LIST(result), 0);
								for (j = 0; j < m * h * width; j++)
									REQUIRE(isfinite(result->data.f32[j]), "row broadcast output should be finite at %d", j);
								REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, cpu[2]->data.f32, result->data.f32, m * h * width, d == 0 ? 1e-6 : (d == 1 ? 2e-3 : 2e-2), "row broadcast should match CPU for datatype %d shape %d op %d reverse %d dynamic %d inplace %d", datatypes[d], s, op, reverse, dynamic, inplace);
							}
						}
					}
				ccv_nnc_tensor_free(result);
				for (i = 0; i < 3; i++)
				{
					ccv_nnc_tensor_view_free(gpu[i]);
					ccv_nnc_tensor_free(storage[i]);
					ccv_nnc_tensor_free(host[i]);
					ccv_nnc_tensor_free(cpu[i]);
				}
			}
	if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("MFA row broadcast preserves overlapping, disjoint and strided views")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_MUL_FORWARD, CCV_NNC_BACKEND_MPS) && ccv_nnc_cmd_ok(CCV_NNC_ADD_FORWARD, CCV_NNC_BACKEND_MPS));
	const int rows = 129, width = 132, count = rows * width, storage_count = 4 * count + 16;
	const struct {
		int offsets[3];
		int factors[3];
	} layouts[] = {
		{{4, 3 * count + 4, 8}, {1, 1, 1}}, // Shifted full-input overlap.
		{{4, 2 * count + 4, 2 * count + 4}, {1, 1, 1}}, // Row-vector overlap.
		{{4, 3 * count + 4, count + 8}, {1, 1, 1}}, // Disjoint slices.
		{{4, 3 * count + 4, count + 8}, {2, 1, 1}}, // Padded rows in the full input.
		{{4, 3 * count + 4, count + 8}, {1, 1, 2}}, // Padded rows in the output.
		{{4, 3 * count + 4, count + 7}, {1, 1, 1}}, // Unaligned output with disjoint inputs.
		{{8, 3 * count + 4, 4}, {1, 1, 1}}, // Backwards full-input overlap.
		{{4, 2 * count + 8, count + 8}, {1, 1, 1}}, // Row vector starts exactly at output end.
		{{4, 2 * count + 4, count + 8}, {1, 1, 1}}, // Row vector overlaps the last four outputs.
	};
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const ccv_nnc_cmd_t cmds[] = { CMD_MUL_FORWARD(1), CMD_ADD_FORWARD(1, 1), CMD_ADD_FORWARD(1, -1), CMD_MUL_FORWARD(0.5), CMD_ADD_FORWARD(0.5, 2) };
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 42);
	int d, layout, op, reverse, i;
	for (d = 0; d < 3; d++)
	{
		ccv_nnc_tensor_t* const source = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, storage_count), 0);
		ccv_nnc_tensor_t* const result = ccv_nnc_tensor_new(0, source->info, 0);
		ccv_nnc_tensor_param_t params = source->info;
		params.datatype = datatypes[d];
		ccv_nnc_tensor_t* const host = ccv_nnc_tensor_new(0, params, 0);
		ccv_nnc_tensor_t* const downloaded = ccv_nnc_tensor_new(0, params, 0);
		params.type = CCV_TENSOR_GPU_MEMORY;
		ccv_nnc_tensor_t* const storage = ccv_nnc_tensor_new(0, params, 0);
		for (i = 0; i < storage_count; i++)
			source->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 2 - 1;
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(source), TENSOR_LIST(host), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host), TENSOR_LIST(source), 0);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, rows, width), 0);
		for (layout = 0; layout < sizeof(layouts) / sizeof(layouts[0]); layout++)
		{
			const int* const offsets = layouts[layout].offsets;
			const int* const factors = layouts[layout].factors;
			ccv_nnc_tensor_view_t* gpu[3];
			ccv_nnc_tensor_view_t* cpu[2];
			for (i = 0; i < 3; i++)
			{
				ccv_nnc_tensor_param_t view_params = i == 1 ? CPU_TENSOR_NHWC(32F, 1, width) : CPU_TENSOR_NHWC(32F, 1, rows, width);
				int stride[CCV_NNC_MAX_DIM_ALLOC];
				ccv_nnc_tensor_get_stride(view_params.dim, stride);
				stride[0] *= factors[i];
				stride[1] *= factors[i];
				int ofs[CCV_NNC_MAX_DIM_ALLOC] = {};
				ofs[ccv_nnc_tensor_nd(view_params.dim) - 1] = offsets[i];
				if (i < 2)
					cpu[i] = ccv_nnc_tensor_view_new(source, view_params, ofs, stride);
				view_params.datatype = datatypes[d];
				view_params.type = CCV_TENSOR_GPU_MEMORY;
				gpu[i] = ccv_nnc_tensor_view_new(storage, view_params, ofs, stride);
			}
			for (op = 0; op < 5; op++)
				for (reverse = 0; reverse < 2; reverse++)
				{
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host), TENSOR_LIST(storage), 0);
					ccv_nnc_cmd_exec(cmds[op], ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)cpu[reverse], (ccv_nnc_tensor_t*)cpu[1 - reverse]), TENSOR_LIST(expected), 0);
					REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmds[op], ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)gpu[reverse], (ccv_nnc_tensor_t*)gpu[1 - reverse]), TENSOR_LIST((ccv_nnc_tensor_t*)gpu[2]), 0), "broadcast view command should execute");
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(storage), TENSOR_LIST(downloaded), 0);
					ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(downloaded), TENSOR_LIST(result), 0);
					for (i = 0; i < storage_count; i++)
					{
						REQUIRE(isfinite(result->data.f32[i]), "broadcast storage should be finite at %d", i);
						const int index = i - offsets[2];
						if (index >= 0 && index < count * factors[2] && index % (width * factors[2]) < width)
						{
							REQUIRE_EQ_WITH_TOLERANCE(result->data.f32[i], expected->data.f32[index / (width * factors[2]) * width + index % width], d == 0 ? 1e-6 : (d == 1 ? 2e-3 : 2e-2), "view output should match CPU for datatype %d layout %d op %d reverse %d", datatypes[d], layout, op, reverse);
						} else {
							REQUIRE_EQ(result->data.f32[i], source->data.f32[i], "broadcast must preserve storage outside its output");
						}
					}
				}
			for (i = 0; i < 3; i++)
				ccv_nnc_tensor_view_free(gpu[i]);
			for (i = 0; i < 2; i++)
				ccv_nnc_tensor_view_free(cpu[i]);
		}
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(storage);
		ccv_nnc_tensor_free(downloaded);
		ccv_nnc_tensor_free(host);
		ccv_nnc_tensor_free(result);
		ccv_nnc_tensor_free(source);
	}
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("MFA channel broadcast add and multiply match CPU with specialized and dynamic lengths")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_MUL_FORWARD, CCV_NNC_BACKEND_MPS) && ccv_nnc_cmd_ok(CCV_NNC_ADD_FORWARD, CCV_NNC_BACKEND_MPS));
	const int shapes[][3] = { {17, 4, 128}, {257, 4, 128}, {4, 4, 128}, {129, 4, 513}, {4, 3, 127}, {1, 4, 768}, {37, 1, 257} };
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const int formats[] = { CCV_TENSOR_FORMAT_NHWC, CCV_TENSOR_FORMAT_NCHW };
	const ccv_nnc_cmd_t cmds[] = { CMD_MUL_FORWARD(1), CMD_ADD_FORWARD(1, 1), CMD_ADD_FORWARD(-1, 1) };
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 17);
	int f, d, s, i, j, op, reverse, dynamic;
	for (f = 0; f < 2; f++)
		for (d = 0; d < 3; d++)
			for (s = 0; s < 7; s++)
			{
				const int m = shapes[s][0], h = shapes[s][1], width = shapes[s][2];
				ccv_nnc_tensor_param_t params[] = { CPU_TENSOR_NHWC(32F, m, 1, width), CPU_TENSOR_NHWC(32F, 1, h, 1), CPU_TENSOR_NHWC(32F, m, h, width) };
				ccv_nnc_tensor_t* cpu[3];
				ccv_nnc_tensor_t* host[3];
				ccv_nnc_tensor_t* storage[3];
				ccv_nnc_tensor_view_t* gpu[3];
				for (i = 0; i < 3; i++)
				{
					params[i].format = formats[f];
					cpu[i] = ccv_nnc_tensor_new(0, params[i], 0);
					const int count = ccv_nnc_tensor_count(params[i]);
					if (i < 2)
						for (j = 0; j < count; j++)
							cpu[i]->data.f32[j] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
					params[i].datatype = datatypes[d];
					host[i] = ccv_nnc_tensor_new(0, params[i], 0);
					params[i].type = CCV_TENSOR_GPU_MEMORY;
					ccv_nnc_tensor_param_t storage_params = params[i];
					memset(storage_params.dim, 0, sizeof(storage_params.dim));
					storage_params.dim[0] = count + 8;
					storage[i] = ccv_nnc_tensor_new(0, storage_params, 0);
					int stride[CCV_NNC_MAX_DIM_ALLOC];
					ccv_nnc_tensor_get_stride(params[i].dim, stride);
					gpu[i] = ccv_nnc_tensor_view_new(storage[i], params[i], DIM_ALLOC(0, 0, 4), stride);
				}
				ccv_nnc_tensor_t* const result = ccv_nnc_tensor_new(0, cpu[2]->info, 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(cpu[0], cpu[1]), TENSOR_LIST(host[0], host[1]), 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[0], host[1]), TENSOR_LIST(cpu[0], cpu[1]), 0);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[0], host[1]), TENSOR_LIST(gpu[0], gpu[1]), 0);
				for (op = 0; op < 3; op++)
					for (reverse = 0; reverse < 2; reverse++)
					{
						ccv_nnc_cmd_exec(cmds[op], ccv_nnc_no_hint, 0, TENSOR_LIST(cpu[reverse], cpu[1 - reverse]), TENSOR_LIST(cpu[2]), 0);
						for (dynamic = 0; dynamic < 2; dynamic++)
						{
							if (dynamic)
								ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
							else
								ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
							REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmds[op], ccv_nnc_no_hint, 0, TENSOR_LIST(gpu[reverse], gpu[1 - reverse]), TENSOR_LIST(gpu[2]), 0), "channel broadcast should execute");
							ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu[2]), TENSOR_LIST(host[2]), 0);
							ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(host[2]), TENSOR_LIST(result), 0);
							REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, cpu[2]->data.f32, result->data.f32, m * h * width, d == 0 ? 1e-6 : (d == 1 ? 2e-3 : 2e-2), "channel broadcast should match CPU for datatype %d shape %d op %d reverse %d dynamic %d", datatypes[d], s, op, reverse, dynamic);
						}
					}
				ccv_nnc_tensor_free(result);
				for (i = 0; i < 3; i++)
				{
					ccv_nnc_tensor_view_free(gpu[i]);
					ccv_nnc_tensor_free(storage[i]);
					ccv_nnc_tensor_free(host[i]);
					ccv_nnc_tensor_free(cpu[i]);
				}
			}
	if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("MFA elementwise multiply matches CPU across dynamic lengths and dispatch variants")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_MUL_FORWARD, CCV_NNC_BACKEND_MPS));
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const int lengths[] = { 384 * 128 * 8, 1024 * 128 * 8, 1028, 1025, 1 };
	const int formats[] = { CCV_TENSOR_FORMAT_NHWC, CCV_TENSOR_FORMAT_NCHW };
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int f, d, l, dynamic, i;
	for (f = 0; f < 2; f++)
		for (d = 0; d < 3; d++)
			for (l = 0; l < 5; l++)
			{
				const int length = lengths[l];
				ccv_nnc_tensor_param_t params = CPU_TENSOR_NHWC(32F, length);
				params.format = formats[f];
				if (l < 2)
				{
					params.dim[0] = length / (128 * 8);
					params.dim[1] = 128;
					params.dim[2] = 8;
				}
				ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, params, 0);
				ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, params, 0);
				ccv_nnc_tensor_t* const reference = ccv_nnc_tensor_new(0, params, 0);
				ccv_nnc_tensor_t* const result = ccv_nnc_tensor_new(0, params, 0);
				for (i = 0; i < length; i++)
				{
					a->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
					b->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
				}
				params.datatype = datatypes[d];
				ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, params, 0);
				ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, params, 0);
				ccv_nnc_tensor_t* const hc = ccv_nnc_tensor_new(0, params, 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(ha, hb), 0);
				ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hb), TENSOR_LIST(a, b), 0);
				ccv_nnc_cmd_exec(CMD_MUL_FORWARD(1), ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(reference), 0);
				params.type = CCV_TENSOR_GPU_MEMORY;
				ccv_nnc_tensor_param_t storage_params = params;
				memset(storage_params.dim, 0, sizeof(storage_params.dim));
				storage_params.dim[0] = length + 8;
				ccv_nnc_tensor_t* const ga_storage = ccv_nnc_tensor_new(0, storage_params, 0);
				ccv_nnc_tensor_t* const gb_storage = ccv_nnc_tensor_new(0, storage_params, 0);
				ccv_nnc_tensor_t* const gc_storage = ccv_nnc_tensor_new(0, storage_params, 0);
				int stride[CCV_NNC_MAX_DIM_ALLOC];
				int ofs[CCV_NNC_MAX_DIM_ALLOC] = {};
				ofs[ccv_nnc_tensor_nd(params.dim) - 1] = 4;
				ccv_nnc_tensor_get_stride(params.dim, stride);
				ccv_nnc_tensor_view_t* const ga = ccv_nnc_tensor_view_new(ga_storage, params, ofs, stride);
				ccv_nnc_tensor_view_t* const gb = ccv_nnc_tensor_view_new(gb_storage, params, ofs, stride);
				ccv_nnc_tensor_view_t* const gc = ccv_nnc_tensor_view_new(gc_storage, params, ofs, stride);
				ccv_nnc_tensor_view_t* const output = l % 3 == 0 ? gc : (l % 3 == 1 ? ga : gb);
				for (dynamic = 0; dynamic < 2; dynamic++)
				{
					if (dynamic)
						ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
					else
						ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hb), TENSOR_LIST(ga, gb), 0);
					REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_MUL_FORWARD(1), ccv_nnc_no_hint, 0, TENSOR_LIST(ga, gb), TENSOR_LIST(output), 0), "MFA multiply should execute");
					ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(output), TENSOR_LIST(hc), 0);
					ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hc), TENSOR_LIST(result), 0);
					REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, reference->data.f32, result->data.f32, length, d == 0 ? 1e-6 : (d == 1 ? 2e-3 : 2e-2), "MFA multiply should match CPU for datatype %d length %d dynamic %d", datatypes[d], length, dynamic);
				}
				ccv_nnc_tensor_view_free(ga);
				ccv_nnc_tensor_view_free(gb);
				ccv_nnc_tensor_view_free(gc);
				ccv_nnc_tensor_free(ga_storage);
				ccv_nnc_tensor_free(gb_storage);
				ccv_nnc_tensor_free(gc_storage);
				ccv_nnc_tensor_free(a);
				ccv_nnc_tensor_free(b);
				ccv_nnc_tensor_free(reference);
				ccv_nnc_tensor_free(result);
				ccv_nnc_tensor_free(ha);
				ccv_nnc_tensor_free(hb);
				ccv_nnc_tensor_free(hc);
			}
	if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("MPS scalar multiply accepts zero-sized tensors without storage")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALAR_MUL_FORWARD, CCV_NNC_BACKEND_MPS));
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF, CCV_32S };
	const int formats[] = { CCV_TENSOR_FORMAT_NHWC, CCV_TENSOR_FORMAT_NCHW, CCV_TENSOR_FORMAT_CHWN };
	const float scales[] = { 1, 0.5, 1.f / 0.7f };
	int d, f, s;
	for (d = 0; d < 4; d++)
		for (f = 0; f < 3; f++)
			for (s = 0; s < 3; s++)
			{
				ccv_nnc_cmd_t cmd = CMD_SCALAR_MUL_FORWARD(scales[s]);
				cmd.backend = CCV_NNC_BACKEND_MPS;
				ccv_nnc_tensor_param_t params = GPU_TENSOR_NHWC(000, 32F, 0);
				params.datatype = datatypes[d];
				params.format = formats[f];
				// Empty activations have no Metal buffer, including when used in-place.
				ccv_nnc_tensor_t input = { .info = params };
				ccv_nnc_tensor_t output = { .info = params };
				REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(&input), TENSOR_LIST(&output), 0), "empty scalar multiply must not access storage");
				REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(&input), TENSOR_LIST(&input), 0), "empty in-place scalar multiply must not access storage");
			}
}

TEST_CASE("MFA scalar multiply matches MPSGraph across data types and dispatch variants")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALAR_MUL_FORWARD, CCV_NNC_BACKEND_MPS));
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const int lengths[] = { 1024, 1020, 1019 };
	const float scales[] = { 1, -1, 1.f / 0.7f };
	float values[1024];
	int i;
	for (i = 0; i < 1024; i++)
		values[i] = (float)((i * 37 + 11) % 4093) / 128 - 16;
	const uint64_t old_flags = ccv_nnc_flags();
	int d, l;
	for (d = 0; d < 3; d++)
		for (l = 0; l < 3; l++)
		{
			const int datatype = datatypes[d];
			const int length = lengths[l];
			ccv_nnc_cmd_t cmd = CMD_SCALAR_MUL_FORWARD(scales[l]);
			cmd.backend = CCV_NNC_BACKEND_MPS;
			ccv_nnc_tensor_param_t cpu_params = CPU_TENSOR_NHWC(32F, length);
			cpu_params.datatype = datatype;
			ccv_nnc_tensor_param_t gpu_params = GPU_TENSOR_NHWC(000, 32F, length);
			gpu_params.datatype = datatype;
			ccv_nnc_tensor_t* const hinput = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hgraph = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hmfa = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const graph = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const mfa = ccv_nnc_tensor_new(0, gpu_params, 0);
			if (datatype == CCV_32F)
				memcpy(hinput->data.f32, values, sizeof(float) * length);
			else if (datatype == CCV_16F)
				ccv_float_to_half_precision(values, (uint16_t*)hinput->data.f16, length);
			else
				ccv_float_to_bfloat(values, (uint16_t*)hinput->data.f16, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hinput), TENSOR_LIST(input), 0), "datatype %d input should transfer to Metal", datatype);
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(graph), 0), "MPSGraph scalar multiply should execute for datatype %d length %d", datatype, length);
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
			if (l == 2)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			else
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(mfa), 0), "MFA scalar multiply should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(graph, mfa), TENSOR_LIST(hgraph, hmfa), 0), "scalar multiply results should transfer to CPU");
			if (datatype == CCV_32F) {
				REQUIRE_ARRAY_EQ(float, hgraph->data.f32, hmfa->data.f32, length, "MFA float scalar multiply should exactly match MPSGraph");
			} else {
				REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph->data.f16, (uint16_t*)hmfa->data.f16, length, "MFA 16-bit scalar multiply should exactly match MPSGraph for datatype %d", datatype);
			}
			ccv_nnc_tensor_free(mfa);
			ccv_nnc_tensor_free(graph);
			ccv_nnc_tensor_free(input);
			ccv_nnc_tensor_free(hmfa);
			ccv_nnc_tensor_free(hgraph);
			ccv_nnc_tensor_free(hinput);
		}
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("MFA subtraction and scalar broadcast match MPSGraph across data types and dispatch variants")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_ADD_FORWARD, CCV_NNC_BACKEND_MPS));
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const int lengths[] = { 1024, 1020, 1019 };
	float values[1024];
	float other_values[1024];
	int i;
	for (i = 0; i < 1024; i++)
	{
		values[i] = (float)((i * 41 + 13) % 4093) / 128 - 16;
		other_values[i] = (float)((i * 67 + 29) % 2039) / 256 - 4;
	}
	const float scalar_value = 2.25f;
	ccv_nnc_cmd_t subtract_cmd = CMD_ADD_FORWARD(1, -1);
	subtract_cmd.backend = CCV_NNC_BACKEND_MPS;
	ccv_nnc_cmd_t negative_first_cmd = CMD_ADD_FORWARD(-1, 1);
	negative_first_cmd.backend = CCV_NNC_BACKEND_MPS;
	const uint64_t old_flags = ccv_nnc_flags();
	int d, l;
	for (d = 0; d < 3; d++)
		for (l = 0; l < 3; l++)
		{
			const int datatype = datatypes[d];
			const int length = lengths[l];
			ccv_nnc_tensor_param_t cpu_params = CPU_TENSOR_NHWC(32F, length);
			cpu_params.datatype = datatype;
			ccv_nnc_tensor_param_t gpu_params = GPU_TENSOR_NHWC(000, 32F, length);
			gpu_params.datatype = datatype;
			ccv_nnc_tensor_param_t cpu_scalar_params = CPU_TENSOR_NHWC(32F, 1, 1);
			cpu_scalar_params.datatype = datatype;
			ccv_nnc_tensor_param_t gpu_scalar_params = GPU_TENSOR_NHWC(000, 32F, 1, 1);
			gpu_scalar_params.datatype = datatype;
			ccv_nnc_tensor_t* const hinput = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hother = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hscalar = ccv_nnc_tensor_new(0, cpu_scalar_params, 0);
			ccv_nnc_tensor_t* const hgraph_broadcast = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hmfa_broadcast = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hgraph_negative = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hmfa_negative = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const other = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const scalar = ccv_nnc_tensor_new(0, gpu_scalar_params, 0);
			ccv_nnc_tensor_t* const graph_broadcast = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const mfa_broadcast = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const graph_negative = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const mfa_negative = ccv_nnc_tensor_new(0, gpu_params, 0);
			if (datatype == CCV_32F)
			{
				memcpy(hinput->data.f32, values, sizeof(float) * length);
				memcpy(hother->data.f32, other_values, sizeof(float) * length);
				hscalar->data.f32[0] = scalar_value;
			} else if (datatype == CCV_16F) {
				ccv_float_to_half_precision(values, (uint16_t*)hinput->data.f16, length);
				ccv_float_to_half_precision(other_values, (uint16_t*)hother->data.f16, length);
				ccv_float_to_half_precision(&scalar_value, (uint16_t*)hscalar->data.f16, 1);
			} else {
				ccv_float_to_bfloat(values, (uint16_t*)hinput->data.f16, length);
				ccv_float_to_bfloat(other_values, (uint16_t*)hother->data.f16, length);
				ccv_float_to_bfloat(&scalar_value, (uint16_t*)hscalar->data.f16, 1);
			}
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hinput, hother, hscalar), TENSOR_LIST(input, other, scalar), 0), "datatype %d subtraction inputs should transfer to Metal", datatype);
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(subtract_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input, scalar), TENSOR_LIST(graph_broadcast), 0), "MPSGraph scalar broadcast subtraction should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(negative_first_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input, other), TENSOR_LIST(graph_negative), 0), "MPSGraph negative-first subtraction should execute for datatype %d length %d", datatype, length);
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
			if (l == 2)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			else
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(subtract_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input, scalar), TENSOR_LIST(mfa_broadcast), 0), "MFA scalar broadcast subtraction should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(negative_first_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input, other), TENSOR_LIST(mfa_negative), 0), "MFA negative-first subtraction should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(graph_broadcast, mfa_broadcast, graph_negative, mfa_negative), TENSOR_LIST(hgraph_broadcast, hmfa_broadcast, hgraph_negative, hmfa_negative), 0), "subtraction results should transfer to CPU");
			if (datatype == CCV_32F)
			{
				REQUIRE_ARRAY_EQ(float, hgraph_broadcast->data.f32, hmfa_broadcast->data.f32, length, "MFA float scalar broadcast subtraction should exactly match MPSGraph");
				REQUIRE_ARRAY_EQ(float, hgraph_negative->data.f32, hmfa_negative->data.f32, length, "MFA float negative-first subtraction should exactly match MPSGraph");
			} else {
				REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_broadcast->data.f16, (uint16_t*)hmfa_broadcast->data.f16, length, "MFA 16-bit scalar broadcast subtraction should exactly match MPSGraph for datatype %d", datatype);
				REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_negative->data.f16, (uint16_t*)hmfa_negative->data.f16, length, "MFA 16-bit negative-first subtraction should exactly match MPSGraph for datatype %d", datatype);
			}
			ccv_nnc_tensor_free(mfa_negative);
			ccv_nnc_tensor_free(graph_negative);
			ccv_nnc_tensor_free(mfa_broadcast);
			ccv_nnc_tensor_free(graph_broadcast);
			ccv_nnc_tensor_free(scalar);
			ccv_nnc_tensor_free(other);
			ccv_nnc_tensor_free(input);
			ccv_nnc_tensor_free(hmfa_negative);
			ccv_nnc_tensor_free(hgraph_negative);
			ccv_nnc_tensor_free(hmfa_broadcast);
			ccv_nnc_tensor_free(hgraph_broadcast);
			ccv_nnc_tensor_free(hscalar);
			ccv_nnc_tensor_free(hother);
			ccv_nnc_tensor_free(hinput);
		}
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("Qwen vocabulary half precision MFA arithmetic matches MPSGraph")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_ADD_FORWARD, CCV_NNC_BACKEND_MPS));
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALAR_MUL_FORWARD, CCV_NNC_BACKEND_MPS));
	const int length = 248320;
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hs = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1), 0);
	float* const values = (float*)ccmalloc(sizeof(float) * length);
	float* const other_values = (float*)ccmalloc(sizeof(float) * length);
	int i;
	for (i = 0; i < length; i++)
	{
		values[i] = (float)((i * 37) % 4093) / 128 - 16;
		other_values[i] = (float)((i * 73 + 19) % 2039) / 256 - 4;
	}
	ccv_float_to_half_precision(values, (uint16_t*)ha->data.f16, length);
	ccv_float_to_half_precision(other_values, (uint16_t*)hb->data.f16, length);
	const float scalar = 2.25f;
	ccv_float_to_half_precision(&scalar, (uint16_t*)hs->data.f16, 1);
	ccfree(values);
	ccfree(other_values);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const s = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1), 0);
	ccv_nnc_tensor_t* const graph_scale = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const mfa_scale = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const graph_broadcast = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const mfa_broadcast = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const graph_subtract = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const mfa_subtract = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hb, hs), TENSOR_LIST(a, b, s), 0);
	ccv_nnc_cmd_t scale_cmd = CMD_SCALAR_MUL_FORWARD(1.f / 0.7f);
	scale_cmd.backend = CCV_NNC_BACKEND_MPS;
	ccv_nnc_cmd_t subtract_cmd = CMD_ADD_FORWARD(1, -1);
	subtract_cmd.backend = CCV_NNC_BACKEND_MPS;
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(scale_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(graph_scale), 0), "MPSGraph scalar multiply should execute");
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(subtract_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, s), TENSOR_LIST(graph_broadcast), 0), "MPSGraph broadcast subtraction should execute");
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(subtract_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(graph_subtract), 0), "MPSGraph subtraction should execute");
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(scale_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(mfa_scale), 0), "MFA scalar multiply should execute");
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(subtract_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, s), TENSOR_LIST(mfa_broadcast), 0), "MFA broadcast subtraction should execute");
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(subtract_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(a, b), TENSOR_LIST(mfa_subtract), 0), "MFA subtraction should execute");
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_tensor_t* const hgraph_scale = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hmfa_scale = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hgraph_broadcast = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hmfa_broadcast = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hgraph_subtract = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hmfa_subtract = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0,
		TENSOR_LIST(graph_scale, mfa_scale, graph_broadcast, mfa_broadcast, graph_subtract, mfa_subtract),
		TENSOR_LIST(hgraph_scale, hmfa_scale, hgraph_broadcast, hmfa_broadcast, hgraph_subtract, hmfa_subtract), 0);
	REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_scale->data.f16, (uint16_t*)hmfa_scale->data.f16, length, "MFA scalar multiply should exactly match MPSGraph");
	REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_broadcast->data.f16, (uint16_t*)hmfa_broadcast->data.f16, length, "MFA scalar broadcast subtraction should exactly match MPSGraph");
	REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_subtract->data.f16, (uint16_t*)hmfa_subtract->data.f16, length, "MFA subtraction should exactly match MPSGraph");
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hs);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(s);
	ccv_nnc_tensor_free(graph_scale);
	ccv_nnc_tensor_free(mfa_scale);
	ccv_nnc_tensor_free(graph_broadcast);
	ccv_nnc_tensor_free(mfa_broadcast);
	ccv_nnc_tensor_free(graph_subtract);
	ccv_nnc_tensor_free(mfa_subtract);
	ccv_nnc_tensor_free(hgraph_scale);
	ccv_nnc_tensor_free(hmfa_scale);
	ccv_nnc_tensor_free(hgraph_broadcast);
	ccv_nnc_tensor_free(hmfa_broadcast);
	ccv_nnc_tensor_free(hgraph_subtract);
	ccv_nnc_tensor_free(hmfa_subtract);
}

TEST_CASE("MFA half precision log and clamp match MPSGraph across dispatch variants")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWLOG_FORWARD, CCV_NNC_BACKEND_MPS));
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_CLAMP_FORWARD, CCV_NNC_BACKEND_MPS));
	const int lengths[] = { 1024, 1020, 1019 };
	float values[1024];
	int i;
	for (i = 0; i < 1024; i++)
		values[i] = (float)((i * 43 + 7) % 2000 + 1) / 200;
	values[0] = 0;
	values[1] = INFINITY;
	values[2] = NAN;
	ccv_nnc_cmd_t log_cmd = CMD_EWLOG_FORWARD();
	log_cmd.backend = CCV_NNC_BACKEND_MPS;
	ccv_nnc_cmd_t clamp_cmd = CMD_CLAMP_FORWARD(0.137f, 4.731f);
	clamp_cmd.backend = CCV_NNC_BACKEND_MPS;
	const uint64_t old_flags = ccv_nnc_flags();
	int l;
	for (l = 0; l < 3; l++)
	{
		const int length = lengths[l];
		ccv_nnc_tensor_t* const hinput = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, length), 0);
		ccv_nnc_tensor_t* const hgraph_log = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, length), 0);
		ccv_nnc_tensor_t* const hmfa_log = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, length), 0);
		ccv_nnc_tensor_t* const hgraph_clamp = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, length), 0);
		ccv_nnc_tensor_t* const hmfa_clamp = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, length), 0);
		ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, length), 0);
		ccv_nnc_tensor_t* const graph_log = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, length), 0);
		ccv_nnc_tensor_t* const mfa_log = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, length), 0);
		ccv_nnc_tensor_t* const graph_clamp = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, length), 0);
		ccv_nnc_tensor_t* const mfa_clamp = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, length), 0);
		ccv_float_to_half_precision(values, (uint16_t*)hinput->data.f16, length);
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hinput), TENSOR_LIST(input), 0), "half input should transfer to Metal");
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(log_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(graph_log), 0), "MPSGraph log should execute for length %d", length);
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(clamp_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(graph_clamp), 0), "MPSGraph clamp should execute for length %d", length);
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
		if (l == 2)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(log_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(mfa_log), 0), "MFA log should execute for length %d", length);
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(clamp_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(mfa_clamp), 0), "MFA clamp should execute for length %d", length);
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(graph_log, mfa_log, graph_clamp, mfa_clamp), TENSOR_LIST(hgraph_log, hmfa_log, hgraph_clamp, hmfa_clamp), 0), "unary results should transfer to CPU");
		REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_log->data.f16, (uint16_t*)hmfa_log->data.f16, length, "MFA half log should exactly match MPSGraph");
		REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_clamp->data.f16, (uint16_t*)hmfa_clamp->data.f16, length, "MFA half clamp should exactly match MPSGraph");
		ccv_nnc_tensor_free(mfa_clamp);
		ccv_nnc_tensor_free(graph_clamp);
		ccv_nnc_tensor_free(mfa_log);
		ccv_nnc_tensor_free(graph_log);
		ccv_nnc_tensor_free(input);
		ccv_nnc_tensor_free(hmfa_clamp);
		ccv_nnc_tensor_free(hgraph_clamp);
		ccv_nnc_tensor_free(hmfa_log);
		ccv_nnc_tensor_free(hgraph_log);
		ccv_nnc_tensor_free(hinput);
	}
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("Qwen vocabulary half precision MFA unary operations match MPSGraph")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWEXP_FORWARD, CCV_NNC_BACKEND_MPS));
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_EWLOG_FORWARD, CCV_NNC_BACKEND_MPS));
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_CLAMP_FORWARD, CCV_NNC_BACKEND_MPS));
	const int length = 248320;
	ccv_nnc_tensor_t* const hinput = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hpositive = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	float* const values = (float*)ccmalloc(sizeof(float) * length);
	float* const positive_values = (float*)ccmalloc(sizeof(float) * length);
	int i;
	for (i = 0; i < length; i++)
	{
		values[i] = (float)((i * 29) % 2001) / 200 - 5;
		positive_values[i] = (float)((i * 43) % 2000 + 1) / 200;
	}
	values[0] = -INFINITY;
	values[1] = INFINITY;
	values[2] = -0.f;
	values[3] = NAN;
	positive_values[0] = 0;
	positive_values[1] = INFINITY;
	positive_values[2] = NAN;
	ccv_float_to_half_precision(values, (uint16_t*)hinput->data.f16, length);
	ccv_float_to_half_precision(positive_values, (uint16_t*)hpositive->data.f16, length);
	ccfree(values);
	ccfree(positive_values);
	ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const positive = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const inplace_clamp = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const graph_exp = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const mfa_exp = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const graph_log = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const mfa_log = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_tensor_t* const graph_clamp = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hinput, hpositive, hinput), TENSOR_LIST(input, positive, inplace_clamp), 0);
	ccv_nnc_cmd_t exp_cmd = CMD_EWEXP_FORWARD();
	exp_cmd.backend = CCV_NNC_BACKEND_MPS;
	ccv_nnc_cmd_t log_cmd = CMD_EWLOG_FORWARD();
	log_cmd.backend = CCV_NNC_BACKEND_MPS;
	ccv_nnc_cmd_t clamp_cmd = CMD_CLAMP_FORWARD(0, NAN);
	clamp_cmd.backend = CCV_NNC_BACKEND_MPS;
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_cmd_exec(exp_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(graph_exp), 0);
	ccv_nnc_cmd_exec(log_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(positive), TENSOR_LIST(graph_log), 0);
	ccv_nnc_cmd_exec(clamp_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(graph_clamp), 0);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_cmd_exec(exp_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input), TENSOR_LIST(mfa_exp), 0);
	ccv_nnc_cmd_exec(log_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(positive), TENSOR_LIST(mfa_log), 0);
	ccv_nnc_cmd_exec(clamp_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(inplace_clamp), TENSOR_LIST(inplace_clamp), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_tensor_t* const hgraph_exp = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hmfa_exp = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hgraph_log = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hmfa_log = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hgraph_clamp = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_tensor_t* const hmfa_clamp = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0,
		TENSOR_LIST(graph_exp, mfa_exp, graph_log, mfa_log, graph_clamp, inplace_clamp),
		TENSOR_LIST(hgraph_exp, hmfa_exp, hgraph_log, hmfa_log, hgraph_clamp, hmfa_clamp), 0);
	REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_exp->data.f16, (uint16_t*)hmfa_exp->data.f16, length, "MFA exp should exactly match MPSGraph");
	REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_log->data.f16, (uint16_t*)hmfa_log->data.f16, length, "MFA log should exactly match MPSGraph");
	REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hgraph_clamp->data.f16, (uint16_t*)hmfa_clamp->data.f16, length, "in-place MFA clamp should exactly match MPSGraph");
	ccv_nnc_tensor_free(hinput);
	ccv_nnc_tensor_free(hpositive);
	ccv_nnc_tensor_free(input);
	ccv_nnc_tensor_free(positive);
	ccv_nnc_tensor_free(inplace_clamp);
	ccv_nnc_tensor_free(graph_exp);
	ccv_nnc_tensor_free(mfa_exp);
	ccv_nnc_tensor_free(graph_log);
	ccv_nnc_tensor_free(mfa_log);
	ccv_nnc_tensor_free(graph_clamp);
	ccv_nnc_tensor_free(hgraph_exp);
	ccv_nnc_tensor_free(hmfa_exp);
	ccv_nnc_tensor_free(hgraph_log);
	ccv_nnc_tensor_free(hmfa_log);
	ccv_nnc_tensor_free(hgraph_clamp);
	ccv_nnc_tensor_free(hmfa_clamp);
}

TEST_CASE("fill if less than MFA supports a rank-two threshold forward, backward, and in-place")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_FILL_IF_LESS_THAN_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	const int datatypes[] = { CCV_32F, CCV_16F, CCV_16BF };
	const int lengths[] = { 1024, 1020, 1019 };
	float input_values[1024];
	float selector_values[1024];
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 2);
	int i;
	for (i = 0; i < 1024; i++)
	{
		input_values[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 5;
		selector_values[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
	}
	const float threshold_value = 0.375;
	selector_values[0] = threshold_value;
	int d, l;
	for (d = 0; d < 3; d++)
		for (l = 0; l < 3; l++)
		{
			const int datatype = datatypes[d];
			const int length = lengths[l];
			ccv_nnc_tensor_param_t cpu_params = CPU_TENSOR_NHWC(32F, length);
			cpu_params.datatype = datatype;
			ccv_nnc_tensor_param_t gpu_params = GPU_TENSOR_NHWC(000, 32F, length);
			gpu_params.datatype = datatype;
			ccv_nnc_tensor_param_t cpu_threshold_params = CPU_TENSOR_NHWC(32F, 1, 1);
			cpu_threshold_params.datatype = datatype;
			ccv_nnc_tensor_param_t gpu_threshold_params = GPU_TENSOR_NHWC(000, 32F, 1, 1);
			gpu_threshold_params.datatype = datatype;
			ccv_nnc_tensor_t* const hinput = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hselector = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hthreshold = ccv_nnc_tensor_new(0, cpu_threshold_params, 0);
			ccv_nnc_tensor_t* const hexpected_forw = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hexpected_back = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hactual_forw = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hactual_inplace = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const hactual_back = ccv_nnc_tensor_new(0, cpu_params, 0);
			ccv_nnc_tensor_t* const input = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const inplace = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const selector = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const threshold = ccv_nnc_tensor_new(0, gpu_threshold_params, 0);
			ccv_nnc_tensor_t* const output = ccv_nnc_tensor_new(0, gpu_params, 0);
			ccv_nnc_tensor_t* const back = ccv_nnc_tensor_new(0, gpu_params, 0);
			if (datatype == CCV_32F)
			{
				memcpy(hinput->data.f32, input_values, sizeof(float) * length);
				memcpy(hselector->data.f32, selector_values, sizeof(float) * length);
				hthreshold->data.f32[0] = threshold_value;
			} else if (datatype == CCV_16F) {
				ccv_float_to_half_precision(input_values, (uint16_t*)hinput->data.f16, length);
				ccv_float_to_half_precision(selector_values, (uint16_t*)hselector->data.f16, length);
				ccv_float_to_half_precision(&threshold_value, (uint16_t*)hthreshold->data.f16, 1);
			} else {
				ccv_float_to_bfloat(input_values, (uint16_t*)hinput->data.f16, length);
				ccv_float_to_bfloat(selector_values, (uint16_t*)hselector->data.f16, length);
				ccv_float_to_bfloat(&threshold_value, (uint16_t*)hthreshold->data.f16, 1);
			}
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hinput, hinput, hselector, hthreshold), TENSOR_LIST(input, inplace, selector, threshold), 0), "datatype %d inputs should transfer to Metal", datatype);
			ccv_nnc_cmd_t forw = CMD_FILL_IF_LESS_THAN_FORWARD(-INFINITY);
			forw.backend = CCV_NNC_BACKEND_MPS;
			ccv_nnc_cmd_t back_cmd = CMD_FILL_IF_LESS_THAN_BACKWARD(-INFINITY);
			back_cmd.backend = CCV_NNC_BACKEND_MPS;
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(forw, ccv_nnc_no_hint, 0, TENSOR_LIST(input, selector, threshold), TENSOR_LIST(output), 0), "MPSGraph forward should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(back_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input, 0, selector, threshold), TENSOR_LIST(back), 0), "MPSGraph backward should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(output, back), TENSOR_LIST(hexpected_forw, hexpected_back), 0), "MPSGraph results should transfer to CPU");
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
			if (l == 2)
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			else
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(forw, ccv_nnc_no_hint, 0, TENSOR_LIST(input, selector, threshold), TENSOR_LIST(output), 0), "MFA forward should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(forw, ccv_nnc_no_hint, 0, TENSOR_LIST(inplace, selector, threshold), TENSOR_LIST(inplace), 0), "MFA in-place forward should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(back_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(input, 0, selector, threshold), TENSOR_LIST(back), 0), "MFA backward should execute for datatype %d length %d", datatype, length);
			REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(output, inplace, back), TENSOR_LIST(hactual_forw, hactual_inplace, hactual_back), 0), "MFA results should transfer to CPU");
			if (datatype == CCV_32F)
			{
				REQUIRE_ARRAY_EQ(float, hexpected_forw->data.f32, hactual_forw->data.f32, length, "MFA float forward should match MPSGraph");
				REQUIRE_ARRAY_EQ(float, hexpected_forw->data.f32, hactual_inplace->data.f32, length, "in-place MFA float forward should match MPSGraph");
				REQUIRE_ARRAY_EQ(float, hexpected_back->data.f32, hactual_back->data.f32, length, "MFA float backward should match MPSGraph");
			} else {
				REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hexpected_forw->data.f16, (uint16_t*)hactual_forw->data.f16, length, "MFA 16-bit forward should match MPSGraph for datatype %d", datatype);
				REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hexpected_forw->data.f16, (uint16_t*)hactual_inplace->data.f16, length, "in-place MFA 16-bit forward should match MPSGraph for datatype %d", datatype);
				REQUIRE_ARRAY_EQ(uint16_t, (uint16_t*)hexpected_back->data.f16, (uint16_t*)hactual_back->data.f16, length, "MFA 16-bit backward should match MPSGraph for datatype %d", datatype);
			}
			ccv_nnc_tensor_free(back);
			ccv_nnc_tensor_free(output);
			ccv_nnc_tensor_free(threshold);
			ccv_nnc_tensor_free(selector);
			ccv_nnc_tensor_free(inplace);
			ccv_nnc_tensor_free(input);
			ccv_nnc_tensor_free(hactual_back);
			ccv_nnc_tensor_free(hactual_inplace);
			ccv_nnc_tensor_free(hactual_forw);
			ccv_nnc_tensor_free(hexpected_back);
			ccv_nnc_tensor_free(hexpected_forw);
			ccv_nnc_tensor_free(hthreshold);
			ccv_nnc_tensor_free(hselector);
			ccv_nnc_tensor_free(hinput);
		}
	if (old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("fill if less than forward with dynamic broadcast threshold on mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_FILL_IF_LESS_THAN_FORWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const selector = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 17, 1), 0);
	ccv_nnc_tensor_t* const threshold = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, 19), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const hselector = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 17, 1), 0);
	ccv_nnc_tensor_t* const hthreshold = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 19), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 17, 19), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	int i;
	for (i = 0; i < 5 * 17 * 19; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 5;
	for (i = 0; i < 17; i++)
		hselector->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
	for (i = 0; i < 19; i++)
		hthreshold->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
	hselector->data.f32[0] = hthreshold->data.f32[0] = 0.5;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hselector, hthreshold), TENSOR_LIST(a, selector, threshold), 0);
	ccv_nnc_cmd_exec(CMD_FILL_IF_LESS_THAN_FORWARD(-INFINITY), ccv_nnc_no_hint, 0, TENSOR_LIST(a, selector, threshold), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_FILL_IF_LESS_THAN_FORWARD(-INFINITY), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hselector, hthreshold), TENSOR_LIST(bt), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "MPS should match CPU with independently broadcast selector and threshold");
	ccv_nnc_cmd_exec(CMD_FILL_IF_LESS_THAN_FORWARD(-INFINITY), ccv_nnc_no_hint, 0, TENSOR_LIST(a, selector, threshold), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(hb), 0);
	REQUIRE_TENSOR_EQ(bt, hb, "MPS should support in-place execution on the first input");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(selector);
	ccv_nnc_tensor_free(threshold);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hselector);
	ccv_nnc_tensor_free(hthreshold);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("fill if less than backward with dynamic broadcast threshold on mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_FILL_IF_LESS_THAN_BACKWARD, CCV_NNC_BACKEND_MPS));
	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const selector = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 17, 1), 0);
	ccv_nnc_tensor_t* const threshold = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, 19), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const hg = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const hselector = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 17, 1), 0);
	ccv_nnc_tensor_t* const hthreshold = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 19), 0);
	ccv_nnc_tensor_t* const hh = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 17, 19), 0);
	ccv_nnc_tensor_t* const ht = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 17, 19), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 1);
	int i;
	for (i = 0; i < 5 * 17 * 19; i++)
		hg->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 10 - 5;
	for (i = 0; i < 17; i++)
		hselector->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
	for (i = 0; i < 19; i++)
		hthreshold->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) * 4 - 2;
	hselector->data.f32[0] = hthreshold->data.f32[0] = 0.5;
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hg, hselector, hthreshold), TENSOR_LIST(g, selector, threshold), 0);
	ccv_nnc_cmd_exec(CMD_FILL_IF_LESS_THAN_BACKWARD(-INFINITY), ccv_nnc_no_hint, 0, TENSOR_LIST(g, 0, selector, threshold), TENSOR_LIST(h), 0);
	ccv_nnc_cmd_exec(CMD_FILL_IF_LESS_THAN_BACKWARD(-INFINITY), ccv_nnc_no_hint, 0, TENSOR_LIST(hg, 0, hselector, hthreshold), TENSOR_LIST(ht), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(h), TENSOR_LIST(hh), 0);
	REQUIRE_TENSOR_EQ(ht, hh, "MPS input gradient should match CPU with dynamic broadcast threshold");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(selector);
	ccv_nnc_tensor_free(threshold);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(hg);
	ccv_nnc_tensor_free(hselector);
	ccv_nnc_tensor_free(hthreshold);
	ccv_nnc_tensor_free(hh);
	ccv_nnc_tensor_free(ht);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
}

TEST_CASE("compare set with mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SET_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 11, 10, 9, 8), 0);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 11, 10, 9, 8), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, CPU_TENSOR_NCHW(32F, 11, 10, 9, 8), 0);
	ccv_nnc_cmd_exec(CMD_SET_FORWARD(10), ccv_nnc_no_hint, 0, TENSOR_LIST(), TENSOR_LIST(a), 0);
	ccv_nnc_cmd_exec(CMD_SET_FORWARD(10), ccv_nnc_no_hint, 0, TENSOR_LIST(), TENSOR_LIST(ga), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(a), TENSOR_LIST(ha), 0);
	REQUIRE_TENSOR_EQ(ha, ga, "format transform result should be the same");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(ga);
}

TEST_CASE("scaled dot product attention with mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	// Bypass error: variable-sized object may not be initialized
#define num_long_trials 7
#define num_short_trials 2
#define num_trials (num_long_trials + num_short_trials)

	for (int trial = 0; trial < num_trials; ++trial) {
		int B_candidates[num_trials] =         {  32, 1, 1, 1,  32,   1,   3, 2, 1 };
		int R_candidates[num_trials] =         { 128, 4128, 4098, 4162, 128, 192,  61, 6, 2 };
		int C_candidates[num_trials] =         { 128, 4128, 4098, 4162, 128,  64,  49, 2, 1 };
		int Hq_candidates[num_trials] =        {   8, 32, 32, 32,  32,  16,  13, 3, 1 };
		int Hk_candidates[num_trials] =        {   8, 8, 8, 8,   8,  16,  13, 3, 1 };
		int D_candidates[num_trials] =         {  64, 32, 32, 32, 128, 128, 191, 4, 8 };
		int is_causal_candidates[num_trials] = {   0, 0, 0, 0,   1,   1,   0, 1, 0 };

		int B = B_candidates[trial];
		int R = R_candidates[trial];
		int C = C_candidates[trial];
		int Hq = Hq_candidates[trial];
		int Hk = Hk_candidates[trial];
		int D = D_candidates[trial];
		int is_causal = is_causal_candidates[trial];
		float scale = 1.0 / sqrt((float)D);

		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);

		for (int i = 0; i < B * R * Hq * D; ++i) {
			q_tensor->data.f32[i] = (float)(i) / (float)(B * R * Hq * D);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			k_tensor->data.f32[i] = (float)(i) / (float)(B * C * Hk * D);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			v_tensor->data.f32[i] = (float)(i) / (float)(B * C * Hk * D);
		}

		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);

		// Why it there 000 in the beginning of the argument list for GPU_TENSOR_NHWC?
		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);

		if (is_causal)
		{
			ccv_nnc_tensor_t* const causal_mask = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
			ccv_nnc_tensor_t* const gpu_causal_mask = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, 1, R, C), 0);
			for (int i = 0; i < R; i++)
				for (int j = 0; j < C; j++)
					causal_mask->data.f32[i * C + j] = 0;
			for (int i = 0; i < R - 1; i++)
				for (int j = ccv_max(i - R + C + 1, 0); j < C; j++)
					causal_mask->data.f32[i * C + j] = -FLT_MAX;
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(causal_mask), TENSOR_LIST(gpu_causal_mask), 0);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_causal_mask), TENSOR_LIST(gpu_o_tensor), 0);
			ccv_nnc_tensor_free(gpu_causal_mask);
			ccv_nnc_tensor_free(causal_mask);
		} else {
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
		}

		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_o_tensor->data.f32, o_tensor->data.f32, B * R * Hq * D, 1e-3, "scaled dot product attention result should be the same");

		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
	}
#undef num_long_trials
#undef num_short_trials
#undef num_trials
}

TEST_CASE("scaled dot product attention with masked NA mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 80;
	const int C = 64;
	const int H = 8;
	const int D = 128;
	const float scale = 1.0 / sqrt((float)D);
	const int q_count = B * R * H * D;
	const int kv_count = B * C * H * D;
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const mask_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const causal_mask_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const mask_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const causal_mask_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1, R, C), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 31);
	for (int i = 0; i < q_count; ++i)
		q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < kv_count; ++i)
		k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < kv_count; ++i)
		v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < R; ++i)
		for (int j = 0; j < C; ++j)
		{
			mask_tensor->data.f32[i * C + j] = ((i * 13 + j * 7) % 11 == 0) ? -0.75 : (((i + j) % 5 == 0) ? 0.125 : 0);
			causal_mask_tensor->data.f32[i * C + j] = (j <= i + C - R) ? 0 : -FLT_MAX;
		}
	ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
	ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(mask_tensor->data.f32, (uint16_t*)mask_tensor_f16->data.f16, R * C);
	ccv_float_to_half_precision(causal_mask_tensor->data.f32, (uint16_t*)causal_mask_tensor_f16->data.f16, R * C);

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_mask_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const gpu_causal_mask_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1, R, C), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, mask_tensor_f16, causal_mask_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_mask_tensor, gpu_causal_mask_tensor), 0);
	for (int trial = 0; trial < 3; ++trial)
	{
		const int is_causal = trial == 1;
		ccv_nnc_tensor_t* const cpu_mask = trial == 2 ? 0 : mask_tensor;
		ccv_nnc_tensor_t* const gpu_mask = trial == 2 ? gpu_causal_mask_tensor : gpu_mask_tensor;
		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		if (cpu_mask)
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, cpu_mask), TENSOR_LIST(o_tensor), 0);
		else
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 1), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, trial == 2 ? 0 : is_causal);
		gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F;
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_mask), TENSOR_LIST(gpu_o_tensor), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		const int count = B * R * H * D;
		float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * count);
		ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < count; ++i)
		{
			const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
			const float relative_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]) / denom;
			if (relative_diff > max_relative_diff)
				max_relative_diff = relative_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 5e-2, "masked NA attention should match CPU reference for trial=%d (max relative diff %g at %d: %g vs %g)", trial, max_relative_diff, max_diff_idx, o_tensor->data.f32[max_diff_idx], gpu_f32[max_diff_idx]);
		ccfree(gpu_f32);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(o_tensor);
	}
	ccv_nnc_tensor_free(gpu_causal_mask_tensor);
	ccv_nnc_tensor_free(gpu_mask_tensor);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(causal_mask_tensor_f16);
	ccv_nnc_tensor_free(mask_tensor_f16);
	ccv_nnc_tensor_free(v_tensor_f16);
	ccv_nnc_tensor_free(k_tensor_f16);
	ccv_nnc_tensor_free(q_tensor_f16);
	ccv_nnc_tensor_free(causal_mask_tensor);
	ccv_nnc_tensor_free(mask_tensor);
	ccv_nnc_tensor_free(v_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(q_tensor);
}

TEST_CASE("scaled dot product attention with generic causal and masked mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2;
	const int R = 96;
	const int C = 80;
	const int H = 4;
	const int D = 64;
	const float scale = 1.0 / sqrt((float)D);
	const int q_count = B * R * H * D;
	const int kv_count = B * C * H * D;
	const int out_count = q_count;
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const triangular_mask_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const broadcast_mask_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const batched_mask_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, 1, R, C), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 67);
	for (int i = 0; i < q_count; ++i)
		q_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	for (int i = 0; i < kv_count; ++i)
		k_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	for (int i = 0; i < kv_count; ++i)
		v_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	for (int i = 0; i < R; ++i)
		for (int j = 0; j < C; ++j)
		{
			triangular_mask_tensor->data.f32[i * C + j] = (j <= i + C - R) ? 0 : -FLT_MAX;
			const int slot = (i * 17 + j * 13) % 29;
			broadcast_mask_tensor->data.f32[i * C + j] = (slot == 0) ? -FLT_MAX : ((slot == 1) ? -0.375 : ((slot == 2) ? 0.125 : 0));
		}
	for (int b = 0; b < B; ++b)
		for (int i = 0; i < R; ++i)
			for (int j = 0; j < C; ++j)
			{
				const int slot = (b * 37 + i * 11 + j * 5) % 31;
				batched_mask_tensor->data.f32[(b * R + i) * C + j] = (slot == 0) ? -FLT_MAX : ((slot == 1) ? -0.5 : ((slot == 2) ? 0.25 : 0));
			}

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_triangular_mask_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const gpu_broadcast_mask_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const gpu_batched_mask_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, 1, R, C), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, triangular_mask_tensor, broadcast_mask_tensor, batched_mask_tensor), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_triangular_mask_tensor, gpu_broadcast_mask_tensor, gpu_batched_mask_tensor), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	for (int trial = 0; trial < 5; ++trial)
	{
		const int is_causal = (trial == 0 || trial == 4);
		ccv_nnc_tensor_t* const cpu_mask = (trial == 1) ? triangular_mask_tensor : ((trial == 2 || trial == 4) ? broadcast_mask_tensor : (trial == 3 ? batched_mask_tensor : 0));
		ccv_nnc_tensor_t* const gpu_mask = (trial == 1) ? gpu_triangular_mask_tensor : ((trial == 2 || trial == 4) ? gpu_broadcast_mask_tensor : (trial == 3 ? gpu_batched_mask_tensor : 0));
		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_cmd_t cpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, trial == 1 ? 1 : is_causal);
		if (trial == 1)
			ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);
		else if (cpu_mask)
			ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, cpu_mask), TENSOR_LIST(o_tensor), 0);
		else
			ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		if (gpu_mask)
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_mask), TENSOR_LIST(gpu_o_tensor), 0);
		else
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		float max_abs_diff = 0;
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < out_count; ++i)
		{
			const float abs_diff = fabsf(o_tensor->data.f32[i] - copy_of_gpu_o_tensor->data.f32[i]);
			const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(copy_of_gpu_o_tensor->data.f32[i])), 1.0f);
			const float relative_diff = abs_diff / denom;
			if (relative_diff > max_relative_diff)
			{
				max_abs_diff = abs_diff;
				max_relative_diff = relative_diff, max_diff_idx = i;
			}
		}
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(o_tensor);
		REQUIRE(max_relative_diff <= 2e-2, "generic MPS attention should match CPU reference for trial=%d (max abs %g relative %g at %d)", trial, max_abs_diff, max_relative_diff, max_diff_idx);
	}
	{
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const mask_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1, R, C), 0);
		ccv_nnc_tensor_t* const q_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const mask_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
		ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
		ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
		ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
		ccv_float_to_half_precision(broadcast_mask_tensor->data.f32, (uint16_t*)mask_tensor_f16->data.f16, R * C);
		ccv_half_precision_to_float((uint16_t*)q_tensor_f16->data.f16, q_tensor_ref->data.f32, q_count);
		ccv_half_precision_to_float((uint16_t*)k_tensor_f16->data.f16, k_tensor_ref->data.f32, kv_count);
		ccv_half_precision_to_float((uint16_t*)v_tensor_f16->data.f16, v_tensor_ref->data.f32, kv_count);
		ccv_half_precision_to_float((uint16_t*)mask_tensor_f16->data.f16, mask_tensor_ref->data.f32, R * C);
		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_ref, k_tensor_ref, v_tensor_ref, mask_tensor_ref), TENSOR_LIST(o_tensor), 0);
		ccv_nnc_tensor_t* const o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_float_to_half_precision(o_tensor->data.f32, (uint16_t*)o_tensor_f16->data.f16, out_count);
		ccv_half_precision_to_float((uint16_t*)o_tensor_f16->data.f16, o_tensor->data.f32, out_count);
		ccv_nnc_tensor_t* const gpu_q_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const gpu_mask_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1, R, C), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, mask_tensor_f16), TENSOR_LIST(gpu_q_tensor_f16, gpu_k_tensor_f16, gpu_v_tensor_f16, gpu_mask_tensor_f16), 0);
		ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F;
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor_f16, gpu_k_tensor_f16, gpu_v_tensor_f16, gpu_mask_tensor_f16), TENSOR_LIST(gpu_o_tensor_f16), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor_f16), TENSOR_LIST(copy_of_gpu_o_tensor_f16), 0);
		float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * out_count);
		ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor_f16->data.f16, gpu_f32, out_count);
		float max_abs_diff = 0;
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < out_count; ++i)
		{
			const float abs_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]);
			const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
			const float relative_diff = abs_diff / denom;
			if (relative_diff > max_relative_diff)
				max_abs_diff = abs_diff, max_relative_diff = relative_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 8e-2, "generic MPS attention should match CPU reference for broadcast masked 16F (max abs %g relative %g at %d)", max_abs_diff, max_relative_diff, max_diff_idx);
		ccfree(gpu_f32);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor_f16);
		ccv_nnc_tensor_free(gpu_o_tensor_f16);
		ccv_nnc_tensor_free(gpu_mask_tensor_f16);
		ccv_nnc_tensor_free(gpu_v_tensor_f16);
		ccv_nnc_tensor_free(gpu_k_tensor_f16);
		ccv_nnc_tensor_free(gpu_q_tensor_f16);
		ccv_nnc_tensor_free(o_tensor_f16);
		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(mask_tensor_ref);
		ccv_nnc_tensor_free(v_tensor_ref);
		ccv_nnc_tensor_free(k_tensor_ref);
		ccv_nnc_tensor_free(q_tensor_ref);
		ccv_nnc_tensor_free(mask_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(q_tensor_f16);
	}
	ccv_nnc_tensor_free(gpu_batched_mask_tensor);
	ccv_nnc_tensor_free(gpu_broadcast_mask_tensor);
	ccv_nnc_tensor_free(gpu_triangular_mask_tensor);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(batched_mask_tensor);
	ccv_nnc_tensor_free(broadcast_mask_tensor);
	ccv_nnc_tensor_free(triangular_mask_tensor);
	ccv_nnc_tensor_free(v_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(q_tensor);
}

TEST_CASE("scaled dot product attention with generic varlen mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 4;
	const int Hq = 4;
	const int Hk = 2;
	const int D = 64;
	const int q_offsets[2][5] = {
		{ 0, 17, 80, 145, 223 },
		{ 0, 16, 81, 147, 226 },
	};
	const int kv_offsets[2][5] = {
		{ 0, 19, 83, 150, 229 },
		{ 0, 18, 82, 149, 229 },
	};
	const int max_seqlen_q[2] = { 78, 79 };
	const int max_seqlen_kv[2] = { 79, 80 };
	const uint64_t old_flags = ccv_nnc_flags();
	for (int trial = 0; trial < 2; ++trial)
	{
		const int is_causal = trial;
		const int total_q = q_offsets[trial][B];
		const int total_k = kv_offsets[trial][B];
		const float scale = 1.0 / sqrt((float)D);
		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_k, Hk, D), 0);
		for (int i = 0; i < total_q * Hq * D; ++i)
			q_tensor->data.f32[i] = (float)((i * 17) % 97 - 48) / 256;
		for (int i = 0; i < total_k * Hk * D; ++i)
		{
			k_tensor->data.f32[i] = (float)((i * 13) % 89 - 44) / 256;
			v_tensor->data.f32[i] = (float)((i * 19) % 101 - 50) / 128;
		}
		ccv_nnc_tensor_t* const o_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		for (int b = 0; b < B; ++b)
		{
			const int q_start = q_offsets[trial][b];
			const int k_start = kv_offsets[trial][b];
			const int R = q_offsets[trial][b + 1] - q_start;
			const int C = kv_offsets[trial][b + 1] - k_start;
			ccv_nnc_tensor_t* const q_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, R, Hq, D), 0);
			ccv_nnc_tensor_t* const k_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, C, Hk, D), 0);
			ccv_nnc_tensor_t* const v_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, C, Hk, D), 0);
			ccv_nnc_tensor_t* const o_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, R, Hq, D), 0);
			memcpy(q_seq->data.f32, q_tensor->data.f32 + q_start * Hq * D, sizeof(float) * R * Hq * D);
			memcpy(k_seq->data.f32, k_tensor->data.f32 + k_start * Hk * D, sizeof(float) * C * Hk * D);
			memcpy(v_seq->data.f32, v_tensor->data.f32 + k_start * Hk * D, sizeof(float) * C * Hk * D);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_seq, k_seq, v_seq), TENSOR_LIST(o_seq), 0);
			memcpy(o_tensor_ref->data.f32 + q_start * Hq * D, o_seq->data.f32, sizeof(float) * R * Hq * D);
			ccv_nnc_tensor_free(q_seq);
			ccv_nnc_tensor_free(k_seq);
			ccv_nnc_tensor_free(v_seq);
			ccv_nnc_tensor_free(o_seq);
		}
		ccv_nnc_tensor_t* const q_seq_offsets = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, B + 1), 0);
		ccv_nnc_tensor_t* const kv_seq_offsets = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, B + 1), 0);
		for (int i = 0; i < B + 1; ++i)
		{
			q_seq_offsets->data.i32[i] = q_offsets[trial][i];
			kv_seq_offsets->data.i32[i] = kv_offsets[trial][i];
		}
		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
		cmd.info.scaled_dot_product_attention.is_varlen = 1;
		cmd.info.scaled_dot_product_attention.max_seqlen_q = max_seqlen_q[trial];
		cmd.info.scaled_dot_product_attention.max_seqlen_kv = max_seqlen_kv[trial];
		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_q_seq_offsets = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, B + 1), 0);
		ccv_nnc_tensor_t* const gpu_kv_seq_offsets = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, B + 1), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, q_seq_offsets, kv_seq_offsets), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_q_seq_offsets, gpu_kv_seq_offsets), 0);
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL, gpu_q_seq_offsets, gpu_kv_seq_offsets), TENSOR_LIST(gpu_o_tensor, NULL), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		float max_abs_diff = 0;
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < total_q * Hq * D; ++i)
		{
			const float abs_diff = fabsf(o_tensor_ref->data.f32[i] - copy_of_gpu_o_tensor->data.f32[i]);
			const float denom = fmaxf(fmaxf(fabsf(o_tensor_ref->data.f32[i]), fabsf(copy_of_gpu_o_tensor->data.f32[i])), 1.0f);
			const float relative_diff = abs_diff / denom;
			if (relative_diff > max_relative_diff)
				max_abs_diff = abs_diff, max_relative_diff = relative_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 2e-2, "generic varlen MPS attention should match CPU reference when causal=%d (max abs %g relative %g at %d)", is_causal, max_abs_diff, max_relative_diff, max_diff_idx);
		// In-place FP32 staging must copy packed rows, not B * max_seqlen_q rows.
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		const int inplace_status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL, gpu_q_seq_offsets, gpu_kv_seq_offsets), TENSOR_LIST(gpu_q_tensor, NULL), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		REQUIRE_EQ(inplace_status, CCV_NNC_EXEC_SUCCESS, "in-place generic varlen attention should execute");
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		for (int i = 0; i < total_q * Hq * D; i++)
			REQUIRE(isfinite(copy_of_gpu_o_tensor->data.f32[i]), "in-place generic varlen attention should stay finite at %d", i);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_o_tensor->data.f32, o_tensor_ref->data.f32, total_q * Hq * D, 1e-5, "in-place generic varlen attention should match CPU when causal=%d", is_causal);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const q_tensor_round = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_round = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_round = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_k, Hk, D), 0);
		ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, total_q * Hq * D);
		ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, total_k * Hk * D);
		ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, total_k * Hk * D);
		ccv_half_precision_to_float((uint16_t*)q_tensor_f16->data.f16, q_tensor_round->data.f32, total_q * Hq * D);
		ccv_half_precision_to_float((uint16_t*)k_tensor_f16->data.f16, k_tensor_round->data.f32, total_k * Hk * D);
		ccv_half_precision_to_float((uint16_t*)v_tensor_f16->data.f16, v_tensor_round->data.f32, total_k * Hk * D);
		ccv_nnc_tensor_t* const o_tensor_ref_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		for (int b = 0; b < B; ++b)
		{
			const int q_start = q_offsets[trial][b];
			const int k_start = kv_offsets[trial][b];
			const int R = q_offsets[trial][b + 1] - q_start;
			const int C = kv_offsets[trial][b + 1] - k_start;
			ccv_nnc_tensor_t* const q_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, R, Hq, D), 0);
			ccv_nnc_tensor_t* const k_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, C, Hk, D), 0);
			ccv_nnc_tensor_t* const v_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, C, Hk, D), 0);
			ccv_nnc_tensor_t* const o_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, R, Hq, D), 0);
			memcpy(q_seq->data.f32, q_tensor_round->data.f32 + q_start * Hq * D, sizeof(float) * R * Hq * D);
			memcpy(k_seq->data.f32, k_tensor_round->data.f32 + k_start * Hk * D, sizeof(float) * C * Hk * D);
			memcpy(v_seq->data.f32, v_tensor_round->data.f32 + k_start * Hk * D, sizeof(float) * C * Hk * D);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_seq, k_seq, v_seq), TENSOR_LIST(o_seq), 0);
			memcpy(o_tensor_ref_f16->data.f32 + q_start * Hq * D, o_seq->data.f32, sizeof(float) * R * Hq * D);
			ccv_nnc_tensor_free(q_seq);
			ccv_nnc_tensor_free(k_seq);
			ccv_nnc_tensor_free(v_seq);
			ccv_nnc_tensor_free(o_seq);
		}
		ccv_nnc_tensor_t* const gpu_q_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor_f16 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), TENSOR_LIST(gpu_q_tensor_f16, gpu_k_tensor_f16, gpu_v_tensor_f16), 0);
		ccv_nnc_cmd_t cmd_f16 = cmd;
		cmd_f16.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F;
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(cmd_f16, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor_f16, gpu_k_tensor_f16, gpu_v_tensor_f16, NULL, NULL, NULL, gpu_q_seq_offsets, gpu_kv_seq_offsets), TENSOR_LIST(gpu_o_tensor_f16, NULL), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor_f16), TENSOR_LIST(copy_of_gpu_o_tensor_f16), 0);
		float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * total_q * Hq * D);
		ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor_f16->data.f16, gpu_f32, total_q * Hq * D);
		max_abs_diff = 0;
		max_relative_diff = 0;
		max_diff_idx = 0;
		for (int i = 0; i < total_q * Hq * D; ++i)
		{
			const float abs_diff = fabsf(o_tensor_ref_f16->data.f32[i] - gpu_f32[i]);
			const float denom = fmaxf(fmaxf(fabsf(o_tensor_ref_f16->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
			const float relative_diff = abs_diff / denom;
			if (relative_diff > max_relative_diff)
				max_abs_diff = abs_diff, max_relative_diff = relative_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 8e-2, "generic varlen 16F MPS attention should match CPU reference when causal=%d (max abs %g relative %g at %d)", is_causal, max_abs_diff, max_relative_diff, max_diff_idx);
		ccfree(gpu_f32);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor_f16);
		ccv_nnc_tensor_free(gpu_o_tensor_f16);
		ccv_nnc_tensor_free(gpu_v_tensor_f16);
		ccv_nnc_tensor_free(gpu_k_tensor_f16);
		ccv_nnc_tensor_free(gpu_q_tensor_f16);
		ccv_nnc_tensor_free(o_tensor_ref_f16);
		ccv_nnc_tensor_free(v_tensor_round);
		ccv_nnc_tensor_free(k_tensor_round);
		ccv_nnc_tensor_free(q_tensor_round);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_kv_seq_offsets);
		ccv_nnc_tensor_free(gpu_q_seq_offsets);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(kv_seq_offsets);
		ccv_nnc_tensor_free(q_seq_offsets);
		ccv_nnc_tensor_free(o_tensor_ref);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(q_tensor);
	}
}

TEST_CASE("scaled dot product attention with NA mps for odd sequence lengths")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int H = 16;
	const int shapes[][3] = {
		{ 47, 47, 64 },
		{ 161, 161, 64 },
		{ 47, 41, 64 },
		{ 161, 145, 64 },
		{ 64, 129, 256 },
		{ 65, 129, 256 },
		{ 161, 145, 256 },
	};
	for (int shape_idx = 0; shape_idx < (int)(sizeof(shapes) / sizeof(shapes[0])); ++shape_idx)
	{
		const int R = shapes[shape_idx][0];
		const int C = shapes[shape_idx][1];
		const int D = shapes[shape_idx][2];
		const float scale = 1.0 / sqrt((float)D);
		const int q_count = B * R * H * D;
		const int kv_count = B * C * H * D;
		for (int is_causal = 0; is_causal <= 1; ++is_causal)
		{
			ccv_nnc_tensor_t* const q_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			for (int r = 0; r < R; ++r)
				for (int h = 0; h < H; ++h)
					for (int d = 0; d < D; ++d)
						q_tensor_ref->data.f32[((r * H + h) * D) + d] = (((r * 17 + h * 5 + d * 3 + is_causal) % 31) - 15) * (1.0 / 128);
			for (int c = 0; c < C; ++c)
				for (int h = 0; h < H; ++h)
					for (int d = 0; d < D; ++d)
					{
						k_tensor_ref->data.f32[((c * H + h) * D) + d] = (((c * 19 + h * 7 + d * 5 + shape_idx) % 31) - 15) * (1.0 / 128);
						v_tensor_ref->data.f32[((c * H + h) * D) + d] = (((c * 29 + h * 11 + d * 7 + 3) % 127) - 63) * (1.0 / 512);
					}
			ccv_float_to_half_precision(q_tensor_ref->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
			ccv_float_to_half_precision(k_tensor_ref->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
			ccv_float_to_half_precision(v_tensor_ref->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
			ccv_half_precision_to_float((uint16_t*)q_tensor_f16->data.f16, q_tensor_ref->data.f32, q_count);
			ccv_half_precision_to_float((uint16_t*)k_tensor_f16->data.f16, k_tensor_ref->data.f32, kv_count);
			ccv_half_precision_to_float((uint16_t*)v_tensor_f16->data.f16, v_tensor_ref->data.f32, kv_count);
			ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_ref, k_tensor_ref, v_tensor_ref), TENSOR_LIST(o_tensor), 0);
			ccv_nnc_tensor_t* const o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_float_to_half_precision(o_tensor->data.f32, (uint16_t*)o_tensor_f16->data.f16, q_count);
			ccv_half_precision_to_float((uint16_t*)o_tensor_f16->data.f16, o_tensor->data.f32, q_count);

			ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
			ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
			gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F;
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

			float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
			ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, q_count);
			float max_abs_diff = 0;
			float max_relative_diff = 0;
			int max_diff_idx = 0;
			for (int i = 0; i < q_count; ++i)
			{
				REQUIRE(isfinite(gpu_f32[i]), "NA attention output should stay finite for R=%d C=%d causal=%d at %d", R, C, is_causal, i);
				const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
				const float abs_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]);
				const float relative_diff = abs_diff / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_abs_diff = abs_diff, max_diff_idx = i;
			}
			const int max_diff_d = max_diff_idx % D;
			const int max_diff_h = (max_diff_idx / D) % H;
			const int max_diff_r = (max_diff_idx / (H * D)) % R;
			const int max_diff_b = max_diff_idx / (R * H * D);
			REQUIRE(max_relative_diff <= 1e-4, "NA attention should match half-rounded CPU reference for R=%d C=%d causal=%d (max abs %g relative %g at b=%d r=%d h=%d d=%d idx=%d: CPU %g GPU %g)", R, C, is_causal, max_abs_diff, max_relative_diff, max_diff_b, max_diff_r, max_diff_h, max_diff_d, max_diff_idx, o_tensor->data.f32[max_diff_idx], gpu_f32[max_diff_idx]);

			ccfree(gpu_f32);
			ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_v_tensor);
			ccv_nnc_tensor_free(gpu_k_tensor);
			ccv_nnc_tensor_free(gpu_q_tensor);
			ccv_nnc_tensor_free(o_tensor_f16);
			ccv_nnc_tensor_free(o_tensor);
			ccv_nnc_tensor_free(v_tensor_ref);
			ccv_nnc_tensor_free(k_tensor_ref);
			ccv_nnc_tensor_free(q_tensor_ref);
			ccv_nnc_tensor_free(q_tensor_f16);
			ccv_nnc_tensor_free(k_tensor_f16);
			ccv_nnc_tensor_free(v_tensor_f16);
		}
	}
}

TEST_CASE("scaled dot product attention NA register tiles preserve layout and saved statistics")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2, Hq = 4, Hk = 2, S = 8;
	const int shapes[][3] = {
		{ 128, 1024, 128 }, // Preserve the small-query fallback.
		{ 8193, 8282, 128 }, { 8193, 8192, 128 }, { 8448, 8321, 128 },
		{ 65, 127, 256 }, { 256, 256, 256 }, { 2049, 513, 256 },
		{ 4097, 4099, 256 }, { 257, 255, 128 }, { 257, 255, 256 },
		{ 4095, 4097, 256 }, { 4097, 4095, 256 }
	};
	for (int trial = 0; trial < sizeof(shapes) / sizeof(shapes[0]); ++trial)
	{
		const int R = shapes[trial][0], C = shapes[trial][1], D = shapes[trial][2];
		const int int8_preference = D == 256 && (R < 4096 || C < 4096);
		const int rows[S] = { 0, 1, 63, 64, R / 2, R - 65, R - 2, R - 1 };
		ccv_nnc_tensor_t* inputs[3];
		ccv_nnc_tensor_t* half_inputs[3];
		ccv_nnc_tensor_t* gpu_inputs[3];
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 911 + trial);
		for (int j = 0; j < 3; ++j)
		{
			const int length = j == 0 ? R : C, heads = j == 0 ? Hq : Hk;
			const int count = B * length * heads * D;
			inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, length, heads, D), 0);
			half_inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, length, heads, D), 0);
			gpu_inputs[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, length, heads, D), 0);
			for (int i = 0; i < count; ++i)
				inputs[j]->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * (j == 2 ? 2 : 4);
			ccv_float_to_half_precision(inputs[j]->data.f32, (uint16_t*)half_inputs[j]->data.f16, count);
			ccv_half_precision_to_float((uint16_t*)half_inputs[j]->data.f16, inputs[j]->data.f32, count);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[j]), TENSOR_LIST(gpu_inputs[j]), 0);
		}
		ccv_nnc_tensor_t* const sampled_q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				memcpy(sampled_q->data.f32 + (b * S + s) * Hq * D, inputs[0]->data.f32 + (b * R + rows[s]) * Hq * D, sizeof(float) * Hq * D);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		const float scale = 1.0f / sqrtf(D);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(sampled_q, inputs[1], inputs[2]), TENSOR_LIST(expected), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_l = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_tensor_t* const half_o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const raw_l = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, Hq, R), 0);
		ccv_nnc_cmd_t command = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		command.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F;
		const uint64_t old_flags = ccv_nnc_flags();
		if (trial > 0)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_o, gpu_l), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o, gpu_l), TENSOR_LIST(half_o, raw_l), 0);
		float* const actual = (float*)ccmalloc(sizeof(float) * B * R * Hq * D);
		float* const lse = (float*)ccmalloc(sizeof(float) * B * R * Hq);
		ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
		// The low-precision MFA contract stores log2 LSE in the half prefix.
		ccv_half_precision_to_float((uint16_t*)raw_l->data.f32, lse, B * R * Hq);
		for (int i = 0; i < B * R * Hq * D; ++i)
			REQUIRE(isfinite(actual[i]), "NA register output should be finite");
		double error2 = 0, reference2 = 0;
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				for (int h = 0; h < Hq; ++h)
				{
					for (int d = 0; d < D; ++d)
					{
						const float ref = expected->data.f32[((b * S + s) * Hq + h) * D + d];
						const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - ref;
						error2 += error * error;
						reference2 += ref * ref;
					}
					double sum = 0;
					for (int c = 0; c < C; ++c)
					{
						double dot = 0;
						for (int d = 0; d < D; ++d)
							dot += sampled_q->data.f32[((b * S + s) * Hq + h) * D + d] * inputs[1]->data.f32[((b * C + c) * Hk + h / (Hq / Hk)) * D + d];
						sum += exp(dot * scale);
					}
					REQUIRE(fabs(lse[(b * Hq + h) * R + rows[s]] - log2(sum)) < 0.02, "saved LSE should preserve head and batch strides");
				}
		REQUIRE(error2 < reference2 * 0.003 * 0.003, "NA register attention should match sampled CPU queries (R=%d C=%d D=%d relative L2=%g)", R, C, D, sqrt(error2 / reference2));
		if (int8_preference)
		{
			// Short wide-head inference retains the faster FP16 fallback for an
			// INT8 preference. Long INT8 inference has separate numerical coverage.
			command.info.scaled_dot_product_attention.flags |= CCV_NNC_GEMM_8I;
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
			const int status = ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_o), 0);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
			REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "wide-head inference with an INT8 preference should execute");
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o), TENSOR_LIST(half_o), 0);
			ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
			for (int i = 0; i < B * R * Hq * D; ++i)
				REQUIRE(isfinite(actual[i]), "wide-head inference output should be finite");
			error2 = 0;
			for (int b = 0; b < B; ++b)
				for (int s = 0; s < S; ++s)
					for (int h = 0; h < Hq; ++h)
						for (int d = 0; d < D; ++d)
						{
							const float ref = expected->data.f32[((b * S + s) * Hq + h) * D + d];
							const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - ref;
							error2 += error * error;
						}
			REQUIRE(error2 < reference2 * 0.003 * 0.003, "wide-head inference should preserve FP16 accuracy with an INT8 preference (R=%d C=%d relative L2=%g)", R, C, sqrt(error2 / reference2));
		}
		// Exercise no-gradient / gradient graph evaluation and exact Q/O reuse.
		// The standard graph retains LSE, so no-LSE command tests alone cannot
		// establish that the inference selector is reachable from CNNP.
		ccv_cnnp_model_t* const model = ccv_cnnp_scaled_dot_product_attention(scale, 0, 0, 0, 0, 0,
			CCV_NNC_GEMM_16F | (int8_preference ? CCV_NNC_GEMM_8I : 0), 0, 0, 0, 1, 0, "attention");
		ccv_cnnp_model_compile(model, TENSOR_PARAM_LIST(gpu_inputs[0]->info, gpu_inputs[1]->info, gpu_inputs[2]->info), CMD_NOOP(), CMD_NOOP());
		const int modes[] = { 1, 0, 1 };
		for (int mode = 0; mode < 3; ++mode)
		{
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[0]), TENSOR_LIST(gpu_inputs[0]), 0);
			ccv_nnc_tensor_t* const model_output = modes[mode] ? gpu_inputs[0] : gpu_o;
			ccv_cnnp_model_evaluate(model, (ccv_cnnp_evaluate_param_t){ .requires_grad = !modes[mode], .is_test = 0 },
				TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(model_output), 0, 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(model_output), TENSOR_LIST(half_o), 0);
			ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
			for (int i = 0; i < B * R * Hq * D; ++i)
				REQUIRE(isfinite(actual[i]), "in-place model attention should be finite");
			error2 = 0;
			for (int b = 0; b < B; ++b)
				for (int s = 0; s < S; ++s)
					for (int h = 0; h < Hq; ++h)
						for (int d = 0; d < D; ++d)
						{
							const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - expected->data.f32[((b * S + s) * Hq + h) * D + d];
							error2 += error * error;
						}
			const double tolerance = int8_preference && !modes[mode] ? 0.05 : 0.003;
			REQUIRE(error2 < reference2 * tolerance * tolerance, "in-place CNNP attention should preserve selected precision (R=%d C=%d D=%d no_backward=%d relative L2=%g)", R, C, D, modes[mode], sqrt(error2 / reference2));
		}
		ccv_cnnp_model_free(model);
		ccfree(actual);
		ccfree(lse);
		ccv_nnc_tensor_free(sampled_q);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_l);
		ccv_nnc_tensor_free(half_o);
		ccv_nnc_tensor_free(raw_l);
		for (int j = 0; j < 3; ++j)
		{
			ccv_nnc_tensor_free(inputs[j]);
			ccv_nnc_tensor_free(half_inputs[j]);
			ccv_nnc_tensor_free(gpu_inputs[j]);
		}
	}
}

TEST_CASE("scaled dot product attention quantized NA query ranges and compact grids preserve layout and saved statistics")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2, Hq = 4, Hk = 2, S = 8;
	const int shapes[][3] = {
		{ 4095, 4096, 128 }, { 4097, 4095, 128 }, { 4097, 4096, 128 },
		{ 4112, 4113, 128 }, { 4129, 4160, 128 }, { 4159, 4159, 128 },
		{ 4160, 4160, 128 }, { 4161, 4161, 128 }, { 8193, 8282, 128 },
		{ 8447, 8192, 128 }, { 4097, 4096, 128 }, { 4095, 4096, 128 },
		{ 129, 31, 128 }, { 257, 65, 128 }, { 513, 1025, 64 },
		{ 257, 513, 256 }, { 4097, 4161, 128 },
		// Cross grid-policy boundaries without changing remainder/source flags.
		{ 4096, 8128, 128 }, { 4096, 8192, 128 }, { 4096, 8128, 128 },
		{ 4096, 4352, 128 }, { 4352, 4352, 128 }, { 4096, 4352, 128 },
		{ 5440, 4352, 128 }, { 5504, 4352, 128 }, { 5440, 4352, 128 }
	};
	for (int trial = 0; trial < 2 * (int)(sizeof(shapes) / sizeof(shapes[0])); ++trial)
	{
		const int shape_idx = trial % (sizeof(shapes) / sizeof(shapes[0]));
		const int R = shapes[shape_idx][0], C = shapes[shape_idx][1], D = shapes[shape_idx][2];
		const int rows[S] = { 0, 1, 63, 64, R / 2, R - 65, R - 2, R - 1 };
		ccv_nnc_tensor_t* inputs[3];
		ccv_nnc_tensor_t* half_inputs[3];
		ccv_nnc_tensor_t* gpu_inputs[3];
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 921 + trial);
		for (int j = 0; j < 3; ++j)
		{
			const int length = j == 0 ? R : C, heads = j == 0 ? Hq : Hk;
			const int count = B * length * heads * D;
			inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, length, heads, D), 0);
			half_inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, length, heads, D), 0);
			gpu_inputs[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, length, heads, D), 0);
			for (int i = 0; i < count; ++i)
				inputs[j]->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) *
					(j == 2 ? (shape_idx == 16 ? 2000 : 2) : 1);
			ccv_float_to_half_precision(inputs[j]->data.f32, (uint16_t*)half_inputs[j]->data.f16, count);
			ccv_half_precision_to_float((uint16_t*)half_inputs[j]->data.f16, inputs[j]->data.f32, count);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[j]), TENSOR_LIST(gpu_inputs[j]), 0);
		}
		ccv_nnc_tensor_t* const sampled_q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				memcpy(sampled_q->data.f32 + (b * S + s) * Hq * D, inputs[0]->data.f32 + (b * R + rows[s]) * Hq * D, sizeof(float) * Hq * D);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		const float scale = 1.0f / sqrtf(D);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(sampled_q, inputs[1], inputs[2]), TENSOR_LIST(expected), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_l = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_tensor_t* const half_o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const raw_l = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, Hq, R), 0);
		ccv_nnc_cmd_t command = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		command.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
		const uint64_t old_flags = ccv_nnc_flags();
		if (trial >= sizeof(shapes) / sizeof(shapes[0]))
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_o, gpu_l), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o, gpu_l), TENSOR_LIST(half_o, raw_l), 0);
		float* const actual = (float*)ccmalloc(sizeof(float) * B * R * Hq * D);
		float* const lse = (float*)ccmalloc(sizeof(float) * B * R * Hq);
		ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
		// The low-precision MFA contract stores log2 LSE in the half prefix.
		ccv_half_precision_to_float((uint16_t*)raw_l->data.f32, lse, B * R * Hq);
		for (int i = 0; i < B * R * Hq * D; ++i)
			REQUIRE(isfinite(actual[i]), "quantized query-range output should be finite");
		double error2 = 0, reference2 = 0;
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				for (int h = 0; h < Hq; ++h)
				{
					for (int d = 0; d < D; ++d)
					{
						const float ref = expected->data.f32[((b * S + s) * Hq + h) * D + d];
						const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - ref;
						error2 += error * error;
						reference2 += ref * ref;
					}
					double sum = 0;
					for (int c = 0; c < C; ++c)
					{
						double dot = 0;
						for (int d = 0; d < D; ++d)
							dot += sampled_q->data.f32[((b * S + s) * Hq + h) * D + d] * inputs[1]->data.f32[((b * C + c) * Hk + h / (Hq / Hk)) * D + d];
						sum += exp(dot * scale);
					}
					REQUIRE(fabs(lse[(b * Hq + h) * R + rows[s]] - log2(sum)) < 0.02, "saved LSE should preserve head and batch strides");
				}
		REQUIRE(error2 < reference2 * 0.02 * 0.02, "quantized query-range attention should match sampled CPU queries (R=%d C=%d D=%d relative L2=%g)", R, C, D, sqrt(error2 / reference2));
		ccfree(actual);
		ccfree(lse);
		ccv_nnc_tensor_free(sampled_q);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_l);
		ccv_nnc_tensor_free(half_o);
		ccv_nnc_tensor_free(raw_l);
		for (int j = 0; j < 3; ++j)
		{
			ccv_nnc_tensor_free(inputs[j]);
			ccv_nnc_tensor_free(half_inputs[j]);
			ccv_nnc_tensor_free(gpu_inputs[j]);
		}
	}
}

TEST_CASE("scaled dot product attention quantized NA split output inference preserves layout and saved statistics")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int S = 8;
	const int shapes[][6] = {
		{ 4095, 4096, 256, 2, 4, 2 }, { 4096, 4095, 256, 2, 4, 2 }, // FP16 fallback boundaries.
		{ 4096, 4096, 256, 2, 4, 2 }, { 4097, 4097, 256, 2, 4, 2 },
		{ 4112, 4161, 256, 2, 4, 2 }, { 4223, 4225, 256, 2, 4, 2 },
		{ 4224, 4224, 256, 2, 4, 2 }, { 4225, 4353, 256, 2, 4, 2 }, // 128-row group boundaries.
		{ 8193, 8282, 256, 2, 4, 2 }, { 4097, 4097, 256, 2, 4, 2 }, // Reuse a cached dynamic shape.
		{ 4097, 4353, 256, 2, 1, 1 }, // Few-head compact dispatch.
		{ 4097, 4353, 256, 4, 1, 1 }, { 4097, 4353, 256, 1, 4, 2 }
	};
	for (int trial = 0; trial < 4 * (int)(sizeof(shapes) / sizeof(shapes[0])); ++trial)
	{
		const int shape_idx = trial % (sizeof(shapes) / sizeof(shapes[0]));
		const int R = shapes[shape_idx][0], C = shapes[shape_idx][1], D = shapes[shape_idx][2];
		const int B = shapes[shape_idx][3], Hq = shapes[shape_idx][4], Hk = shapes[shape_idx][5];
		const int rows[S] = { 0, 1, 127, 128, R / 2, R - 129, R - 2, R - 1 };
		ccv_nnc_tensor_t* inputs[3];
		ccv_nnc_tensor_t* half_inputs[3];
		ccv_nnc_tensor_t* gpu_inputs[3];
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 961 + trial);
		for (int j = 0; j < 3; ++j)
		{
			const int length = j == 0 ? R : C, heads = j == 0 ? Hq : Hk;
			const int count = B * length * heads * D;
			inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, length, heads, D), 0);
			half_inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, length, heads, D), 0);
			gpu_inputs[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, length, heads, D), 0);
			for (int i = 0; i < count; ++i)
				inputs[j]->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) *
					(j == 2 ? (shape_idx == 7 ? 2000 : 2) : 1);
			ccv_float_to_half_precision(inputs[j]->data.f32, (uint16_t*)half_inputs[j]->data.f16, count);
			ccv_half_precision_to_float((uint16_t*)half_inputs[j]->data.f16, inputs[j]->data.f32, count);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[j]), TENSOR_LIST(gpu_inputs[j]), 0);
		}
		ccv_nnc_tensor_t* const sampled_q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				memcpy(sampled_q->data.f32 + (b * S + s) * Hq * D, inputs[0]->data.f32 + (b * R + rows[s]) * Hq * D, sizeof(float) * Hq * D);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		const float scale = 1.0f / sqrtf(D);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(sampled_q, inputs[1], inputs[2]), TENSOR_LIST(expected), 0);
		const int alias = (trial / (sizeof(shapes) / sizeof(shapes[0]))) % 2;
		ccv_nnc_tensor_t* const gpu_o = alias ? gpu_inputs[0] : ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_l = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_tensor_t* const half_o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const raw_l = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, Hq, R), 0);
		for (int i = 0; i < 2 * B * Hq * R; ++i)
			((uint16_t*)raw_l->data.f32)[i] = 0x7e00;
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(raw_l), TENSOR_LIST(gpu_l), 0);
		ccv_nnc_cmd_t command = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		command.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
		const uint64_t old_flags = ccv_nnc_flags();
		if (trial >= 2 * sizeof(shapes) / sizeof(shapes[0]))
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, CCV_NNC_NO_BACKWARD, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_o, gpu_l), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o, gpu_l), TENSOR_LIST(half_o, raw_l), 0);
		float* const actual = (float*)ccmalloc(sizeof(float) * B * R * Hq * D);
		float* const lse = (float*)ccmalloc(sizeof(float) * B * R * Hq);
		ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
		// The low-precision MFA contract stores log2 LSE in the half prefix.
		ccv_half_precision_to_float((uint16_t*)raw_l->data.f32, lse, B * R * Hq);
		for (int i = 0; i < B * R * Hq * D; ++i)
			REQUIRE(isfinite(actual[i]), "split-output inference output should be finite");
		for (int i = 0; i < B * R * Hq; ++i)
			REQUIRE(isfinite(lse[i]), "split-output inference should write every saved LSE");
		double error2 = 0, reference2 = 0;
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				for (int h = 0; h < Hq; ++h)
				{
					for (int d = 0; d < D; ++d)
					{
						const float ref = expected->data.f32[((b * S + s) * Hq + h) * D + d];
						const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - ref;
						error2 += error * error;
						reference2 += ref * ref;
					}
					double sum = 0;
					for (int c = 0; c < C; ++c)
					{
						double dot = 0;
						for (int d = 0; d < D; ++d)
							dot += sampled_q->data.f32[((b * S + s) * Hq + h) * D + d] * inputs[1]->data.f32[((b * C + c) * Hk + h / (Hq / Hk)) * D + d];
						sum += exp(dot * scale);
					}
					REQUIRE(fabs(lse[(b * Hq + h) * R + rows[s]] - log2(sum)) < 0.02, "saved LSE should preserve head and batch strides");
				}
		REQUIRE(error2 < reference2 * 0.02 * 0.02, "split-output inference attention should match sampled CPU queries (R=%d C=%d D=%d relative L2=%g)", R, C, D, sqrt(error2 / reference2));
		ccfree(actual);
		ccfree(lse);
		ccv_nnc_tensor_free(sampled_q);
		ccv_nnc_tensor_free(expected);
		if (!alias)
			ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_l);
		ccv_nnc_tensor_free(half_o);
		ccv_nnc_tensor_free(raw_l);
		for (int j = 0; j < 3; ++j)
		{
			ccv_nnc_tensor_free(inputs[j]);
			ccv_nnc_tensor_free(half_inputs[j]);
			ccv_nnc_tensor_free(gpu_inputs[j]);
		}
	}
}

TEST_CASE("scaled dot product attention quantized NA partitioned inference preserves tails and saved statistics")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1, S = 8, D = 128;
	const int shapes[][4] = {
		{ 4095, 24577, 48, 12 }, // Query-length fallback boundary.
		{ 4096, 24576, 48, 12 }, { 4097, 24577, 48, 12 },
		{ 8193, 32767, 32, 8 }, // Aggregate-work fallback boundary.
		{ 8193, 32768, 32, 8 },
		{ 4097, 24577, 64, 16 }, // Scratch cap lowers the query chunk to 4032.
		{ 4097, 24577, 48, 12 } // Reuse an earlier dynamic shader shape.
	};
	for (int trial = 0; trial < 2 * (int)(sizeof(shapes) / sizeof(shapes[0])); ++trial)
	{
		const int shape_idx = trial % (sizeof(shapes) / sizeof(shapes[0]));
		const int R = shapes[shape_idx][0], C = shapes[shape_idx][1], Hq = shapes[shape_idx][2], Hk = shapes[shape_idx][3];
		const int rows[S] = { 0, 1, 63, 64, R / 2, R - 65, R - 2, R - 1 };
		ccv_nnc_tensor_t* inputs[3];
		ccv_nnc_tensor_t* half_inputs[3];
		ccv_nnc_tensor_t* gpu_inputs[3];
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 931 + trial);
		for (int j = 0; j < 3; ++j)
		{
			const int length = j == 0 ? R : C, heads = j == 0 ? Hq : Hk;
			const int count = B * length * heads * D;
			inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, length, heads, D), 0);
			half_inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, length, heads, D), 0);
			gpu_inputs[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, length, heads, D), 0);
			for (int i = 0; i < count; ++i)
				inputs[j]->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * (j == 2 ? 2 : 1);
			if (j == 2 && shape_idx == 2)
				for (int i = 0; i < count; ++i)
					inputs[j]->data.f32[i] *= 1000;
			ccv_float_to_half_precision(inputs[j]->data.f32, (uint16_t*)half_inputs[j]->data.f16, count);
			ccv_half_precision_to_float((uint16_t*)half_inputs[j]->data.f16, inputs[j]->data.f32, count);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[j]), TENSOR_LIST(gpu_inputs[j]), 0);
		}
		ccv_nnc_tensor_t* const sampled_q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				memcpy(sampled_q->data.f32 + (b * S + s) * Hq * D, inputs[0]->data.f32 + (b * R + rows[s]) * Hq * D, sizeof(float) * Hq * D);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, S, Hq, D), 0);
		const float scale = 1.0f / sqrtf(D);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(sampled_q, inputs[1], inputs[2]), TENSOR_LIST(expected), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_l = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_tensor_t* const half_o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const raw_l = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, Hq, R), 0);
		ccv_nnc_cmd_t command = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		command.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
		const uint64_t old_flags = ccv_nnc_flags();
		if (trial >= sizeof(shapes) / sizeof(shapes[0]))
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, CCV_NNC_NO_BACKWARD, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_o, gpu_l), 0);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o, gpu_l), TENSOR_LIST(half_o, raw_l), 0);
		float* const actual = (float*)ccmalloc(sizeof(float) * B * R * Hq * D);
		float* const lse = (float*)ccmalloc(sizeof(float) * B * R * Hq);
		ccv_half_precision_to_float((uint16_t*)half_o->data.f16, actual, B * R * Hq * D);
		// The low-precision MFA contract stores log2 LSE in the half prefix.
		ccv_half_precision_to_float((uint16_t*)raw_l->data.f32, lse, B * R * Hq);
		for (int i = 0; i < B * R * Hq * D; ++i)
			REQUIRE(isfinite(actual[i]), "partitioned inference output should be finite");
		double error2 = 0, reference2 = 0;
		for (int b = 0; b < B; ++b)
			for (int s = 0; s < S; ++s)
				for (int h = 0; h < Hq; ++h)
				{
					for (int d = 0; d < D; ++d)
					{
						const float ref = expected->data.f32[((b * S + s) * Hq + h) * D + d];
						const double error = actual[((b * R + rows[s]) * Hq + h) * D + d] - ref;
						error2 += error * error;
						reference2 += ref * ref;
					}
					double sum = 0;
					for (int c = 0; c < C; ++c)
					{
						double dot = 0;
						for (int d = 0; d < D; ++d)
							dot += sampled_q->data.f32[((b * S + s) * Hq + h) * D + d] * inputs[1]->data.f32[((b * C + c) * Hk + h / (Hq / Hk)) * D + d];
						sum += exp(dot * scale);
					}
					REQUIRE(fabs(lse[(b * Hq + h) * R + rows[s]] - log2(sum)) < 0.02, "saved LSE should preserve head and batch strides");
				}
		REQUIRE(error2 < reference2 * 0.02 * 0.02, "partitioned inference attention should match sampled CPU queries (R=%d C=%d D=%d relative L2=%g)", R, C, D, sqrt(error2 / reference2));
		if (shape_idx == 2)
		{
			if (trial >= sizeof(shapes) / sizeof(shapes[0]))
				ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
			ccv_nnc_cmd_exec(command, ccv_nnc_no_hint, CCV_NNC_NO_BACKWARD, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_inputs[0], gpu_l), 0);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M);
			if (!(old_flags & CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C))
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
			ccv_nnc_tensor_t* const in_place = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_inputs[0]), TENSOR_LIST(in_place), 0);
			REQUIRE_ARRAY_EQ(uint16_t, in_place->data.f16, half_o->data.f16, B * R * Hq * D, "partitioned exact Q/O reuse should preserve the output");
			ccv_nnc_tensor_free(in_place);
		}
		ccfree(actual);
		ccfree(lse);
		ccv_nnc_tensor_free(sampled_q);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_l);
		ccv_nnc_tensor_free(half_o);
		ccv_nnc_tensor_free(raw_l);
		for (int j = 0; j < 3; ++j)
		{
			ccv_nnc_tensor_free(inputs[j]);
			ccv_nnc_tensor_free(half_inputs[j]);
			ccv_nnc_tensor_free(gpu_inputs[j]);
		}
	}
}

TEST_CASE("scaled dot product attention with NA mps splitKV decode")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const struct {
		int R;
		int C;
		int Hq;
		int Hk;
		int D;
	} cases[] = {
		{ 1, 1536, 40, 4, 256 },
		{ 1, 2112, 8, 8, 256 },
		{ 1, 2113, 8, 8, 256 },
		{ 1, 8193, 40, 4, 256 },
		{ 2, 4096, 8, 8, 128 },
		{ 7, 4096, 8, 8, 128 },
		{ 7, 4097, 8, 8, 128 },
		{ 16, 4096, 8, 8, 128 },
		{ 16, 4096, 32, 8, 128 },
		{ 16, 4097, 32, 8, 128 },
		{ 32, 4096, 4, 4, 128 },
	};
	for (int case_idx = 0; case_idx < sizeof(cases) / sizeof(cases[0]); ++case_idx)
	{
		const int R = cases[case_idx].R;
		const int C = cases[case_idx].C;
		const int Hq = cases[case_idx].Hq;
		const int Hk = cases[case_idx].Hk;
		const int D = cases[case_idx].D;
		const int q_count = B * R * Hq * D;
		const int kv_count = B * C * Hk * D;
		const float scale = 1.0 / sqrt((float)D);
		for (int is_causal = 0; is_causal <= 1; ++is_causal)
		{
			ccv_nnc_tensor_t* const q_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
			ccv_nnc_tensor_t* const k_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
			ccv_nnc_tensor_t* const v_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
			ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
			ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
			ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
			for (int i = 0; i < q_count; ++i)
				q_tensor_ref->data.f32[i] = (float)((i * 17 + is_causal * 13 + R * 5) % 61 - 30) * (1.0 / 128);
			for (int i = 0; i < kv_count; ++i)
			{
				k_tensor_ref->data.f32[i] = (float)((i * 19 + R * 7) % 67 - 33) * (1.0 / 128);
				v_tensor_ref->data.f32[i] = (float)((i * 23 + C / 32) % 127 - 63) * (1.0 / 512);
			}
			ccv_float_to_half_precision(q_tensor_ref->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
			ccv_float_to_half_precision(k_tensor_ref->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
			ccv_float_to_half_precision(v_tensor_ref->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
			ccv_half_precision_to_float((uint16_t*)q_tensor_f16->data.f16, q_tensor_ref->data.f32, q_count);
			ccv_half_precision_to_float((uint16_t*)k_tensor_f16->data.f16, k_tensor_ref->data.f32, kv_count);
			ccv_half_precision_to_float((uint16_t*)v_tensor_f16->data.f16, v_tensor_ref->data.f32, kv_count);
			ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_ref, k_tensor_ref, v_tensor_ref), TENSOR_LIST(o_tensor), 0);
			ccv_nnc_tensor_t* const o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
			ccv_float_to_half_precision(o_tensor->data.f32, (uint16_t*)o_tensor_f16->data.f16, q_count);
			ccv_half_precision_to_float((uint16_t*)o_tensor_f16->data.f16, o_tensor->data.f32, q_count);

			ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
			ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
			ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
			ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
			ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
			ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

			float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
			ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, q_count);
			float max_abs_diff = 0;
			float max_relative_diff = 0;
			int max_diff_idx = 0;
			for (int i = 0; i < q_count; ++i)
			{
				REQUIRE(isfinite(gpu_f32[i]), "splitKV NA attention output should stay finite for R=%d C=%d Hq=%d Hk=%d D=%d causal=%d at %d", R, C, Hq, Hk, D, is_causal, i);
				const float abs_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]);
				const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
				const float relative_diff = abs_diff / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_abs_diff = abs_diff, max_diff_idx = i;
			}
			REQUIRE(max_relative_diff <= 2e-3, "splitKV NA attention should match half-rounded CPU reference for R=%d C=%d Hq=%d Hk=%d D=%d causal=%d (max abs %g relative %g at %d: CPU %g GPU %g)", R, C, Hq, Hk, D, is_causal, max_abs_diff, max_relative_diff, max_diff_idx, o_tensor->data.f32[max_diff_idx], gpu_f32[max_diff_idx]);

			ccfree(gpu_f32);
			ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_v_tensor);
			ccv_nnc_tensor_free(gpu_k_tensor);
			ccv_nnc_tensor_free(gpu_q_tensor);
			ccv_nnc_tensor_free(o_tensor_f16);
			ccv_nnc_tensor_free(o_tensor);
			ccv_nnc_tensor_free(v_tensor_ref);
			ccv_nnc_tensor_free(k_tensor_ref);
			ccv_nnc_tensor_free(q_tensor_ref);
			ccv_nnc_tensor_free(q_tensor_f16);
			ccv_nnc_tensor_free(k_tensor_f16);
			ccv_nnc_tensor_free(v_tensor_f16);
		}
	}
}

TEST_CASE("scaled dot product attention with BF16 R1 mps decode")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 1;
	const int C = 4097;
	const int Hq = 40;
	const int Hk = 4;
	const int D = 256;
	const int q_count = B * R * Hq * D;
	const int kv_count = B * C * Hk * D;
	const float scale = 1.0 / sqrt((float)D);
	for (int is_causal = 0; is_causal <= 1; ++is_causal)
	{
		ccv_nnc_tensor_t* const q_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const q_tensor_bf16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_bf16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_bf16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		for (int i = 0; i < q_count; ++i)
			q_tensor_ref->data.f32[i] = (float)((i * 13 + is_causal * 7) % 71 - 35) * (1.0 / 128);
		for (int i = 0; i < kv_count; ++i)
		{
			k_tensor_ref->data.f32[i] = (float)((i * 17 + C / 16) % 79 - 39) * (1.0 / 128);
			v_tensor_ref->data.f32[i] = (float)((i * 29 + Hq) % 127 - 63) * (1.0 / 512);
		}
		ccv_float_to_bfloat(q_tensor_ref->data.f32, (uint16_t*)q_tensor_bf16->data.f16, q_count);
		ccv_float_to_bfloat(k_tensor_ref->data.f32, (uint16_t*)k_tensor_bf16->data.f16, kv_count);
		ccv_float_to_bfloat(v_tensor_ref->data.f32, (uint16_t*)v_tensor_bf16->data.f16, kv_count);
		ccv_bfloat_to_float((uint16_t*)q_tensor_bf16->data.f16, q_tensor_ref->data.f32, q_count);
		ccv_bfloat_to_float((uint16_t*)k_tensor_bf16->data.f16, k_tensor_ref->data.f32, kv_count);
		ccv_bfloat_to_float((uint16_t*)v_tensor_bf16->data.f16, v_tensor_ref->data.f32, kv_count);

		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_ref, k_tensor_ref, v_tensor_ref), TENSOR_LIST(o_tensor), 0);
		ccv_nnc_tensor_t* const o_tensor_bf16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_float_to_bfloat(o_tensor->data.f32, (uint16_t*)o_tensor_bf16->data.f16, q_count);
		ccv_bfloat_to_float((uint16_t*)o_tensor_bf16->data.f16, o_tensor->data.f32, q_count);

		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_bf16, k_tensor_bf16, v_tensor_bf16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
		ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

		float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
		ccv_bfloat_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, q_count);
		float max_abs_diff = 0;
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < q_count; ++i)
		{
			REQUIRE(isfinite(gpu_f32[i]), "BF16 R1 attention output should stay finite for C=%d Hq=%d Hk=%d D=%d causal=%d at %d", C, Hq, Hk, D, is_causal, i);
			const float abs_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]);
			const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
			const float relative_diff = abs_diff / denom;
			if (relative_diff > max_relative_diff)
				max_relative_diff = relative_diff, max_abs_diff = abs_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 8e-3, "BF16 R1 attention should match bfloat-rounded CPU reference for C=%d Hq=%d Hk=%d D=%d causal=%d (max abs %g relative %g at %d: CPU %g GPU %g)", C, Hq, Hk, D, is_causal, max_abs_diff, max_relative_diff, max_diff_idx, o_tensor->data.f32[max_diff_idx], gpu_f32[max_diff_idx]);

		ccfree(gpu_f32);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(o_tensor_bf16);
		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(v_tensor_ref);
		ccv_nnc_tensor_free(k_tensor_ref);
		ccv_nnc_tensor_free(q_tensor_ref);
		ccv_nnc_tensor_free(q_tensor_bf16);
		ccv_nnc_tensor_free(k_tensor_bf16);
		ccv_nnc_tensor_free(v_tensor_bf16);
	}
}

TEST_CASE("scaled dot product attention with attention sinks on mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	float max_abs = 0;
	float max_relative = 0;
	float expected = 0;
	float actual = 0;
	int max_idx = 0;
	int status = _mps_sdpa_attention_sinks_compare(CCV_32F, 1, 0, 1, 17, 23, 4, 2, 64, 0, 1, 0, 2e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "generic global sink should run and match CPU reference with attention sinks (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, CCV_NNC_GEMM_16F, 1, 47, 41, 8, 8, 64, 0, 8, 0, 5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "NA per-head sink should run and match CPU reference with attention sinks (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, CCV_NNC_GEMM_16F, 1, 17, 23, 8, 4, 64, 1, 8, 4, 5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "NA sliding-window grouped-query per-head sink should match CPU reference (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 1, CCV_NNC_GEMM_16F, 1, 17, 23, 8, 4, 64, 1, 8, 4, 5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "generic MFA sliding-window grouped-query per-head sink should match CPU reference (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, CCV_NNC_GEMM_16F, 1, 23, 23, 8, 8, 64, 1, 8, 1, 5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "NA sliding-window size 1 per-head sink should match CPU reference (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, CCV_NNC_GEMM_16F, 1, 17, 23, 8, 8, 64, 1, 8, 64, 5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "NA sliding-window size covering C should match CPU reference (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, CCV_NNC_GEMM_16F, 1, 7, 4096, 8, 8, 128, 1, 8, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "NA splitKV per-head sink should run and match CPU reference with attention sinks (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, 0, 1, 1, 1536, 8, 4, 128, 1, 8, 0, 5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "R1 direct per-head sink should run and match CPU reference with attention sinks (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, 0, 1, 1, 4097, 8, 4, 128, 1, 8, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "R1 split per-head sink should run and match CPU reference with attention sinks (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);

	max_abs = 0;
	max_relative = 0;
	expected = 0;
	actual = 0;
	max_idx = 0;
	status = _mps_sdpa_attention_sinks_compare(CCV_16F, 0, CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I, 1, 64, 64, 8, 8, 128, 0, 8, 0, 5e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0, "NAInt8 per-head sink should run and match CPU reference with attention sinks (status %d max abs %g relative %g at %d: CPU %g GPU %g)", status, max_abs, max_relative, max_idx, expected, actual);
}

TEST_CASE("scaled dot product attention generic FP32 in-place output preserves queries")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const struct {
		int B, R, C, D, is_causal, offset, has_lse;
	} cases[] = {
		// D=512 spills both Q and O across KV tiles in AttentionKernel.
		{ 1, 129, 129, 512, 0, 0, 0 },
		{ 1, 129, 129, 512, 1, 1, 1 },
		{ 2, 257, 513, 512, 0, 1, 1 },
		{ 2, 257, 513, 512, 1, 0, 0 },
		{ 1, 1, 513, 512, 1, 1, 0 },
		// Also cover the register-cached case with the same staging policy.
		{ 2, 17, 129, 64, 1, 1, 1 },
	};
	const int Hq = 4, Hk = 1;
	for (int c = 0; c < sizeof(cases) / sizeof(cases[0]); c++)
	{
		const int B = cases[c].B, R = cases[c].R, C = cases[c].C, D = cases[c].D;
		const int offset = cases[c].offset * Hq * D;
		const int q_count = B * R * Hq * D;
		const int kv_count = B * C * Hk * D;
		ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const expected = ccv_nnc_tensor_new(0, q->info, 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, q->info, 0);
		ccv_nnc_tensor_t* const storage = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, q_count + offset + Hq * D), 0);
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, c + 41);
		for (int i = 0; i < q_count; i++)
			q->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 2;
		for (int i = 0; i < kv_count; i++)
		{
			k->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 2;
			v->data.f32[i] = (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 2;
		}
		for (int i = 0; i < q_count + offset + Hq * D; i++)
			storage->data.f32[i] = -123;
		ccv_nnc_tensor_t* const gpu_storage = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, q_count + offset + Hq * D), 0);
		ccv_nnc_tensor_view_t* const gpu_q = ccv_nnc_tensor_view_new(gpu_storage, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), DIM_ALLOC(0, cases[c].offset, 0, 0), DIM_ALLOC(R * Hq * D, Hq * D, D, 1));
		ccv_nnc_tensor_t* const gpu_k = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_lse = cases[c].has_lse ? ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0) : 0;
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(storage, k, v), TENSOR_LIST(gpu_storage, gpu_k, gpu_v), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q), TENSOR_LIST((ccv_nnc_tensor_t*)gpu_q), 0);
		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0 / sqrtf((float)D), cases[c].is_causal);
		const int cpu_status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, v), TENSOR_LIST(expected), 0);
		ccv_nnc_stream_context_t* const stream = ccv_nnc_stream_context_new(CCV_STREAM_CONTEXT_GPU);
		const uint64_t old_flags = ccv_nnc_flags();
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		const int gpu_status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)gpu_q, gpu_k, gpu_v), TENSOR_LIST((ccv_nnc_tensor_t*)gpu_q, gpu_lse), stream);
		// A subsequent compute dispatch must still work after the blit encoder.
		const int followup_status = ccv_nnc_cmd_exec(CMD_SCALAR_MUL_FORWARD(2), ccv_nnc_no_hint, 0, TENSOR_LIST((ccv_nnc_tensor_t*)gpu_q), TENSOR_LIST(gpu_o), stream);
		ccv_nnc_stream_context_wait(stream);
		if (!(old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS))
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o, gpu_storage), TENSOR_LIST(actual, storage), 0);
		REQUIRE_EQ(cpu_status, CCV_NNC_EXEC_SUCCESS, "CPU reference should execute for case %d", c);
		REQUIRE_EQ(gpu_status, CCV_NNC_EXEC_SUCCESS, "in-place generic attention should execute for case %d", c);
		REQUIRE_EQ(followup_status, CCV_NNC_EXEC_SUCCESS, "compute should resume after the blit for case %d", c);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, storage->data.f32 + offset, expected->data.f32, q_count, 1e-5, "in-place attention should match CPU for case %d", c);
		for (int i = 0; i < q_count; i++)
		{
			REQUIRE(isfinite(storage->data.f32[offset + i]) && isfinite(actual->data.f32[i]), "attention and subsequent compute should stay finite for case %d at %d", c, i);
			expected->data.f32[i] *= 2;
		}
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, expected->data.f32, q_count, 2e-5, "compute after the blit should read the final output for case %d", c);
		for (int i = 0; i < offset; i++)
			REQUIRE_EQ(storage->data.f32[i], -123, "blit should preserve the destination prefix for case %d", c);
		for (int i = offset + q_count; i < offset + q_count + Hq * D; i++)
			REQUIRE_EQ(storage->data.f32[i], -123, "blit should preserve the destination suffix for case %d", c);
		ccv_nnc_stream_context_free(stream);
		if (gpu_lse)
			ccv_nnc_tensor_free(gpu_lse);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_v);
		ccv_nnc_tensor_free(gpu_k);
		ccv_nnc_tensor_view_free(gpu_q);
		ccv_nnc_tensor_free(gpu_storage);
		ccv_nnc_tensor_free(storage);
		ccv_nnc_tensor_free(actual);
		ccv_nnc_tensor_free(expected);
		ccv_nnc_tensor_free(v);
		ccv_nnc_tensor_free(k);
		ccv_nnc_tensor_free(q);
	}
}


TEST_CASE("scaled dot product attention sliding window ignores poisoned accumulator scratch")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
#ifdef HAVE_MPS
	const size_t scratch_bytes = 4 * 1024 * 1024;
	float* const poison = ccmalloc(scratch_bytes);
	for (size_t i = 0; i < scratch_bytes / sizeof(float); i++)
		poison[i] = NAN;
	mtl_buffer_t* const scratch = ccv_nnc_mfa_request_scratch(ccv_nnc_default_mfa_context(), scratch_bytes);
	mpmemcpy(scratch, 0, CCV_TENSOR_GPU_MEMORY, poison, 0, CCV_TENSOR_CPU_MEMORY, scratch_bytes);
	ccfree(poison);
	float max_abs = 0, max_relative = 0, expected = 0, actual = 0;
	int max_idx = 0;
	// D=512 spills O to scratch. With C > R and a short causal window, even
	// the first query starts at a nonzero key tile and must not load old O.
	const int status = _mps_sdpa_attention_sinks_compare(
		CCV_16F, 1, CCV_NNC_GEMM_16F, 1, 257, 513, 4, 1, 512, 1, 4, 32,
		5e-3, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(status, 0,
		"sliding-window attention must initialize its first accumulator despite NaN scratch (status %d max abs %g relative %g at %d: CPU %g GPU %g)",
		status, max_abs, max_relative, max_idx, expected, actual);
#endif
}

TEST_CASE("scaled dot product attention with varlen NA mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 4;
	const int Hq = 4;
	const int Hk = 2;
	const int D = 64;
	const int q_offsets[2][5] = {
		{ 0, 17, 80, 145, 223 },
		{ 0, 16, 81, 147, 226 },
	};
	const int kv_offsets[2][5] = {
		{ 0, 19, 83, 150, 229 },
		{ 0, 18, 82, 149, 229 },
	};
	const int max_seqlen_q[2] = { 78, 79 };
	const int max_seqlen_kv[2] = { 79, 80 };
	for (int trial = 0; trial < 2; ++trial)
	{
		const int is_causal = trial;
		const int total_q = q_offsets[trial][B];
		const int total_k = kv_offsets[trial][B];
		const float scale = 1.0 / sqrt((float)D);
		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_k, Hk, D), 0);
		for (int i = 0; i < total_q * Hq * D; ++i)
			q_tensor->data.f32[i] = (float)((i * 17) % 97 - 48) / 256;
		for (int i = 0; i < total_k * Hk * D; ++i)
		{
			k_tensor->data.f32[i] = (float)((i * 13) % 89 - 44) / 256;
			v_tensor->data.f32[i] = (float)((i * 19) % 101 - 50) / 128;
		}
		ccv_nnc_tensor_t* const o_tensor_ref = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		for (int b = 0; b < B; ++b)
		{
			const int q_start = q_offsets[trial][b];
			const int k_start = kv_offsets[trial][b];
			const int R = q_offsets[trial][b + 1] - q_start;
			const int C = kv_offsets[trial][b + 1] - k_start;
			ccv_nnc_tensor_t* const q_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, R, Hq, D), 0);
			ccv_nnc_tensor_t* const k_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, C, Hk, D), 0);
			ccv_nnc_tensor_t* const v_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, C, Hk, D), 0);
			ccv_nnc_tensor_t* const o_seq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, R, Hq, D), 0);
			memcpy(q_seq->data.f32, q_tensor->data.f32 + q_start * Hq * D, sizeof(float) * R * Hq * D);
			memcpy(k_seq->data.f32, k_tensor->data.f32 + k_start * Hk * D, sizeof(float) * C * Hk * D);
			memcpy(v_seq->data.f32, v_tensor->data.f32 + k_start * Hk * D, sizeof(float) * C * Hk * D);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_seq, k_seq, v_seq), TENSOR_LIST(o_seq), 0);
			memcpy(o_tensor_ref->data.f32 + q_start * Hq * D, o_seq->data.f32, sizeof(float) * R * Hq * D);
			ccv_nnc_tensor_free(q_seq);
			ccv_nnc_tensor_free(k_seq);
			ccv_nnc_tensor_free(v_seq);
			ccv_nnc_tensor_free(o_seq);
		}
		ccv_nnc_tensor_t* const h_q_seq_offsets = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, B + 1), 0);
		ccv_nnc_tensor_t* const h_kv_seq_offsets = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, B + 1), 0);
		for (int i = 0; i < B + 1; ++i)
		{
			h_q_seq_offsets->data.i32[i] = q_offsets[trial][i];
			h_kv_seq_offsets->data.i32[i] = kv_offsets[trial][i];
		}
		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
		cmd.info.scaled_dot_product_attention.is_varlen = 1;
		cmd.info.scaled_dot_product_attention.max_seqlen_q = max_seqlen_q[trial];
		cmd.info.scaled_dot_product_attention.max_seqlen_kv = max_seqlen_kv[trial];
		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, NULL, NULL, NULL, h_q_seq_offsets, h_kv_seq_offsets), TENSOR_LIST(o_tensor, NULL), 0);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, o_tensor->data.f32, o_tensor_ref->data.f32, total_q * Hq * D, 1e-5, "varlen CPU computed output should match per-sequence CPU output when causal=%d", is_causal);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_k, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), 0);
		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_q, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_k, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_q_seq_offsets = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, B + 1), 0);
		ccv_nnc_tensor_t* const gpu_kv_seq_offsets = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, B + 1), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, h_q_seq_offsets, h_kv_seq_offsets), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_q_seq_offsets, gpu_kv_seq_offsets), 0);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL, gpu_q_seq_offsets, gpu_kv_seq_offsets), TENSOR_LIST(gpu_o_tensor, NULL), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor_f16), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(copy_of_gpu_o_tensor_f16), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_o_tensor->data.f32, o_tensor->data.f32, total_q * Hq * D, 5e-3, "varlen MPS computed output should match packed CPU output when causal=%d", is_causal);
		ccv_nnc_cmd_t int8_cmd = cmd;
		int8_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
		ccv_nnc_tensor_t* const gpu_o_tensor_int8 = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(int8_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL, gpu_q_seq_offsets, gpu_kv_seq_offsets), TENSOR_LIST(gpu_o_tensor_int8, NULL), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor_int8_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor_int8), TENSOR_LIST(copy_of_gpu_o_tensor_int8_f16), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor_int8 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, total_q, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(copy_of_gpu_o_tensor_int8_f16), TENSOR_LIST(copy_of_gpu_o_tensor_int8), 0);
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < total_q * Hq * D; ++i)
		{
			const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(copy_of_gpu_o_tensor_int8->data.f32[i])), 1.0f);
			const float relative_diff = fabsf(o_tensor->data.f32[i] - copy_of_gpu_o_tensor_int8->data.f32[i]) / denom;
			if (relative_diff > max_relative_diff)
				max_relative_diff = relative_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 5e-2, "varlen quantized MPS output should match packed CPU output when causal=%d (max relative diff %g at %d: %g vs %g)", is_causal, max_relative_diff, max_diff_idx, o_tensor->data.f32[max_diff_idx], copy_of_gpu_o_tensor_int8->data.f32[max_diff_idx]);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(o_tensor_ref);
		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(h_q_seq_offsets);
		ccv_nnc_tensor_free(h_kv_seq_offsets);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(gpu_q_seq_offsets);
		ccv_nnc_tensor_free(gpu_kv_seq_offsets);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor_int8);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor_int8_f16);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor_int8);
	}
}

TEST_CASE("scaled dot product attention with quantized NA mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 128;
	const int C = 64;
	const int H = 24;
	const int Ds[] = { 64, 80, 128, 130, 160, 192, 224, 256 };
	const int datatypes[] = { CCV_16F, CCV_16BF, CCV_32F };
	const float tolerances[] = { 2e-2, 3e-2, 2e-2 };
	const char* datatype_names[] = { "16F", "16BF", "32F" };
	for (int d_idx = 0; d_idx < (int)(sizeof(Ds) / sizeof(Ds[0])); ++d_idx)
	{
		const int D = Ds[d_idx];
		const float scale = 1.0 / sqrt((float)D);

		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		const int q_count = B * R * H * D;
		const int kv_count = B * C * H * D;
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 11 + d_idx);
		for (int i = 0; i < q_count; ++i)
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		for (int i = 0; i < kv_count; ++i)
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		for (int i = 0; i < kv_count; ++i)
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;

		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_cmd_t cpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);

		for (int datatype_idx = 0; datatype_idx < 3; ++datatype_idx)
		{
			const int datatype = datatypes[datatype_idx];
			ccv_nnc_tensor_t* q_input = q_tensor;
			ccv_nnc_tensor_t* k_input = k_tensor;
			ccv_nnc_tensor_t* v_input = v_tensor;
			ccv_nnc_tensor_t* copy_of_gpu_o_tensor = 0;
			ccv_nnc_tensor_t* gpu_q_tensor = 0;
			ccv_nnc_tensor_t* gpu_k_tensor = 0;
			ccv_nnc_tensor_t* gpu_v_tensor = 0;
			ccv_nnc_tensor_t* gpu_o_tensor = 0;
			if (datatype == CCV_16F)
			{
				ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
				ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
				ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
				q_input = q_tensor_f16;
				k_input = k_tensor_f16;
				v_input = v_tensor_f16;
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			} else if (datatype == CCV_16BF) {
				ccv_float_to_bfloat(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
				ccv_float_to_bfloat(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
				ccv_float_to_bfloat(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
				q_input = q_tensor_f16;
				k_input = k_tensor_f16;
				v_input = v_tensor_f16;
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, H, D), 0);
			} else {
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			}
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_input, k_input, v_input), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
			ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
			gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

			const int count = B * R * H * D;
			float* const cpu_f32 = (float*)ccmalloc(sizeof(float) * count);
			float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * count);
			memcpy(cpu_f32, o_tensor->data.f32, sizeof(float) * count);
			if (datatype == CCV_16F)
				ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
			else if (datatype == CCV_16BF)
				ccv_bfloat_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
			else
				memcpy(gpu_f32, copy_of_gpu_o_tensor->data.f32, sizeof(float) * count);
			float max_relative_diff = 0;
			int max_diff_idx = 0;
			for (int i = 0; i < count; ++i)
			{
				const float denom = fmaxf(fmaxf(fabsf(cpu_f32[i]), fabsf(gpu_f32[i])), 1.0f);
				const float relative_diff = fabsf(cpu_f32[i] - gpu_f32[i]) / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_diff_idx = i;
			}
			REQUIRE(max_relative_diff <= tolerances[datatype_idx], "quantized attention result should match CPU reference for dtype=%s D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], D, max_relative_diff, max_diff_idx, cpu_f32[max_diff_idx], gpu_f32[max_diff_idx]);

			ccfree(cpu_f32);
			ccfree(gpu_f32);
			ccv_nnc_tensor_free(gpu_o_tensor);
			ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_q_tensor);
			ccv_nnc_tensor_free(gpu_k_tensor);
			ccv_nnc_tensor_free(gpu_v_tensor);
		}
		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
	}
}

TEST_CASE("scaled dot product attention with quantized NA mps and zero mask")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 128;
	const int C = 64;
	const int H = 16;
	const int D = 128;
	const float scale = 1.0 / sqrt((float)D);
	const int q_count = B * R * H * D;
	const int kv_count = B * C * H * D;
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const zero_mask = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const causal_visible_zero_mask = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1, R, C), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 23);
	for (int i = 0; i < q_count; ++i)
		q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < kv_count; ++i)
		k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < kv_count; ++i)
		v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	memset(zero_mask->data.f16, 0, sizeof(uint16_t) * R * C);
	float* const causal_visible_zero_mask_f32 = (float*)ccmalloc(sizeof(float) * R * C);
	for (int i = 0; i < R; ++i)
		for (int j = 0; j < C; ++j)
			causal_visible_zero_mask_f32[i * C + j] = (j <= i + C - R) ? 0 : 1;
	ccv_float_to_half_precision(causal_visible_zero_mask_f32, (uint16_t*)causal_visible_zero_mask->data.f16, R * C);
	ccfree(causal_visible_zero_mask_f32);
	ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
	ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_zero_mask = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const gpu_causal_visible_zero_mask = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1, R, C), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, zero_mask, causal_visible_zero_mask), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_zero_mask, gpu_causal_visible_zero_mask), 0);
	for (int is_causal = 0; is_causal <= 1; ++is_causal)
	{
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const gpu_masked_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_masked_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
		gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
		ccv_nnc_tensor_t* const gpu_mask_tensor = is_causal ? gpu_causal_visible_zero_mask : gpu_zero_mask;
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_mask_tensor), TENSOR_LIST(gpu_masked_o_tensor), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor, gpu_masked_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor, copy_of_gpu_masked_o_tensor), 0);

		const int count = B * R * H * D;
		float* const unmasked_f32 = (float*)ccmalloc(sizeof(float) * count);
		float* const masked_f32 = (float*)ccmalloc(sizeof(float) * count);
		ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, unmasked_f32, count);
		ccv_half_precision_to_float((uint16_t*)copy_of_gpu_masked_o_tensor->data.f16, masked_f32, count);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, masked_f32, unmasked_f32, count, 1e-3, "zero-mask quantized attention should match unmasked quantized attention when causal=%d", is_causal);
		ccfree(masked_f32);
		ccfree(unmasked_f32);
		ccv_nnc_tensor_free(copy_of_gpu_masked_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_masked_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
	}
	ccv_nnc_tensor_free(gpu_causal_visible_zero_mask);
	ccv_nnc_tensor_free(gpu_zero_mask);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(causal_visible_zero_mask);
	ccv_nnc_tensor_free(zero_mask);
	ccv_nnc_tensor_free(q_tensor_f16);
	ccv_nnc_tensor_free(k_tensor_f16);
	ccv_nnc_tensor_free(v_tensor_f16);
	ccv_nnc_tensor_free(q_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(v_tensor);
}

TEST_CASE("scaled dot product attention with quantized NA mps and numeric mask")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 64;
	const int C = 64;
	const int H = 8;
	const int D = 128;
	const float scale = 1.0 / sqrt((float)D);
	const int q_count = B * R * H * D;
	const int kv_count = B * C * H * D;
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const mask_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, R, C), 0);
	ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const mask_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, 1, R, C), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 29);
	for (int i = 0; i < q_count; ++i)
		q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < kv_count; ++i)
		k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < kv_count; ++i)
		v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	for (int i = 0; i < R; ++i)
		for (int j = 0; j < C; ++j)
			mask_tensor->data.f32[i * C + j] = ((i * 13 + j * 7) % 11 == 0) ? -0.75 : (((i + j) % 5 == 0) ? 0.125 : 0);
	ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
	ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(mask_tensor->data.f32, (uint16_t*)mask_tensor_f16->data.f16, R * C);

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_mask_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, 1, R, C), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, mask_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_mask_tensor), 0);
	for (int is_causal = 0; is_causal <= 1; ++is_causal)
	{
		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, mask_tensor), TENSOR_LIST(o_tensor), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
		gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_mask_tensor), TENSOR_LIST(gpu_o_tensor), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		const int count = B * R * H * D;
		float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * count);
		ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
		float max_relative_diff = 0;
		int max_diff_idx = 0;
		for (int i = 0; i < count; ++i)
		{
			const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
			const float relative_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]) / denom;
			if (relative_diff > max_relative_diff)
				max_relative_diff = relative_diff, max_diff_idx = i;
		}
		REQUIRE(max_relative_diff <= 5e-2, "numeric-mask quantized attention should match CPU reference when causal=%d (max relative diff %g at %d: %g vs %g)", is_causal, max_relative_diff, max_diff_idx, o_tensor->data.f32[max_diff_idx], gpu_f32[max_diff_idx]);
		ccfree(gpu_f32);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(o_tensor);
	}
	ccv_nnc_tensor_free(gpu_mask_tensor);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(mask_tensor_f16);
	ccv_nnc_tensor_free(v_tensor_f16);
	ccv_nnc_tensor_free(k_tensor_f16);
	ccv_nnc_tensor_free(q_tensor_f16);
	ccv_nnc_tensor_free(mask_tensor);
	ccv_nnc_tensor_free(v_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(q_tensor);
}

TEST_CASE("scaled dot product attention with quantized causal NA mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int H = 8;
	const int Ds[] = { 64, 256 };
	const int is_causal = 1;
	const float tolerance = 4e-3;
	const float empty_row_tolerance = 1e-6;
	const int shapes[][2] = {
		{ 17, 64 }, // R remainder, R < C.
		{ 47, 41 }, // R and C remainders, R > C.
		{ 65, 37 }, // R > C with many empty causal rows.
		{ 79, 80 }, // R and C remainders, R < C by one.
		{ 47, 47 }, // R == C, remainder-only traversal.
		{ 65, 65 }, // R == C, full and remainder traversal.
		{ 83, 97 }, // Both R and C arbitrary, R < C.
		{ 97, 83 }, // Both R and C arbitrary, R > C.
		{ 128, 64 }, // Existing covered shape.
	};
	for (int d_idx = 0; d_idx < (int)(sizeof(Ds) / sizeof(Ds[0])); ++d_idx)
	{
		const int D = Ds[d_idx];
		const float scale = 1.0 / sqrt((float)D);
		for (int shape_idx = 0; shape_idx < (int)(sizeof(shapes) / sizeof(shapes[0])); ++shape_idx)
		{
			const int R = shapes[shape_idx][0];
			const int C = shapes[shape_idx][1];
			const int q_count = B * R * H * D;
			const int kv_count = B * C * H * D;
			ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			// Zero Q/K makes causal attention average exactly the visible V columns.
			memset(q_tensor->data.f32, 0, sizeof(float) * q_count);
			memset(k_tensor->data.f32, 0, sizeof(float) * kv_count);
			memset(v_tensor->data.f32, 0, sizeof(float) * kv_count);
			for (int c = 0; c < C; ++c)
				for (int h = 0; h < H; ++h)
				{
					const int sentinel_d = (c * 17 + h * 13) % D;
					v_tensor->data.f32[(c * H + h) * D + sentinel_d] = 1;
				}
			ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
			ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
			ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
			ccv_half_precision_to_float((uint16_t*)q_tensor_f16->data.f16, q_tensor->data.f32, q_count);
			ccv_half_precision_to_float((uint16_t*)k_tensor_f16->data.f16, k_tensor->data.f32, kv_count);
			ccv_half_precision_to_float((uint16_t*)v_tensor_f16->data.f16, v_tensor->data.f32, kv_count);

			ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);

			ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
			ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal);
			gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

			const int count = B * R * H * D;
			float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * count);
			ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
			float max_relative_diff = 0;
			float max_abs_diff = 0;
			int max_diff_idx = 0;
			for (int i = 0; i < count; ++i)
			{
				REQUIRE(isfinite(gpu_f32[i]), "quantized causal attention output should stay finite for R=%d C=%d D=%d at %d", R, C, D, i);
				const int r = (i / (H * D)) % R;
				if (R > C && r < R - C)
					REQUIRE(fabsf(gpu_f32[i]) <= empty_row_tolerance, "quantized causal attention should zero empty leading row for R=%d C=%d D=%d at r=%d idx=%d: GPU %g", R, C, D, r, i, gpu_f32[i]);
				const float denom = fmaxf(fmaxf(fabsf(o_tensor->data.f32[i]), fabsf(gpu_f32[i])), 1.0f);
				const float abs_diff = fabsf(o_tensor->data.f32[i] - gpu_f32[i]);
				const float relative_diff = abs_diff / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_abs_diff = abs_diff, max_diff_idx = i;
			}
			const int max_diff_d = max_diff_idx % D;
			const int max_diff_h = (max_diff_idx / D) % H;
			const int max_diff_r = (max_diff_idx / (H * D)) % R;
			REQUIRE(max_abs_diff <= tolerance, "quantized causal attention result should match CPU reference for R=%d C=%d D=%d (max abs %g relative %g at r=%d h=%d d=%d idx=%d: CPU %g GPU %g)", R, C, D, max_abs_diff, max_relative_diff, max_diff_r, max_diff_h, max_diff_d, max_diff_idx, o_tensor->data.f32[max_diff_idx], gpu_f32[max_diff_idx]);

			ccfree(gpu_f32);
			ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_q_tensor);
			ccv_nnc_tensor_free(gpu_k_tensor);
			ccv_nnc_tensor_free(gpu_v_tensor);
			ccv_nnc_tensor_free(o_tensor);
			ccv_nnc_tensor_free(q_tensor);
			ccv_nnc_tensor_free(k_tensor);
			ccv_nnc_tensor_free(v_tensor);
			ccv_nnc_tensor_free(q_tensor_f16);
			ccv_nnc_tensor_free(k_tensor_f16);
			ccv_nnc_tensor_free(v_tensor_f16);
		}
	}
}

TEST_CASE("scaled dot product attention with quantized NA mps batched")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 3;
	const int R = 128;
	const int C = 128;
	const int H = 8;
	const int Ds[] = { 64, 128, 256 };
	const int datatypes[] = { CCV_16F, CCV_16BF, CCV_32F };
	const float tolerances[] = { 2e-2, 3e-2, 2e-2 };
	const char* datatype_names[] = { "16F", "16BF", "32F" };
	for (int d_idx = 0; d_idx < (int)(sizeof(Ds) / sizeof(Ds[0])); ++d_idx)
	{
		const int D = Ds[d_idx];
		const float scale = 1.0 / sqrt((float)D);

		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		const int q_count = B * R * H * D;
		const int kv_count = B * C * H * D;
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 101 + d_idx);
		for (int i = 0; i < q_count; ++i)
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		for (int i = 0; i < kv_count; ++i)
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		for (int i = 0; i < kv_count; ++i)
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;

		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_cmd_t cpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);

		for (int datatype_idx = 0; datatype_idx < 3; ++datatype_idx)
		{
			const int datatype = datatypes[datatype_idx];
			ccv_nnc_tensor_t* q_input = q_tensor;
			ccv_nnc_tensor_t* k_input = k_tensor;
			ccv_nnc_tensor_t* v_input = v_tensor;
			ccv_nnc_tensor_t* copy_of_gpu_o_tensor = 0;
			ccv_nnc_tensor_t* gpu_q_tensor = 0;
			ccv_nnc_tensor_t* gpu_k_tensor = 0;
			ccv_nnc_tensor_t* gpu_v_tensor = 0;
			ccv_nnc_tensor_t* gpu_o_tensor = 0;
			if (datatype == CCV_16F)
			{
				ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
				ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
				ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
				q_input = q_tensor_f16;
				k_input = k_tensor_f16;
				v_input = v_tensor_f16;
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			} else if (datatype == CCV_16BF) {
				ccv_float_to_bfloat(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
				ccv_float_to_bfloat(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
				ccv_float_to_bfloat(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
				q_input = q_tensor_f16;
				k_input = k_tensor_f16;
				v_input = v_tensor_f16;
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, H, D), 0);
			} else {
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			}
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_input, k_input, v_input), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
			ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
			gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
			ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

			const int count = B * R * H * D;
			float* const cpu_f32 = (float*)ccmalloc(sizeof(float) * count);
			float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * count);
			memcpy(cpu_f32, o_tensor->data.f32, sizeof(float) * count);
			if (datatype == CCV_16F)
				ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
			else if (datatype == CCV_16BF)
				ccv_bfloat_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
			else
				memcpy(gpu_f32, copy_of_gpu_o_tensor->data.f32, sizeof(float) * count);
			float max_relative_diff = 0;
			int max_diff_idx = 0;
			for (int i = 0; i < count; ++i)
			{
				const float denom = fmaxf(fmaxf(fabsf(cpu_f32[i]), fabsf(gpu_f32[i])), 1.0f);
				const float relative_diff = fabsf(cpu_f32[i] - gpu_f32[i]) / denom;
				if (relative_diff > max_relative_diff)
					max_relative_diff = relative_diff, max_diff_idx = i;
			}
			REQUIRE(max_relative_diff <= tolerances[datatype_idx], "quantized batched attention result should match CPU reference for dtype=%s D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], D, max_relative_diff, max_diff_idx, cpu_f32[max_diff_idx], gpu_f32[max_diff_idx]);

			ccfree(cpu_f32);
			ccfree(gpu_f32);
			ccv_nnc_tensor_free(gpu_o_tensor);
			ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_q_tensor);
			ccv_nnc_tensor_free(gpu_k_tensor);
			ccv_nnc_tensor_free(gpu_v_tensor);
		}
		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
	}
}

TEST_CASE("scaled dot product attention with quantized NA mps for non-multiple-of-64 sequence")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 129;
	const int H = 24;
	const int Cs[] = { 130, 224 };
	const int Ds[] = { 128, 130, 224, 256 };
	const int datatypes[] = { CCV_16F, CCV_16BF, CCV_32F };
	const float tolerances[] = { 4e-2, 5e-2, 4e-2 };
	const char* datatype_names[] = { "16F", "16BF", "32F" };
	for (int c_idx = 0; c_idx < (int)(sizeof(Cs) / sizeof(Cs[0])); ++c_idx)
	{
		const int C = Cs[c_idx];
		for (int d_idx = 0; d_idx < (int)(sizeof(Ds) / sizeof(Ds[0])); ++d_idx)
		{
			const int D = Ds[d_idx];
			const float scale = 1.0 / sqrt((float)D);

			ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			const int q_count = B * R * H * D;
			const int kv_count = B * C * H * D;
			dsfmt_t dsfmt;
			dsfmt_init_gen_rand(&dsfmt, 211 + c_idx * 17 + d_idx);
			for (int i = 0; i < q_count; ++i)
				q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			for (int i = 0; i < kv_count; ++i)
				k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			for (int i = 0; i < kv_count; ++i)
				v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;

			ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_cmd_t cpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
			ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);

			for (int datatype_idx = 0; datatype_idx < 3; ++datatype_idx)
			{
				const int datatype = datatypes[datatype_idx];
				ccv_nnc_tensor_t* q_input = q_tensor;
				ccv_nnc_tensor_t* k_input = k_tensor;
				ccv_nnc_tensor_t* v_input = v_tensor;
				ccv_nnc_tensor_t* copy_of_gpu_o_tensor = 0;
				ccv_nnc_tensor_t* gpu_q_tensor = 0;
				ccv_nnc_tensor_t* gpu_k_tensor = 0;
				ccv_nnc_tensor_t* gpu_v_tensor = 0;
				ccv_nnc_tensor_t* gpu_o_tensor = 0;
				if (datatype == CCV_16F)
				{
					ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
					ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
					ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
					q_input = q_tensor_f16;
					k_input = k_tensor_f16;
					v_input = v_tensor_f16;
					gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
					gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
					gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
					gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
					copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
				} else if (datatype == CCV_16BF) {
					ccv_float_to_bfloat(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
					ccv_float_to_bfloat(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
					ccv_float_to_bfloat(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
					q_input = q_tensor_f16;
					k_input = k_tensor_f16;
					v_input = v_tensor_f16;
					gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
					gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
					gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
					gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
					copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, H, D), 0);
				} else {
					gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
					gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
					gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
					gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
					copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
				}
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_input, k_input, v_input), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);
				ccv_nnc_cmd_t gpu_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
				gpu_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
				ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), TENSOR_LIST(gpu_o_tensor), 0);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor), 0);

				const int count = B * R * H * D;
				float* const cpu_f32 = (float*)ccmalloc(sizeof(float) * count);
				float* const gpu_f32 = (float*)ccmalloc(sizeof(float) * count);
				memcpy(cpu_f32, o_tensor->data.f32, sizeof(float) * count);
				if (datatype == CCV_16F)
					ccv_half_precision_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
				else if (datatype == CCV_16BF)
					ccv_bfloat_to_float((uint16_t*)copy_of_gpu_o_tensor->data.f16, gpu_f32, count);
				else
					memcpy(gpu_f32, copy_of_gpu_o_tensor->data.f32, sizeof(float) * count);
				float max_relative_diff = 0;
				int max_diff_idx = 0;
				for (int i = 0; i < count; ++i)
				{
					const float denom = fmaxf(fmaxf(fabsf(cpu_f32[i]), fabsf(gpu_f32[i])), 1.0f);
					const float relative_diff = fabsf(cpu_f32[i] - gpu_f32[i]) / denom;
					if (relative_diff > max_relative_diff)
						max_relative_diff = relative_diff, max_diff_idx = i;
				}
				REQUIRE(max_relative_diff <= tolerances[datatype_idx], "quantized attention result should match CPU reference for dtype=%s C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], C, D, max_relative_diff, max_diff_idx, cpu_f32[max_diff_idx], gpu_f32[max_diff_idx]);

				ccfree(cpu_f32);
				ccfree(gpu_f32);
				ccv_nnc_tensor_free(gpu_o_tensor);
				ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
				ccv_nnc_tensor_free(gpu_q_tensor);
				ccv_nnc_tensor_free(gpu_k_tensor);
				ccv_nnc_tensor_free(gpu_v_tensor);
			}
			ccv_nnc_tensor_free(o_tensor);
			ccv_nnc_tensor_free(q_tensor);
			ccv_nnc_tensor_free(k_tensor);
			ccv_nnc_tensor_free(v_tensor);
			ccv_nnc_tensor_free(q_tensor_f16);
			ccv_nnc_tensor_free(k_tensor_f16);
			ccv_nnc_tensor_free(v_tensor_f16);
		}
	}
}

TEST_CASE("scaled dot product attention with quantized NA mps across every key tail")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2, R = 17, Hq = 4, Hk = 2, D = 128;
	const int q_count = B * R * Hq * D;
	const int old_flags = ccv_nnc_flags();
	// Cover short sequences, an aligned tile, and all 63 remainders with both
	// specialized and runtime lengths (reusing cached kernels across tails).
	for (int trial = 0; trial < 132; ++trial)
	{
		const int shape_idx = trial % 66;
		const int C = shape_idx == 0 ? 1 : shape_idx == 1 ? 20 : 64 + shape_idx - 2;
		const int kv_count = B * C * Hk * D;
		ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 231 + trial);
		for (int i = 0; i < q_count; ++i)
			q->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		for (int i = 0; i < kv_count; ++i)
		{
			k->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			v->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.25;
		}
		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0 / sqrtf(D), 0);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, v), TENSOR_LIST(o), 0);
		ccv_nnc_tensor_t* const gpu_q = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, v), TENSOR_LIST(gpu_q, gpu_k, gpu_v), 0);
		cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_8I;
		if (trial >= 66)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q, gpu_k, gpu_v), TENSOR_LIST(gpu_o), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o), TENSOR_LIST(actual), 0);
		ccv_nnc_disable_flag((CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C) & ~old_flags);
		double error2 = 0, reference2 = 0;
		for (int i = 0; i < q_count; ++i)
		{
			REQUIRE(isfinite(actual->data.f32[i]), "key tail C=%d should produce finite output at %d", C, i);
			const double error = actual->data.f32[i] - o->data.f32[i];
			error2 += error * error;
			reference2 += (double)o->data.f32[i] * o->data.f32[i];
		}
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, o->data.f32, q_count, 1e-2, "every key tail should match CPU attention with batching and grouped queries (C=%d)", C);
		REQUIRE(error2 < reference2 * 1e-4, "key tail C=%d should have relative L2 error below 1%%", C);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_v);
		ccv_nnc_tensor_free(gpu_k);
		ccv_nnc_tensor_free(gpu_q);
		ccv_nnc_tensor_free(actual);
		ccv_nnc_tensor_free(o);
		ccv_nnc_tensor_free(v);
		ccv_nnc_tensor_free(k);
		ccv_nnc_tensor_free(q);
	}
}

TEST_CASE("scaled dot product attention with quantized NA mps across V-mean reduction sizes")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2, R = 5, Hq = 6, Hk = 3;
	const int Cs[] = { 20480, 20481, 32769, 20480 };
	const int Ds[] = { 80, 128, 192 };
	const int old_flags = ccv_nnc_flags();
	// Cross the 256/128 reduction-thread boundary in both directions, with
	// partial channel tiles and non-power-of-two heads, including runtime C.
	for (int trial = 0; trial < 24; ++trial)
	{
		const int C = Cs[trial % 4];
		const int D = Ds[(trial / 4) % 3];
		const int q_count = B * R * Hq * D;
		const int kv_count = B * C * Hk * D;
		ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const o = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const actual = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 231 + trial);
		for (int i = 0; i < q_count; ++i)
			q->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		for (int i = 0; i < kv_count; ++i)
		{
			k->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			v->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.25;
		}
		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0 / sqrtf(D), 0);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, v), TENSOR_LIST(o), 0);
		ccv_nnc_tensor_t* const gpu_q = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, v), TENSOR_LIST(gpu_q, gpu_k, gpu_v), 0);
		cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_8I;
		if (trial >= 12)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C);
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q, gpu_k, gpu_v), TENSOR_LIST(gpu_o), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o), TENSOR_LIST(actual), 0);
		ccv_nnc_disable_flag((CCV_NNC_DISABLE_MFA_GEMM_SPECIALIZING_M | CCV_NNC_DISABLE_MFA_ATTENTION_SPECIALIZING_C) & ~old_flags);
		double error2 = 0, reference2 = 0;
		for (int i = 0; i < q_count; ++i)
		{
			REQUIRE(isfinite(actual->data.f32[i]), "V-mean C=%d should produce finite output at %d", C, i);
			const double error = actual->data.f32[i] - o->data.f32[i];
			error2 += error * error;
			reference2 += (double)o->data.f32[i] * o->data.f32[i];
		}
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, actual->data.f32, o->data.f32, q_count, 1e-2, "both V-mean reduction sizes should match CPU attention with batching and grouped queries (C=%d)", C);
		REQUIRE(error2 < reference2 * 1e-4, "V-mean C=%d should have relative L2 error below 1%%", C);
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_v);
		ccv_nnc_tensor_free(gpu_k);
		ccv_nnc_tensor_free(gpu_q);
		ccv_nnc_tensor_free(actual);
		ccv_nnc_tensor_free(o);
		ccv_nnc_tensor_free(v);
		ccv_nnc_tensor_free(k);
		ccv_nnc_tensor_free(q);
	}
}

TEST_CASE("scaled dot product attention low precision gradient preserves diffuse probabilities")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
	const int R = 257, C = 1024, H = 2;
	const int heads[] = { 64, 128 };
	for (int trial = 0; trial < 4; ++trial)
	{
		const int D = heads[trial % 2];
		const int flags = CCV_NNC_GEMM_16F | (trial < 2 ? CCV_NNC_GEMM_8I : 0);
		const float scale = 1.0f / sqrtf(D);
		ccv_nnc_tensor_t* inputs[4];
		ccv_nnc_tensor_t* half_inputs[4];
		ccv_nnc_tensor_t* gpu_inputs[4];
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 701 + trial);
		for (int j = 0; j < 4; ++j)
		{
			const int length = (j == 1 || j == 2) ? C : R;
			inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, length, H, D), 0);
			half_inputs[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length, H, D), 0);
			gpu_inputs[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length, H, D), 0);
			for (int i = 0; i < length * H * D; ++i)
				inputs[j]->data.f32[i] = j < 2 ? (dsfmt_genrand_open_close(&dsfmt) - 0.5) * 0.25 : dsfmt_genrand_open_close(&dsfmt) - (j == 3 ? -0.125 : 0.5);
			ccv_float_to_half_precision(inputs[j]->data.f32, (uint16_t*)half_inputs[j]->data.f16, length * H * D);
			ccv_half_precision_to_float((uint16_t*)half_inputs[j]->data.f16, inputs[j]->data.f32, length * H * D);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(half_inputs[j]), TENSOR_LIST(gpu_inputs[j]), 0);
		}
		ccv_nnc_tensor_t* expected[3];
		ccv_nnc_tensor_t* actual[3];
		ccv_nnc_tensor_t* half_actual[3];
		ccv_nnc_tensor_t* gpu_gradients[3];
		for (int j = 0; j < 3; ++j)
		{
			const int length = j == 0 ? R : C;
			expected[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, length, H, D), 0);
			actual[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, length, H, D), 0);
			half_actual[j] = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 1, length, H, D), 0);
			gpu_gradients[j] = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, length, H, D), 0);
		}
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(inputs[3], 0, 0, inputs[0], inputs[1], inputs[2]), TENSOR_LIST(expected[0], expected[1], expected[2]), 0);
		ccv_nnc_tensor_t* const gpu_o = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 1, R, H, D), 0);
		ccv_nnc_tensor_t* const gpu_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 1, H, R), 0);
		ccv_nnc_cmd_t forward = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
		forward.info.scaled_dot_product_attention.flags = flags;
		ccv_nnc_cmd_exec(forward, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_inputs[0], gpu_inputs[1], gpu_inputs[2]), TENSOR_LIST(gpu_o, gpu_lse), 0);
		ccv_nnc_cmd_t backward = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0);
		backward.info.scaled_dot_product_attention.flags = flags;
		backward.info.scaled_dot_product_attention.deterministic = 0;
		ccv_nnc_cmd_exec(backward, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_inputs[3], 0, 0, gpu_inputs[0], gpu_inputs[1], gpu_inputs[2], 0, 0, 0, gpu_o, gpu_lse), TENSOR_LIST(gpu_gradients[0], gpu_gradients[1], gpu_gradients[2]), 0);
		for (int j = 0; j < 3; ++j)
		{
			const int count = (j == 0 ? R : C) * H * D;
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_gradients[j]), TENSOR_LIST(half_actual[j]), 0);
			ccv_half_precision_to_float((uint16_t*)half_actual[j]->data.f16, actual[j]->data.f32, count);
			double error2 = 0, reference2 = 0;
			for (int i = 0; i < count; ++i)
			{
				REQUIRE(isfinite(actual[j]->data.f32[i]), "diffuse attention gradient should be finite");
				const double delta = actual[j]->data.f32[i] - expected[j]->data.f32[i];
				error2 += delta * delta;
				reference2 += (double)expected[j]->data.f32[i] * expected[j]->data.f32[i];
			}
			// Relative checks reject zero gradients even when absolute errors are small.
			const double tolerance = j == 2 ? 0.02 : 0.05;
			REQUIRE(error2 < reference2 * tolerance * tolerance, "diffuse gradient should match CPU (D=%d, gradient=%d, flags=%d, relative L2=%g)", D, j, flags, sqrt(error2 / reference2));
			ccv_nnc_tensor_free(expected[j]);
			ccv_nnc_tensor_free(actual[j]);
			ccv_nnc_tensor_free(half_actual[j]);
			ccv_nnc_tensor_free(gpu_gradients[j]);
		}
		for (int j = 0; j < 4; ++j)
		{
			ccv_nnc_tensor_free(inputs[j]);
			ccv_nnc_tensor_free(half_inputs[j]);
			ccv_nnc_tensor_free(gpu_inputs[j]);
		}
		ccv_nnc_tensor_free(gpu_o);
		ccv_nnc_tensor_free(gpu_lse);
	}
}

TEST_CASE("scaled dot product attention gradient with quantized NA mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2;
	const int R = 128;
	const int C = 128;
	const int H = 8;
	const int Ds[] = { 64, 80, 96, 128 };
	const int datatypes[] = { CCV_16F, CCV_16BF, CCV_32F };
	const char* datatype_names[] = { "16F", "16BF", "32F" };
	const float dq_tolerances[] = { 8e-2, 8e-2, 8e-2 };
	const float dk_tolerances[] = { 1e-1, 1e-1, 1e-1 };
	const float dv_tolerances[] = { 8e-2, 8e-2, 8e-2 };
	for (int d_idx = 0; d_idx < (int)(sizeof(Ds) / sizeof(Ds[0])); ++d_idx)
	{
		const int D = Ds[d_idx];
		const int q_count = B * R * H * D;
		const int kv_count = B * C * H * D;
		const float scale = 1.0 / sqrt((float)D);
		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const do_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
		dsfmt_t dsfmt;
		dsfmt_init_gen_rand(&dsfmt, 181 + d_idx);
		for (int i = 0; i < q_count; ++i)
		{
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		}
		for (int i = 0; i < kv_count; ++i)
		{
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		}
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);

		for (int datatype_idx = 0; datatype_idx < 3; ++datatype_idx)
		{
			const int datatype = datatypes[datatype_idx];
			ccv_nnc_tensor_t* q_input = q_tensor;
			ccv_nnc_tensor_t* k_input = k_tensor;
			ccv_nnc_tensor_t* v_input = v_tensor;
			ccv_nnc_tensor_t* do_input = do_tensor;
			ccv_nnc_tensor_t* gpu_q_tensor = 0;
			ccv_nnc_tensor_t* gpu_k_tensor = 0;
			ccv_nnc_tensor_t* gpu_v_tensor = 0;
			ccv_nnc_tensor_t* gpu_do_tensor = 0;
			ccv_nnc_tensor_t* gpu_o_tensor = 0;
			ccv_nnc_tensor_t* gpu_dq_tensor = 0;
			ccv_nnc_tensor_t* gpu_dk_tensor = 0;
			ccv_nnc_tensor_t* gpu_dv_tensor = 0;
			ccv_nnc_tensor_t* copy_of_gpu_dq_tensor = 0;
			ccv_nnc_tensor_t* copy_of_gpu_dk_tensor = 0;
			ccv_nnc_tensor_t* copy_of_gpu_dv_tensor = 0;
			if (datatype == CCV_16F)
			{
				ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
				ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
				ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
				ccv_float_to_half_precision(do_tensor->data.f32, (uint16_t*)do_tensor_f16->data.f16, q_count);
				q_input = q_tensor_f16;
				k_input = k_tensor_f16;
				v_input = v_tensor_f16;
				do_input = do_tensor_f16;
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
				gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
				copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
				copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
				copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			} else if (datatype == CCV_16BF) {
				ccv_float_to_bfloat(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
				ccv_float_to_bfloat(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
				ccv_float_to_bfloat(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
				ccv_float_to_bfloat(do_tensor->data.f32, (uint16_t*)do_tensor_f16->data.f16, q_count);
				q_input = q_tensor_f16;
				k_input = k_tensor_f16;
				v_input = v_tensor_f16;
				do_input = do_tensor_f16;
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
				gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
				copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, H, D), 0);
				copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, H, D), 0);
				copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, H, D), 0);
			} else {
				gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
				gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
				copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
				copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
				copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			}
			ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, H, R), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_input, k_input, v_input, do_input), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);
			ccv_nnc_cmd_t gpu_forw_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
			gpu_forw_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
			ccv_nnc_cmd_exec(gpu_forw_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);
			ccv_nnc_cmd_exec(CMD_SET_FORWARD(0), ccv_nnc_no_hint, 0, TENSOR_LIST(), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
			ccv_nnc_cmd_t gpu_back_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0);
			gpu_back_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
			gpu_back_cmd.info.scaled_dot_product_attention.deterministic = 0;
			ccv_nnc_cmd_exec(gpu_back_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

			float* const dq_cpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
			float* const dk_cpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
			float* const dv_cpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
			float* const dq_gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
			float* const dk_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
			float* const dv_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
			memcpy(dq_cpu_f32, dq_tensor->data.f32, sizeof(float) * q_count);
			memcpy(dk_cpu_f32, dk_tensor->data.f32, sizeof(float) * kv_count);
			memcpy(dv_cpu_f32, dv_tensor->data.f32, sizeof(float) * kv_count);
			if (datatype == CCV_16F)
			{
				ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dq_tensor->data.f16, dq_gpu_f32, q_count);
				ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dk_tensor->data.f16, dk_gpu_f32, kv_count);
				ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dv_tensor->data.f16, dv_gpu_f32, kv_count);
			} else if (datatype == CCV_16BF) {
				ccv_bfloat_to_float((uint16_t*)copy_of_gpu_dq_tensor->data.f16, dq_gpu_f32, q_count);
				ccv_bfloat_to_float((uint16_t*)copy_of_gpu_dk_tensor->data.f16, dk_gpu_f32, kv_count);
				ccv_bfloat_to_float((uint16_t*)copy_of_gpu_dv_tensor->data.f16, dv_gpu_f32, kv_count);
			} else {
				memcpy(dq_gpu_f32, copy_of_gpu_dq_tensor->data.f32, sizeof(float) * q_count);
				memcpy(dk_gpu_f32, copy_of_gpu_dk_tensor->data.f32, sizeof(float) * kv_count);
				memcpy(dv_gpu_f32, copy_of_gpu_dv_tensor->data.f32, sizeof(float) * kv_count);
			}
			float dq_max_relative_diff = 0;
			float dk_max_relative_diff = 0;
			float dv_max_relative_diff = 0;
			int dq_max_diff_idx = 0;
			int dk_max_diff_idx = 0;
			int dv_max_diff_idx = 0;
			for (int i = 0; i < q_count; ++i)
			{
				const float denom = fmaxf(fmaxf(fabsf(dq_cpu_f32[i]), fabsf(dq_gpu_f32[i])), 1.0f);
				const float relative_diff = fabsf(dq_cpu_f32[i] - dq_gpu_f32[i]) / denom;
				if (relative_diff > dq_max_relative_diff)
					dq_max_relative_diff = relative_diff, dq_max_diff_idx = i;
			}
			for (int i = 0; i < kv_count; ++i)
			{
				float denom = fmaxf(fmaxf(fabsf(dk_cpu_f32[i]), fabsf(dk_gpu_f32[i])), 1.0f);
				float relative_diff = fabsf(dk_cpu_f32[i] - dk_gpu_f32[i]) / denom;
				if (relative_diff > dk_max_relative_diff)
					dk_max_relative_diff = relative_diff, dk_max_diff_idx = i;
				denom = fmaxf(fmaxf(fabsf(dv_cpu_f32[i]), fabsf(dv_gpu_f32[i])), 1.0f);
				relative_diff = fabsf(dv_cpu_f32[i] - dv_gpu_f32[i]) / denom;
				if (relative_diff > dv_max_relative_diff)
					dv_max_relative_diff = relative_diff, dv_max_diff_idx = i;
			}
			REQUIRE(dq_max_relative_diff <= dq_tolerances[datatype_idx], "quantized attention dQ should match CPU reference for dtype=%s R=%d C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], R, C, D, dq_max_relative_diff, dq_max_diff_idx, dq_cpu_f32[dq_max_diff_idx], dq_gpu_f32[dq_max_diff_idx]);
			REQUIRE(dk_max_relative_diff <= dk_tolerances[datatype_idx], "quantized attention dK should match CPU reference for dtype=%s R=%d C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], R, C, D, dk_max_relative_diff, dk_max_diff_idx, dk_cpu_f32[dk_max_diff_idx], dk_gpu_f32[dk_max_diff_idx]);
			REQUIRE(dv_max_relative_diff <= dv_tolerances[datatype_idx], "quantized attention dV should match CPU reference for dtype=%s R=%d C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], R, C, D, dv_max_relative_diff, dv_max_diff_idx, dv_cpu_f32[dv_max_diff_idx], dv_gpu_f32[dv_max_diff_idx]);

			ccfree(dq_cpu_f32);
			ccfree(dk_cpu_f32);
			ccfree(dv_cpu_f32);
			ccfree(dq_gpu_f32);
			ccfree(dk_gpu_f32);
			ccfree(dv_gpu_f32);
			ccv_nnc_tensor_free(gpu_q_tensor);
			ccv_nnc_tensor_free(gpu_k_tensor);
			ccv_nnc_tensor_free(gpu_v_tensor);
			ccv_nnc_tensor_free(gpu_do_tensor);
			ccv_nnc_tensor_free(gpu_o_tensor);
			ccv_nnc_tensor_free(gpu_dq_tensor);
			ccv_nnc_tensor_free(gpu_dk_tensor);
			ccv_nnc_tensor_free(gpu_dv_tensor);
			ccv_nnc_tensor_free(gpu_softmax_lse);
			ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
			ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
			ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
		}

		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(do_tensor);
		ccv_nnc_tensor_free(dq_tensor);
		ccv_nnc_tensor_free(dk_tensor);
		ccv_nnc_tensor_free(dv_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(do_tensor_f16);
	}
}

TEST_CASE("scaled dot product attention grouped-query gradient with quantized NA mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 31;
	const int C = 1038;
	const int Hq = 8;
	const int Hk = 2;
	const int D = 128;
	const int q_count = B * R * Hq * D;
	const int kv_count = B * C * Hk * D;
	const float scale = 1.0 / sqrt((float)D);
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const do_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 219);
	for (int i = 0; i < q_count; ++i)
	{
		q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	}
	for (int i = 0; i < kv_count; ++i)
	{
		k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		v_tensor->data.f32[i] = 64 + dsfmt_genrand_open_close(&dsfmt) - 0.5;
	}
	ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
	ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(do_tensor->data.f32, (uint16_t*)do_tensor_f16->data.f16, q_count);
	ccv_half_precision_to_float((uint16_t*)q_tensor_f16->data.f16, q_tensor->data.f32, q_count);
	ccv_half_precision_to_float((uint16_t*)k_tensor_f16->data.f16, k_tensor->data.f32, kv_count);
	ccv_half_precision_to_float((uint16_t*)v_tensor_f16->data.f16, v_tensor->data.f32, kv_count);
	ccv_half_precision_to_float((uint16_t*)do_tensor_f16->data.f16, do_tensor->data.f32, q_count);
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
	ccv_nnc_tensor_t* const gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, do_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);

	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	ccv_nnc_cmd_t gpu_forw_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
	gpu_forw_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
	const int forward_status = ccv_nnc_cmd_exec(gpu_forw_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);
	ccv_nnc_cmd_t gpu_back_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0);
	gpu_back_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
	gpu_back_cmd.info.scaled_dot_product_attention.deterministic = 0;
	const int backward_status = ccv_nnc_cmd_exec(gpu_back_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	if (old_flags & CCV_NNC_DISABLE_MFA_ATTENTION)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
	if (old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	REQUIRE_EQ(forward_status, CCV_NNC_EXEC_SUCCESS, "quantized grouped-query attention forward should execute");
	REQUIRE_EQ(backward_status, CCV_NNC_EXEC_SUCCESS, "quantized grouped-query attention backward should execute");
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

	float* const dq_gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
	float* const dk_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
	float* const dv_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
	ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dq_tensor->data.f16, dq_gpu_f32, q_count);
	ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dk_tensor->data.f16, dk_gpu_f32, kv_count);
	ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dv_tensor->data.f16, dv_gpu_f32, kv_count);
	float dq_max_relative_diff = 0;
	float dk_max_relative_diff = 0;
	float dv_max_relative_diff = 0;
	float dv_reference_max = 0;
	float dv_gpu_max = 0;
	for (int i = 0; i < q_count; ++i)
	{
		REQUIRE(isfinite(dq_gpu_f32[i]), "quantized grouped-query dQ should stay finite at %d", i);
		const float denom = fmaxf(fmaxf(fabsf(dq_tensor->data.f32[i]), fabsf(dq_gpu_f32[i])), 1.0f);
		dq_max_relative_diff = fmaxf(dq_max_relative_diff, fabsf(dq_tensor->data.f32[i] - dq_gpu_f32[i]) / denom);
	}
	for (int i = 0; i < kv_count; ++i)
	{
		REQUIRE(isfinite(dk_gpu_f32[i]), "quantized grouped-query dK should stay finite at %d", i);
		REQUIRE(isfinite(dv_gpu_f32[i]), "quantized grouped-query dV should stay finite at %d", i);
		dv_reference_max = fmaxf(dv_reference_max, fabsf(dv_tensor->data.f32[i]));
		dv_gpu_max = fmaxf(dv_gpu_max, fabsf(dv_gpu_f32[i]));
		float denom = fmaxf(fmaxf(fabsf(dk_tensor->data.f32[i]), fabsf(dk_gpu_f32[i])), 1.0f);
		dk_max_relative_diff = fmaxf(dk_max_relative_diff, fabsf(dk_tensor->data.f32[i] - dk_gpu_f32[i]) / denom);
		denom = fmaxf(fmaxf(fabsf(dv_tensor->data.f32[i]), fabsf(dv_gpu_f32[i])), 1.0f);
		dv_max_relative_diff = fmaxf(dv_max_relative_diff, fabsf(dv_tensor->data.f32[i] - dv_gpu_f32[i]) / denom);
	}
	REQUIRE(dq_max_relative_diff <= 8e-2, "quantized grouped-query dQ should match CPU reference (max relative diff %g)", dq_max_relative_diff);
	REQUIRE(dk_max_relative_diff <= 1.2e-1, "quantized grouped-query dK should match CPU reference (max relative diff %g)", dk_max_relative_diff);
	REQUIRE(dv_max_relative_diff <= 1e-1, "quantized grouped-query dV should match CPU reference (max relative diff %g)", dv_max_relative_diff);
	REQUIRE(dv_gpu_max >= dv_reference_max * 0.5, "quantized grouped-query dV should not collapse to zero (%g versus reference %g)", dv_gpu_max, dv_reference_max);

	ccfree(dq_gpu_f32);
	ccfree(dk_gpu_f32);
	ccfree(dv_gpu_f32);
	ccv_nnc_tensor_free(q_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(v_tensor);
	ccv_nnc_tensor_free(do_tensor);
	ccv_nnc_tensor_free(dq_tensor);
	ccv_nnc_tensor_free(dk_tensor);
	ccv_nnc_tensor_free(dv_tensor);
	ccv_nnc_tensor_free(q_tensor_f16);
	ccv_nnc_tensor_free(k_tensor_f16);
	ccv_nnc_tensor_free(v_tensor_f16);
	ccv_nnc_tensor_free(do_tensor_f16);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_do_tensor);
	ccv_nnc_tensor_free(gpu_o_tensor);
	ccv_nnc_tensor_free(gpu_softmax_lse);
	ccv_nnc_tensor_free(gpu_dq_tensor);
	ccv_nnc_tensor_free(gpu_dk_tensor);
	ccv_nnc_tensor_free(gpu_dv_tensor);
	ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
	ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
	ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
}

TEST_CASE("scaled dot product attention gradient with quantized NA mps for rectangular and edge sequence lengths")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
	typedef struct {
		int R;
		int C;
	} qna_backward_shape_t;
	const int B = 1;
	const int H = 8;
	const int Ds[] = { 64, 128 };
	const qna_backward_shape_t shapes[] = {
		{ .R = 32, .C = 64 },
		{ .R = 40, .C = 72 },
		{ .R = 80, .C = 64 },
		{ .R = 96, .C = 88 },
		{ .R = 64, .C = 192 },
		{ .R = 144, .C = 64 },
	};
	const int datatypes[] = { CCV_16F, CCV_16BF, CCV_32F };
	const char* datatype_names[] = { "16F", "16BF", "32F" };
	const float dq_tolerances[] = { 8e-2, 8e-2, 8e-2 };
	const float dk_tolerances[] = { 1e-1, 1e-1, 1e-1 };
	const float dv_tolerances[] = { 8e-2, 8e-2, 8e-2 };
	for (int shape_idx = 0; shape_idx < (int)(sizeof(shapes) / sizeof(shapes[0])); ++shape_idx)
	{
		const int R = shapes[shape_idx].R;
		const int C = shapes[shape_idx].C;
		for (int d_idx = 0; d_idx < (int)(sizeof(Ds) / sizeof(Ds[0])); ++d_idx)
		{
			const int D = Ds[d_idx];
			const int q_count = B * R * H * D;
			const int kv_count = B * C * H * D;
			const float scale = 1.0 / sqrt((float)D);
			ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
			ccv_nnc_tensor_t* const do_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
			dsfmt_t dsfmt;
			dsfmt_init_gen_rand(&dsfmt, 281 + shape_idx * 17 + d_idx);
			for (int i = 0; i < q_count; ++i)
			{
				q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
				do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			}
			for (int i = 0; i < kv_count; ++i)
			{
				k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
				v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
			}
			ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);

			for (int datatype_idx = 0; datatype_idx < 3; ++datatype_idx)
			{
				const int datatype = datatypes[datatype_idx];
				ccv_nnc_tensor_t* q_input = q_tensor;
				ccv_nnc_tensor_t* k_input = k_tensor;
				ccv_nnc_tensor_t* v_input = v_tensor;
				ccv_nnc_tensor_t* do_input = do_tensor;
				ccv_nnc_tensor_t* gpu_q_tensor = 0;
				ccv_nnc_tensor_t* gpu_k_tensor = 0;
				ccv_nnc_tensor_t* gpu_v_tensor = 0;
				ccv_nnc_tensor_t* gpu_do_tensor = 0;
				ccv_nnc_tensor_t* gpu_o_tensor = 0;
				ccv_nnc_tensor_t* gpu_dq_tensor = 0;
				ccv_nnc_tensor_t* gpu_dk_tensor = 0;
				ccv_nnc_tensor_t* gpu_dv_tensor = 0;
				ccv_nnc_tensor_t* copy_of_gpu_dq_tensor = 0;
				ccv_nnc_tensor_t* copy_of_gpu_dk_tensor = 0;
				ccv_nnc_tensor_t* copy_of_gpu_dv_tensor = 0;
				if (datatype == CCV_16F)
				{
					ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
					ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
					ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
					ccv_float_to_half_precision(do_tensor->data.f32, (uint16_t*)do_tensor_f16->data.f16, q_count);
					q_input = q_tensor_f16;
					k_input = k_tensor_f16;
					v_input = v_tensor_f16;
					do_input = do_tensor_f16;
					gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
					gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
					gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
					gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
					gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
					gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
					gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
					gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
					copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
					copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
					copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
				} else if (datatype == CCV_16BF) {
					ccv_float_to_bfloat(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
					ccv_float_to_bfloat(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
					ccv_float_to_bfloat(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
					ccv_float_to_bfloat(do_tensor->data.f32, (uint16_t*)do_tensor_f16->data.f16, q_count);
					q_input = q_tensor_f16;
					k_input = k_tensor_f16;
					v_input = v_tensor_f16;
					do_input = do_tensor_f16;
					gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
					gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
					gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
					gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
					gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
					gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, H, D), 0);
					gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
					gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, H, D), 0);
					copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, H, D), 0);
					copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, H, D), 0);
					copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, H, D), 0);
				} else {
					gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
					gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
					gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
					gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
					gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
					gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
					gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
					gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
					copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
					copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
					copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
				}
				ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, H, R), 0);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_input, k_input, v_input, do_input), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);
				ccv_nnc_cmd_t gpu_forw_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
				gpu_forw_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
				ccv_nnc_cmd_exec(gpu_forw_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);
				ccv_nnc_cmd_exec(CMD_SET_FORWARD(0), ccv_nnc_no_hint, 0, TENSOR_LIST(), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
				ccv_nnc_cmd_t gpu_back_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0);
				gpu_back_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
				gpu_back_cmd.info.scaled_dot_product_attention.deterministic = 0;
				ccv_nnc_cmd_exec(gpu_back_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

				float* const dq_cpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
				float* const dk_cpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
				float* const dv_cpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
				float* const dq_gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
				float* const dk_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
				float* const dv_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
				memcpy(dq_cpu_f32, dq_tensor->data.f32, sizeof(float) * q_count);
				memcpy(dk_cpu_f32, dk_tensor->data.f32, sizeof(float) * kv_count);
				memcpy(dv_cpu_f32, dv_tensor->data.f32, sizeof(float) * kv_count);
				if (datatype == CCV_16F)
				{
					ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dq_tensor->data.f16, dq_gpu_f32, q_count);
					ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dk_tensor->data.f16, dk_gpu_f32, kv_count);
					ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dv_tensor->data.f16, dv_gpu_f32, kv_count);
				} else if (datatype == CCV_16BF) {
					ccv_bfloat_to_float((uint16_t*)copy_of_gpu_dq_tensor->data.f16, dq_gpu_f32, q_count);
					ccv_bfloat_to_float((uint16_t*)copy_of_gpu_dk_tensor->data.f16, dk_gpu_f32, kv_count);
					ccv_bfloat_to_float((uint16_t*)copy_of_gpu_dv_tensor->data.f16, dv_gpu_f32, kv_count);
				} else {
					memcpy(dq_gpu_f32, copy_of_gpu_dq_tensor->data.f32, sizeof(float) * q_count);
					memcpy(dk_gpu_f32, copy_of_gpu_dk_tensor->data.f32, sizeof(float) * kv_count);
					memcpy(dv_gpu_f32, copy_of_gpu_dv_tensor->data.f32, sizeof(float) * kv_count);
				}
				float dq_max_relative_diff = 0;
				float dk_max_relative_diff = 0;
				float dv_max_relative_diff = 0;
				int dq_max_diff_idx = 0;
				int dk_max_diff_idx = 0;
				int dv_max_diff_idx = 0;
				for (int i = 0; i < q_count; ++i)
				{
					const float denom = fmaxf(fmaxf(fabsf(dq_cpu_f32[i]), fabsf(dq_gpu_f32[i])), 1.0f);
					const float relative_diff = fabsf(dq_cpu_f32[i] - dq_gpu_f32[i]) / denom;
					if (relative_diff > dq_max_relative_diff)
						dq_max_relative_diff = relative_diff, dq_max_diff_idx = i;
				}
				for (int i = 0; i < kv_count; ++i)
				{
					float denom = fmaxf(fmaxf(fabsf(dk_cpu_f32[i]), fabsf(dk_gpu_f32[i])), 1.0f);
					float relative_diff = fabsf(dk_cpu_f32[i] - dk_gpu_f32[i]) / denom;
					if (relative_diff > dk_max_relative_diff)
						dk_max_relative_diff = relative_diff, dk_max_diff_idx = i;
					denom = fmaxf(fmaxf(fabsf(dv_cpu_f32[i]), fabsf(dv_gpu_f32[i])), 1.0f);
					relative_diff = fabsf(dv_cpu_f32[i] - dv_gpu_f32[i]) / denom;
					if (relative_diff > dv_max_relative_diff)
						dv_max_relative_diff = relative_diff, dv_max_diff_idx = i;
				}
				REQUIRE(dq_max_relative_diff <= dq_tolerances[datatype_idx], "quantized attention dQ should match CPU reference for dtype=%s R=%d C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], R, C, D, dq_max_relative_diff, dq_max_diff_idx, dq_cpu_f32[dq_max_diff_idx], dq_gpu_f32[dq_max_diff_idx]);
				REQUIRE(dk_max_relative_diff <= dk_tolerances[datatype_idx], "quantized attention dK should match CPU reference for dtype=%s R=%d C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], R, C, D, dk_max_relative_diff, dk_max_diff_idx, dk_cpu_f32[dk_max_diff_idx], dk_gpu_f32[dk_max_diff_idx]);
				REQUIRE(dv_max_relative_diff <= dv_tolerances[datatype_idx], "quantized attention dV should match CPU reference for dtype=%s R=%d C=%d D=%d (max relative diff %g at %d: %g vs %g)", datatype_names[datatype_idx], R, C, D, dv_max_relative_diff, dv_max_diff_idx, dv_cpu_f32[dv_max_diff_idx], dv_gpu_f32[dv_max_diff_idx]);

				ccfree(dq_cpu_f32);
				ccfree(dk_cpu_f32);
				ccfree(dv_cpu_f32);
				ccfree(dq_gpu_f32);
				ccfree(dk_gpu_f32);
				ccfree(dv_gpu_f32);
				ccv_nnc_tensor_free(gpu_q_tensor);
				ccv_nnc_tensor_free(gpu_k_tensor);
				ccv_nnc_tensor_free(gpu_v_tensor);
				ccv_nnc_tensor_free(gpu_do_tensor);
				ccv_nnc_tensor_free(gpu_o_tensor);
				ccv_nnc_tensor_free(gpu_dq_tensor);
				ccv_nnc_tensor_free(gpu_dk_tensor);
				ccv_nnc_tensor_free(gpu_dv_tensor);
				ccv_nnc_tensor_free(gpu_softmax_lse);
				ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
				ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
				ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
			}

			ccv_nnc_tensor_free(q_tensor);
			ccv_nnc_tensor_free(k_tensor);
			ccv_nnc_tensor_free(v_tensor);
			ccv_nnc_tensor_free(do_tensor);
			ccv_nnc_tensor_free(dq_tensor);
			ccv_nnc_tensor_free(dk_tensor);
			ccv_nnc_tensor_free(dv_tensor);
			ccv_nnc_tensor_free(q_tensor_f16);
			ccv_nnc_tensor_free(k_tensor_f16);
			ccv_nnc_tensor_free(v_tensor_f16);
			ccv_nnc_tensor_free(do_tensor_f16);
		}
	}
}

TEST_CASE("scaled dot product attention gradient with quantized NA mps on 1536 square surface")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
	const int B = 1;
	const int R = 1536;
	const int C = 1536;
	const int H = 24;
	const int D = 128;
	const int q_count = B * R * H * D;
	const int kv_count = B * C * H * D;
	const float scale = 1.0 / sqrt((float)D);
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const do_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 4177);
	for (int i = 0; i < q_count; ++i)
	{
		// Use a stronger shared Q / K signal on this surface so QK^T produces
		// sharper rows than the fully diffuse random-input case.
		const float q = 2.f * (dsfmt_genrand_open_close(&dsfmt) - 0.5f);
		q_tensor->data.f32[i] = q;
		k_tensor->data.f32[i] = q + 0.125f * (dsfmt_genrand_open_close(&dsfmt) - 0.5f);
		do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
		v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) - 0.5;
	}
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);

	ccv_float_to_half_precision(q_tensor->data.f32, (uint16_t*)q_tensor_f16->data.f16, q_count);
	ccv_float_to_half_precision(k_tensor->data.f32, (uint16_t*)k_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(v_tensor->data.f32, (uint16_t*)v_tensor_f16->data.f16, kv_count);
	ccv_float_to_half_precision(do_tensor->data.f32, (uint16_t*)do_tensor_f16->data.f16, q_count);

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, H, R), 0);
	ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);
	ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, H, D), 0);

	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, do_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);
	ccv_nnc_cmd_t gpu_forw_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0);
	gpu_forw_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
	ccv_nnc_cmd_exec(gpu_forw_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);
	ccv_nnc_cmd_exec(CMD_SET_FORWARD(0), ccv_nnc_no_hint, 0, TENSOR_LIST(), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
	ccv_nnc_cmd_t gpu_back_cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0);
	gpu_back_cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_16F | CCV_NNC_GEMM_8I;
	gpu_back_cmd.info.scaled_dot_product_attention.deterministic = 0;
	ccv_nnc_cmd_exec(gpu_back_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

	float* const dq_gpu_f32 = (float*)ccmalloc(sizeof(float) * q_count);
	float* const dk_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
	float* const dv_gpu_f32 = (float*)ccmalloc(sizeof(float) * kv_count);
	ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dq_tensor->data.f16, dq_gpu_f32, q_count);
	ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dk_tensor->data.f16, dk_gpu_f32, kv_count);
	ccv_half_precision_to_float((uint16_t*)copy_of_gpu_dv_tensor->data.f16, dv_gpu_f32, kv_count);

	float dq_max_relative_diff = 0;
	float dk_max_relative_diff = 0;
	float dv_max_relative_diff = 0;
	float dq_cpu_max_abs = 0;
	float dq_gpu_max_abs = 0;
	float dk_cpu_max_abs = 0;
	float dk_gpu_max_abs = 0;
	float dv_cpu_max_abs = 0;
	float dv_gpu_max_abs = 0;
	int dq_max_diff_idx = 0;
	int dk_max_diff_idx = 0;
	int dv_max_diff_idx = 0;
	for (int i = 0; i < q_count; ++i)
	{
		dq_cpu_max_abs = fmaxf(dq_cpu_max_abs, fabsf(dq_tensor->data.f32[i]));
		dq_gpu_max_abs = fmaxf(dq_gpu_max_abs, fabsf(dq_gpu_f32[i]));
		const float denom = fmaxf(fmaxf(fabsf(dq_tensor->data.f32[i]), fabsf(dq_gpu_f32[i])), 1.0f);
		const float relative_diff = fabsf(dq_tensor->data.f32[i] - dq_gpu_f32[i]) / denom;
		if (relative_diff > dq_max_relative_diff)
			dq_max_relative_diff = relative_diff, dq_max_diff_idx = i;
	}
	for (int i = 0; i < kv_count; ++i)
	{
		dk_cpu_max_abs = fmaxf(dk_cpu_max_abs, fabsf(dk_tensor->data.f32[i]));
		dk_gpu_max_abs = fmaxf(dk_gpu_max_abs, fabsf(dk_gpu_f32[i]));
		float denom = fmaxf(fmaxf(fabsf(dk_tensor->data.f32[i]), fabsf(dk_gpu_f32[i])), 1.0f);
		float relative_diff = fabsf(dk_tensor->data.f32[i] - dk_gpu_f32[i]) / denom;
		if (relative_diff > dk_max_relative_diff)
			dk_max_relative_diff = relative_diff, dk_max_diff_idx = i;
		dv_cpu_max_abs = fmaxf(dv_cpu_max_abs, fabsf(dv_tensor->data.f32[i]));
		dv_gpu_max_abs = fmaxf(dv_gpu_max_abs, fabsf(dv_gpu_f32[i]));
		denom = fmaxf(fmaxf(fabsf(dv_tensor->data.f32[i]), fabsf(dv_gpu_f32[i])), 1.0f);
		relative_diff = fabsf(dv_tensor->data.f32[i] - dv_gpu_f32[i]) / denom;
		if (relative_diff > dv_max_relative_diff)
			dv_max_relative_diff = relative_diff, dv_max_diff_idx = i;
	}
	REQUIRE(dq_gpu_max_abs >= dq_cpu_max_abs * 0.5f && dq_gpu_max_abs <= dq_cpu_max_abs * 2.0f,
		"quantized attention dQ magnitude should stay close to CPU reference on 1536 surface (cpu max abs %g gpu max abs %g)",
		dq_cpu_max_abs, dq_gpu_max_abs);
	REQUIRE(dk_gpu_max_abs >= dk_cpu_max_abs * 0.5f && dk_gpu_max_abs <= dk_cpu_max_abs * 2.0f,
		"quantized attention dK magnitude should stay close to CPU reference on 1536 surface (cpu max abs %g gpu max abs %g)",
		dk_cpu_max_abs, dk_gpu_max_abs);
	REQUIRE(dv_gpu_max_abs >= dv_cpu_max_abs * 0.5f && dv_gpu_max_abs <= dv_cpu_max_abs * 2.0f,
		"quantized attention dV magnitude should stay close to CPU reference on 1536 surface (cpu max abs %g gpu max abs %g)",
		dv_cpu_max_abs, dv_gpu_max_abs);
	REQUIRE(dq_max_relative_diff <= 8e-2, "quantized attention dQ should match CPU reference on 1536 surface (max relative diff %g at %d: %g vs %g)", dq_max_relative_diff, dq_max_diff_idx, dq_tensor->data.f32[dq_max_diff_idx], dq_gpu_f32[dq_max_diff_idx]);
	REQUIRE(dk_max_relative_diff <= 1e-1, "quantized attention dK should match CPU reference on 1536 surface (max relative diff %g at %d: %g vs %g)", dk_max_relative_diff, dk_max_diff_idx, dk_tensor->data.f32[dk_max_diff_idx], dk_gpu_f32[dk_max_diff_idx]);
	REQUIRE(dv_max_relative_diff <= 8e-2, "quantized attention dV should match CPU reference on 1536 surface (max relative diff %g at %d: %g vs %g)", dv_max_relative_diff, dv_max_diff_idx, dv_tensor->data.f32[dv_max_diff_idx], dv_gpu_f32[dv_max_diff_idx]);

	ccfree(dq_gpu_f32);
	ccfree(dk_gpu_f32);
	ccfree(dv_gpu_f32);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_do_tensor);
	ccv_nnc_tensor_free(gpu_o_tensor);
	ccv_nnc_tensor_free(gpu_dq_tensor);
	ccv_nnc_tensor_free(gpu_dk_tensor);
	ccv_nnc_tensor_free(gpu_dv_tensor);
	ccv_nnc_tensor_free(gpu_softmax_lse);
	ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
	ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
	ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
	ccv_nnc_tensor_free(q_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(v_tensor);
	ccv_nnc_tensor_free(do_tensor);
	ccv_nnc_tensor_free(dq_tensor);
	ccv_nnc_tensor_free(dk_tensor);
	ccv_nnc_tensor_free(dv_tensor);
	ccv_nnc_tensor_free(q_tensor_f16);
	ccv_nnc_tensor_free(k_tensor_f16);
	ccv_nnc_tensor_free(v_tensor_f16);
	ccv_nnc_tensor_free(do_tensor_f16);
}

TEST_CASE("scaled dot product attention with mps in bfloat precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
#define num_long_trials 8
#define num_short_trials 4
#define num_trials (num_long_trials + num_short_trials)

	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 10);
	for (int trial = 0; trial < num_trials; ++trial) {
		const int B_candidates[num_trials] = {  32,   12, 16, 1, 2, 1, 32,   12, 16, 1, 2, 1 };
		const int R_candidates[num_trials] = { 160,  256, 128, 77, 77, 5, 160,  256, 128, 77, 77, 5 };
		const int C_candidates[num_trials] = { 128,  128, 128, 128, 128, 5, 128,  128, 128, 128, 128, 5 };
		const int Hq_candidates[num_trials] = {   8,  8, 8, 8, 8, 32, 8,  8, 8, 8, 8, 32 };
		const int Hk_candidates[num_trials] = {   8,  8, 4, 2, 8, 32, 8,  8, 8, 8, 8, 32 };
		const int D_candidates[num_trials] = {  64, 40, 160, 192, 256, 128, 48, 96, 160, 192, 256, 128 };

		const int B = B_candidates[trial];
		const int R = R_candidates[trial];
		const int C = C_candidates[trial];
		const int Hq = Hq_candidates[trial];
		const int Hk = Hk_candidates[trial];
		const int D = D_candidates[trial];
		const int is_causal = 0;
		const float scale = 1.0 / sqrt((float)D);

		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);

		for (int i = 0; i < B * R * Hq * D; ++i) {
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}

		ccv_nnc_tensor_t* const o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(o_tensor), 0);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor), TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), 0);

		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor), 0);

		ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_o_tensor), TENSOR_LIST(copy_of_gpu_o_tensor_f16), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_o_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(copy_of_gpu_o_tensor_f16), TENSOR_LIST(copy_of_gpu_o_tensor), 0);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_o_tensor->data.f32, o_tensor->data.f32, B * R * Hq * D, 8e-3, "scaled dot product attention result should be the same");

		ccv_nnc_tensor_free(o_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_o_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(gpu_softmax_lse);
	}
#undef num_long_trials
#undef num_short_trials
#undef num_trials
}

TEST_CASE("scaled dot product attention + unify head with mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	ccv_nnc_symbolic_graph_t* const sdp_symbolic_graph = ccv_nnc_symbolic_graph_new();
	ccv_nnc_tensor_symbol_t q = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 32, 128, 8, 64), "q");
	ccv_nnc_tensor_symbol_t k = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 32, 128, 8, 64), "k");
	ccv_nnc_tensor_symbol_t v = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 32, 128, 8, 64), "v");
	ccv_nnc_tensor_symbol_t w = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 512, 512), "w");
	ccv_nnc_tensor_symbol_t bias = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 512), "bias");
	ccv_nnc_tensor_symbol_t c = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 32, 128, 8, 64), "c");
	ccv_nnc_tensor_symbol_t r = ccv_nnc_tensor_symbol_new(sdp_symbolic_graph, CPU_TENSOR_NHWC(32F, 32, 128, 512), "r");
	ccv_nnc_graph_exec_symbol_new(sdp_symbolic_graph, CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0 / 8, 0), TENSOR_SYMBOL_LIST(q, k, v, NO_TENSOR_SYMBOL, w, bias), TENSOR_SYMBOL_LIST(r, NO_TENSOR_SYMBOL, c), "scaled_dot_product_attention");
	ccv_nnc_graph_exec_symbol_autogen(sdp_symbolic_graph, 0, 0, CCV_NNC_AUTOGEN_ALL_EXECS | CCV_NNC_AUTOGEN_SOURCES_AND_DESTINATIONS);
	ccv_nnc_graph_t* sdp_graph = 0;
	ccv_nnc_tensor_arena_t* sdp_tensor_arena = 0;
	ccv_nnc_graph_exec_arena_t* sdp_graph_exec_arena = 0;
	ccv_nnc_symbolic_graph_compile(sdp_symbolic_graph, ccv_nnc_default_compile_params, 0, 0, 0, 0, SYMBOLIC_GRAPH_SOURCES(sdp_symbolic_graph), SYMBOLIC_GRAPH_DESTINATIONS(sdp_symbolic_graph), &sdp_graph, &sdp_tensor_arena, &sdp_graph_exec_arena);
	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_from_symbol(sdp_tensor_arena, q);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_from_symbol(sdp_tensor_arena, k);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_from_symbol(sdp_tensor_arena, v);
	ccv_nnc_tensor_t* const w_tensor = ccv_nnc_tensor_from_symbol(sdp_tensor_arena, w);
	ccv_nnc_tensor_t* const bias_tensor = ccv_nnc_tensor_from_symbol(sdp_tensor_arena, bias);
	dsfmt_t dsfmt;
	int i;
	dsfmt_init_gen_rand(&dsfmt, 1);
	for (i = 0; i < 32 * 8 * 128 * 64; i++)
		q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 32 * 8 * 128 * 64; i++)
		k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 32 * 8 * 128 * 64; i++)
		v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 512 * 512; i++)
		w_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 512; i++)
		bias_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_symbolic_graph_t* const g_symbolic_graph = ccv_nnc_symbolic_graph_new();
	ccv_nnc_tensor_symbol_t gq = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 32, 128, 8, 64), "q");
	ccv_nnc_tensor_symbol_t gk = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 32, 128, 8, 64), "k");
	ccv_nnc_tensor_symbol_t gv = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 32, 128, 8, 64), "v");
	ccv_nnc_tensor_symbol_t gw = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 512, 512), "w");
	ccv_nnc_tensor_symbol_t gbias = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 512), "bias");
	ccv_nnc_tensor_symbol_t gc = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 32, 128, 8, 64), "c");
	ccv_nnc_tensor_symbol_t gr = ccv_nnc_tensor_symbol_new(g_symbolic_graph, GPU_TENSOR_NHWC(000, 32F, 32, 128, 512), "r");
	ccv_nnc_graph_exec_symbol_new(g_symbolic_graph, CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0 / 8, 0), TENSOR_SYMBOL_LIST(gq, gk, gv, NO_TENSOR_SYMBOL, gw, gbias), TENSOR_SYMBOL_LIST(gr, NO_TENSOR_SYMBOL, gc), "scaled_dot_product_attention");
	ccv_nnc_graph_exec_symbol_autogen(g_symbolic_graph, 0, 0, CCV_NNC_AUTOGEN_ALL_EXECS | CCV_NNC_AUTOGEN_SOURCES_AND_DESTINATIONS);
	ccv_nnc_graph_t* g_graph = 0;
	ccv_nnc_tensor_arena_t* g_tensor_arena = 0;
	ccv_nnc_graph_exec_arena_t* g_graph_exec_arena = 0;
	ccv_nnc_symbolic_graph_compile(g_symbolic_graph, ccv_nnc_default_compile_params, 0, 0, 0, 0, SYMBOLIC_GRAPH_SOURCES(g_symbolic_graph), SYMBOLIC_GRAPH_DESTINATIONS(g_symbolic_graph), &g_graph, &g_tensor_arena, &g_graph_exec_arena);
	ccv_nnc_tensor_t* const gq_tensor = ccv_nnc_tensor_from_symbol(g_tensor_arena, gq);
	ccv_nnc_tensor_t* const gk_tensor = ccv_nnc_tensor_from_symbol(g_tensor_arena, gk);
	ccv_nnc_tensor_t* const gv_tensor = ccv_nnc_tensor_from_symbol(g_tensor_arena, gv);
	ccv_nnc_tensor_t* const gw_tensor = ccv_nnc_tensor_from_symbol(g_tensor_arena, gw);
	ccv_nnc_tensor_t* const gbias_tensor = ccv_nnc_tensor_from_symbol(g_tensor_arena, gbias);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, w_tensor, bias_tensor), TENSOR_LIST(gq_tensor, gk_tensor, gv_tensor, gw_tensor, gbias_tensor), 0);
	ccv_nnc_graph_run(sdp_graph, 0, TRAVERSE_FULL, 0, 0);
	ccv_nnc_graph_run(g_graph, 0, TRAVERSE_FULL, 0, 0);
	ccv_nnc_tensor_t* const r_tensor = ccv_nnc_tensor_from_symbol(sdp_tensor_arena, r);
	ccv_nnc_tensor_t* const gr_tensor = ccv_nnc_tensor_from_symbol(g_tensor_arena, gr);
	ccv_nnc_tensor_t* const hr = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 32, 128, 512), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gr_tensor), TENSOR_LIST(hr), 0);
	float max_relative_diff = 0;
	int max_diff_idx = 0;
	for (i = 0; i < 32 * 128 * 512; i++)
	{
		const float denom = fmaxf(fmaxf(fabsf(r_tensor->data.f32[i]), fabsf(hr->data.f32[i])), 1.0f);
		const float relative_diff = fabsf(r_tensor->data.f32[i] - hr->data.f32[i]) / denom;
		if (relative_diff > max_relative_diff)
			max_relative_diff = relative_diff, max_diff_idx = i;
	}
	REQUIRE(max_relative_diff <= 2e-3, "graph computed result should match scaled dot product attention op result (max relative diff %g at %d: %g vs %g)", max_relative_diff, max_diff_idx, r_tensor->data.f32[max_diff_idx], hr->data.f32[max_diff_idx]);
	ccv_nnc_symbolic_graph_free(sdp_symbolic_graph);
	ccv_nnc_tensor_arena_free(sdp_tensor_arena);
	ccv_nnc_graph_exec_arena_free(sdp_graph_exec_arena);
	ccv_nnc_graph_free(sdp_graph);
	ccv_nnc_symbolic_graph_free(g_symbolic_graph);
	ccv_nnc_tensor_arena_free(g_tensor_arena);
	ccv_nnc_graph_exec_arena_free(g_graph_exec_arena);
	ccv_nnc_graph_free(g_graph);
	ccv_nnc_tensor_free(hr);
}

TEST_CASE("scaled dot product attention + row-wise 8i unify head with mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2;
	const int R = 16;
	const int H = 4;
	const int D = 32;
	const int K = H * D;
	ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const hk = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const hv = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const hw_dense = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, K, K), 0);
	ccv_nnc_tensor_t* const hwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(CPU_TENSOR_NHWC(32F, K, K)), 0);
	ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, K), 0);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 1);
	int i;
	for (i = 0; i < B * R * H * D; i++)
	{
		hq->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
		hk->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
		hv->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	}
	for (i = 0; i < K * K; i++)
		hw_dense->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	for (i = 0; i < K; i++)
		hbias->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	const size_t qsize = ccv_nnc_quantize_8i_rowwise(hw_dense->data.u8, CCV_32F, CCV_TENSOR_CPU_MEMORY, K * K, K, 0, 0, hwq->data.u8, ccv_nnc_tensor_data_size_without_padding(hwq->info));
	REQUIRE_EQ(qsize, ccv_nnc_tensor_data_size_without_padding(hwq->info), "row-wise 8i weight quantization should fit the output tensor");
	ccv_nnc_tensor_t* const gq = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gk = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gv = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gwq = ccv_nnc_tensor_new(0, ccv_nnc_tensor_8i_rowwise(GPU_TENSOR_NHWC(000, 32F, K, K)), 0);
	ccv_nnc_tensor_t* const gwd = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, K, K), 0);
	ccv_nnc_tensor_t* const gbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, K), 0);
	ccv_nnc_tensor_t* const grq = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, K), 0);
	ccv_nnc_tensor_t* const grd = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, K), 0);
	ccv_nnc_tensor_t* const gcq = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
	ccv_nnc_tensor_t* const gcd = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hq, hk, hv, hwq, hbias), TENSOR_LIST(gq, gk, gv, gwq, gbias), 0);
	ccv_nnc_dequantize_8i_rowwise(gwq->data.u8, CCV_32F, CCV_TENSOR_GPU_MEMORY, qsize, K, gwd->data.u8, K * K);
	ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(1.0 / 8, 0);
	cmd.info.scaled_dot_product_attention.flags = CCV_NNC_GEMM_8I;
	ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gq, gk, gv, NULL, gwq, gbias), TENSOR_LIST(grq, NULL, gcq), 0);
	ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gq, gk, gv, NULL, gwd, gbias), TENSOR_LIST(grd, NULL, gcd), 0);
	ccv_nnc_tensor_t* const hrq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, K), 0);
	ccv_nnc_tensor_t* const hrd = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, K), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(grq, grd), TENSOR_LIST(hrq, hrd), 0);
	float max_relative_diff = 0;
	int max_diff_idx = 0;
	for (i = 0; i < B * R * K; i++)
	{
		const float denom = fmaxf(fmaxf(fabsf(hrq->data.f32[i]), fabsf(hrd->data.f32[i])), 1.0f);
		const float relative_diff = fabsf(hrq->data.f32[i] - hrd->data.f32[i]) / denom;
		if (relative_diff > max_relative_diff)
			max_relative_diff = relative_diff, max_diff_idx = i;
	}
	REQUIRE(max_relative_diff <= 5e-2, "row-wise 8i unify head result should match dequantized weight result (max relative diff %g at %d: %g vs %g)", max_relative_diff, max_diff_idx, hrq->data.f32[max_diff_idx], hrd->data.f32[max_diff_idx]);
	ccv_nnc_tensor_free(hq);
	ccv_nnc_tensor_free(hk);
	ccv_nnc_tensor_free(hv);
	ccv_nnc_tensor_free(hw_dense);
	ccv_nnc_tensor_free(hwq);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(gq);
	ccv_nnc_tensor_free(gk);
	ccv_nnc_tensor_free(gv);
	ccv_nnc_tensor_free(gwq);
	ccv_nnc_tensor_free(gwd);
	ccv_nnc_tensor_free(gbias);
	ccv_nnc_tensor_free(grq);
	ccv_nnc_tensor_free(grd);
	ccv_nnc_tensor_free(gcq);
	ccv_nnc_tensor_free(gcd);
	ccv_nnc_tensor_free(hrq);
	ccv_nnc_tensor_free(hrd);
}

TEST_CASE("scaled dot product attention gradient with mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
#define num_long_trials 2
#define num_short_trials 2
#define num_trials (num_long_trials + num_short_trials)

	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 10);
	for (int trial = 0; trial < num_trials; ++trial) {
		int B_candidates[num_trials] = {  32,   3, 2, 1 };
		int R_candidates[num_trials] = { 128,  61, 6, 2 };
		int C_candidates[num_trials] = { 128,  49, 2, 1 };
		int H_candidates[num_trials] = {   8,  13, 3, 1 };
		int D_candidates[num_trials] = {  64, 191, 4, 8 };

		int B = B_candidates[trial];
		int R = R_candidates[trial];
		int C = C_candidates[trial];
		int H = H_candidates[trial];
		int D = D_candidates[trial];
		float scale = 1.0 / sqrt((float)D);

		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);

		for (int i = 0; i < B * R * H * D; ++i) {
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * H * D; ++i) {
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * H * D; ++i) {
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}

		ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		for (int i = 0; i < B * R * H * D; ++i) {
			do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);

		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, H, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, do_tensor), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);

		ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, H, R), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);

		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, H, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dv_tensor->data.f32, dv_tensor->data.f32, B * C * H * D, 5e-3, "scaled dot product attention result should be the same");
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dq_tensor->data.f32, dq_tensor->data.f32, B * R * H * D, 5e-3, "scaled dot product attention result should be the same");
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dk_tensor->data.f32, dk_tensor->data.f32, B * C * H * D, 5e-3, "scaled dot product attention result should be the same");

		ccv_nnc_tensor_free(do_tensor);
		ccv_nnc_tensor_free(gpu_do_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(dq_tensor);
		ccv_nnc_tensor_free(dk_tensor);
		ccv_nnc_tensor_free(dv_tensor);
		ccv_nnc_tensor_free(gpu_dq_tensor);
		ccv_nnc_tensor_free(gpu_dk_tensor);
		ccv_nnc_tensor_free(gpu_dv_tensor);
		ccv_nnc_tensor_free(gpu_softmax_lse);
	}
#undef num_long_trials
#undef num_short_trials
#undef num_trials
}

TEST_CASE("scaled dot product attention grouped-query gradient with mps")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
	const int B = 2;
	const int R = 61;
	const int C = 49;
	const int Hq = 32;
	const int Hk = 8;
	const int D = 128;
	const float scale = 1.0 / sqrt((float)D);
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 10);

	ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
	for (int i = 0; i < B * R * Hq * D; ++i)
	{
		q_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
		do_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	}
	for (int i = 0; i < B * C * Hk * D; ++i)
	{
		k_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
		v_tensor->data.f32[i] = (float)(dsfmt_genrand_open_close(&dsfmt) - 0.5);
	}
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);

	ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
	ccv_nnc_tensor_t* const gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, R, Hq, D), 0);
	ccv_nnc_tensor_t* const gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
	ccv_nnc_tensor_t* const gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, C, Hk, D), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, do_tensor), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);

	const uint64_t old_flags = ccv_nnc_flags();
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);
	for (int use_mps_graph = 0; use_mps_graph < 2; ++use_mps_graph)
	{
		if (use_mps_graph)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
		else
		{
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
		}
		const int status = ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);
		if (old_flags & CCV_NNC_DISABLE_MFA)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
		if (old_flags & CCV_NNC_DISABLE_MFA_ATTENTION)
			ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
		else
			ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_ATTENTION);
		REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "grouped-query attention backward should execute");

		ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);
		for (int i = 0; i < B * R * Hq * D; ++i)
			REQUIRE(isfinite(copy_of_gpu_dq_tensor->data.f32[i]), "grouped-query dQ should stay finite at %d", i);
		for (int i = 0; i < B * C * Hk * D; ++i)
		{
			REQUIRE(isfinite(copy_of_gpu_dk_tensor->data.f32[i]), "grouped-query dK should stay finite at %d", i);
			REQUIRE(isfinite(copy_of_gpu_dv_tensor->data.f32[i]), "grouped-query dV should stay finite at %d", i);
		}
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dq_tensor->data.f32, dq_tensor->data.f32, B * R * Hq * D, 5e-3, "grouped-query dQ should match the CPU reference");
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dk_tensor->data.f32, dk_tensor->data.f32, B * C * Hk * D, 1e-2, "grouped-query dK should match the CPU reference");
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dv_tensor->data.f32, dv_tensor->data.f32, B * C * Hk * D, 1e-2, "grouped-query dV should match the CPU reference");
		ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
	}

	ccv_nnc_tensor_free(q_tensor);
	ccv_nnc_tensor_free(k_tensor);
	ccv_nnc_tensor_free(v_tensor);
	ccv_nnc_tensor_free(do_tensor);
	ccv_nnc_tensor_free(dq_tensor);
	ccv_nnc_tensor_free(dk_tensor);
	ccv_nnc_tensor_free(dv_tensor);
	ccv_nnc_tensor_free(gpu_q_tensor);
	ccv_nnc_tensor_free(gpu_k_tensor);
	ccv_nnc_tensor_free(gpu_v_tensor);
	ccv_nnc_tensor_free(gpu_do_tensor);
	ccv_nnc_tensor_free(gpu_o_tensor);
	ccv_nnc_tensor_free(gpu_softmax_lse);
	ccv_nnc_tensor_free(gpu_dq_tensor);
	ccv_nnc_tensor_free(gpu_dk_tensor);
	ccv_nnc_tensor_free(gpu_dv_tensor);
}

TEST_CASE("scaled dot product attention gradient with mps in half precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
#define num_long_trials 8
#define num_short_trials 4
#define num_trials (num_long_trials + num_short_trials)

	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 10);
	for (int trial = 0; trial < num_trials; ++trial) {
		const int B_candidates[num_trials] = {  32,   12, 16, 1, 2, 1, 32,   12, 16, 1, 2, 1 };
		const int R_candidates[num_trials] = { 160,  256, 128, 77, 77, 5, 160,  256, 128, 77, 77, 5 };
		const int C_candidates[num_trials] = { 128,  128, 128, 128, 128, 5, 128,  128, 128, 128, 128, 5 };
		const int Hq_candidates[num_trials] = {   8,  8, 8, 8, 8, 32, 8,  8, 8, 8, 8, 32 };
		const int Hk_candidates[num_trials] = {   8,  8, 8, 8, 8, 32, 8,  8, 8, 8, 8,  8 };
		const int D_candidates[num_trials] = {  64, 40, 160, 192, 256, 128, 48, 96, 160, 192, 256, 128 };

		const int B = B_candidates[trial];
		const int R = R_candidates[trial];
		const int C = C_candidates[trial];
		const int Hq = Hq_candidates[trial];
		const int Hk = Hk_candidates[trial];
		const int D = D_candidates[trial];
		const int is_causal = 0;
		const float scale = 1.0 / sqrt((float)D);

		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);

		for (int i = 0; i < B * R * Hq * D; ++i) {
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}

		ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		for (int i = 0; i < B * R * Hq * D; ++i) {
			do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const do_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, do_tensor), TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, do_tensor_f16), 0);

		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, do_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);

		ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);

		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, is_causal);
		cmd.info.scaled_dot_product_attention.deterministic = 0;
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor_f16, copy_of_gpu_dk_tensor_f16, copy_of_gpu_dv_tensor_f16), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(copy_of_gpu_dq_tensor_f16, copy_of_gpu_dk_tensor_f16, copy_of_gpu_dv_tensor_f16), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dq_tensor->data.f32, dq_tensor->data.f32, B * R * Hq * D, 1e-3, "scaled dot product attention dQ should be the same for trial %d", trial);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dv_tensor->data.f32, dv_tensor->data.f32, B * C * Hk * D, 6e-3, "scaled dot product attention dV should be the same for trial %d", trial);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dk_tensor->data.f32, dk_tensor->data.f32, B * C * Hk * D, 3e-3, "scaled dot product attention dK should be the same for trial %d", trial);

		ccv_nnc_tensor_free(do_tensor);
		ccv_nnc_tensor_free(gpu_do_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dq_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_dk_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_dv_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(do_tensor_f16);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(dq_tensor);
		ccv_nnc_tensor_free(dk_tensor);
		ccv_nnc_tensor_free(dv_tensor);
		ccv_nnc_tensor_free(gpu_dq_tensor);
		ccv_nnc_tensor_free(gpu_dk_tensor);
		ccv_nnc_tensor_free(gpu_dv_tensor);
		ccv_nnc_tensor_free(gpu_softmax_lse);
	}
#undef num_long_trials
#undef num_short_trials
#undef num_trials
}

TEST_CASE("scaled dot product attention gradient with mps in bfloat precision")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD, CCV_NNC_BACKEND_MPS));
#define num_long_trials 8
#define num_short_trials 4
#define num_trials (num_long_trials + num_short_trials)

	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 10);
	for (int trial = 0; trial < num_trials; ++trial) {
		const int B_candidates[num_trials] = {  32,   12, 16, 1, 2, 1, 32,   12, 16, 1, 2, 1 };
		const int R_candidates[num_trials] = { 160,  256, 128, 77, 77, 5, 160,  256, 128, 77, 77, 5 };
		const int C_candidates[num_trials] = { 128,  128, 128, 128, 128, 5, 128,  128, 128, 128, 128, 5 };
		const int Hq_candidates[num_trials] = {   8,  8, 8, 8, 8, 32, 8,  8, 8, 8, 8, 32 };
		const int Hk_candidates[num_trials] = {   8,  8, 8, 8, 8, 32, 8,  8, 8, 8, 8,  8 };
		const int D_candidates[num_trials] = {  64, 40, 160, 192, 256, 128, 48, 96, 160, 192, 256, 128 };

		const int B = B_candidates[trial];
		const int R = R_candidates[trial];
		const int C = C_candidates[trial];
		const int Hq = Hq_candidates[trial];
		const int Hk = Hk_candidates[trial];
		const int D = D_candidates[trial];
		const int is_causal = 0;
		const float scale = 1.0 / sqrt((float)D);

		ccv_nnc_tensor_t* const q_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);

		for (int i = 0; i < B * R * Hq * D; ++i) {
			q_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			k_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		for (int i = 0; i < B * C * Hk * D; ++i) {
			v_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}

		ccv_nnc_tensor_t* const do_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		for (int i = 0; i < B * R * Hq * D; ++i) {
			do_tensor->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
		}
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(do_tensor, 0, 0, q_tensor, k_tensor, v_tensor), TENSOR_LIST(dq_tensor, dk_tensor, dv_tensor), 0);
		ccv_nnc_tensor_t* const q_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const k_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const v_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const do_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor, k_tensor, v_tensor, do_tensor), TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, do_tensor_f16), 0);

		ccv_nnc_tensor_t* const gpu_q_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_k_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_v_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_o_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_do_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_dq_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const gpu_dk_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const gpu_dv_tensor = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16BF, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(q_tensor_f16, k_tensor_f16, v_tensor_f16, do_tensor_f16), TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, gpu_do_tensor), 0);

		ccv_nnc_tensor_t* const gpu_softmax_lse = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, B, Hq, R), 0);
		ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ATTENTION_FORWARD(scale, is_causal), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, NULL, NULL, NULL), TENSOR_LIST(gpu_o_tensor, gpu_softmax_lse), 0);

		ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ATTENTION_BACKWARD(scale, is_causal);
		cmd.info.scaled_dot_product_attention.deterministic = 0;
		ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_do_tensor, 0, 0, gpu_q_tensor, gpu_k_tensor, gpu_v_tensor, 0, 0, 0, gpu_o_tensor, gpu_softmax_lse), TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor_f16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16BF, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gpu_dq_tensor, gpu_dk_tensor, gpu_dv_tensor), TENSOR_LIST(copy_of_gpu_dq_tensor_f16, copy_of_gpu_dk_tensor_f16, copy_of_gpu_dv_tensor_f16), 0);

		ccv_nnc_tensor_t* const copy_of_gpu_dq_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, R, Hq, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dk_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_tensor_t* const copy_of_gpu_dv_tensor = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, B, C, Hk, D), 0);
		ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(copy_of_gpu_dq_tensor_f16, copy_of_gpu_dk_tensor_f16, copy_of_gpu_dv_tensor_f16), TENSOR_LIST(copy_of_gpu_dq_tensor, copy_of_gpu_dk_tensor, copy_of_gpu_dv_tensor), 0);

		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dq_tensor->data.f32, dq_tensor->data.f32, B * R * Hq * D, 5e-3, "scaled dot product attention bfloat dQ should be the same for trial %d", trial);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dv_tensor->data.f32, dv_tensor->data.f32, B * C * Hk * D, Hq == Hk ? 2e-2 : 3e-2, "scaled dot product attention bfloat dV should be the same for trial %d", trial);
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, copy_of_gpu_dk_tensor->data.f32, dk_tensor->data.f32, B * C * Hk * D, Hq == Hk ? 1e-2 : 2e-2, "scaled dot product attention bfloat dK should be the same for trial %d", trial);

		ccv_nnc_tensor_free(do_tensor);
		ccv_nnc_tensor_free(gpu_do_tensor);
		ccv_nnc_tensor_free(gpu_o_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dq_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_dk_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_dv_tensor_f16);
		ccv_nnc_tensor_free(copy_of_gpu_dq_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dk_tensor);
		ccv_nnc_tensor_free(copy_of_gpu_dv_tensor);
		ccv_nnc_tensor_free(q_tensor);
		ccv_nnc_tensor_free(k_tensor);
		ccv_nnc_tensor_free(v_tensor);
		ccv_nnc_tensor_free(q_tensor_f16);
		ccv_nnc_tensor_free(k_tensor_f16);
		ccv_nnc_tensor_free(v_tensor_f16);
		ccv_nnc_tensor_free(do_tensor_f16);
		ccv_nnc_tensor_free(gpu_q_tensor);
		ccv_nnc_tensor_free(gpu_k_tensor);
		ccv_nnc_tensor_free(gpu_v_tensor);
		ccv_nnc_tensor_free(dq_tensor);
		ccv_nnc_tensor_free(dk_tensor);
		ccv_nnc_tensor_free(dv_tensor);
		ccv_nnc_tensor_free(gpu_dq_tensor);
		ccv_nnc_tensor_free(gpu_dk_tensor);
		ccv_nnc_tensor_free(gpu_dv_tensor);
		ccv_nnc_tensor_free(gpu_softmax_lse);
	}
#undef num_long_trials
#undef num_short_trials
#undef num_trials
}

TEST_CASE("backward gemm with no transpose")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 4, 3), 0);

	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
	};

	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 4, 2), 0);

	float bp[] = {
		21, 22, 23,
		24, 25, 26,
	};

	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);

	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);

	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_t cmd = CMD_GEMM_BACKWARD();
	cmd.backend = CCV_NNC_BACKEND_MPS;
	cmd.algorithm = 1; // This is cblas.

	ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(h, db, dbias), 0);

	ccv_nnc_tensor_t* const ch = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC( 32F, 4, 2), 0);
	ccv_nnc_tensor_t* const cdb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC( 32F, 2, 3), 0);
	ccv_nnc_tensor_t* const cdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC( 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(h, db, dbias), TENSOR_LIST(ch, cdb, cdbias), 0);

	float dbiastp[] = {
		22, 26, 30,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);

	REQUIRE_TENSOR_EQ(cdbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 4, 2), 0);

	REQUIRE_TENSOR_EQ(ch, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 3 * 13 + 6 * 15 + 9 * 17 + 12 * 19,
		1 * 14 + 4 * 16 + 7 * 18 + 10 * 20, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	REQUIRE_TENSOR_EQ(cdb, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
}

TEST_CASE("backward gemm with transpose a")
{
		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	float ap[] = {
		13, 15, 17, 19,
		14, 16, 18, 20,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	float bp[] = {
		21, 22, 23,
		24, 25, 26,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4), 0);
	ccv_nnc_tensor_t* gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22, 26, 30,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 4 * 21 + 5 * 22 + 6 * 23, 7 * 21 + 8 * 22 + 9 * 23, 10 * 21 + 11 * 22 + 12 * 23,
		1 * 24 + 2 * 25 + 3 * 26, 4 * 24 + 5 * 25 + 6 * 26, 7 * 24 + 8 * 25 + 9 * 26, 10 * 24 + 11 * 25 + 12 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 3 * 13 + 6 * 15 + 9 * 17 + 12 * 19,
		1 * 14 + 4 * 16 + 7 * 18 + 10 * 20, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with transpose b")
{
		GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	float bp[] = {
		21, 24,
		22, 25,
		23, 26,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 2), 0);
	ccv_nnc_tensor_t* gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22, 26, 30,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 1 * 14 + 4 * 16 + 7 * 18 + 10 * 20,
		2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20,
		3 * 13 + 6 * 15 + 9 * 17 + 12 * 19, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with transpose a and b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 4, 3), 0);
	float ap[] = {
		13, 15, 17, 19,
		14, 16, 18, 20,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	float bp[] = {
		21, 24,
		22, 25,
		23, 26,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4), 0);
	ccv_nnc_tensor_t* gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(TRANSPOSE(0, 1), TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22, 26, 30,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 4 * 21 + 5 * 22 + 6 * 23, 7 * 21 + 8 * 22 + 9 * 23, 10 * 21 + 11 * 22 + 12 * 23,
		1 * 24 + 2 * 25 + 3 * 26, 4 * 24 + 5 * 25 + 6 * 26, 7 * 24 + 8 * 25 + 9 * 26, 10 * 24 + 11 * 25 + 12 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 1 * 14 + 4 * 16 + 7 * 18 + 10 * 20,
		2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20,
		3 * 13 + 6 * 15 + 9 * 17 + 12 * 19, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}


TEST_CASE("backward gemm large data set")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* g = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* dbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* h = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hg = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hh = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 64; i++)
		hg->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias, hg), TENSOR_LIST(a, w, bias, g), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(hg, ha, hw, 0), TENSOR_LIST(hh, hdw, hdbias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, w, 0), TENSOR_LIST(h, dw, dbias), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* tdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* th = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b, dw, dbias, h), TENSOR_LIST(tb, tdw, tdbias, th), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb->data.f32, hb->data.f32, 10 * 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tdw->data.f32, hdw->data.f32, 64 * 128, 5e-3, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tdbias->data.f32, hdbias->data.f32, 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, th->data.f32, hh->data.f32, 10 * 128, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hg);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hdbias);
	ccv_nnc_tensor_free(hh);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(th);
	ccv_nnc_tensor_free(tdw);
	ccv_nnc_tensor_free(tdbias);
}

TEST_CASE("backward gemm no bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* g = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* h = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hg = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hh = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 64; i++)
		hg->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hg), TENSOR_LIST(a, w, g), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(hg, ha, hw, 0), TENSOR_LIST(hh, hdw, 0), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, w, 0), TENSOR_LIST(h, dw, 0), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* th = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b, dw, h), TENSOR_LIST(tb, tdw, th), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb->data.f32, hb->data.f32, 10 * 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tdw->data.f32, hdw->data.f32, 64 * 128, 5e-3, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, th->data.f32, hh->data.f32, 10 * 128, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hg);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hh);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(th);
	ccv_nnc_tensor_free(tdw);
}

TEST_CASE("backward gemm no h")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* g = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* dw = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* dbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hg = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 64; i++)
		hg->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias, hg), TENSOR_LIST(a, w, bias, g), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(hg, ha, hw, 0), TENSOR_LIST(0, hdw, hdbias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, w, 0), TENSOR_LIST(0, dw, dbias), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* tdw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* tdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b, dw, dbias, 0), TENSOR_LIST(tb, tdw, tdbias, 0), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb->data.f32, hb->data.f32, 10 * 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tdw->data.f32, hdw->data.f32, 64 * 128, 5e-3, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tdbias->data.f32, hdbias->data.f32, 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(dw);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hg);
	ccv_nnc_tensor_free(hdw);
	ccv_nnc_tensor_free(hdbias);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(tdw);
	ccv_nnc_tensor_free(tdbias);
}

TEST_CASE("backward gemm no dw")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	ccv_nnc_tensor_t* a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);
	ccv_nnc_tensor_t* w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64, 128), 0);
	ccv_nnc_tensor_t* bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* g = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 64), 0);
	ccv_nnc_tensor_t* dbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 64), 0);
	ccv_nnc_tensor_t* h = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 10, 128), 0);

	ccv_nnc_tensor_t* ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_tensor_t* hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64, 128), 0);
	ccv_nnc_tensor_t* hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hg = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* hdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* hh = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	int i;
	for (i = 0; i < 64 * 128; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / (64 * 128);
	for (i = 0; i < 64; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 128; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	for (i = 0; i < 10 * 64; i++)
		hg->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias, hg), TENSOR_LIST(a, w, bias, g), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(hg, ha, hw, 0), TENSOR_LIST(hh, 0, hdbias), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, w, 0), TENSOR_LIST(h, 0, dbias), 0);
	ccv_nnc_tensor_t* tb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 64), 0);
	ccv_nnc_tensor_t* tdbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 64), 0);
	ccv_nnc_tensor_t* th = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 10, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b, 0, dbias, h), TENSOR_LIST(tb, 0, tdbias, th), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tb->data.f32, hb->data.f32, 10 * 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, tdbias->data.f32, hdbias->data.f32, 64, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, th->data.f32, hh->data.f32, 10 * 128, 1e-5, "GPU computed output should be numerically close to CPU computed ones");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hg);
	ccv_nnc_tensor_free(hdbias);
	ccv_nnc_tensor_free(hh);
	ccv_nnc_tensor_free(tb);
	ccv_nnc_tensor_free(th);
	ccv_nnc_tensor_free(tdbias);
}

TEST_CASE("backwar gemm with no transpose batch 2, same b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
		131, 141,
		151, 161,
		171, 181,
		191, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		21, 22, 23,
		24, 25, 26,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22 + 220, 26 + 260, 30 + 300,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);
	
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 21 + 20 * 22 + 30 * 23, 10 * 24 + 20 * 25 + 30 * 26,
		40 * 21 + 50 * 22 + 60 * 23, 40 * 24 + 50 * 25 + 60 * 26,
		70 * 21 + 80 * 22 + 90 * 23, 70 * 24 + 80 * 25 + 90 * 26,
		100 * 21 + 110 * 22 + 120 * 23, 100 * 24 + 110 * 25 + 120 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19 + 10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 2 * 13 + 5 * 15 + 8 * 17 + 11 * 19 + 20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 3 * 13 + 6 * 15 + 9 * 17 + 12 * 19 + 30 * 131 + 60 * 151 + 90 * 171 + 120 * 191,
		1 * 14 + 4 * 16 + 7 * 18 + 10 * 20 + 10 * 141 + 40 * 161 + 70 * 181 + 100 * 201, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20 + 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20 + 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with no transpose batch 2, batched b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
		131, 141,
		151, 161,
		171, 181,
		191, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		21, 22, 23,
		24, 25, 26,
		212, 222, 232,
		242, 252, 262,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 1, 3), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 1, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22, 26, 30,
		220, 260, 300,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 2, 1, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 212 + 20 * 222 + 30 * 232, 10 * 242 + 20 * 252 + 30 * 262,
		40 * 212 + 50 * 222 + 60 * 232, 40 * 242 + 50 * 252 + 60 * 262,
		70 * 212 + 80 * 222 + 90 * 232, 70 * 242 + 80 * 252 + 90 * 262,
		100 * 212 + 110 * 222 + 120 * 232, 100 * 242 + 110 * 252 + 120 * 262,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 3 * 13 + 6 * 15 + 9 * 17 + 12 * 19,
		1 * 14 + 4 * 16 + 7 * 18 + 10 * 20, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
		10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 30 * 131 + 60 * 151 + 90 * 171 + 120 * 191,
		10 * 141 + 40 * 161 + 70 * 181 + 100 * 201, 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201, 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with transpose a batch 2, same b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 15, 17, 19,
		14, 16, 18, 20,
		131, 151, 171, 191,
		141, 161, 181, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	float bp[] = {
		21, 22, 23,
		24, 25, 26,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3), 0);
	ccv_nnc_tensor_t* const gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22 + 220, 26 + 260, 30 + 300,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 4 * 21 + 5 * 22 + 6 * 23, 7 * 21 + 8 * 22 + 9 * 23, 10 * 21 + 11 * 22 + 12 * 23,
		1 * 24 + 2 * 25 + 3 * 26, 4 * 24 + 5 * 25 + 6 * 26, 7 * 24 + 8 * 25 + 9 * 26, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 21 + 20 * 22 + 30 * 23, 40 * 21 + 50 * 22 + 60 * 23, 70 * 21 + 80 * 22 + 90 * 23, 100 * 21 + 110 * 22 + 120 * 23,
		10 * 24 + 20 * 25 + 30 * 26, 40 * 24 + 50 * 25 + 60 * 26, 70 * 24 + 80 * 25 + 90 * 26, 100 * 24 + 110 * 25 + 120 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19 + 10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 2 * 13 + 5 * 15 + 8 * 17 + 11 * 19 + 20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 3 * 13 + 6 * 15 + 9 * 17 + 12 * 19 + 30 * 131 + 60 * 151 + 90 * 171 + 120 * 191,
		1 * 14 + 4 * 16 + 7 * 18 + 10 * 20 + 10 * 141 + 40 * 161 + 70 * 181 + 100 * 201, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20 + 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20 + 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with transpose b batch 2, batched b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
		131, 141,
		151, 161,
		171, 181,
		191, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		21, 24,
		22, 25,
		23, 26,
		212, 242,
		222, 252,
		232, 262,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 1, 3), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 1, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22, 26, 30,
		220, 260, 300,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 2, 1, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 212 + 20 * 222 + 30 * 232, 10 * 242 + 20 * 252 + 30 * 262,
		40 * 212 + 50 * 222 + 60 * 232, 40 * 242 + 50 * 252 + 60 * 262,
		70 * 212 + 80 * 222 + 90 * 232, 70 * 242 + 80 * 252 + 90 * 262,
		100 * 212 + 110 * 222 + 120 * 232, 100 * 242 + 110 * 252 + 120 * 262,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 1 * 14 + 4 * 16 + 7 * 18 + 10 * 20,
		2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20,
		3 * 13 + 6 * 15 + 9 * 17 + 12 * 19, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
		10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 10 * 141 + 40 * 161 + 70 * 181 + 100 * 201,
		20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201,
		30 * 131 + 60 * 151 + 90 * 171 + 120 * 191, 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with transpose a and b batch 2, same b")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 15, 17, 19,
		14, 16, 18, 20,
		131, 151, 171, 191,
		141, 161, 181, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	float bp[] = {
		21, 24,
		22, 25,
		23, 26,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const dbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 2), 0);
	ccv_nnc_tensor_t* const gdbias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(TRANSPOSE(1, 2), TRANSPOSE(0, 1)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb, gdbias), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb, gdbias), TENSOR_LIST(h, db, dbias), 0);
	float dbiastp[] = {
		22 + 220, 26 + 260, 30 + 300,
	};
	ccv_nnc_tensor_t dbiast = ccv_nnc_tensor(dbiastp, CPU_TENSOR_NHWC(32F, 3), 0);
	REQUIRE_TENSOR_EQ(dbias, &dbiast, "bias should be equal");
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 4 * 21 + 5 * 22 + 6 * 23, 7 * 21 + 8 * 22 + 9 * 23, 10 * 21 + 11 * 22 + 12 * 23,
		1 * 24 + 2 * 25 + 3 * 26, 4 * 24 + 5 * 25 + 6 * 26, 7 * 24 + 8 * 25 + 9 * 26, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 21 + 20 * 22 + 30 * 23, 40 * 21 + 50 * 22 + 60 * 23, 70 * 21 + 80 * 22 + 90 * 23, 100 * 21 + 110 * 22 + 120 * 23,
		10 * 24 + 20 * 25 + 30 * 26, 40 * 24 + 50 * 25 + 60 * 26, 70 * 24 + 80 * 25 + 90 * 26, 100 * 24 + 110 * 25 + 120 * 26,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19 + 10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 1 * 14 + 4 * 16 + 7 * 18 + 10 * 20 + 10 * 141 + 40 * 161 + 70 * 181 + 100 * 201,
		2 * 13 + 5 * 15 + 8 * 17 + 11 * 19 + 20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20 + 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201,
		3 * 13 + 6 * 15 + 9 * 17 + 12 * 19 + 30 * 131 + 60 * 151 + 90 * 171 + 120 * 191, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20 + 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(dbias);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
	ccv_nnc_tensor_free(gdbias);
}

TEST_CASE("backward gemm with no transpose batch 2, batched b, no bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
		131, 141,
		151, 161,
		171, 181,
		191, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		21, 22, 23,
		24, 25, 26,
		212, 222, 232,
		242, 252, 262,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 3), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 3), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb), TENSOR_LIST(h, db), 0);
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 212 + 20 * 222 + 30 * 232, 10 * 242 + 20 * 252 + 30 * 262,
		40 * 212 + 50 * 222 + 60 * 232, 40 * 242 + 50 * 252 + 60 * 262,
		70 * 212 + 80 * 222 + 90 * 232, 70 * 242 + 80 * 252 + 90 * 262,
		100 * 212 + 110 * 222 + 120 * 232, 100 * 242 + 110 * 252 + 120 * 262,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 3 * 13 + 6 * 15 + 9 * 17 + 12 * 19,
		1 * 14 + 4 * 16 + 7 * 18 + 10 * 20, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
		10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 30 * 131 + 60 * 151 + 90 * 171 + 120 * 191,
		10 * 141 + 40 * 161 + 70 * 181 + 100 * 201, 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201, 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 2, 3), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
}

TEST_CASE("backward gemm with transpose b batch 2, batched b, no bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 14,
		15, 16,
		17, 18,
		19, 20,
		131, 141,
		151, 161,
		171, 181,
		191, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	float bp[] = {
		21, 24,
		22, 25,
		23, 26,
		212, 242,
		222, 252,
		232, 262,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 2), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb), TENSOR_LIST(h, db), 0);
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 1 * 24 + 2 * 25 + 3 * 26,
		4 * 21 + 5 * 22 + 6 * 23, 4 * 24 + 5 * 25 + 6 * 26,
		7 * 21 + 8 * 22 + 9 * 23, 7 * 24 + 8 * 25 + 9 * 26,
		10 * 21 + 11 * 22 + 12 * 23, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 212 + 20 * 222 + 30 * 232, 10 * 242 + 20 * 252 + 30 * 262,
		40 * 212 + 50 * 222 + 60 * 232, 40 * 242 + 50 * 252 + 60 * 262,
		70 * 212 + 80 * 222 + 90 * 232, 70 * 242 + 80 * 252 + 90 * 262,
		100 * 212 + 110 * 222 + 120 * 232, 100 * 242 + 110 * 252 + 120 * 262,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 4, 2), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 1 * 14 + 4 * 16 + 7 * 18 + 10 * 20,
		2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20,
		3 * 13 + 6 * 15 + 9 * 17 + 12 * 19, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
		10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 10 * 141 + 40 * 161 + 70 * 181 + 100 * 201,
		20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201,
		30 * 131 + 60 * 151 + 90 * 171 + 120 * 191, 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
}

TEST_CASE("backward gemm with transpose a and b batch 2, batch b, no bias")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_GEMM_FORWARD, CCV_NNC_BACKEND_MPS) &&
		ccv_nnc_cmd_ok(CCV_NNC_GEMM_BACKWARD, CCV_NNC_BACKEND_MPS));
	float gp[] = {
		1, 2, 3,
		4, 5, 6,
		7, 8, 9,
		10, 11, 12,
		10, 20, 30,
		40, 50, 60,
		70, 80, 90,
		100, 110, 120,
	};
	ccv_nnc_tensor_t* const g = ccv_nnc_tensor_new(gp, CPU_TENSOR_NHWC(32F, 2, 4, 3), 0);
	float ap[] = {
		13, 15, 17, 19,
		14, 16, 18, 20,
		131, 151, 171, 191,
		141, 161, 181, 201,
	};
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(ap, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	float bp[] = {
		21, 24,
		22, 25,
		23, 26,
		212, 242,
		222, 252,
		232, 262,
	};
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(bp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const h = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const db = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const gg = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 4, 3), 0);
	ccv_nnc_tensor_t* const ga = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const gb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_tensor_t* const gh = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 2, 4), 0);
	ccv_nnc_tensor_t* const gdb = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 2, 3, 2), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(g, a, b), TENSOR_LIST(gg, ga, gb), 0);
	ccv_nnc_cmd_exec(CMD_GEMM_BACKWARD(TRANSPOSE(1, 2), TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(gg, ga, gb), TENSOR_LIST(gh, gdb), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(gh, gdb), TENSOR_LIST(h, db), 0);
	float htp[] = {
		1 * 21 + 2 * 22 + 3 * 23, 4 * 21 + 5 * 22 + 6 * 23, 7 * 21 + 8 * 22 + 9 * 23, 10 * 21 + 11 * 22 + 12 * 23,
		1 * 24 + 2 * 25 + 3 * 26, 4 * 24 + 5 * 25 + 6 * 26, 7 * 24 + 8 * 25 + 9 * 26, 10 * 24 + 11 * 25 + 12 * 26,
		10 * 212 + 20 * 222 + 30 * 232, 40 * 212 + 50 * 222 + 60 * 232, 70 * 212 + 80 * 222 + 90 * 232, 100 * 212 + 110 * 222 + 120 * 232,
		10 * 242 + 20 * 252 + 30 * 262, 40 * 242 + 50 * 252 + 60 * 262, 70 * 242 + 80 * 252 + 90 * 262, 100 * 242 + 110 * 252 + 120 * 262,
	};
	ccv_nnc_tensor_t ht = ccv_nnc_tensor(htp, CPU_TENSOR_NHWC(32F, 2, 2, 4), 0);
	REQUIRE_TENSOR_EQ(h, &ht, "h should be equal");
	float dbtp[] = {
		1 * 13 + 4 * 15 + 7 * 17 + 10 * 19, 1 * 14 + 4 * 16 + 7 * 18 + 10 * 20,
		2 * 13 + 5 * 15 + 8 * 17 + 11 * 19, 2 * 14 + 5 * 16 + 8 * 18 + 11 * 20,
		3 * 13 + 6 * 15 + 9 * 17 + 12 * 19, 3 * 14 + 6 * 16 + 9 * 18 + 12 * 20,
		10 * 131 + 40 * 151 + 70 * 171 + 100 * 191, 10 * 141 + 40 * 161 + 70 * 181 + 100 * 201,
		20 * 131 + 50 * 151 + 80 * 171 + 110 * 191, 20 * 141 + 50 * 161 + 80 * 181 + 110 * 201,
		30 * 131 + 60 * 151 + 90 * 171 + 120 * 191, 30 * 141 + 60 * 161 + 90 * 181 + 120 * 201,
	};
	ccv_nnc_tensor_t dbt = ccv_nnc_tensor(dbtp, CPU_TENSOR_NHWC(32F, 2, 3, 2), 0);
	REQUIRE_TENSOR_EQ(db, &dbt, "db should be equal");
	ccv_nnc_tensor_free(g);
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(h);
	ccv_nnc_tensor_free(db);
	ccv_nnc_tensor_free(gg);
	ccv_nnc_tensor_free(ga);
	ccv_nnc_tensor_free(gb);
	ccv_nnc_tensor_free(gh);
	ccv_nnc_tensor_free(gdb);
}

TEST_CASE("mps segmented gemm")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 11);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 384, 256), 0);
	ccv_nnc_tensor_t* const hindices = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 3), 0);
	hindices->data.i32[0] = 1;
	hindices->data.i32[1] = 0;
	hindices->data.i32[2] = 2;
	ccv_nnc_tensor_t* const hcounts = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 3), 0);
	hcounts->data.i32[0] = 129;
	hcounts->data.i32[1] = 131;
	hcounts->data.i32[2] = 124;
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 128, 256), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 384, 128), 0);
	ccv_nnc_tensor_t* const bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 384, 128), 0);
	int i;
	for (i = 0; i < 3 * 128 * 256; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / 256;
	for (i = 0; i < 384 * 256; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 384, 256), 0);
	ccv_nnc_tensor_t* const indices = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, 3), 0);
	ccv_nnc_tensor_t* const counts = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, 3), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 3, 128, 256), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32F, 384, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hindices, hcounts, hw), TENSOR_LIST(a, indices, counts, w), 0);
	ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, indices, counts, w), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hindices, hcounts, hw), TENSOR_LIST(bt), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, hb->data.f32, bt->data.f32, 384 * 128, 3e-4, "segmented GEMM result should match CPU reference");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(indices);
	ccv_nnc_tensor_free(counts);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hindices);
	ccv_nnc_tensor_free(hcounts);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(bt);
}

TEST_CASE("mps segmented gemm with bias in half precision, split-k")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SEGMENTED_GEMM_FORWARD, CCV_NNC_BACKEND_MPS));
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 13);
	ccv_nnc_tensor_t* const ha = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 272, 4096), 0);
	ccv_nnc_tensor_t* const hindices = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 2), 0);
	hindices->data.i32[0] = 1;
	hindices->data.i32[1] = 0;
	ccv_nnc_tensor_t* const hcounts = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 2), 0);
	hcounts->data.i32[0] = 136;
	hcounts->data.i32[1] = 136;
	ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 128, 4096), 0);
	ccv_nnc_tensor_t* const hbias = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 2, 128), 0);
	ccv_nnc_tensor_t* const hb = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 272, 128), 0);
	ccv_nnc_tensor_t* const hb16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 272, 128), 0);
	ccv_nnc_tensor_t* const bt = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 272, 128), 0);
	int i;
	for (i = 0; i < 2 * 128 * 4096; i++)
		hw->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / 4096;
	for (i = 0; i < 2 * 128; i++)
		hbias->data.f32[i] = dsfmt_genrand_open_close(&dsfmt) / 128;
	for (i = 0; i < 272 * 4096; i++)
		ha->data.f32[i] = dsfmt_genrand_open_close(&dsfmt);
	ccv_nnc_tensor_t* const ha16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 272, 4096), 0);
	ccv_nnc_tensor_t* const hw16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 2, 128, 4096), 0);
	ccv_nnc_tensor_t* const hbias16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, 2, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hw, hbias), TENSOR_LIST(ha16, hw16, hbias16), 0);
	ccv_nnc_tensor_t* const a = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 272, 4096), 0);
	ccv_nnc_tensor_t* const indices = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, 2), 0);
	ccv_nnc_tensor_t* const counts = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, 2), 0);
	ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 2, 128, 4096), 0);
	ccv_nnc_tensor_t* const bias = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 2, 128), 0);
	ccv_nnc_tensor_t* const b = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, 272, 128), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(ha16, hindices, hcounts, hw16, hbias16), TENSOR_LIST(a, indices, counts, w, bias), 0);
	ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(a, indices, counts, w, bias), TENSOR_LIST(b), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(b), TENSOR_LIST(hb16), 0);
	ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hb16), TENSOR_LIST(hb), 0);
	ccv_nnc_cmd_exec(CMD_SEGMENTED_GEMM_FORWARD(NO_TRANSPOSE, TRANSPOSE(1, 2)), ccv_nnc_no_hint, 0, TENSOR_LIST(ha, hindices, hcounts, hw, hbias), TENSOR_LIST(bt), 0);
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, hb->data.f32, bt->data.f32, 272 * 128, 2e-2, "half-precision segmented GEMM result should match CPU reference");
	ccv_nnc_tensor_free(a);
	ccv_nnc_tensor_free(indices);
	ccv_nnc_tensor_free(counts);
	ccv_nnc_tensor_free(w);
	ccv_nnc_tensor_free(bias);
	ccv_nnc_tensor_free(b);
	ccv_nnc_tensor_free(ha);
	ccv_nnc_tensor_free(hindices);
	ccv_nnc_tensor_free(hcounts);
	ccv_nnc_tensor_free(hw);
	ccv_nnc_tensor_free(hbias);
	ccv_nnc_tensor_free(hb);
	ccv_nnc_tensor_free(hb16);
	ccv_nnc_tensor_free(bt);
	ccv_nnc_tensor_free(ha16);
	ccv_nnc_tensor_free(hw16);
	ccv_nnc_tensor_free(hbias16);
}

// Derived from shapes.txt NA lines, assuming the call shape is C = A @ B^T.
NA_GEMM_SHAPE_TEST(306, 2048, 3840)
NA_GEMM_SHAPE_TEST(306, 4096, 3840)
NA_GEMM_SHAPE_TEST(306, 3840, 4096)
NA_GEMM_SHAPE_TEST(306, 15360, 3840)
NA_GEMM_SHAPE_TEST(306, 3840, 15360)
NA_GEMM_SHAPE_TEST(1024, 4096, 4096)
NA_GEMM_SHAPE_TEST(1024, 32, 4096)
NA_GEMM_SHAPE_TEST(1024, 16384, 4096)
NA_GEMM_SHAPE_TEST(1024, 4096, 16384)
NA_GEMM_SHAPE_TEST(1024, 2048, 2048)
NA_GEMM_SHAPE_TEST(1024, 32, 2048)
NA_GEMM_SHAPE_TEST(1024, 8192, 2048)
NA_GEMM_SHAPE_TEST(1024, 2048, 8192)
NA_GEMM_SHAPE_TEST(1, 2048, 256)
NA_GEMM_SHAPE_TEST(1, 2048, 2048)
NA_GEMM_SHAPE_TEST(1, 4096, 256)
NA_GEMM_SHAPE_TEST(1, 4096, 4096)
NA_GEMM_SHAPE_TEST(2, 2048, 2048)
NA_GEMM_SHAPE_TEST(2, 4096, 4096)
NA_GEMM_SHAPE_TEST(3, 4096, 4096)
NA_GEMM_SHAPE_TEST(4, 4096, 4096)
NA_GEMM_SHAPE_TEST(5, 4096, 4096)
NA_GEMM_SHAPE_TEST(6, 1024, 3072)
NA_GEMM_SHAPE_TEST(6, 4096, 4096)
NA_GEMM_SHAPE_TEST(7, 4096, 4096)
NA_GEMM_SHAPE_TEST(8, 4096, 4096)
NA_GEMM_SHAPE_TEST(16, 4096, 4096)
NA_GEMM_SHAPE_TEST(32, 4096, 4096)
NA_GEMM_SHAPE_TEST(48, 4096, 4096)
NA_GEMM_SHAPE_TEST(48, 4096, 15360)
NA_GEMM_SHAPE_TEST(16, 4096, 24576)
NA_GEMM_SHAPE_TEST(3, 4096, 32768)
NA_GEMM_SHAPE_TEST(6, 4096, 32768)
NA_GEMM_SHAPE_TEST(8, 4096, 32768)
NA_GEMM_SHAPE_TEST(16, 4096, 32768)
NA_GEMM_SHAPE_TEST(1024, 4096, 128)
NA_GEMM_SHAPE_TEST(257, 2048, 128)
NA_GEMM_SHAPE_TEST(33792, 4096, 4096)
NA_GEMM_SHAPE_TEST(33792, 32, 4096)
NA_GEMM_SHAPE_TEST(257, 2048, 2048)
NA_GEMM_SHAPE_TEST(257, 32, 2048)
NA_GEMM_SHAPE_TEST(33792, 2048, 4096)
NA_GEMM_SHAPE_TEST(33792, 4096, 2048)
NA_GEMM_SHAPE_TEST(33792, 16384, 4096)
NA_GEMM_SHAPE_TEST(33792, 4096, 16384)
NA_GEMM_SHAPE_TEST(257, 8192, 2048)
NA_GEMM_SHAPE_TEST(257, 2048, 8192)
NA_GEMM_SHAPE_TEST(33792, 128, 4096)
NA_GEMM_SHAPE_TEST(257, 128, 2048)
NA_GEMM_BIAS_SHAPE_TEST(306, 2048, 3840)
NA_GEMM_BIAS_SHAPE_TEST(306, 4096, 3840)
NA_GEMM_BIAS_SHAPE_TEST(306, 3840, 4096)
NA_GEMM_BIAS_SHAPE_TEST(306, 15360, 3840)
NA_GEMM_BIAS_SHAPE_TEST(306, 3840, 15360)
NA_GEMM_BIAS_SHAPE_TEST(1024, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(1024, 32, 4096)
NA_GEMM_BIAS_SHAPE_TEST(1024, 16384, 4096)
NA_GEMM_BIAS_SHAPE_TEST(1024, 4096, 16384)
NA_GEMM_BIAS_SHAPE_TEST(1024, 2048, 2048)
NA_GEMM_BIAS_SHAPE_TEST(1024, 32, 2048)
NA_GEMM_BIAS_SHAPE_TEST(1024, 8192, 2048)
NA_GEMM_BIAS_SHAPE_TEST(1024, 2048, 8192)
NA_GEMM_BIAS_SHAPE_TEST(1, 2048, 256)
NA_GEMM_BIAS_SHAPE_TEST(1, 2048, 2048)
NA_GEMM_BIAS_SHAPE_TEST(1, 4096, 256)
NA_GEMM_BIAS_SHAPE_TEST(1, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(2, 2048, 2048)
NA_GEMM_BIAS_SHAPE_TEST(2, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(3, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(4, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(5, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(6, 1024, 3072)
NA_GEMM_BIAS_SHAPE_TEST(6, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(7, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(8, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(3, 4096, 32768)
NA_GEMM_BIAS_SHAPE_TEST(16, 4096, 32768)
NA_GEMM_BIAS_SHAPE_TEST(32, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(48, 4096, 4096)
NA_GEMM_BFLOAT_SHAPE_TEST(3, 4096, 4096)
NA_GEMM_BFLOAT_SHAPE_TEST(5, 4096, 4096)
NA_GEMM_BFLOAT_SHAPE_TEST(6, 1024, 3072)
NA_GEMM_BFLOAT_SHAPE_TEST(7, 4096, 4096)
NA_GEMM_BFLOAT_SHAPE_TEST(8, 4096, 4096)
NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(3, 4096, 4096)
NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(5, 4096, 4096)
NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(6, 1024, 3072)
NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(7, 4096, 4096)
NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(8, 4096, 4096)
NA_GEMM_BFLOAT_SHAPE_TEST(48, 4096, 4096)
NA_GEMM_BFLOAT_BIAS_SHAPE_TEST(48, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(1024, 4096, 128)
NA_GEMM_BIAS_SHAPE_TEST(257, 2048, 128)
NA_GEMM_BIAS_SHAPE_TEST(33792, 4096, 4096)
NA_GEMM_BIAS_SHAPE_TEST(33792, 32, 4096)
NA_GEMM_BIAS_SHAPE_TEST(257, 2048, 2048)
NA_GEMM_BIAS_SHAPE_TEST(257, 32, 2048)
NA_GEMM_BIAS_SHAPE_TEST(33792, 2048, 4096)
NA_GEMM_BIAS_SHAPE_TEST(33792, 4096, 2048)
NA_GEMM_BIAS_SHAPE_TEST(33792, 16384, 4096)
NA_GEMM_BIAS_SHAPE_TEST(33792, 4096, 16384)
NA_GEMM_BIAS_SHAPE_TEST(257, 8192, 2048)
NA_GEMM_BIAS_SHAPE_TEST(257, 2048, 8192)
NA_GEMM_BIAS_SHAPE_TEST(33792, 128, 4096)
NA_GEMM_BIAS_SHAPE_TEST(257, 128, 2048)

TEST_CASE("scaled dot product arg partition cpu reference")
{
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 2, 2), 0);
	ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 2), 0);
	ccv_nnc_tensor_t* const head_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 2), 0);
	ccv_nnc_tensor_t* const selected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 1, 3), 0);
	q->data.f32[0] = 1;
	q->data.f32[1] = 0;
	q->data.f32[2] = 0;
	q->data.f32[3] = 1;
	const float k_data[] = { 1, 1, 2, -1, -1, 3, 0, 0 };
	memcpy(k->data.f32, k_data, sizeof(k_data));
	head_w->data.f32[0] = 1;
	head_w->data.f32[1] = -2;
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD(3, 1, 0, 4, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, head_w), TENSOR_LIST(selected), 0);
	const int expected[] = { 1, 3, 0 };
	REQUIRE_ARRAY_EQ(int, selected->data.i32, expected, 3, "arg partition should apply relu before head weights and sort descending");
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(k);
	ccv_nnc_tensor_free(head_w);
	ccv_nnc_tensor_free(selected);
}

TEST_CASE("scaled dot product arg partition causal compression cpu reference")
{
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 1, 1), 0);
	ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 1), 0);
	ccv_nnc_tensor_t* const head_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 5, 1), 0);
	ccv_nnc_tensor_t* const selected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 5, 3), 0);
	int i;
	for (i = 0; i < 5; i++)
		q->data.f32[i] = head_w->data.f32[i] = 1;
	k->data.f32[0] = 1;
	k->data.f32[1] = 2;
	k->data.f32[2] = 3;
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD(3, 1, 1, 4, 7), ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, head_w), TENSOR_LIST(selected), 0);
	const int expected[] = {
		0, 1, -1,
		0, 1, -1,
		0, 1, -1,
		0, 1, -1,
		0, 1, 2,
	};
	REQUIRE_ARRAY_EQ(int, selected->data.i32, expected, 15, "causal compression should return every visible row chronologically when all rows fit");
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(k);
	ccv_nnc_tensor_free(head_w);
	ccv_nnc_tensor_free(selected);
}

TEST_CASE("scaled dot product arg partition uses the absolute query offset for causal compression")
{
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 1, 1), 0);
	ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 40, 1), 0);
	ccv_nnc_tensor_t* const head_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 4, 1), 0);
	ccv_nnc_tensor_t* const selected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 4, 4), 0);
	int i;
	for (i = 0; i < 4; i++)
		q->data.f32[i] = head_w->data.f32[i] = 1;
	for (i = 0; i < 40; i++)
		k->data.f32[i] = i + 1;
	ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD(4, 1, 1, 4, 159), ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, head_w), TENSOR_LIST(selected), 0);
	const int expected[] = {
		39, 38, 37, 36,
		39, 38, 37, 36,
		39, 38, 37, 36,
		39, 38, 37, 36,
	};
	REQUIRE_ARRAY_EQ(int, selected->data.i32, expected, 16, "all four queries should see all 40 completed compressed rows");
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(k);
	ccv_nnc_tensor_free(head_w);
	ccv_nnc_tensor_free(selected);
}

TEST_CASE("scaled dot product arg partition cpu reference pads an empty key set")
{
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 2, 4), 0);
	ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 0, 4), 0);
	ccv_nnc_tensor_t* const head_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 3, 2), 0);
	ccv_nnc_tensor_t* const selected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 3, 5), 0);
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD(5, 1, 1, 4, 0), ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, head_w), TENSOR_LIST(selected), 0), "arg partition should accept an empty key set");
	const int expected[] = {
		-1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1,
	};
	REQUIRE_ARRAY_EQ(int, selected->data.i32, expected, 15, "an empty key set should produce only terminators");
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(k);
	ccv_nnc_tensor_free(head_w);
	ccv_nnc_tensor_free(selected);
}

static void _mps_scaled_dot_product_arg_partition_fill_stable(ccv_nnc_tensor_t* const q, ccv_nnc_tensor_t* const k, ccv_nnc_tensor_t* const head_w)
{
	const int T = q->info.dim[0];
	const int H = q->info.dim[1];
	const int D = q->info.dim[2];
	const int C = k->info.dim[0];
	int t, h, d, c;
	for (t = 0; t < T; t++)
		for (h = 0; h < H; h++)
			for (d = 0; d < D; d++)
				q->data.f32[(t * H + h) * D + d] = (d == 0) ? (1.0f + (float)h / 1024.0f) : 0;
	for (c = 0; c < C; c++)
		for (d = 0; d < D; d++)
			k->data.f32[c * D + d] = (d == 0) ? (float)(c + 1) : 0;
	for (t = 0; t < T; t++)
		for (h = 0; h < H; h++)
			head_w->data.f32[t * H + h] = 1;
}

static void _mps_scaled_dot_product_arg_partition_from_float(const int datatype, const float* const source, ccv_nnc_tensor_t* const tensor, const int count)
{
	if (count == 0)
		return;
	if (datatype == CCV_32F)
		memcpy(tensor->data.f32, source, sizeof(float) * count);
	else if (datatype == CCV_16F)
		ccv_float_to_half_precision(source, (uint16_t*)tensor->data.f16, count);
	else if (datatype == CCV_16BF)
		ccv_float_to_bfloat(source, (uint16_t*)tensor->data.f16, count);
	else
		assert(0);
}

static void _mps_scaled_dot_product_arg_partition_to_float(const int datatype, const ccv_nnc_tensor_t* const tensor, float* const destination, const int count)
{
	if (count == 0)
		return;
	if (datatype == CCV_32F)
		memcpy(destination, tensor->data.f32, sizeof(float) * count);
	else if (datatype == CCV_16F)
		ccv_half_precision_to_float((uint16_t*)tensor->data.f16, destination, count);
	else if (datatype == CCV_16BF)
		ccv_bfloat_to_float((uint16_t*)tensor->data.f16, destination, count);
	else
		assert(0);
}

static int _mps_scaled_dot_product_arg_partition_compare(const int T, const int C, const int H, const int D, const int kth, const int is_causal, const int compression_ratio, const int query_offset, const int datatype, const int force_graph, const int force_generic_mfa)
{
	ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, H, D), 0);
	ccv_nnc_tensor_t* const hk = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, C, D), 0);
	ccv_nnc_tensor_t* const hhead_w = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, H), 0);
	ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, T, kth), 0);
	ccv_nnc_tensor_t* const hselected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, T, kth), 0);
	_mps_scaled_dot_product_arg_partition_fill_stable(hq, hk, hhead_w);
	ccv_nnc_tensor_param_t hq_input_params = CPU_TENSOR_NHWC(32F, T, H, D);
	hq_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t hk_input_params = CPU_TENSOR_NHWC(32F, C, D);
	hk_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t hhead_w_input_params = CPU_TENSOR_NHWC(32F, T, H);
	hhead_w_input_params.datatype = datatype;
	ccv_nnc_tensor_t* const hq_input = ccv_nnc_tensor_new(0, hq_input_params, 0);
	ccv_nnc_tensor_t* const hk_input = ccv_nnc_tensor_new(0, hk_input_params, 0);
	ccv_nnc_tensor_t* const hhead_w_input = ccv_nnc_tensor_new(0, hhead_w_input_params, 0);
	_mps_scaled_dot_product_arg_partition_from_float(datatype, hq->data.f32, hq_input, T * H * D);
	_mps_scaled_dot_product_arg_partition_from_float(datatype, hk->data.f32, hk_input, C * D);
	_mps_scaled_dot_product_arg_partition_from_float(datatype, hhead_w->data.f32, hhead_w_input, T * H);
	_mps_scaled_dot_product_arg_partition_to_float(datatype, hq_input, hq->data.f32, T * H * D);
	_mps_scaled_dot_product_arg_partition_to_float(datatype, hk_input, hk->data.f32, C * D);
	_mps_scaled_dot_product_arg_partition_to_float(datatype, hhead_w_input, hhead_w->data.f32, T * H);
	ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD(kth, 1, is_causal, compression_ratio, query_offset);
	ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(hq, hk, hhead_w), TENSOR_LIST(href), 0);
	ccv_nnc_tensor_param_t q_params = GPU_TENSOR_NHWC(000, 32F, T, H, D);
	q_params.datatype = datatype;
	ccv_nnc_tensor_param_t k_params = GPU_TENSOR_NHWC(000, 32F, C, D);
	k_params.datatype = datatype;
	ccv_nnc_tensor_param_t head_w_params = GPU_TENSOR_NHWC(000, 32F, T, H);
	head_w_params.datatype = datatype;
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, q_params, 0);
	ccv_nnc_tensor_t* const kg = ccv_nnc_tensor_new(0, k_params, 0);
	ccv_nnc_tensor_t* const head_w = ccv_nnc_tensor_new(0, head_w_params, 0);
	ccv_nnc_tensor_t* const selected = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, T, kth), 0);
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hq_input, hk_input, hhead_w_input), TENSOR_LIST(q, kg, head_w), 0);
	const uint64_t old_flags = ccv_nnc_flags();
	if (force_graph)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	if (force_generic_mfa)
	{
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	}
	const int gpu_status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, kg, head_w), TENSOR_LIST(selected), 0);
	if (old_flags & CCV_NNC_DISABLE_MFA)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
	if (old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)
		ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	else
		ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
	int i;
	int mismatch = 0;
	if (gpu_status != CCV_NNC_EXEC_SUCCESS)
		mismatch = -1;
	else {
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(selected), TENSOR_LIST(hselected), 0);
		for (i = 0; i < T * kth && !mismatch; i++)
			if (hselected->data.i32[i] != href->data.i32[i])
				mismatch = i + 1;
	}
	ccv_nnc_tensor_free(hq);
	ccv_nnc_tensor_free(hk);
	ccv_nnc_tensor_free(hhead_w);
	ccv_nnc_tensor_free(hq_input);
	ccv_nnc_tensor_free(hk_input);
	ccv_nnc_tensor_free(hhead_w_input);
	ccv_nnc_tensor_free(href);
	ccv_nnc_tensor_free(hselected);
	ccv_nnc_tensor_free(q);
	ccv_nnc_tensor_free(kg);
	ccv_nnc_tensor_free(head_w);
	ccv_nnc_tensor_free(selected);
	return mismatch;
}

TEST_CASE("scaled dot product arg partition with MPSGraph")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(5, 6, 2, 4, 8, 1, 4, 19, CCV_32F, 1, 0), 0, "MPSGraph selected ids should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(10, 2, 2, 4, 3, 1, 4, -2, CCV_32F, 1, 0), 0, "MPSGraph selected ids should pad zero-visible causal compression rows");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(5, 0, 2, 4, 3, 1, 4, 0, CCV_32F, 1, 0), 0, "MPSGraph selected ids should pad an empty compressed key set");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 40, 2, 4, 4, 1, 4, 0, CCV_32F, 1, 0), 0, "MPSGraph should respect a zero query offset");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 40, 2, 4, 4, 1, 4, 159, CCV_32F, 1, 0), 0, "MPSGraph should respect an explicit absolute query offset");
}

TEST_CASE("scaled dot product arg partition enumeration with MFA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(5, 6, 2, 4, 8, 1, 4, 19, CCV_32F, 0, 1), 0, "MFA should enumerate every visible compressed row");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 2, 2, 4, 4, 0, 4, 0, CCV_32F, 0, 1), 0, "MFA should enumerate non-causal compressed rows");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(5, 0, 2, 4, 3, 1, 4, 0, CCV_32F, 0, 1), 0, "MFA should pad an empty compressed key set");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 3, 2, 4, 4, 1, 4, 0, CCV_32F, 0, 1), 0, "MFA enumeration should respect a zero query offset");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 3, 2, 4, 4, 1, 4, 159, CCV_32F, 0, 1), 0, "MFA enumeration should respect an explicit absolute query offset");
}

TEST_CASE("scaled dot product arg partition with MFA DS4-native shape")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 8, 64, 128, 4, 1, 4, 29, CCV_32F, 0, 0), 0, "MFA selected ids should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(160, 32, 64, 128, 8, 1, 4, -32, CCV_32F, 0, 0), 0, "MFA selected ids should pad zero-visible causal compression rows");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 40, 64, 128, 4, 1, 4, 0, CCV_32F, 0, 0), 0, "MFA should respect a zero query offset");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 40, 64, 128, 4, 1, 4, 159, CCV_32F, 0, 0), 0, "MFA should respect an explicit absolute query offset");
}

TEST_CASE("scaled dot product arg partition with MFA FP16 DS4-native shape")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 8, 64, 128, 4, 1, 4, 29, CCV_16F, 0, 0), 0, "MFA FP16 selected ids should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(1, 1024, 64, 128, 512, 1, 4, 4095, CCV_16F, 0, 0), 0, "MFA FP16 decode tile selected ids should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 1024, 64, 128, 512, 1, 4, 2048, CCV_16F, 0, 0), 0, "MFA FP16 causal score culling should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 1024, 64, 128, 512, 0, 4, 0, CCV_16F, 0, 0), 0, "MFA FP16 selected ids should match CPU reference before runtime C reuse");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 4096, 64, 128, 512, 0, 4, 0, CCV_16F, 0, 0), 0, "MFA FP16 should reuse its pipeline with runtime C");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(1, 16384, 64, 128, 512, 1, 4, 65535, CCV_16F, 0, 0), 0, "MFA FP16 should hierarchically merge eight causal top-k tiles");
}

TEST_CASE("scaled dot product arg partition with generic MFA FP16 DS4-native shape")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 8, 64, 128, 4, 1, 4, 29, CCV_16F, 0, 1), 0, "generic MFA FP16 selected ids should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(160, 32, 64, 128, 8, 1, 4, -32, CCV_16F, 0, 1), 0, "generic MFA FP16 selected ids should pad zero-visible causal compression rows");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 40, 64, 128, 4, 1, 4, 0, CCV_16F, 0, 1), 0, "generic MFA should respect a zero query offset");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(4, 40, 64, 128, 4, 1, 4, 159, CCV_16F, 0, 1), 0, "generic MFA should respect an explicit absolute query offset");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 1024, 64, 128, 512, 0, 4, 0, CCV_16F, 0, 1), 0, "generic MFA FP16 selected ids should match CPU reference before runtime C reuse");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 4096, 64, 128, 512, 0, 4, 0, CCV_16F, 0, 1), 0, "generic MFA FP16 should reuse its pipeline with runtime C");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(3, 8193, 64, 128, 512, 0, 4, 0, CCV_16F, 0, 1), 0, "generic MFA FP16 should reuse its pipeline across the old four-tile boundary");
}

TEST_CASE("scaled dot product arg partition with MFA BF16 DS4-native shape")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int status = _mps_scaled_dot_product_arg_partition_compare(3, 8, 64, 128, 4, 1, 4, 29, CCV_16BF, 0, 0);
	GUARD_ELSE_RETURN(status != -1);
	REQUIRE_EQ(status, 0, "MFA BF16 selected ids should match CPU reference");
}

TEST_CASE("scaled dot product arg partition with MFA 32 index heads")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	int generic;
	for (generic = 0; generic <= 1; generic++)
	{
		REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(17, 1057, 32, 128, 512, 1, 2, 2048, CCV_32F, 0, generic), 0, "MFA FP32 with 32 heads should match CPU reference across partial score tiles");
		REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(1, 1024, 32, 128, 512, 1, 2, 2047, CCV_16F, 0, generic), 0, "MFA FP16 decode with 32 heads should match CPU reference");
		REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(17, 1057, 32, 128, 512, 1, 2, 2048, CCV_16F, 0, generic), 0, "MFA FP16 prefill with 32 heads should match CPU reference");
		REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(17, 1057, 64, 128, 512, 1, 2, 2048, CCV_16F, 0, generic), 0, "MFA should specialize the pipeline when switching to 64 heads");
		REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(17, 1025, 32, 128, 512, 1, 2, 2048, CCV_16F, 0, generic), 0, "MFA should reuse the 32-head pipeline with a new key count");
	}
}

TEST_CASE("scaled dot product arg partition with MFA BF16 32 index heads")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int status = _mps_scaled_dot_product_arg_partition_compare(17, 1057, 32, 128, 512, 1, 2, 2048, CCV_16BF, 0, 0);
	GUARD_ELSE_RETURN(status != -1);
	REQUIRE_EQ(status, 0, "MFA BF16 with 32 heads should match CPU reference");
	REQUIRE_EQ(_mps_scaled_dot_product_arg_partition_compare(17, 1057, 32, 128, 512, 1, 2, 2048, CCV_16BF, 0, 1), 0, "generic MFA BF16 with 32 heads should match CPU reference");
}

TEST_CASE("scaled dot product arg partition with MFA arbitrary index heads")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD, CCV_NNC_BACKEND_MPS));
	const int heads[] = { 1, 3, 7, 33, 65, 128 };
	dsfmt_t dsfmt;
	dsfmt_init_gen_rand(&dsfmt, 0);
	const uint64_t old_flags = ccv_nnc_flags();
	int shape, h, generic, i;
	for (shape = 0; shape < 2; shape++)
		for (h = 0; h < sizeof(heads) / sizeof(heads[0]); h++)
		{
			const int T = shape == 0 ? 1 : 17;
			const int C = 1057;
			const int H = heads[h];
			ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, H, 128), 0);
			ccv_nnc_tensor_t* const hk = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, C, 128), 0);
			ccv_nnc_tensor_t* const hw = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, T, H), 0);
			ccv_nnc_tensor_t* const hq16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, H, 128), 0);
			ccv_nnc_tensor_t* const hk16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, C, 128), 0);
			ccv_nnc_tensor_t* const hw16 = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(16F, T, H), 0);
			ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, T, 512), 0);
			ccv_nnc_tensor_t* const hselected = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, T, 512), 0);
			// Small integers keep scores exactly representable, so ranked ids can be compared exactly.
			for (i = 0; i < T * H * 128; i++)
				hq->data.f32[i] = (int)(dsfmt_genrand_close_open(&dsfmt) * 9) - 4;
			for (i = 0; i < C * 128; i++)
				hk->data.f32[i] = (int)(dsfmt_genrand_close_open(&dsfmt) * 9) - 4;
			for (i = 0; i < T * H; i++)
				hw->data.f32[i] = (int)(dsfmt_genrand_close_open(&dsfmt) * 4) + 1;
			ccv_nnc_cmd_exec(CMD_DATATYPE_CONVERSION_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hq, hk, hw), TENSOR_LIST(hq16, hk16, hw16), 0);
			const ccv_nnc_cmd_t cmd = CMD_SCALED_DOT_PRODUCT_ARG_PARTITION_FORWARD(512, 1, 1, 2, 2048);
			ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(hq, hk, hw), TENSOR_LIST(href), 0);
			ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, H, 128), 0);
			ccv_nnc_tensor_t* const k = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, C, 128), 0);
			ccv_nnc_tensor_t* const w = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 16F, T, H), 0);
			ccv_nnc_tensor_t* const selected = ccv_nnc_tensor_new(0, GPU_TENSOR_NHWC(000, 32S, T, 512), 0);
			ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hq16, hk16, hw16), TENSOR_LIST(q, k, w), 0);
			for (generic = 0; generic <= 1; generic++)
			{
				ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
				if (generic)
					ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
				else
					ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
				const int status = ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, k, w), TENSOR_LIST(selected), 0);
				if (old_flags & CCV_NNC_DISABLE_MFA)
					ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA);
				else
					ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA);
				if (old_flags & CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS)
					ccv_nnc_enable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
				else
					ccv_nnc_disable_flag(CCV_NNC_DISABLE_MFA_NEURAL_ACCELERATORS);
				REQUIRE_EQ(status, CCV_NNC_EXEC_SUCCESS, "MFA should support arbitrary head counts");
				ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(selected), TENSOR_LIST(hselected), 0);
				REQUIRE_TENSOR_EQ(hselected, href, "MFA selected ids with arbitrary head counts should match CPU reference");
			}
			ccv_nnc_tensor_free(hq);
			ccv_nnc_tensor_free(hk);
			ccv_nnc_tensor_free(hw);
			ccv_nnc_tensor_free(hq16);
			ccv_nnc_tensor_free(hk16);
			ccv_nnc_tensor_free(hw16);
			ccv_nnc_tensor_free(href);
			ccv_nnc_tensor_free(hselected);
			ccv_nnc_tensor_free(q);
			ccv_nnc_tensor_free(k);
			ccv_nnc_tensor_free(w);
			ccv_nnc_tensor_free(selected);
		}
}

TEST_CASE("sparse indexed attention cpu reference applies dense causal window and sparse terminator")
{
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 4, 1, 1), 0);
	ccv_nnc_tensor_t* const dense_k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 2, 1, 1), 0);
	ccv_nnc_tensor_t* const dense_v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 2, 1, 1), 0);
	ccv_nnc_tensor_t* const sparse_k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 3, 1, 1), 0);
	ccv_nnc_tensor_t* const sparse_v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 3, 1, 1), 0);
	ccv_nnc_tensor_t* const indices = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 4, 3), 0);
	ccv_nnc_tensor_t* const out = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 4, 1, 1), 0);
	int i;
	for (i = 0; i < 4; i++)
		q->data.f32[i] = 1;
	const float dense_k_data[] = { 0, 1 };
	const float dense_v_data[] = { 10, 20 };
	const float sparse_k_data[] = { 2, 3, 4 };
	const float sparse_v_data[] = { 30, 40, 50 };
	const int indices_data[] = {
		1, -1, 0,
		2, 0, -1,
		-1, 0, 1,
		0, 1, 2,
	};
	memcpy(dense_k->data.f32, dense_k_data, sizeof(dense_k_data));
	memcpy(dense_v->data.f32, dense_v_data, sizeof(dense_v_data));
	memcpy(sparse_k->data.f32, sparse_k_data, sizeof(sparse_k_data));
	memcpy(sparse_v->data.f32, sparse_v_data, sizeof(sparse_v_data));
	memcpy(indices->data.i32, indices_data, sizeof(indices_data));
	ccv_nnc_cmd_t cmd = CMD_SPARSE_INDEXED_ATTENTION_FORWARD(1, 1, 0);
	int sliding_window;
	for (sliding_window = 0; sliding_window <= 1; sliding_window++)
	{
		cmd.info.sparse_indexed_attention.sliding_window = sliding_window;
		REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, dense_k, dense_v, sparse_k, sparse_v, indices), TENSOR_LIST(out), 0), "sparse indexed attention CPU reference should run");
		float expected[4];
		for (i = 0; i < 4; i++)
		{
			float scores[5];
			float values[5];
			int count = 0;
			int dense_end = 2 - 4 + i + 1;
			dense_end = ccv_max(0, ccv_min(2, dense_end));
			const int dense_start = sliding_window > 0 ? ccv_max(0, dense_end - sliding_window) : 0;
			int r;
			for (r = dense_start; r < dense_end; r++)
			{
				scores[count] = dense_k_data[r];
				values[count] = dense_v_data[r];
				++count;
			}
			for (r = 0; r < 3; r++)
			{
				const int idx = indices_data[i * 3 + r];
				if (idx < 0)
					break;
				scores[count] = sparse_k_data[idx];
				values[count] = sparse_v_data[idx];
				++count;
			}
			float maxval = -FLT_MAX;
			for (r = 0; r < count; r++)
				maxval = ccv_max(maxval, scores[r]);
			float sumval = 0;
			expected[i] = 0;
			for (r = 0; r < count; r++)
			{
				const float weight = expf(scores[r] - maxval);
				sumval += weight;
				expected[i] += values[r] * weight;
			}
			expected[i] /= sumval;
		}
		REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, out->data.f32, expected, 4, 1e-5, "CPU reference should apply the causal dense window while sparse ids terminate at first negative");
	}
	cmd = CMD_SPARSE_INDEXED_ATTENTION_FORWARD(1, 0, 0);
	cmd.info.sparse_indexed_attention.sliding_window = 1;
	REQUIRE_EQ(CCV_NNC_EXEC_INVALID, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, dense_k, dense_v, sparse_k, sparse_v, indices), TENSOR_LIST(out), 0), "sparse indexed attention should reject a sliding window in non-causal mode");
	cmd = CMD_SPARSE_INDEXED_ATTENTION_FORWARD(1, 1, 0);
	cmd.info.sparse_indexed_attention.sliding_window = -1;
	REQUIRE_EQ(CCV_NNC_EXEC_INVALID, ccv_nnc_cmd_exec(cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, dense_k, dense_v, sparse_k, sparse_v, indices), TENSOR_LIST(out), 0), "sparse indexed attention should reject a negative sliding window");
	ccv_nnc_tensor_free(out);
	ccv_nnc_tensor_free(indices);
	ccv_nnc_tensor_free(sparse_v);
	ccv_nnc_tensor_free(sparse_k);
	ccv_nnc_tensor_free(dense_v);
	ccv_nnc_tensor_free(dense_k);
	ccv_nnc_tensor_free(q);
}

TEST_CASE("sparse indexed attention cpu reference applies attention sink to denominator only")
{
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 2, 1, 1), 0);
	ccv_nnc_tensor_t* const dense_k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, 1, 1), 0);
	ccv_nnc_tensor_t* const dense_v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, 1, 1), 0);
	ccv_nnc_tensor_t* const sparse_k = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, 1, 1), 0);
	ccv_nnc_tensor_t* const sparse_v = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, 1, 1), 0);
	ccv_nnc_tensor_t* const indices = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32S, 2, 1), 0);
	ccv_nnc_tensor_t* const sinks = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, 1, 1), 0);
	ccv_nnc_tensor_t* const out = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 2, 1, 1), 0);
	q->data.f32[0] = q->data.f32[1] = 1;
	dense_k->data.f32[0] = 0;
	dense_v->data.f32[0] = 0;
	sparse_k->data.f32[0] = 0;
	sparse_v->data.f32[0] = 8;
	indices->data.i32[0] = 0;
	indices->data.i32[1] = -1;
	sinks->data.f32[0] = 0;
	REQUIRE_EQ(CCV_NNC_EXEC_SUCCESS, ccv_nnc_cmd_exec(CMD_SPARSE_INDEXED_ATTENTION_FORWARD(1, 1, 1), ccv_nnc_no_hint, 0, TENSOR_LIST(q, dense_k, dense_v, sparse_k, sparse_v, indices, sinks), TENSOR_LIST(out), 0), "sparse indexed attention CPU reference with sinks should run");
	const float expected[] = { 4, 0 };
	REQUIRE_ARRAY_EQ_WITH_TOLERANCE(float, out->data.f32, expected, 2, 1e-5, "attention sink should add softmax mass without adding value mass");
	ccv_nnc_tensor_free(out);
	ccv_nnc_tensor_free(sinks);
	ccv_nnc_tensor_free(indices);
	ccv_nnc_tensor_free(sparse_v);
	ccv_nnc_tensor_free(sparse_k);
	ccv_nnc_tensor_free(dense_v);
	ccv_nnc_tensor_free(dense_k);
	ccv_nnc_tensor_free(q);
}

static void _mps_sparse_indexed_attention_fill(const int T, const int H, const int D, const int dense_rows, const int sparse_rows, const int K, float* const q, float* const dense, float* const sparse, int* const indices, float* const sinks)
{
	int i, h, t, k;
	for (i = 0; i < T * H * D; i++)
		q[i] = (float)(((i * 17 + 11) % 97) - 48) / 256;
	for (i = 0; i < dense_rows * D; i++)
		dense[i] = (float)(((i * 19 + 7) % 89) - 44) / 256;
	for (i = 0; i < sparse_rows * D; i++)
		sparse[i] = (float)(((i * 23 + 5) % 101) - 50) / 256;
	if (K == 0)
	{
		for (t = 0; t < T; t++)
			indices[t] = -1;
	} else {
		for (t = 0; t < T; t++)
			for (k = 0; k < K; k++)
				indices[t * K + k] = (k == K - 1 && ((t & 1) || T == 1)) ? -1 : (t * 17 + k * 13) % sparse_rows;
	}
	for (h = 0; h < H; h++)
		sinks[h] = (float)(((h * 7 + 3) % 17) - 8) / 32;
}

static int _mps_sparse_indexed_attention_compare(const int datatype, const int T, const int H, const int D, const int dense_rows, const int sparse_rows, const int K, const int attention_sinks, const int sliding_window, const float tolerance, float* const max_abs_ref, float* const max_relative_ref, int* const max_idx_ref, float* const expected_ref, float* const actual_ref)
{
	const int q_count = T * H * D;
	const int dense_count = dense_rows * D;
	const int sparse_count = sparse_rows * D;
	int status = 0;
	ccv_nnc_tensor_t* const hq = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, T, H, D), 0);
	ccv_nnc_tensor_t* const hdense = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, dense_rows, 1, D), 0);
	const ccv_nnc_tensor_param_t hsparse_params = sparse_rows == 0 ? CPU_TENSOR_NHWC(32F, 0) : CPU_TENSOR_NHWC(32F, 1, sparse_rows, 1, D);
	ccv_nnc_tensor_t* const hsparse = ccv_nnc_tensor_new(0, hsparse_params, 0);
	ccv_nnc_tensor_param_t hindices_params = K == 0 ? CPU_TENSOR_NHWC(32S, T) : CPU_TENSOR_NHWC(32S, T, K);
	ccv_nnc_tensor_t* const hindices = ccv_nnc_tensor_new(0, hindices_params, 0);
	ccv_nnc_tensor_t* const hsinks = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, 1, H, 1), 0);
	ccv_nnc_tensor_t* const href = ccv_nnc_tensor_new(0, CPU_TENSOR_NHWC(32F, 1, T, H, D), 0);
	_mps_sparse_indexed_attention_fill(T, H, D, dense_rows, sparse_rows, K, hq->data.f32, hdense->data.f32, hsparse->data.f32, hindices->data.i32, hsinks->data.f32);
	ccv_nnc_tensor_param_t q_input_params = CPU_TENSOR_NHWC(32F, 1, T, H, D);
	q_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t dense_input_params = CPU_TENSOR_NHWC(32F, 1, dense_rows, 1, D);
	dense_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t sparse_input_params = sparse_rows == 0 ? CPU_TENSOR_NHWC(32F, 0) : CPU_TENSOR_NHWC(32F, 1, sparse_rows, 1, D);
	sparse_input_params.datatype = datatype;
	ccv_nnc_tensor_param_t sinks_input_params = CPU_TENSOR_NHWC(32F, 1, 1, H, 1);
	sinks_input_params.datatype = datatype;
	ccv_nnc_tensor_t* const hq_input = ccv_nnc_tensor_new(0, q_input_params, 0);
	ccv_nnc_tensor_t* const hdense_input = ccv_nnc_tensor_new(0, dense_input_params, 0);
	ccv_nnc_tensor_t* const hsparse_input = ccv_nnc_tensor_new(0, sparse_input_params, 0);
	ccv_nnc_tensor_t* const hsinks_input = ccv_nnc_tensor_new(0, sinks_input_params, 0);
	_mps_sdpa_store_float_as_datatype(datatype, hq->data.f32, hq_input->data.u8, q_count);
	_mps_sdpa_store_float_as_datatype(datatype, hdense->data.f32, hdense_input->data.u8, dense_count);
	_mps_sdpa_store_float_as_datatype(datatype, hsparse->data.f32, hsparse_input->data.u8, sparse_count);
	_mps_sdpa_store_float_as_datatype(datatype, hsinks->data.f32, hsinks_input->data.u8, H);
	_mps_forward_scaled_gemm_to_float(datatype, hq_input->data.u8, q_count, hq->data.f32);
	_mps_forward_scaled_gemm_to_float(datatype, hdense_input->data.u8, dense_count, hdense->data.f32);
	_mps_forward_scaled_gemm_to_float(datatype, hsparse_input->data.u8, sparse_count, hsparse->data.f32);
	_mps_forward_scaled_gemm_to_float(datatype, hsinks_input->data.u8, H, hsinks->data.f32);
	ccv_nnc_cmd_t cpu_cmd = CMD_SPARSE_INDEXED_ATTENTION_FORWARD(1.0f / sqrtf((float)D), 1, attention_sinks);
	cpu_cmd.info.sparse_indexed_attention.sliding_window = sliding_window;
	const int cpu_status = attention_sinks ?
		ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(hq, hdense, hdense, hsparse, hsparse, hindices, hsinks), TENSOR_LIST(href), 0) :
		ccv_nnc_cmd_exec(cpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(hq, hdense, hdense, hsparse, hsparse, hindices), TENSOR_LIST(href), 0);
	if (cpu_status != CCV_NNC_EXEC_SUCCESS)
	{
		status = -1;
		goto cleanup_host;
	}
	ccv_nnc_tensor_param_t q_params = GPU_TENSOR_NHWC(000, 32F, 1, T, H, D);
	q_params.datatype = datatype;
	ccv_nnc_tensor_param_t dense_params = GPU_TENSOR_NHWC(000, 32F, 1, dense_rows, 1, D);
	dense_params.datatype = datatype;
	ccv_nnc_tensor_param_t sparse_params = sparse_rows == 0 ? GPU_TENSOR_NHWC(000, 32F, 0) : GPU_TENSOR_NHWC(000, 32F, 1, sparse_rows, 1, D);
	sparse_params.datatype = datatype;
	ccv_nnc_tensor_param_t sinks_params = GPU_TENSOR_NHWC(000, 32F, 1, 1, H, 1);
	sinks_params.datatype = datatype;
	ccv_nnc_tensor_t* const q = ccv_nnc_tensor_new(0, q_params, 0);
	ccv_nnc_tensor_t* const dense = ccv_nnc_tensor_new(0, dense_params, 0);
	ccv_nnc_tensor_t* const sparse = ccv_nnc_tensor_new(0, sparse_params, 0);
	ccv_nnc_tensor_param_t indices_params = K == 0 ? GPU_TENSOR_NHWC(000, 32S, T) : GPU_TENSOR_NHWC(000, 32S, T, K);
	ccv_nnc_tensor_t* const indices = ccv_nnc_tensor_new(0, indices_params, 0);
	ccv_nnc_tensor_t* const sinks = ccv_nnc_tensor_new(0, sinks_params, 0);
	ccv_nnc_tensor_t* const out = ccv_nnc_tensor_new(0, q_params, 0);
	ccv_nnc_tensor_t* const hactual = ccv_nnc_tensor_new(0, q_input_params, 0);
	if (attention_sinks)
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hq_input, hdense_input, hsparse_input, hindices, hsinks_input), TENSOR_LIST(q, dense, sparse, indices, sinks), 0);
	else
		ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(hq_input, hdense_input, hsparse_input, hindices), TENSOR_LIST(q, dense, sparse, indices), 0);
	ccv_nnc_cmd_t gpu_cmd = CMD_SPARSE_INDEXED_ATTENTION_FORWARD(1.0f / sqrtf((float)D), 1, attention_sinks);
	gpu_cmd.info.sparse_indexed_attention.sliding_window = sliding_window;
	const int gpu_status = attention_sinks ?
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, dense, dense, sparse, sparse, indices, sinks), TENSOR_LIST(out), 0) :
		ccv_nnc_cmd_exec(gpu_cmd, ccv_nnc_no_hint, 0, TENSOR_LIST(q, dense, dense, sparse, sparse, indices), TENSOR_LIST(out), 0);
	if (gpu_status != CCV_NNC_EXEC_SUCCESS)
	{
		status = -2;
		goto cleanup_device;
	}
	ccv_nnc_cmd_exec(CMD_DATA_TRANSFER_FORWARD(), ccv_nnc_no_hint, 0, TENSOR_LIST(out), TENSOR_LIST(hactual), 0);
	float* const expected = (float*)ccmalloc(sizeof(float) * q_count);
	float* const actual = (float*)ccmalloc(sizeof(float) * q_count);
	_mps_sdpa_round_to_datatype(datatype, href->data.f32, expected, q_count);
	_mps_forward_scaled_gemm_to_float(datatype, hactual->data.u8, q_count, actual);
	float max_abs = 0;
	float max_relative = 0;
	int max_idx = 0;
	int i;
	for (i = 0; i < q_count; i++)
	{
		if (!isfinite(actual[i]))
		{
			status = -3;
			max_idx = i;
			break;
		}
		const float abs_diff = fabsf(expected[i] - actual[i]);
		const float denom = fmaxf(fmaxf(fabsf(expected[i]), fabsf(actual[i])), 1.0f);
		const float relative = abs_diff / denom;
		if (relative > max_relative)
			max_relative = relative, max_abs = abs_diff, max_idx = i;
	}
	if (status == 0 && max_relative > tolerance)
		status = 1;
	*max_abs_ref = max_abs;
	*max_relative_ref = max_relative;
	*max_idx_ref = max_idx;
	*expected_ref = expected[max_idx];
	*actual_ref = actual[max_idx];
	ccfree(actual);
	ccfree(expected);
cleanup_device:
	ccv_nnc_tensor_free(hactual);
	ccv_nnc_tensor_free(out);
	ccv_nnc_tensor_free(sinks);
	ccv_nnc_tensor_free(indices);
	ccv_nnc_tensor_free(sparse);
	ccv_nnc_tensor_free(dense);
	ccv_nnc_tensor_free(q);
cleanup_host:
	ccv_nnc_tensor_free(hsinks_input);
	ccv_nnc_tensor_free(hsparse_input);
	ccv_nnc_tensor_free(hdense_input);
	ccv_nnc_tensor_free(hq_input);
	ccv_nnc_tensor_free(href);
	ccv_nnc_tensor_free(hsinks);
	ccv_nnc_tensor_free(hindices);
	ccv_nnc_tensor_free(hsparse);
	ccv_nnc_tensor_free(hdense);
	ccv_nnc_tensor_free(hq);
	return status;
}

TEST_CASE("sparse indexed attention shape-selected paths with MFA FP16")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SPARSE_INDEXED_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	float max_abs, max_relative, expected, actual;
	int max_idx;
	const int sparse_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 4, 8, 4, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	GUARD_ELSE_RETURN(sparse_status != -2);
	REQUIRE_EQ(sparse_status, 0, "MFA FP16 sparse indexed attention should match CPU reference");
	const int multi_block_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 37, 97, 65, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(multi_block_status == 0, "MFA FP16 sparse indexed attention should match CPU reference across multiple row blocks (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", multi_block_status, max_abs, max_relative, max_idx, expected, actual);
	const int dense_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 37, 1, 0, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(dense_status, 0, "MFA FP16 dense-only sparse indexed attention should match CPU reference");
	const int empty_sparse_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 37, 0, 0, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(empty_sparse_status, 0, "empty sparse indexed attention should fall back to dense scaled dot product attention");
	const int runtime_rows_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 13, 19, 4, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(runtime_rows_status == 0, "MFA FP16 sparse indexed attention should reuse its pipeline with runtime dense and sparse rows (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", runtime_rows_status, max_abs, max_relative, max_idx, expected, actual);
	const int d128_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 128, 4, 8, 4, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(d128_status, 0, "MFA FP16 sparse indexed attention D=128 shape-selected path should match CPU reference");
	const int generic_fp32_status = _mps_sparse_indexed_attention_compare(CCV_32F, 5, 64, 128, 7, 9, 3, 1, 0, 1e-4, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(generic_fp32_status == 0, "generic MFA FP32 sparse indexed attention should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", generic_fp32_status, max_abs, max_relative, max_idx, expected, actual);
	const int generic_t9_status = _mps_sparse_indexed_attention_compare(CCV_16F, 9, 7, 128, 7, 9, 3, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(generic_t9_status == 0, "generic MFA FP16 sparse indexed attention T=9 should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", generic_t9_status, max_abs, max_relative, max_idx, expected, actual);
	const int generic_runtime_rows_status = _mps_sparse_indexed_attention_compare(CCV_16F, 9, 7, 128, 13, 19, 3, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(generic_runtime_rows_status == 0, "generic MFA FP16 sparse indexed attention should reuse its pipeline with runtime dense and sparse rows (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", generic_runtime_rows_status, max_abs, max_relative, max_idx, expected, actual);
	const int generic_no_sink_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 96, 6, 7, 2, 0, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(generic_no_sink_status == 0, "generic MFA FP16 sparse indexed attention without sinks should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", generic_no_sink_status, max_abs, max_relative, max_idx, expected, actual);
}

TEST_CASE("sparse indexed attention R1 with MFA")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SPARSE_INDEXED_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	float max_abs, max_relative, expected, actual;
	int max_idx;
	const int direct_status = _mps_sparse_indexed_attention_compare(CCV_16F, 1, 64, 512, 127, 257, 65, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(direct_status == 0, "MFA FP16 sparse indexed attention R1 direct mode should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", direct_status, max_abs, max_relative, max_idx, expected, actual);
	const int runtime_shape_status = _mps_sparse_indexed_attention_compare(CCV_16F, 1, 64, 512, 31, 91, 33, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(runtime_shape_status == 0, "MFA FP16 sparse indexed attention R1 should reuse its direct pipeline with runtime dense rows, sparse rows, and K (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", runtime_shape_status, max_abs, max_relative, max_idx, expected, actual);
	const int window_status = _mps_sparse_indexed_attention_compare(CCV_16F, 1, 64, 512, 37, 97, 17, 1, 3, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(window_status == 0, "MFA FP16 sparse indexed attention R1 sliding-window mode should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", window_status, max_abs, max_relative, max_idx, expected, actual);
	const int split_status = _mps_sparse_indexed_attention_compare(CCV_16F, 1, 64, 128, 7, 2113, 2049, 1, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(split_status == 0, "MFA FP16 sparse indexed attention R1 split/reduce mode should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", split_status, max_abs, max_relative, max_idx, expected, actual);
	const int arbitrary_shape_status = _mps_sparse_indexed_attention_compare(CCV_16F, 1, 7, 130, 23, 71, 19, 0, 0, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(arbitrary_shape_status == 0, "MFA FP16 sparse indexed attention R1 shape-selected route with arbitrary H and D should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", arbitrary_shape_status, max_abs, max_relative, max_idx, expected, actual);
	const int bf16_status = _mps_sparse_indexed_attention_compare(CCV_16BF, 1, 64, 128, 31, 129, 33, 1, 0, 5e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE(bf16_status == 0, "MFA BF16 sparse indexed attention R1 direct mode should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", bf16_status, max_abs, max_relative, max_idx, expected, actual);
}

TEST_CASE("sparse indexed attention sliding window with MFA FP16")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SPARSE_INDEXED_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	float max_abs, max_relative, expected, actual;
	int max_idx;
	const int generic_status = _mps_sparse_indexed_attention_compare(CCV_16F, 9, 7, 128, 7, 9, 3, 1, 3, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	GUARD_ELSE_RETURN(generic_status != -2);
	REQUIRE(generic_status == 0, "generic MFA FP16 sparse indexed attention sliding window should match CPU reference (status=%d max abs %g relative %g at %d: CPU %g GPU %g)", generic_status, max_abs, max_relative, max_idx, expected, actual);
	const int dense_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 37, 1, 0, 1, 3, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(dense_status, 0, "MFA FP16 dense-only sparse indexed attention sliding window should match CPU reference");
	const int d512_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 512, 4, 8, 4, 1, 2, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(d512_status, 0, "MFA FP16 sparse indexed attention D=512 shape-selected path with sliding window should match CPU reference");
	const int d128_status = _mps_sparse_indexed_attention_compare(CCV_16F, 5, 64, 128, 4, 8, 4, 1, 2, 1e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	REQUIRE_EQ(d128_status, 0, "MFA FP16 sparse indexed attention D=128 shape-selected path with sliding window should match CPU reference");
}

TEST_CASE("sparse indexed attention with MFA BF16 DS4-native shape")
{
	GUARD_ELSE_RETURN(ccv_nnc_cmd_ok(CCV_NNC_SPARSE_INDEXED_ATTENTION_FORWARD, CCV_NNC_BACKEND_MPS));
	float max_abs, max_relative, expected, actual;
	int max_idx;
	const int sparse_status = _mps_sparse_indexed_attention_compare(CCV_16BF, 5, 64, 512, 4, 8, 4, 1, 0, 5e-2, &max_abs, &max_relative, &max_idx, &expected, &actual);
	GUARD_ELSE_RETURN(sparse_status != -2);
	REQUIRE_EQ(sparse_status, 0, "MFA BF16 sparse indexed attention should match CPU reference");
}

#ifdef HAVE_MPS

TEST_CASE("MFA durable scratch validates allocation and keeps concurrent leases exclusive")
{
	ccv_nnc_mfa_context_t* const context = ccv_nnc_default_mfa_context();
	GUARD_ELSE_RETURN(context && ccv_nnc_mfa_context_supported(context));
	REQUIRE(!ccv_nnc_mfa_request_durable_scratch(context, 0), "zero-byte durable scratch should be rejected");
	REQUIRE(!ccv_nnc_mfa_request_durable_scratch(context, UINT64_MAX), "oversized durable scratch should fail without aborting");
	enum { lease_count = 32 };
	ccv_nnc_mfa_durable_scratch_t** const leases = cccalloc(lease_count, sizeof(ccv_nnc_mfa_durable_scratch_t*));
	mtl_buffer_t** const buffers = cccalloc(lease_count, sizeof(mtl_buffer_t*));
	dispatch_apply(lease_count, dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^(size_t i) {
		leases[i] = ccv_nnc_mfa_request_durable_scratch(context, 4096);
		buffers[i] = ccv_nnc_mfa_durable_scratch_buffer(leases[i]);
	});
	int i, j;
	for (i = 0; i < lease_count; i++)
	{
		REQUIRE(leases[i] && buffers[i], "concurrent durable scratch allocation %d should succeed", i);
		for (j = 0; j < i; j++)
			REQUIRE(buffers[i] != buffers[j], "active durable scratch leases %d and %d should not alias", i, j);
	}
	dispatch_apply(lease_count, dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^(size_t i) {
		ccv_nnc_mfa_release_durable_scratch(leases[i]);
	});
	ccfree(buffers);
	ccfree(leases);
}

TEST_CASE("MFA durable scratch retirement follows its owning command batch")
{
	ccv_nnc_mfa_context_t* const context = ccv_nnc_default_mfa_context();
	GUARD_ELSE_RETURN(context && ccv_nnc_mfa_context_supported(context));
	ccv_nnc_mfa_clear_pipeline_cache(context);
	ccv_nnc_mfa_durable_scratch_t* const first = ccv_nnc_mfa_request_durable_scratch(context, 4096);
	ccv_nnc_mfa_durable_scratch_t* const second = ccv_nnc_mfa_request_durable_scratch(context, 4096);
	mtl_buffer_t* const first_buffer = ccv_nnc_mfa_durable_scratch_buffer(first);
	mtl_buffer_t* const second_buffer = ccv_nnc_mfa_durable_scratch_buffer(second);
	REQUIRE(first && first_buffer && second && second_buffer, "durable scratch allocations should succeed");
	mtl_command_batch_t* const first_batch = ccv_nnc_stream_context_start_command_batch(0);
	mtl_command_batch_t* const second_batch = ccv_nnc_stream_context_start_command_batch(0);
	REQUIRE(first_batch && second_batch, "command batches should be available");
	REQUIRE(ccv_nnc_mfa_retire_durable_scratch(first, first_batch), "first durable scratch should attach to its consuming command batch");
	REQUIRE(ccv_nnc_mfa_retire_durable_scratch(second, second_batch), "second durable scratch should attach to its consuming command batch");
	ccv_nnc_mfa_durable_scratch_t* const concurrent = ccv_nnc_mfa_request_durable_scratch(context, 4096);
	mtl_buffer_t* const concurrent_buffer = ccv_nnc_mfa_durable_scratch_buffer(concurrent);
	REQUIRE(concurrent_buffer != first_buffer && concurrent_buffer != second_buffer, "retired scratch should remain leased before command completion");
	ccv_nnc_stream_context_finish_command_batch(0, second_batch);
	ccv_nnc_mfa_durable_scratch_t* const recycled_second = ccv_nnc_mfa_request_durable_scratch(context, 4096);
	REQUIRE(ccv_nnc_mfa_durable_scratch_buffer(recycled_second) == second_buffer, "only the completed second batch should recycle its scratch");
	ccv_nnc_stream_context_finish_command_batch(0, first_batch);
	ccv_nnc_mfa_durable_scratch_t* const recycled_first = ccv_nnc_mfa_request_durable_scratch(context, 4096);
	REQUIRE(ccv_nnc_mfa_durable_scratch_buffer(recycled_first) == first_buffer, "the first batch should recycle its scratch after its own completion");
	ccv_nnc_mfa_release_durable_scratch(concurrent);
	ccv_nnc_mfa_release_durable_scratch(recycled_second);
	ccv_nnc_mfa_release_durable_scratch(recycled_first);
}

#endif

#include "case_main.h"
