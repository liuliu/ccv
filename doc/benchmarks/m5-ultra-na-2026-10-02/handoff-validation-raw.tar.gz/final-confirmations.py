from pathlib import Path
import json,subprocess,time,sys

root=Path('/Users/liu/workspace/ccv');out=Path('/private/tmp/ccv-m5-handoff')
assert (out/'final-build-provenance.json').exists()
sys.path.insert(0,str(root/'bin/mfa'))
from na_benchmark_manifest import manifest
geometry=lambda c:(c['operation'],tuple(c['shape']),c['dispatch_flags'],c['causal'],c['output_cast'])
final=manifest();canonical={geometry(c):c for c in final['workloads']}
flagged={};original=[]
for phase in ['coverage','source-supplement','backward','causal-final']:
    meta=json.loads((out/phase/'metadata.json').read_text())
    cases={c['id']:c for c in meta['workloads']}
    summary=json.loads((out/phase/'summary.json').read_text())
    assert summary['failed_records']==0,(phase,summary['failed_records'])
    for flag in summary['live_baseline_comparison']:
        if flag['status']=='regression':
            case=canonical[geometry(cases[flag['id']])]
            flagged[case['id']]=case
            original.append(dict(phase=phase,canonical_id=case['id'],**flag))
(out/'initial-regression-flags.json').write_text(json.dumps(original,indent=2)+'\n')
(out/'regression-repeat-manifest.json').write_text(json.dumps(dict(final,workloads=list(flagged.values())),indent=2)+'\n')
base=['python3','bin/mfa/na_application_sweep.py','--baseline-frontend',str(out/'baseline-probe')]
long_ids=['h3-480p-ui-10s','h3-720p-ui-10s','h3-480p-ui-10s-output-cast',
          'h3-720p-ui-10s-ffn-down-cast','gemm-rows-2048-6144-6144',
          'local-qwen35-4b-m3072-down']
long=base+['--suite','coverage','--output',str(out/'final-long')]
for case in long_ids:long+=['--id',case]
jobs=[('final-smoke',base+['--suite','smoke','--output',str(out/'final-smoke')]),('final-long',long)]
if flagged:
    jobs.append(('regression-repeat',base+['--suite','all','--manifest',str(out/'regression-repeat-manifest.json'),
                  '--repeats','4','--samples','31','--warmup-seconds','2',
                  '--output',str(out/'regression-repeat')]))
records=[]
for name,args in jobs:
    start=time.time();print('START',name,flush=True)
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=root/'test/int/nnc' if name=='final-register-tests' else root,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=args,exit=result.returncode,seconds=time.time()-start))
    (out/'final-confirmations.json').write_text(json.dumps(records,indent=2)+'\n')
    print('DONE',records[-1],flush=True)
