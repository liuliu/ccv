import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/ccv-m5-attention-r1-parity')
commands=[
 ('policy-numerical',['python3',str(ROOT/'bin/mfa/attention_r1_sweep.py'),'--manifest',str(OUT/'policy-numerical-manifest.json'),'--precision','both','--repeats','1','--samples','8','--warmup-seconds','.01','--output',str(OUT/'policy-numerical')]),
 ('policy-final',['python3','harness/sweep.py','--output','policy-final','--manifest','policy-manifest.json','--suite','coverage','--frontend','./policy-application','--baseline-frontend','./group4-application','--mlx','/private/tmp/ccv-na-int8-integration/mlx-probe','--repeats','2','--samples','64','--warmup-seconds','2','--absolute-ms','.002']),
]
records=[]
for name,args in commands:
    assert not (OUT/name).exists()
    print('START',name,flush=True)
    with (OUT/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=OUT,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=args,exit_code=result.returncode))
    (OUT/'policy-validation.json').write_text(json.dumps(records,indent=2)+'\n')
    print('END',name,result.returncode,flush=True)
    if name=='policy-numerical' and result.returncode: raise SystemExit(result.returncode)
