import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT=Path(__file__).resolve().parent
PROBE=Path('/private/tmp/ccv-m5-attention-r1-parity/bin/mfa/attention_r1_bench')
DEST=OUT/'profile-long-d256'
DEST.mkdir(exist_ok=False)
env=dict(os.environ,CCV_NA_WARMUP_SECONDS='2')
records=[]
for rep in range(2):
    for p,sg in ([(256,16),(512,32)] if rep==0 else [(512,32),(256,16)]):
        args=[str(PROBE),'1','65536','256','1','24','4','3','64','1','3','0','1',str(p),str(sg)]
        name=f'{rep}-p{p}'
        before=subprocess.check_output([str(OUT/'harness/thermal')],text=True).strip()
        assert before=='0'
        with (DEST/(name+'.log')).open('w') as log:
            result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        after=subprocess.check_output([str(OUT/'harness/thermal')],text=True).strip()
        record=dict(name=name,args=args,exit_code=result.returncode,thermal_before=before,thermal_after=after)
        records.append(record)
        (DEST/'records.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256(PROBE.read_bytes()).hexdigest(),warmup_seconds=2,records=records),indent=2)+'\n')
        print(name,result.returncode,flush=True)
        if result.returncode or after!='0': raise SystemExit(1)
        time.sleep(1)
