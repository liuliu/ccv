import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/ccv-m5-attention-r1-parity')
cases=json.loads((ROOT/'bin/mfa/attention_r1_shapes.json').read_text())['workloads']
missing=json.loads((OUT/'missing-numerical-manifest.json').read_text())['workloads']
controls=json.loads((OUT/'policy-manifest.json').read_text())['workloads'][1:]
recheck={x['id']:x for x in [*missing,*controls]}
records=[]
for case in cases:
    for precision in [0,1]:
        args=[*map(str,case['shape']),'80',str(int(case['causal'])),str(precision)]
        before=subprocess.check_output([str(OUT/'selection-before'),*args],text=True).strip()
        after=subprocess.check_output([str(OUT/'selection-after'),*args],text=True).strip()
        records.append(dict(id=case['id'],shape=case['shape'],causal=case['causal'],precision=precision,before=before,after=after,changed=before!=after))
        if before!=after: recheck[case['id']]=case
meta=dict(core_count=80,fields=['mode','partitions','simdgroups','heads_per_simd','reduce_simds'],
          binaries={name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ['selection-before','selection-after']},records=records)
(OUT/'selection-audit.json').write_text(json.dumps(meta,indent=2)+'\n')
(OUT/'policy-numerical-manifest.json').write_text(json.dumps(dict(workloads=list(recheck.values())),indent=2)+'\n')
print('Inspected',len(records),'selections; changed:',[r for r in records if r['changed']],flush=True)
print('Post-policy numerical cases:',len(recheck),flush=True)
