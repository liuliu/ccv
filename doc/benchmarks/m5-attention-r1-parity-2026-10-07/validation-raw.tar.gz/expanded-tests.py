import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/ccv-m5-attention-r1-parity')
commands=[['make','-C','test/int/nnc','-o','libccv.a','mpsblas.tests.o','mpsdnn.tests.o','DEBUG=1','-j4'],['make','-C','test/int/nnc','-o','libccv.a','-W','mpsblas.tests.o','-W','mpsdnn.tests.o','mpsblas.tests','mpsdnn.tests','DEBUG=1']]
with (OUT/'expanded-test-build.log').open('w') as log:
    for args in commands:
        print('BUILD',args,flush=True)
        result=subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode: raise SystemExit(result.returncode)
obj=ROOT/'test/int/nnc/mpsblas.tests.o'
src=ROOT/'test/int/nnc/mpsblas.tests.c'
assert obj.stat().st_mtime>=src.stat().st_mtime
records=[]
for name,args in [('cache-expanded',['./mpsblas.tests','decode cache transitions']),('lse-expanded',['./mpsblas.tests','decode preserves saved logsumexp']),('full-dnn-policy',['./mpsdnn.tests'])]:
    with (OUT/'integration'/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=ROOT/'test/int/nnc',stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=args,exit_code=result.returncode))
    print(name,result.returncode,flush=True)
    (OUT/'integration/expanded-tests.json').write_text(json.dumps(dict(build_commands=commands,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256((ROOT/'test/int/nnc/mpsblas.tests').read_bytes()).hexdigest(),records=records),indent=2)+'\n')
raise SystemExit(int(any(row['exit_code'] for row in records)))
