"""Audit all measurements and prove reuse of unchanged GPU configurations."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/ccv-m5-attention-r1-parity')
REPORT=ROOT/'doc/benchmarks/m5-attention-r1-parity-2026-10-07'
def read(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def records(path): return [json.loads(line) for line in path.read_text().splitlines()]

old_meta=read(OUT/'final/metadata.json')
new_meta=read(OUT/'policy-final/metadata.json')
selector='lib/nnc/mfa/kernels/AttentionR1Descriptor.cpp'
assert set(old_meta['kernel_sources_sha256'])==set(new_meta['kernel_sources_sha256'])
changed_sources={p for p in old_meta['kernel_sources_sha256'] if old_meta['kernel_sources_sha256'][p]!=new_meta['kernel_sources_sha256'][p]}
assert changed_sources=={selector}
for path,expected in new_meta['kernel_sources_sha256'].items():
    assert digest(ROOT/path)==expected,path
assert digest(OUT/'pre-policy-source'/selector)==old_meta['kernel_sources_sha256'][selector]
old=(OUT/'pre-policy-source'/selector).read_text(); new=(ROOT/selector).read_text()
start='AttentionR1Descriptor AttentionR1Descriptor::select('
end='std::size_t std::hash<AttentionR1Descriptor>::operator()'
assert old.split(start)[0]==new.split(start)[0]
assert old.split(end)[1]==new.split(end)[1]
for directory in ['gqa2-final','outlier-recheck']:
    meta=read(OUT/directory/'metadata.json')
    assert meta['kernel_sources_sha256']==old_meta['kernel_sources_sha256']
    assert meta['binaries']==old_meta['binaries']
for name in ['previous','mlx']:
    assert new_meta['binaries'][name]==old_meta['binaries'][name]
assert new_meta['devices']==old_meta['devices']
assert digest(OUT/'application')==old_meta['binaries']['current']['sha256']
assert digest(OUT/'policy-application')==new_meta['binaries']['current']['sha256']
selection=read(OUT/'selection-audit.json')
assert selection['core_count']==80
for name,expected in selection['binaries'].items(): assert digest(OUT/name)==expected
selected={(tuple(r['shape']),bool(r['causal']),r['precision']):r for r in selection['records']}
assert len(selected)==232
assert sum(r['changed'] for r in selection['records'])==4
assert all(r['changed']==(r['before']!=r['after']) for r in selection['records'])
assert all(r['exit_code']==0 for r in read(OUT/'policy-build.json'))
assert 'AttentionR1Descriptor.cpp' in (OUT/'policy-build.log').read_text()

cases={}; by_case={}; timed_count=0; phase_for={}; old_times={}
for directory,count in [('final',62),('gqa2-final',6),('policy-final',5)]:
    run=OUT/directory; meta=read(run/'metadata.json'); batch=records(run/'records.jsonl')
    assert len(meta['workloads'])==count and len(batch)==count*6
    assert meta['repeats']==2 and meta['samples']==64 and meta['warmup_seconds']==2
    ids={c['id'] for c in meta['workloads']}; assert len(ids)==count
    seen=set(); times={}
    for record in batch:
        key=record['repeat'],record['id'],record['variant']
        assert key not in seen; seen.add(key)
        assert record['id'] in ids and record['repeat'] in [0,1]
        assert record['variant'] in ['fp16','previous_fp16','mlx']
        assert record['ok'] and record['exit_code']==0
        assert record['thermal_before']==record['thermal_after']=='0'
        stem=f"{record['repeat']}-{record['id']}-{record['variant']}"
        output=(run/(stem+'.log')).read_text(); assert 'all_finite=1' in output
        samples=list(map(float,re.search(r'gpu_samples_ms=([^\s]+)',output)[1].split(',')))
        assert len(samples)==64 and all(math.isfinite(x) and x>0 for x in samples)
        times.setdefault((record['id'],record['variant']),[]).append(statistics.median(samples)*1000)
    for case in meta['workloads']:
        name=case['id']
        if name in cases:
            assert directory=='policy-final' and name=='r1-c65536-b1-h24-4-d256'
            old_times[name]=statistics.median(by_case[name,'fp16'])
        cases[name]=case; phase_for[name]=directory
        for variant in ['fp16','previous_fp16','mlx']:
            assert len(times[name,variant])==2
            by_case[name,variant]=times[name,variant]
    timed_count+=len(batch)
assert len(cases)==72 and timed_count==438
rows=[]
for name,case in cases.items():
    if phase_for[name]!='policy-final':
        assert not selected[tuple(case['shape']),bool(case['causal']),0]['changed'],name
    r,c,d,b,hq,hk=case['shape']
    a,p,m=[statistics.median(by_case[name,k]) for k in ['fp16','previous_fp16','mlx']]
    rows.append(dict(id=name,R=r,C=c,D=d,B=b,Hq=hq,Hkv=hk,causal=case['causal'],
        current_us=a,previous_candidate_us=p,mlx_us=m,current_over_mlx=a/m,
        current_over_previous=a/p,mlx_gap_us=a-m,previous_gap_us=a-p,
        mlx_gap=a>m*1.05 and a-m>2,previous_regression=a>p*1.05 and a-p>2,
        current_pass0_us=by_case[name,'fp16'][0],current_pass1_us=by_case[name,'fp16'][1],
        evidence_phase=phase_for[name],pre_policy_current_us=old_times.get(name,'')))
with (REPORT/'comparison.csv').open('w') as file:
    writer=csv.DictWriter(file,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows)

manifest=read(ROOT/'bin/mfa/attention_r1_shapes.json')['workloads']; assert len(manifest)==116
covered=set(); fresh=set(); numerical_count=0
for directory,count in [('numerical-final',192),('gqa2-numerical',12),('policy-numerical',30)]:
    run=OUT/directory; summary=read(run/'summary.json'); batch=records(run/'records.jsonl')
    assert summary['records']==count and summary['failed']==0 and len(batch)==count
    assert len(summary['comparisons'])==count
    for record in batch:
        assert record['ok'] and record['exit_code']==0
        assert record['thermal_before']==record['thermal_after']=='0'
        assert len(record['samples_ms'])==8
        assert all(math.isfinite(x) and x>0 for x in record['samples_ms'])
        stem=f"{record['repeat']}-{record['id']}-p{record['precision']}-{record['variant']}"
        assert 'all_finite=1' in (run/(stem+'.log')).read_text()
        key=record['id'],record['precision'];covered.add(key)
        if directory=='policy-numerical': fresh.add(key)
    numerical_count+=count
assert covered=={(case['id'],precision) for case in manifest for precision in [0,1]}
assert numerical_count==234 and len(covered)==232
assert {(r['id'],r['precision']) for r in selection['records'] if r['changed']}<=fresh
numerical_shapes={(*case['shape'],bool(case['causal'])) for case in manifest}
assert all((*case['shape'],bool(case['causal'])) in numerical_shapes for case in cases.values())

recheck_records=records(OUT/'outlier-recheck/records.jsonl');assert len(recheck_records)==18
recheck_times={}
for record in recheck_records:
    assert record['ok'] and record['exit_code']==0
    assert record['thermal_before']==record['thermal_after']=='0'
    stem=f"{record['repeat']}-{record['id']}-{record['variant']}"
    output=(OUT/'outlier-recheck'/(stem+'.log')).read_text()
    samples=list(map(float,re.search(r'gpu_samples_ms=([^\s]+)',output)[1].split(',')))
    assert len(samples)==64 and all(math.isfinite(x) and x>0 for x in samples)
    assert 'all_finite=1' in output
    recheck_times.setdefault(record['variant'],[]).append(statistics.median(samples)*1000)
assert set(recheck_times)=={'fp16','previous_fp16','mlx'}
assert all(len(group)==6 for group in recheck_times.values())
summary=dict(shapes=len(cases),timed_processes=timed_count,samples_per_process=64,
    numerical_processes=numerical_count,numerical_unique_combinations=len(covered),numerical_failures=0,
    mlx_gaps=[r for r in rows if r['mlx_gap']],previous_regressions=[r for r in rows if r['previous_regression']],
    geometric_mean_current_over_mlx=math.exp(statistics.mean(math.log(r['current_over_mlx']) for r in rows)),
    outlier_recheck_process_medians_us=recheck_times,
    source_equivalence=dict(changed_sources=sorted(changed_sources),selection_records=len(selection['records']),
        changed_selections=[r for r in selection['records'] if r['changed']],
        reused_timed_shapes=sum(phase!='policy-final' for phase in phase_for.values())),groups={})
for label,group in [('R1',[r for r in rows if r['R']==1]),('R2',[r for r in rows if r['R']==2]),('single_batch',[r for r in rows if r['B']==1]),('multiple_batches',[r for r in rows if r['B']>1])]:
    summary['groups'][label]=dict(shapes=len(group),maximum_current_over_mlx=max(r['current_over_mlx'] for r in group),material_mlx_gaps=sum(r['mlx_gap'] for r in group),geometric_mean_current_over_mlx=math.exp(statistics.mean(math.log(r['current_over_mlx']) for r in group)))
(REPORT/'audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
