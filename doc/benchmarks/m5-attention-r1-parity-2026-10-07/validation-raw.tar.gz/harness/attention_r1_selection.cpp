// Inspect production selection without creating a Metal device or dispatching work.
#include "nnc/mfa/kernels/AttentionR1Descriptor.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>

int main(int argc, char** argv) {
  if (argc != 10) return 2;
  const unsigned r=std::atoi(argv[1]), c=std::atoi(argv[2]), d=std::atoi(argv[3]);
  const unsigned b=std::atoi(argv[4]), hq=std::atoi(argv[5]), hk=std::atoi(argv[6]);
  const unsigned cores=std::atoi(argv[7]);
  const bool causal=std::atoi(argv[8]), bf16=std::atoi(argv[9]);
  if (!r || !c || !d || !b || !hq || !hk || hq%hk) return 2;
  const auto desc=AttentionR1Descriptor::select(bf16 ? GEMMOperandPrecision::BF16 : GEMMOperandPrecision::FP16,
      c,hq,hk,d,1/std::sqrt(float(d)),true,false,r,causal,b,cores);
  std::printf("%u %u %u %u %u\n",unsigned(desc.mode),desc.workgroups,desc.simdgroups,
      desc.headsPerSIMD,desc.reductionSIMDGroups);
}
