import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT=Path(__file__).resolve().parent
PROBE=Path('/private/tmp/ccv-m5-attention-r1-parity/bin/mfa/attention_r1_bench')
DEST=OUT/'profile-cap-controls'
DEST.mkdir(exist_ok=False)
env=dict(os.environ,CCV_NA_WARMUP_SECONDS='2')
cases=[
 ('r1-c65536-b4-h24-4-d256',[1,65536,256,4,24,4],256,512),
 ('r1-c16384-b16-h16-4-d256',[1,16384,256,16,16,4],64,128),
 ('r2-c16384-b16-h16-4-d256',[2,16384,256,16,16,4],64,128),
 ('r1-c32768-b4-h16-16-d128',[1,32768,128,4,16,16],128,256),
]
records=[]
for index,(name,shape,old,new) in enumerate(cases):
    for p in ([old,new] if index%2==0 else [new,old]):
        sg=min(32 if p>=512 else 16,max(4,p//4))
        args=[str(PROBE),*map(str,shape),'3','64','1','3','0','1',str(p),str(sg)]
        stem=f'{name}-p{p}'
        before=subprocess.check_output([str(OUT/'harness/thermal')],text=True).strip()
        assert before=='0'
        print('START',stem,flush=True)
        with (DEST/(stem+'.log')).open('w') as log:
            result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        after=subprocess.check_output([str(OUT/'harness/thermal')],text=True).strip()
        records.append(dict(name=stem,shape=shape,args=args,exit_code=result.returncode,thermal_before=before,thermal_after=after))
        (DEST/'records.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256(PROBE.read_bytes()).hexdigest(),warmup_seconds=2,records=records),indent=2)+'\n')
        print('END',stem,result.returncode,flush=True)
        if result.returncode or after!='0': raise SystemExit(1)
        time.sleep(1)
