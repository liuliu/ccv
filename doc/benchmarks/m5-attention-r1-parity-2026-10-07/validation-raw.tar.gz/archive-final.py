"""Package benchmark evidence without machine-specific executables."""
import hashlib
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/ccv-m5-attention-r1-parity')
REPORT = ROOT / 'doc/benchmarks/m5-attention-r1-parity-2026-10-07'
# Require completed audits; a half-run must not become the reported artifact.
assert (REPORT/'audit.json').is_file()
required = ['final', 'numerical-final', 'gqa2-final', 'gqa2-numerical',
            'paired-focus', 'private-repeats', 'profile-private', 'profile-ablation',
            'integration', 'group4-source', 'initial', 'validation', 'outlier-recheck',
            'policy-final', 'policy-numerical', 'profile-long-d256',
            'profile-cap-controls', 'pre-policy-source']
selected = []
for directory in required:
    assert (OUT/directory).is_dir(), directory
    for file in (OUT/directory).rglob('*'):
        if file.is_file() and file.suffix in ['.cpp','.hpp','.py','.json','.jsonl','.csv','.log','.txt','.patch']:
            selected.append((file, str(file.relative_to(OUT))))
for name in ['na_application_bench.cpp','application-group4.cpp','mlx_na_bench.cpp','mlx-dsplit-jit.patch',
             'sweep.py','na_benchmark_manifest.py','thermal.m','CMakeLists.txt',
             'attention_r1_selection.cpp']:
    selected.append((OUT/'harness'/name,'harness/'+name))
for name in ['final-manifest.json','gqa2-manifest.json','paired-focus-manifest.json',
             'final-provenance.json','completion-provenance.json','build-probe.json','audit-final.py','archive-final.py',
             'final-debug-build.log','final-mps-build.log','test-recompile.log','expanded-test-build.log',
             'write-report.py','finish-validation.py','finish-validation.json','expanded-tests.py','outlier-recheck-manifest.json',
             'unstable-baseline-metadata.json','initial-comparison.csv','validation-comparison.csv','validation-manifest.json','initial-manifest.json',
             'policy-manifest.json','policy-numerical-manifest.json','missing-numerical-manifest.json',
             'selection-audit.json','build-selection-before.json','build-selection-before-result.json',
             'build-selection-before.log','build-policy.py','policy-build.json','policy-build.log',
             'inspect-policy.py','run-policy-validation.py','policy-validation.json',
             'profile-long-d256.py','profile-cap-controls.py','audit-before-policy.py','initial-audit.log',
             'complete-evidence.py']:
    selected.append((OUT/name,name))
for directory in ['paired-version','balanced-version']:
    for name in ['diff.patch','sha256.json']:
        file = OUT/directory/name
        if file.exists(): selected.append((file, directory+'/'+name))
for name in ['attention_r1_bench.cpp','attention_r1_sweep.py','attention_r1_shapes.json',
             'attention_r1_thermal.m','attention_r1_bench.txt']:
    selected.append((ROOT/'bin/mfa'/name,'permanent/'+name))
assert all(file.is_file() for file,_ in selected)
assert len({name for _,name in selected}) == len(selected)
archive = REPORT/'validation-raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for file,name in sorted(selected,key=lambda x:x[1]):
        tar.add(file,arcname=name,recursive=False)
manifest = {name:hashlib.sha256(file.read_bytes()).hexdigest() for file,name in selected}
(REPORT/'raw-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(REPORT/'archive-sha256.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(len(selected),'files,',archive.stat().st_size,'compressed bytes')
