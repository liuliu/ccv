"""Record the final tested sources and package verified measurement evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/ccv-m5-attention-r1-parity')
REPORT = ROOT/'doc/benchmarks/m5-attention-r1-parity-2026-10-07'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

expanded = json.loads((OUT/'integration/expanded-tests.json').read_text())
assert len(expanded['records']) == 3
assert all(row['exit_code'] == 0 for row in expanded['records'])
assert expanded['source_sha256'] == digest(ROOT/'test/int/nnc/mpsblas.tests.c')
assert expanded['binary_sha256'] == digest(ROOT/'test/int/nnc/mpsblas.tests')
for name in ['cache-expanded', 'lse-expanded', 'full-dnn-policy']:
    assert 'all test case(s) passed, congratulations!' in (OUT/'integration'/(name+'.log')).read_text()
assert '[126/126]' in (OUT/'integration/full-dnn-policy.log').read_text()
sources = [
    'lib/nnc/mfa/ccv_nnc_mfa_attention.cpp',
    'lib/nnc/mfa/kernels/AttentionR1Descriptor.cpp',
    'lib/nnc/mfa/kernels/AttentionR1Descriptor.hpp',
    'lib/nnc/mfa/kernels/AttentionR1Kernel.cpp',
    'test/int/nnc/mpsblas.tests.c', 'bin/mfa/makefile',
    'bin/mfa/attention_r1_bench.cpp', 'bin/mfa/attention_r1_sweep.py',
    'bin/mfa/attention_r1_shapes.json', 'bin/mfa/attention_r1_thermal.m',
    'bin/mfa/attention_r1_bench.txt',
]
binaries = [OUT/'application', OUT/'policy-application', OUT/'group4-application',
            OUT/'selection-before', OUT/'selection-after',
            ROOT/'bin/mfa/attention_r1_bench', ROOT/'test/int/nnc/mpsblas.tests',
            ROOT/'test/int/nnc/mpsdnn.tests', Path('/private/tmp/ccv-na-int8-integration/mlx-probe')]
provenance = dict(
    base='bd7f3d37890887f1dce06db7c473c0f9ee9fb4a3',
    branch='m5-attention-r1-parity',
    source_sha256={name:digest(ROOT/name) for name in sources},
    binaries={str(path):digest(path) for path in binaries},
    note='final-provenance.json preserves the earlier policy; this file records the final policy and expanded integration tests. No timing outlier is discarded.',
)
(OUT/'completion-provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')
for script in ['audit-final.py', 'write-report.py', 'archive-final.py']:
    result = subprocess.run(['python3', str(OUT/script)], cwd=OUT, capture_output=True, text=True)
    (OUT/(script.removesuffix('.py')+'-completion.log')).write_text(result.stdout+result.stderr)
    assert result.returncode == 0, (script, result.stdout, result.stderr)
    print('Completed', script, flush=True)
manifest = json.loads((REPORT/'raw-sha256.json').read_text())
archive = REPORT/'validation-raw.tar.gz'
assert (REPORT/'archive-sha256.txt').read_text().split()[0] == digest(archive)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(manifest)
    assert {m.name for m in members} == set(manifest)
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == manifest[member.name], member.name
print('Verified', len(manifest), 'archive entries;', archive.stat().st_size, 'bytes', flush=True)
