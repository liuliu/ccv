"""Audit saved complete-operation samples and produce reviewable comparisons."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

OUT = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/ccv-m5-attention-r1-parity')
REPORT = ROOT / 'doc/benchmarks/m5-attention-r1-parity-2026-10-07'
final_meta = json.loads((OUT/'final/metadata.json').read_text())
for directory in ['gqa2-final','outlier-recheck']:
    meta = json.loads((OUT/directory/'metadata.json').read_text())
    assert meta['kernel_sources_sha256'] == final_meta['kernel_sources_sha256']
    assert meta['binaries'] == final_meta['binaries']
for path, expected in final_meta['kernel_sources_sha256'].items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest() == expected, path
cases, records = {}, []
for directory, count in [('final',62),('gqa2-final',6)]:
    run = OUT / directory
    meta = json.loads((run/'metadata.json').read_text())
    batch = [json.loads(line) for line in (run/'records.jsonl').read_text().splitlines()]
    assert len(meta['workloads']) == count and len(batch) == count*3*2
    for case in meta['workloads']:
        assert case['id'] not in cases
        cases[case['id']] = case
    records.extend({**record, '_directory': directory} for record in batch)
assert len(cases) == 68 and len(records) == 408
seen, by_case = set(), {}
for record in records:
    key = record['repeat'], record['id'], record['variant']
    assert key not in seen
    seen.add(key)
    assert record['ok'] and record['exit_code'] == 0
    assert record['thermal_before'] == record['thermal_after'] == '0'
    stem = f"{record['repeat']}-{record['id']}-{record['variant']}"
    output = (OUT / record['_directory'] / (stem + '.log')).read_text()
    assert 'all_finite=1' in output
    match = re.search(r'gpu_samples_ms=([^\s]+)', output)
    samples = list(map(float, match[1].split(',')))
    assert len(samples) == 64 and all(math.isfinite(x) and x > 0 for x in samples)
    by_case.setdefault((record['id'], record['variant']), []).append(statistics.median(samples))
rows = []
for name, case in cases.items():
    r, c, d, b, hq, hk = case['shape']
    times = {}
    for variant in ['fp16', 'previous_fp16', 'mlx']:
        group = by_case[name, variant]
        assert len(group) == 2
        times[variant] = statistics.median(group) * 1000
    current, previous, mlx = [times[key] for key in ['fp16', 'previous_fp16', 'mlx']]
    rows.append(dict(id=name, R=r, C=c, D=d, B=b, Hq=hq, Hkv=hk, causal=case['causal'],
                     current_us=current, previous_candidate_us=previous, mlx_us=mlx,
                     current_over_mlx=current/mlx, current_over_previous=current/previous,
                     mlx_gap_us=current-mlx, previous_gap_us=current-previous,
                     mlx_gap=current > mlx*1.05 and current-mlx > 2,
                     previous_regression=current > previous*1.05 and current-previous > 2,
                     current_pass0_us=by_case[name, 'fp16'][0]*1000,
                     current_pass1_us=by_case[name, 'fp16'][1]*1000))
with (REPORT/'comparison.csv').open('w') as file:
    writer = csv.DictWriter(file, rows[0]); writer.writeheader(); writer.writerows(rows)
num = json.loads((OUT/'numerical-final/summary.json').read_text())
assert num['records'] == 192 and num['failed'] == 0
assert len(num['comparisons']) == 192
extra = json.loads((OUT/'gqa2-numerical/summary.json').read_text())
assert extra['records'] == 12 and extra['failed'] == 0
covered = {(row['id'],row['precision']) for row in num['comparisons']+extra['comparisons']}
manifest = json.loads((ROOT/'bin/mfa/attention_r1_shapes.json').read_text())['workloads']
assert len(manifest) == 102
numerical_shapes = {(*case['shape'],bool(case['causal'])) for case in manifest}
assert all((*case['shape'],bool(case['causal'])) in numerical_shapes for case in cases.values())
assert covered == {(case['id'],precision) for case in manifest for precision in [0,1]}
summary = dict(shapes=len(cases), timed_processes=len(records), samples_per_process=64,
               numerical_processes=num['records']+extra['records'], numerical_failures=num['failed']+extra['failed'],
               mlx_gaps=[row for row in rows if row['mlx_gap']],
               previous_regressions=[row for row in rows if row['previous_regression']],
               geometric_mean_current_over_mlx=math.exp(statistics.mean(math.log(row['current_over_mlx']) for row in rows)))
recheck_records = [json.loads(line) for line in (OUT/'outlier-recheck/records.jsonl').read_text().splitlines()]
assert len(recheck_records) == 18
recheck_times = {}
for record in recheck_records:
    assert record['ok'] and record['exit_code'] == 0
    assert record['thermal_before'] == record['thermal_after'] == '0'
    stem = f"{record['repeat']}-{record['id']}-{record['variant']}"
    output = (OUT/'outlier-recheck'/(stem+'.log')).read_text()
    samples = list(map(float,re.search(r'gpu_samples_ms=([^\s]+)',output)[1].split(',')))
    assert len(samples) == 64 and all(math.isfinite(x) and x>0 for x in samples)
    assert 'all_finite=1' in output
    recheck_times.setdefault(record['variant'],[]).append(statistics.median(samples)*1000)
assert set(recheck_times) == {'fp16','previous_fp16','mlx'}
assert all(len(group)==6 for group in recheck_times.values())
summary['outlier_recheck_process_medians_us'] = recheck_times
summary['groups'] = {}
for label, group in [('R1',[r for r in rows if r['R']==1]),('R2',[r for r in rows if r['R']==2]),('single_batch',[r for r in rows if r['B']==1]),('multiple_batches',[r for r in rows if r['B']>1])]:
    summary['groups'][label] = dict(shapes=len(group), maximum_current_over_mlx=max(r['current_over_mlx'] for r in group), material_mlx_gaps=sum(r['mlx_gap'] for r in group), geometric_mean_current_over_mlx=math.exp(statistics.mean(math.log(r['current_over_mlx']) for r in group)))
(REPORT/'audit.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary,indent=2))
