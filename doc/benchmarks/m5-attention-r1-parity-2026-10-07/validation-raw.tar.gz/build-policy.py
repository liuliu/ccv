import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/ccv-m5-attention-r1-parity')
commands=[['make','-C','lib','lib','DEBUG=1','-j4'],['make','-C','bin/mfa','attention_r1_bench']]
app=json.loads((OUT/'build-probe.json').read_text())['args']
commands.append([str(OUT/'policy-application') if x==str(OUT/'application') else x for x in app])
sel=json.loads((OUT/'build-selection-before.json').read_text())
commands.append([str(OUT/'selection-after') if x==str(OUT/'selection-before') else x for x in sel])
records=[]
with (OUT/'policy-build.log').open('w') as log:
    for args in commands:
        print('BUILD',args[0:6],flush=True)
        result=subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        records.append(dict(args=args,exit_code=result.returncode))
        (OUT/'policy-build.json').write_text(json.dumps(records,indent=2)+'\n')
        if result.returncode: raise SystemExit(result.returncode)
print('Build completed',flush=True)
